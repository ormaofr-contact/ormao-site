---
name: free-tools
description: Lorsque l'utilisateur souhaite planifier, évaluer ou créer un outil gratuit à des fins marketing — génération de leads, valeur SEO ou notoriété de marque. À utiliser également lorsque l'utilisateur mentionne « engineering as marketing », « free tool », « outil gratuit », « outil marketing », « calculateur », « générateur », « outil interactif », « outil de lead gen », « créer un outil pour des leads », « ressource gratuite », « calculateur de ROI », « outil d'évaluation », « outil d'audit », « devrais-je créer un outil gratuit » ou « outils pour la génération de leads ». Utilisez cette compétence dès que quelqu'un souhaite concevoir un outil utile et l'offrir gratuitement pour attirer des leads ou acquérir des liens. Pour les lead magnets sous forme de contenus téléchargeables (ebooks, checklists, templates), consultez lead-magnets.
metadata:
  version: 2.0.3
---

# Stratégie d'outils gratuits (Engineering as Marketing)

Vous êtes un expert en stratégie d'« engineering-as-marketing ». Votre objectif est d'aider à planifier et à évaluer des outils gratuits qui génèrent des leads, attirent du trafic organique et renforcent la notoriété de la marque.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement des informations non traitées ou spécifiques à cette tâche.

Avant d'élaborer une stratégie d'outil, comprenez :

1. **Le contexte commercial** - Quel est le produit principal ? Qui est le public cible ? Quels problèmes rencontre-t-il ?

2. **Les objectifs** - Génération de leads ? SEO/trafic ? Notoriété de la marque ? Éducation produit ?

3. **Les ressources** - Capacité technique de développement ? Bande passante pour la maintenance continue ? Budget pour la promotion ?

---

## Principes fondamentaux

**« Votre produit est mon opportunité marketing. »** Bezos disait : « votre marge est mon opportunité ». La version engineering-as-marketing : prenez une fonctionnalité que d'autres monétisent et concevez-en une version gratuite comme canal d'acquisition. Unsplash a distribué gratuitement les photos de stock que Getty vendait — et Getty l'a racheté. Consultez [references/tool-benchmarks.md](references/tool-benchmarks.md) pour des études de cas sourcées et les limites de mesure.

### 1. Résoudre un vrai problème
- L'outil doit apporter une réelle valeur ajoutée
- Il résout un problème que votre audience rencontre réellement
- Il reste utile même sans votre produit principal

### 2. Être adjacent au produit principal
- En lien avec ce que vous vendez
- Parcours naturel de l'outil vers le produit
- Sensibilise au problème que vous résolvez

### 3. Simple et ciblé
- Fait une seule chose, mais très bien
- Faible friction à l'utilisation
- Valeur immédiate

### 4. Valoir l'investissement
- Valeur d'un lead × nombre de leads attendus > coût de développement + maintenance

---

## Vue d'ensemble des types d'outils

| Type | Exemples | Idéal pour |
|------|----------|------------|
| Calculateurs | ROI, économies, estimateurs de prix | Prises de décision basées sur des chiffres |
| Générateurs | Templates, politiques, noms | Créer quelque chose rapidement |
| Analyseurs | Évaluateurs de sites web, auditeurs SEO | Évaluer un travail existant |
| Outils de test | Prévisualisation des balises méta, tests de vitesse | Vérifier si quelque chose fonctionne |
| Bibliothèques | Packs d'icônes, templates, snippets | Matériel de référence |
| Interactifs | Tutoriels, playgrounds, quiz | Apprendre / comprendre |

**Pour le détail des types d'outils et des exemples** : consultez [references/tool-types.md](references/tool-types.md)

**Pour des exemples de cas sourcés (Unsplash, HubSpot Website Grader, Buffer, Shopify) et les exigences de preuve** : consultez [references/tool-benchmarks.md](references/tool-benchmarks.md)

---

## Cadre d'idéation

### Partir des points de friction

1. **Quels problèmes votre audience recherche-t-elle sur Google ?** - Recherche sur les requêtes de recherche, questions fréquentes

2. **Quels processus manuels sont fastidieux ?** - Tâches sur tableur, calculs répétitifs

3. **De quoi ont-ils besoin avant d'acheter votre produit ?** - Évaluations, planification, comparaisons

4. **Quelles informations aimeraient-ils avoir sous la main ?** - Données difficiles d'accès, benchmarks

### Valider l'idée

- **Demande de recherche** : Existe-t-il un volume de recherche ? Quel est le niveau de concurrence ?
- **Unicité** : Qu'existe-t-il déjà ? Comment être 10 fois meilleur ?
- **Qualité des leads** : Cette audience correspond-elle à vos acheteurs cibles ?
- **Faisabilité de développement** : Quelle complexité ? Pouvez-vous définir le périmètre d'un MVP ?

---

## Stratégie de capture de leads

### Options de gating (verrouillage)

| Approche | Avantages | Inconvénients |
|----------|-----------|---------------|
| Totalement verrouillé (gated) | Capture maximale | Utilisation plus faible |
| Partiellement verrouillé | Équilibre entre les deux | Schéma courant |
| Non verrouillé + optionnel | Portée maximale | Capture plus faible |
| Entièrement ouvert (ungated) | Purement SEO/marque | Aucun lead direct |

### Bonnes pratiques pour la capture de leads
- Échange de valeur clair : « Obtenez votre rapport complet »
- Friction minimale : Email uniquement
- Afficher un aperçu de ce qu'ils vont recevoir
- Optionnel : Segmenter en posant une question de qualification unique

---

## Considérations SEO

### Stratégie de mots-clés
**Page de destination de l'outil** : « calculateur de [sujet] », « générateur de [sujet] », « outil gratuit de [type d'outil] »

**Contenu de soutien** : « Comment [cas d'usage] », « Qu'est-ce que [concept] »

### Link Building
Les outils gratuits attirent des liens parce qu'ils sont :
- Véritablement utiles (les gens les citent en référence)
- Uniques (on ne peut pas créer de lien vers n'importe quelle page classique)
- Partageables (amplification sur les réseaux sociaux)

---

## Développer ou acheter (Build vs. Buy)

### Développer sur mesure
Quand : Concept unique, au cœur de la marque, forte valeur stratégique, capacité de développement disponible

### Utiliser des outils No-Code
Options : Outgrow, Involve.me, Typeform, Tally, Bubble, Webflow
Quand : Vitesse de mise sur le marché, ressources de développement limitées, test de concept

### Intégrer un outil existant (Embed)
Quand : Une bonne solution existe déjà, marque blanche disponible, pas de différenciation stratégique majeure

---

## Périmètre du MVP

### Outil minimum viable
1. Fonctionnalité principale uniquement — accomplit une seule tâche, fonctionne de manière fiable
2. Expérience utilisateur essentielle — saisie claire, résultat évident, fonctionne sur mobile
3. Capture basique de leads — collecte d'adresses email, envoi des leads vers une destination utile

### Ce qu'il faut ignorer au départ
Création de compte, enregistrement des résultats, fonctionnalités avancées, design parfait, traitement de chaque cas particulier

---

## Grille d'évaluation

Notez chaque facteur de 1 à 5 :

| Facteur | Note |
|---------|------|
| Demande de recherche existante | ___ |
| Adéquation de l'audience avec les acheteurs | ___ |
| Unicité par rapport à l'existant | ___ |
| Parcours naturel vers le produit | ___ |
| Faisabilité de développement | ___ |
| Charge de maintenance (inverse : 5 = faible charge) | ___ |
| Potentiel de link-building | ___ |
| Potentiel de partage | ___ |

**25+** : Candidat solide | **15-24** : Prometteur | **<15** : À reconsidérer

---

## Questions spécifiques à la tâche

1. Quels outils existants votre audience utilise-t-elle comme solutions de contournement ?
2. Comment générez-vous actuellement des leads ?
3. Quelles sont les ressources techniques disponibles ?
4. Quels sont les délais et le budget ?

---

## Pièges courants

- **Sur-développement (Over-engineering)** — Lancer un outil trop lourd avant d'avoir validé la demande. Unsplash a commencé sous la forme d'un simple blog Tumblr avec des liens Dropbox, avant d'investir dans un site sur mesure une fois la demande confirmée. Limitez-vous à une seule tâche utile et testez-la auprès de votre audience.
- **Mauvaise intégration au produit** — Un outil sans passerelle naturelle vers votre produit génère du trafic mais pas de pipeline commercial. Les meilleurs exemples mettent en lumière la valeur du produit (un analyseur peut démontrer le problème que votre produit payant résout).
- **Dette de maintenance et de sécurité** — Les outils qui font du scraping, appellent des API ou acceptent des saisies utilisateur se dégradent et deviennent des surfaces d'attaque. Prévoyez un budget d'entretien avant de développer.
- **Métriques de vanité (Vanity metrics)** — Les visiteurs et les volumes d'utilisation sont flatteurs mais ne rapportent rien. Suivez les leads, le taux de qualification et la conversion vers l'essai ou l'inscription — mesurés au sein de votre propre entonnoir.

## Compétences associées

- **lead-magnets** : Pour les lead magnets de contenus téléchargeables (ebooks, checklists, templates)
- **cro** : Pour optimiser la page d'atterrissage de l'outil
- **seo-audit** : Pour l'optimisation SEO de l'outil
- **link-building** : Pour promouvoir l'outil auprès de sites qui créent des liens vers des ressources similaires
- **analytics** : Pour mesurer l'utilisation de l'outil
- **emails** : Pour le nurturing des leads issus de l'outil
