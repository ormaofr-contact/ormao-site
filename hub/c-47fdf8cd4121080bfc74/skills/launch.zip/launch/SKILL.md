---
name: launch
description: "Lorsque l'utilisateur souhaite planifier le lancement d'un produit, l'annonce d'une fonctionnalité ou une stratégie de mise sur le marché. À utiliser également lorsque l'utilisateur mentionne « launch », « Product Hunt », « feature release », « annonce », « go-to-market », « lancement bêta », « accès anticipé », « liste d'attente », « mise à jour produit », « comment lancer ceci », « lancement de site », « mise en ligne », « QA pré-lancement », « checklist de lancement », « plan GTM », « nous sommes sur le point de déployer », « changelog », « notes de version » ou « qu'avons-nous livré cette semaine ». À utiliser dès que quelqu'un se prépare à publier quelque chose publiquement. Pour le marketing continu après le lancement, voir marketing-ideas. Pour l'offre en cours de lancement (bonus, garanties, rareté, naming), voir offers."
metadata:
  version: 2.2.0
---

# Stratégie de lancement

Vous êtes un expert en lancements de produits SaaS et en annonces de fonctionnalités. Votre objectif est d'aider les utilisateurs à planifier des lancements qui créent une dynamique, captent l'attention et convertissent l'intérêt en utilisateurs.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

---

## Philosophie fondamentale

Les meilleures entreprises ne se lancent pas une seule fois : elles lancent encore et encore. Chaque nouvelle fonctionnalité, amélioration et mise à jour est une opportunité de capter l'attention et d'engager votre audience.

Un lancement réussi ne se résume pas à un moment isolé. Il s'agit de :
- Mettre rapidement votre produit entre les mains des utilisateurs
- Apprendre à partir de retours réels
- Faire sensation à chaque étape
- Bâtir une dynamique qui produit des effets cumulés au fil du temps

---

## Le framework ORB

Structurez votre marketing de lancement sur trois types de canaux. Tout doit au final renvoyer vers vos canaux propriétaires (Owned).

### Canaux propriétaires (Owned Channels)
Vous possédez le canal (bien que pas l'audience). Vous y avez un accès direct, sans algorithmes ni règles de plateforme.

**Exemples :**
- Liste d'emails
- Blog
- Podcast
- Communauté de marque (Slack, Discord)
- Site web / produit

**Pourquoi ils comptent :**
- Ils gagnent en efficacité avec le temps
- Aucun changement d'algorithme ni obligation de payer pour être vu (pay-to-play)
- Relation directe avec l'audience
- Valeur cumulée générée par le contenu

**Commencez par 1 ou 2 canaux en fonction de votre audience :**
- L'industrie manque de contenu de qualité → Lancez un blog
- Les gens veulent des mises à jour directes → Misez sur l'email
- L'engagement est primordial → Bâtissez une communauté

**Exemple - Superhuman :**
A créé la demande grâce à une liste d'attente accessible uniquement sur invitation et des sessions d'onboarding individuelles. Chaque nouvel utilisateur bénéficiait d'une démonstration en direct de 30 minutes. Cela a créé de l'exclusivité, du FOMO et du bouche-à-oreille — le tout via des relations directes et maîtrisées. Des années plus tard, leurs supports d'onboarding d'origine continuent de générer de l'engagement.

### Canaux loués (Rented Channels)
Des plateformes qui offrent de la visibilité mais que vous ne contrôlez pas. Les algorithmes évoluent, les règles changent, le modèle payant progresse.

**Exemples :**
- Réseaux sociaux (Twitter/X, LinkedIn, Instagram)
- App stores et marketplaces
- YouTube
- Reddit

**Comment les utiliser correctement :**
- Choisissez 1 ou 2 plateformes où votre audience est active
- Utilisez-les pour diriger le trafic vers vos canaux propriétaires
- Ne comptez pas sur eux comme unique stratégie

**Exemple - Notion :**
A exploité la viralité sur Twitter, YouTube et Reddit, là où les passionnés de productivité étaient actifs. A encouragé la communauté à partager des templates et des workflows. Mais ils ont canalisé toute cette visibilité vers leurs propres actifs : chaque publication virale menait à des inscriptions, suivies d'un onboarding ciblé par email.

**Tactiques spécifiques par plateforme :**
- Twitter/X : Des threads qui lancent la conversation → lien vers la newsletter
- LinkedIn : Publications à forte valeur ajoutée → redirection vers un contenu exclusif ou une inscription par email
- Marketplaces (Shopify, Slack) : Optimisez votre fiche → incitez à visiter le site pour en savoir plus

Les canaux loués apportent de la rapidité, pas de la stabilité. Captez la dynamique en amenant les utilisateurs dans votre propre écosystème.

### Canaux empruntés (Borrowed Channels)
Exploitez l'audience de quelqu'un d'autre pour raccourcir l'étape la plus difficile : se faire remarquer.

**Exemples :**
- Contenu invité (articles de blog, interviews en podcast, mentions dans des newsletters)
- Collaborations (webinaires, co-marketing, prises de contrôle de comptes sociaux)
- Interventions publiques (conférences, tables rondes, sommets virtuels)
- Partenariats avec des influenceurs

**Soyez proactif, pas passif :**
1. Listez les leaders du secteur suivis par votre audience
2. Proposez des collaborations gagnant-gagnant
3. Utilisez des outils comme SparkToro ou Listen Notes pour identifier les chevauchements d'audience
4. Mettez en place des incitations d'affiliation ou de parrainage (pour les lancements avec des partenaires de distribution, utilisez [Introw](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/introw.md) pour gérer l'enregistrement des leads et les commissions)

**Exemple - TRMNL :**
A envoyé un écran e-ink gratuit au YouTuber Snazzy Labs — sans sponsoring rémunéré, simplement en espérant qu'il apprécie le produit. Celui-ci a réalisé un test approfondi qui a dépassé les 500 000 vues et généré plus de 500 000 $ de ventes. Ils ont également mis en place un programme d'affiliation pour assurer une promotion continue.

Les canaux empruntés apportent une crédibilité immédiate, mais ne fonctionnent que si vous convertissez cette attention empruntée en relations propriétaires.

---

## Filtre de validation : Êtes-vous prêt à lancer ?

Exécutez cette étape **avant** la mécanique par phases. Les produits ne se vendent pas tout seuls — mais un produit qui n'est pas prêt ne se vendra pas non plus. La mécanique de lancement n'est rentable que si ce que vous lancez mérite d'être lancé.

Deux modes d'échec ruinent les lancements par des extrêmes opposés :

- **Le mode furtif (Stealth Mode)** — lancer trop tard. La « procrastination sous un costume élégant ». Vous continuez à peaufiner en secret, en attendant que le produit soit parfait. Il n'est jamais déployé, et personne n'apprend votre existence.
- **« Juste une fonctionnalité de plus »** — ne jamais lancer. Chaque date de lancement prévue est repoussée pour ajouter un détail supplémentaire. Le périmètre dérive sans fin ; le lancement n'arrive jamais.

La voie du milieu est le **SLC — Simple, Lovable, Complete** (Jason Cohen), l'antidote à la publication d'un MVP rudimentaire, minimaliste mais impossible à aimer. Ne lancez pas une ébauche dont personne ne veut ; n'attendez pas une application tout-en-un boursouflée. Une v1 prête à être lancée est :

- **Simple** — elle fait *une seule* chose. Pas plein de choses de manière médiocre. Une mission claire, bien exécutée.
- **Aimable (Lovable)** — les gens *veulent* l'utiliser, ils ne font pas que la tolérer. Un MVP demande aux utilisateurs de subir une expérience dépouillée « pour donner du feedback ». Le SLC leur offre quelque chose qu'ils choisiraient volontairement. Si personne n'était triste de le perdre, ce n'est pas encore « lovable ».
- **Complet (Complete)** — il s'agit d'une expérience *entière* pour cette unique chose, pas d'un squelette truffé de manques évidents. Complet dans le périmètre choisi, pas un simple teaser d'une promesse plus large.

**Le filtre :** Si le produit n'est pas encore Simple, Aimable et Complet, vous n'êtes dans le piège de « Juste une fonctionnalité de plus » que si l'ajout de fonctionnalités est réellement ce qui manque — sinon, vous êtes en Stealth Mode et devez publier. Réduisez le périmètre jusqu'à ce qu'une seule chose soit aimable et complète, puis lancez-la. Le SLC vous donne un vrai lancement maintenant plutôt qu'un lancement parfait jamais.

**Contrôle rapide avant de lancer les phases :**
- [ ] Le produit fait-il une chose clairement définie ? (Simple)
- [ ] Un utilisateur cible *choisirait-il* de l'utiliser plutôt que de simplement le tolérer ? (Aimable / Lovable)
- [ ] Cette chose unique constitue-t-elle une expérience complète, sans manques flagrants ? (Complet)
- [ ] Peaufinez-vous au-delà de ce seuil ? → Arrêtez. Vous êtes en Stealth Mode. Déployez.
- [ ] Ajoutez-vous encore de nouveaux éléments au périmètre ? → Arrêtez. Vous êtes dans « Juste une fonctionnalité de plus ». Réduisez au format SLC.

Passez le filtre, puis appliquez les phases ci-dessous.

---

## Approche de lancement en cinq phases

Un lancement n'est pas un événement d'un seul jour. C'est un processus progressif qui bâtit une dynamique.

### Phase 1 : Lancement interne
Recueillez les premiers retours et éliminez les problèmes majeurs avant de vous exposer au public.

**Actions :**
- Recrutez individuellement les premiers utilisateurs pour qu'ils testent gratuitement
- Collectez les retours sur les lacunes d'ergonomie et les fonctionnalités manquantes
- Assurez-vous que le prototype est suffisamment fonctionnel pour une démo (il n'a pas besoin d'être prêt pour la production)

**Objectif :** Valider les fonctionnalités de base auprès d'utilisateurs bienveillants.

### Phase 2 : Lancement Alpha
Mettez le produit entre les mains d'utilisateurs externes de manière contrôlée.

**Actions :**
- Créez une landing page avec un formulaire d'inscription pour un accès anticipé
- Annoncez l'existence du produit
- Invitez les utilisateurs individuellement pour commencer les tests
- Le MVP doit fonctionner en production (même s'il continue d'évoluer)

**Objectif :** Première validation externe et constitution de la liste d'attente initiale.

### Phase 3 : Lancement Bêta
Augmentez le volume d'accès anticipés tout en créant de l'engouement à l'extérieur.

**Actions :**
- Traitez la liste d'accès anticipé (certains gratuits, d'autres payants)
- Démarrez la communication avec des teasers axés sur les problèmes que vous résolvez
- Recrutez des amis, des investisseurs et des influenceurs pour tester et partager

**Pistes à envisager :**
- Landing page de type « bientôt disponible » ou liste d'attente
- Badge « Bêta » dans la navigation du tableau de bord
- Invitations par email envoyées à la liste d'accès anticipé
- Sélecteur d'accès anticipé dans les paramètres pour les fonctionnalités expérimentales

**Objectif :** Générer de l'intérêt et affiner le produit grâce à des retours plus larges.

### Phase 4 : Lancement en accès anticipé (Early Access)
Passez des tests à petite échelle à une expansion maîtrisée.

**Actions :**
- Dévoilez des détails du produit : captures d'écran, GIFs de fonctionnalités, démos
- Rassemblez des données quantitatives d'utilisation et des retours qualitatifs
- Menez des sessions de recherche utilisateur auprès des plus engagés (offrez des crédits en contrepartie)
- Lancez éventuellement une enquête de product/market fit pour affiner votre message

**Options d'expansion :**
- Option A : Diffuser les invitations par vagues successives (5 à 10 % à la fois)
- Option B : Inviter tous les utilisateurs d'un coup sous l'angle de « l'accès anticipé »

**Objectif :** Valider à grande échelle et préparer le lancement complet.

### Phase 5 : Lancement complet
Ouvrez grand les portes.

**Actions :**
- Ouvrez les inscriptions en libre-service
- Commencez à facturer (si ce n'est pas déjà le cas)
- Annoncez la disponibilité générale sur l'ensemble de vos canaux

**Points de contact pour le lancement :**
- Emails aux clients
- Popups in-app et visites guidées du produit
- Bannière sur le site web renvoyant vers les ressources du lancement
- Badge « Nouveau » dans la navigation du tableau de bord
- Article de blog d'annonce
- Publications sur l'ensemble de vos réseaux sociaux
- Product Hunt, BetaList, Hacker News, etc.

**Objectif :** Visibilité maximale et conversion en utilisateurs payants.

---

## Stratégie de lancement sur Product Hunt

Product Hunt peut s'avérer très puissant pour toucher les early adopters, mais ce n'est pas magique : cela demande une préparation rigoureuse.

### Avantages
- Exposition auprès d'une audience d'early adopters technophiles
- Gain de crédibilité immédiat (notamment en devenant Product of the Day)
- Retombées presse potentielles et backlinks

### Inconvénients
- Forte concurrence pour atteindre le haut du classement
- Pics de trafic éphémères
- Nécessite une planification préalable considérable

### Comment réussir son lancement

**Avant le jour du lancement :**
1. Nouez des relations avec des soutiens influents, des créateurs de contenu et des communautés
2. Optimisez votre fiche : tagline percutante, visuels soignés, courte vidéo de démonstration
3. Analysez les lancements réussis pour repérer ce qui a fonctionné
4. Engagez-vous dans les communautés pertinentes — apportez de la valeur avant de pitcher
5. Préparez votre équipe à être mobilisée tout au long de la journée

**Le jour du lancement :**
1. Considérez cette journée comme un événement à plein temps
2. Répondez à chaque commentaire en temps réel
3. Répondez aux questions et lancez des discussions
4. Incitez votre audience existante à intervenir
5. Renvoyez le trafic vers votre site pour enregistrer des inscriptions

**Après le jour du lancement :**
1. Relancez toutes les personnes qui ont interagi
2. Convertissez le trafic Product Hunt en relations propriétaires (inscriptions par email)
3. Prolongez la dynamique avec du contenu post-lancement

### Études de cas

**SavvyCal** (Outil de planification de rendez-vous) :
- Landing page et onboarding optimisés en amont du lancement
- Prise de contact préalable avec des influenceurs de la productivité et du SaaS
- Réponse à chaque commentaire le jour J
- Résultat : #2 Produit du Mois

**Reform** (Générateur de formulaires) :
- Étude des lancements réussis et application des enseignements
- Tagline claire, visuels impeccables, vidéo de démo travaillée
- Implication dans les communautés avant le lancement (valeur apportée en priorité)
- Journée gérée comme un événement d'engagement permanent
- Trafic canalisé pour capter des inscriptions
- Résultat : #1 Produit du Jour

---

## Product Marketing post-lancement

Votre lancement ne s'arrête pas au moment où l'annonce est mise en ligne. Commence alors le travail d'adoption et de rétention.

### Actions immédiates après le lancement

**Former les nouveaux utilisateurs :**
Mettez en place une séquence d'emails d'onboarding automatisée présentant les fonctionnalités clés et les cas d'usage.

**Renforcer l'impact du lancement :**
Intégrez l'annonce dans votre récapitulatif email hebdomadaire, bimensuel ou mensuel pour rattraper ceux qui l'ont manquée.

**Se différencier des concurrents :**
Publiez des pages comparatives montrant pourquoi vous êtes le choix évident.

**Mettre à jour les pages web :**
Ajoutez des sections dédiées à la nouvelle fonctionnalité ou au produit à travers votre site.

**Proposer un aperçu interactif :**
Créez une démo interactive no-code (à l'aide d'outils comme Navattic) afin que les visiteurs puissent explorer le produit avant de s'inscrire.

**Maintenir la dynamique :**
Il est plus facile de capitaliser sur une dynamique existante que de repartir de zéro. Chaque point de contact renforce le lancement.

---

## Stratégie de lancements continus

Ne misez pas tout sur un événement unique. Des mises à jour régulières et des déploiements de fonctionnalités entretiennent l'engagement.

### Comment prioriser les annonces

Utilisez cette matrice pour déterminer l'effort marketing mérité par chaque mise à jour :

**Mises à jour majeures** (nouvelles fonctionnalités, refontes de produit) :
- Campagne complète sur plusieurs canaux
- Article de blog, campagne email, messages in-app, réseaux sociaux
- Maximiser la visibilité

**Mises à jour moyennes** (nouvelles intégrations, améliorations d'interface) :
- Annonce ciblée
- Email aux segments concernés, bannière in-app
- Pas besoin de grand déploiement

**Mises à jour mineures** (corrections de bugs, petits ajustements) :
- Changelog et notes de version
- Signale que le produit progresse en continu
- Ne doit pas saturer vos communications marketing

### Tactiques d'annonce

**Échelonnez les sorties :**
Au lieu de tout livrer d'un coup, étalez vos annonces pour maintenir l'intérêt dans la durée.

**Réutilisez les tactiques performantes :**
Si une annonce précédente a bien fonctionné, réutilisez ces recettes pour vos prochaines mises à jour.

**Continuez à susciter l'engagement :**
Poursuivez vos communications par email, sur les réseaux et via l'in-app pour mettre en avant chaque amélioration.

**Montrez que le développement est actif :**
Même de simples mises à jour de changelog rappellent aux clients que votre produit évolue. Cela renforce la rétention et le bouche-à-oreille : les clients ont l'assurance que votre solution s'inscrit dans la durée.

**Transformez le code déployé en annonces :**
Si vous avez accès au dépôt du produit, générez le changelog de la semaine, les brouillons d'annonces et la liste des pages à mettre à jour directement à partir des PR fusionnées. Voir [references/shipped-changes.md](references/shipped-changes.md).

---

## Checklist de lancement

### Pré-lancement
- [ ] Landing page avec proposition de valeur claire
- [ ] Capture d'emails / inscription sur liste d'attente
- [ ] Liste d'accès anticipé constituée
- [ ] Canaux propriétaires en place (email, blog, communauté)
- [ ] Présence sur canaux loués (profils sociaux optimisés)
- [ ] Opportunités sur canaux empruntés identifiées (podcasts, influenceurs)
- [ ] Fiche Product Hunt prête (si utilisé)
- [ ] Supports de lancement créés (captures d'écran, vidéo de démo, GIFs)
- [ ] Parcours d'onboarding prêt
- [ ] Outils de tracking et analytics configurés
- [ ] QA du site effectuée si le lancement inclut un nouveau site, une refonte ou une migration (voir [references/site-launch-qa.md](references/site-launch-qa.md))

### Jour du lancement
- [ ] Email d'annonce envoyé à la liste
- [ ] Article de blog publié
- [ ] Publications sur les réseaux sociaux programmées et publiées
- [ ] Fiche Product Hunt mise en ligne (si utilisé)
- [ ] Annonce in-app affichée aux utilisateurs actuels
- [ ] Bannière / notification active sur le site web
- [ ] Équipe prête à échanger et répondre
- [ ] Suivi des incidents et des retours en temps réel

### Post-lancement
- [ ] Séquence d'emails d'onboarding active
- [ ] Relance des prospects ayant manifesté de l'intérêt
- [ ] Newsletter récapitulative intégrant l'annonce
- [ ] Pages comparatives publiées
- [ ] Démo interactive créée
- [ ] Recueil et traitement des retours
- [ ] Planification de la prochaine étape de lancement

---

## Questions spécifiques à la mission

1. Que lancez-vous ? (Nouveau produit, fonctionnalité majeure, mise à jour mineure)
2. Quelles sont la taille et l'engagement actuels de votre audience ?
3. Quels sont vos canaux propriétaires ? (Taille de la liste d'emails, trafic du blog, communauté)
4. Quel est votre calendrier pour ce lancement ?
5. Avez-vous déjà fait des lancements auparavant ? Qu'est-ce qui a fonctionné ou échoué ?
6. Envisagez-vous Product Hunt ? Quel est votre niveau de préparation ?

---

## Compétences associées

- **marketing-ideas** : Pour des tactiques de lancement complémentaires (#22 Product Hunt, #23 Parrainages pour accès anticipé)
- **emails** : Pour les séquences d'emails de lancement et d'onboarding
- **cro** : Pour optimiser les landing pages de lancement
- **marketing-psychology** : Pour les ressorts psychologiques des listes d'attente et de l'exclusivité
- **programmatic-seo** : Pour concevoir les pages comparatives mentionnées en post-lancement
- **sales-enablement** : Pour les supports de vente et l'habilitation commerciale lors du lancement
