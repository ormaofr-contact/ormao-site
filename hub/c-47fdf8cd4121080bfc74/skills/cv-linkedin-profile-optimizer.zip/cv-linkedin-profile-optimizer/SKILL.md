---
name: linkedin-profile-optimizer
description: Optimiser le profil LinkedIn pour le référencement, la visibilité auprès des recruteurs et l'engagement
---

# Optimiseur de profil LinkedIn

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Optimiser son profil LinkedIn pour sa recherche d'emploi
- Améliorer sa visibilité et son référencement sur LinkedIn
- Synchroniser son CV avec son profil LinkedIn
- Attirer des recruteurs et des opportunités professionnelles
- Mentionne : « LinkedIn », « profil LinkedIn », « optimiser LinkedIn », « titre LinkedIn », « recruteur »

## Capacités principales

- Optimiser le titre professionnel (headline) pour les recherches
- Rédiger une section Infos/Résumé percutante
- Structurer la section Expérience pour un impact maximal
- Améliorer le score d'exhaustivité du profil
- Ajouter des mots-clés pertinents pour les recherches des recruteurs
- Aligner LinkedIn avec le CV tout en tirant parti des spécificités de la plateforme

## LinkedIn vs CV : Différences clés

| Aspect | CV | LinkedIn |
|--------|----|----------|
| Longueur | 1 à 2 pages | Illimitée |
| Ton | Formel | Plus conversationnel |
| Mots-clés | Spécifiques au poste visé | À l'échelle de l'industrie |
| Public | Un employeur précis | Tous les recruteurs |
| Mises à jour | À chaque candidature | Toujours à jour |
| Personnalité | Minimale | Plus marquée |

## Optimisation des sections du profil

### 1. Photo de profil

**Exigences :**
- Portrait professionnel (pas de photo décontractée)
- Le visage occupe 60 % du cadre
- Arrière-plan neutre ou en lien avec la marque
- Bon éclairage, haute résolution
- Tenue vestimentaire appropriée à votre secteur
- Expression chaleureuse (léger sourire)

**Impact :** Les profils avec photo obtiennent 21 fois plus de vues

### 2. Bannière d'arrière-plan

**Bonnes pratiques :**
- Utilisez un visuel professionnel ou une image liée à votre secteur
- Peut inclure des éléments d'image de marque personnelle (personal branding)
- Dimensions : 1584 x 396 pixels
- Évitez les motifs trop chargés qui détournent l'attention de votre photo

**Options :**
- Marque de l'entreprise (si approprié)
- Imagerie liée au secteur d'activité
- Design abstrait et professionnel
- Énoncé de positionnement personnel

### 3. Titre professionnel (Le plus important pour le référencement)

**Limite de caractères :** 220 caractères

**Formule :** [Poste] | [Expertise clé] | [Proposition de valeur]

**Exemples :**

❌ **Titres faibles :**
- « À l'écoute de nouvelles opportunités »
- « Product Manager en recherche d'emploi »
- « Étudiant à l'Université »
- « Open to work »

✅ **Titres percutants :**
```
Senior Product Manager | B2B SaaS | Driving 0→1 Products from Concept to $10M ARR

Data Scientist | Machine Learning & Analytics | Turning Data into Business Decisions

Software Engineer | Python, AWS, Kubernetes | Building Scalable Systems at Fortune 500

Marketing Director | Growth & Brand Strategy | 3x Revenue Growth at Series B Startups
```

**Stratégie de mots-clés :**
Intégrez les termes recherchés par les recruteurs :
- L'intitulé de votre poste (et ses variantes)
- Compétences clés (langages, outils, méthodologies)
- Termes sectoriels
- Certifications

### 4. Section Infos (Résumé)

**Limite de caractères :** 2 600 caractères
**Longueur recommandée :** 1 500 à 2 000 caractères (3 à 5 paragraphes)

**Structure :**

```
[ACCROCHE - Première ligne captivante visible dans l'aperçu]

[PARAGRAPHE 1 : Qui vous êtes et ce que vous faites]

[PARAGRAPHE 2 : Vos réalisations clés et spécialités]

[PARAGRAPHE 3 : Ce que vous recherchez ou ce qui vous passionne]

[LISTE DE COMPÉTENCES : Compétences clés, mots-clés recherchables]

[APPEL À L'ACTION : Comment vous contacter]
```

**Exemple :**

```
I help SaaS companies turn product ideas into revenue.

For the past 8 years, I've been building products that people actually want to use. From a payments platform that processed $50M monthly to a developer tool used by 100K+ engineers, I've led cross-functional teams from idea to launch and beyond.

What I do best:
→ Transform ambiguous customer problems into clear product roadmaps
→ Build and lead high-performing product teams
→ Drive growth through data-informed decision making
→ Bridge technical and business stakeholders

Currently, I'm a Senior Product Manager at [Company], where I lead our API platform serving 500+ enterprise customers. Previously, I led product at [Previous Company] through their Series B and 10x growth.

Key skills: Product Strategy, Roadmap Planning, Agile/Scrum, User Research, A/B Testing, SQL, Data Analysis, Stakeholder Management, B2B SaaS, API Products

Let's connect! I'm always happy to chat about product, SaaS, or career advice for aspiring PMs. Reach me at [email].
```

**La première ligne est cruciale :**
Seuls ~300 caractères s'affichent avant le bouton « Voir plus » : faites en sorte qu'ils marquent les esprits !

### 5. Section Expérience

**Différences clés avec le CV :**
- Peut être plus longue et plus détaillée
- Doit inclure des médias (présentations, liens)
- Peut laisser transparaître votre personnalité
- À mettre à jour régulièrement (pas seulement en période de recherche d'emploi)

**Pour chaque poste, inclure :**
- Intitulé de poste clair
- Entreprise (avec logo associé)
- Période d'activité
- Localisation
- Description (2 à 3 phrases sur le rôle)
- 4 à 6 points à puces avec réalisations chiffrées
- Pièces jointes multimédias si disponibles

**Exemple :**

```
Senior Product Manager
TechCorp Inc. · Full-time
Jan 2021 - Present · 3 yrs 1 mo
San Francisco, CA · Hybrid

Leading product strategy for TechCorp's API Platform, serving 500+ enterprise customers and generating $20M ARR.

• Grew platform revenue from $5M to $20M ARR by launching 3 new product lines and expanding into enterprise segment
• Led cross-functional team of 15 (engineering, design, data) to deliver 25+ features with 95% on-time delivery rate  
• Improved customer retention from 82% to 94% through proactive feature development based on usage analytics
• Established product analytics framework using Amplitude, increasing feature adoption by 40%
• Collaborated with sales team to close 50+ enterprise deals worth $10M+ by participating in technical sales calls

Skills: Product Management · B2B SaaS · API Design · Agile Methodology · Stakeholder Management
```

### 6. Section Compétences

**Stratégie :**
- Listez jusqu'à 50 compétences (utilisez les 50 !)
- Triez par pertinence et recommandations
- Obtenez des recommandations sur vos compétences clés
- Incluez à la fois des compétences techniques (hard skills) et relationnelles (soft skills)

**Catégories à inclure :**
- Compétences spécifiques au poste (Product Management, Data Analysis)
- Outils (JIRA, Salesforce, Python)
- Méthodologies (Agile, Six Sigma)
- Compétences comportementales (Leadership, Communication)
- Termes sectoriels (B2B, SaaS, Enterprise)

**Top 3 des compétences mises en avant :**
Choisissez vos trois compétences les plus importantes et les plus recommandées

### 7. Section Sélection (Featured)

**À utiliser pour :**
- Éléments de portfolio
- Articles publiés
- Présentations
- Retombées presse / médias
- Publications majeures
- Projets phares

**Pourquoi c'est important :**
Occupe une place prépondérante sur le profil : mettez en valeur vos meilleures réalisations

### 8. Recommandations

**Objectif :** 5 à 10 recommandations de qualité

**Meilleures sources :**
- Anciens managers
- Collaborateurs directs
- Partenaires interfonctionnels
- Clients

**Comment les obtenir :**
1. Rédigez d'abord des recommandations pour d'autres
2. Sollicitez directement des personnes précises
3. Facilitez-leur la tâche : suggérez des points à aborder
4. Choisissez le bon moment (après la réussite d'un projet)

## Optimisation des mots-clés

### Trouver des mots-clés
1. Analysez les offres d'emploi pour le poste visé
2. Examinez les profils de personnes occupant les postes convoités
3. Utilisez les suggestions de la section Compétences de LinkedIn
4. Consultez les publications du secteur pour repérer la terminologie actuelle

### Emplacement des mots-clés
Placez les mots-clés dans :
- Le titre professionnel (poids le plus élevé)
- La section Infos (plusieurs fois de manière naturelle)
- Les descriptions d'expériences
- La section Compétences
- Les recommandations (invitez vos contacts à les mentionner)

### Conseils pour l'algorithme de recherche
- Les correspondances exactes comptent (utilisez des expressions exactes)
- La densité des mots-clés aide (répétez les termes majeurs)
- L'activité récente renforce la visibilité
- Les profils complets sont mieux classés
- L'engagement élargit votre portée

## Liste de vérification de l'exhaustivité du profil

**Exigences du profil « Expert absolu » (All-Star) :**
- ✅ Photo professionnelle
- ✅ Titre professionnel personnalisé (pas seulement l'intitulé du poste)
- ✅ Poste actuel avec description
- ✅ Deux postes antérieurs
- ✅ Formation
- ✅ Au moins 5 compétences
- ✅ Secteur d'activité et code postal
- ✅ Plus de 50 relations

**Au-delà de l'Expert absolu :**
- ✅ Bannière d'arrière-plan personnalisée
- ✅ Section Sélection renseignée
- ✅ Section Infos (1 500+ caractères)
- ✅ Médias riches dans la section Expérience
- ✅ Plus de 500 relations
- ✅ Recommandations (5+)
- ✅ Les 50 compétences renseignées
- ✅ Expérience de bénévolat
- ✅ Certifications

## Paramètres de visibilité pour les recruteurs

### Fonctionnalité « À l'écoute de nouvelles opportunités » (Open to Work)
**Paramètres à configurer :**
- Intitulés de postes qui vous intéressent
- Préférences géographiques
- Date de début
- Types d'emploi (temps plein, contrat, etc.)

**Options de visibilité :**
- Tous les membres de LinkedIn (affiche le badge vert)
- Recruteurs uniquement (masqué, plus discret)

### Visibilité du profil
Assurez-vous que ces options sont ACTIVÉES :
- Options d'affichage du profil : Afficher le profil complet
- Partage des modifications du profil : À votre convenance
- Présence dans LinkedIn Services : ACTIVÉ (si pertinent)

## Stratégie de contenu

### Pourquoi publier du contenu ?
- Augmente la visibilité du profil
- Démontre votre expertise
- Développe votre image de marque personnelle
- Attire les opportunités

### Types de contenu :
1. Analyses/avis sur le secteur
2. Retours d'expérience et leçons professionnelles
3. Étapes clés de votre carrière
4. Ressources utiles
5. Interactions avec les publications d'autres membres

### Fréquence de publication :
- Minimum : 1 fois par semaine
- Optimale : 3 à 5 fois par semaine
- Commentaires/interactions : Quotidiennement

## Format de restitution

Lors de l'optimisation d'un profil LinkedIn :

```markdown
# OPTIMISATION DU PROFIL LINKEDIN

## Évaluation du profil actuel
**Exhaustivité :** X %
**Score de référencement :** X/10
**Points clés à améliorer :** [Liste]

## Sections optimisées

### Titre professionnel (Headline)
**Actuel :** [Leur titre actuel]
**Optimisé :** [Nouveau titre intégrant les mots-clés]

### Section Infos (About)
[Texte complet et optimisé de la section Infos]

### Améliorations de l'Expérience
**[Nom de l'entreprise]**
- À ajouter : [Ajouts suggérés]
- À modifier : [Modifications suggérées]
- Médias à intégrer : [Suggestions]

### Compétences à ajouter
[Liste des compétences à ajouter en lien avec les postes visés]

### Mots-clés intégrés
[Liste des mots-clés intégrés sur l'ensemble du profil]

## Plan d'action
1. [ ] Mettre à jour le titre professionnel
2. [ ] Réécrire la section Infos
3. [ ] Mettre à jour la description du poste actuel
4. [ ] Ajouter X compétences
5. [ ] Solliciter X recommandations
6. [ ] Ajouter du contenu dans la section Sélection
7. [ ] Télécharger une photo professionnelle
```

## Synchronisation CV vers LinkedIn

### Ce qu'il faut garder à l'identique :
- Réalisations principales et indicateurs chiffrés
- Intitulés de postes et dates
- Compétences clés et qualifications
- Trame générale de votre parcours

### Ce qu'il faut enrichir :
- Davantage de détails dans les descriptions
- Contexte supplémentaire
- Davantage de points à puces par poste
- Personnalité et tonalité propre

### Ce qu'il faut adapter :
- Le ton (plus conversationnel)
- La longueur (peut être plus longue)
- Les mots-clés (plus larges que ceux d'une offre d'emploi ciblée)
- L'appel à l'action (ajouter vos coordonnées)
