---
name: founder-pricing
description: >-
  Trouve le prix que les acheteurs paieront réellement. Analyse les quatre réponses de prix par acheteur du panel consommateur dans une fourchette de sensibilité au prix de Van Westendorp (trop bon marché, une bonne affaire, commence à être cher, trop cher), la confronte aux tarifs réels des concurrents et à la marge exigée par le DAF, puis recommande un prix, une échelle tarifaire (bon / mieux / meilleur) et une offre de lancement à tester. À utiliser lorsque l'utilisateur demande « combien devrais-je facturer », « fixe le prix de ceci », « est-ce que X $ est trop cher », « stratégie de prix », « quel prix », ou après le panel consommateur.
argument-hint: "[prix actuel]"
---

# founder-pricing

Le prix est le levier le plus rapide sur la marge et celui sur lequel les fondateurs font le plus de suppositions au hasard. Cette compétence le définit à partir de trois éléments vérifiables : ce que les acheteurs ont dit, ce que les concurrents facturent, et ce que l'entreprise doit gagner.

Outil dans ce dossier :

```bash
python3 "${CLAUDE_SKILL_DIR}/van_westendorp.py" founder/panel/answers --price 6.50 --out founder/pricing-curve.md
```

## Étape 1 : ce que les acheteurs ont dit

Si `/founder-consumer` a été exécuté, chaque acheteur a répondu à quatre questions de prix. Exécutez l'outil sur `founder/panel/answers` (ou un CSV contenant les colonnes `too_cheap, cheap, expensive, too_expensive` issues de vraies enquêtes, qui sont toujours préférables aux réponses simulées). Il indique :

| point | signification |
| --- | --- |
| PMC | en dessous de ce seuil, trop de gens pensent que c'est trop bon marché pour être de qualité |
| OPP | le prix présentant le moins de résistance dans un sens comme dans l'autre |
| IPP | le point où autant de personnes considèrent que c'est une bonne affaire que de personnes le jugent cher |
| PME | au-dessus de ce seuil, trop de personnes n'achèteront pas du tout |

L'intervalle de PMC à PME constitue la fourchette acceptable. Si le panel n'a pas été exécuté, signalez-le et proposez d'exécuter d'abord `/founder-consumer --quick`. N'inventez pas de fourchette.

## Étape 2 : ce que les concurrents facturent

Depuis `founder/competitors.md` (ou cherchez-les maintenant, depuis leurs propres pages tarifaires publiques, avec des liens) : le prix des substituts les plus proches pour le même usage. Notez ce que chaque prix inclut, afin de comparer ce qui est comparable. Un matcha latte est comparé à d'autres matcha lattes et au café qu'il remplace, pas à un sachet de thé.

## Étape 3 : ce dont l'entreprise a besoin

Depuis `founder/numbers.json` : le coût variable par unité et le seuil de rentabilité. Exécutez l'outil du DAF à deux ou trois prix candidats pour voir la marge et le seuil de rentabilité pour chacun :

```bash
python3 "${CLAUDE_SKILL_DIR}/../founder-cfo/unit_economics.py" founder/numbers.json --price 7.00
```

## Étape 4 : décider

Rédigez `founder/pricing.md` :

1. **Le prix**, et pourquoi : où il se situe dans la fourchette acceptable, par rapport aux concurrents, et la marge qu'il dégage (issue de l'outil, pas d'une estimation au hasard).
2. **L'échelle tarifaire**, si l'entreprise peut en avoir une : une offre bon / mieux / meilleur (taille, pack, abonnement, adhésion) avec une raison de monter chaque échelon.
3. **L'offre de lancement** : un prix d'introduction ou un bonus pour le lancement qui n'habitue pas les acheteurs à attendre des réductions, avec une date de fin.
4. **Ce qu'il faut tester avec de vrais acheteurs** : deux prix situés dans la fourchette et la manière de les tester (deux pages d'atterrissage, une prévente à chaque tarif, un test A/B sur le tableau des menus).
5. Les objections de prix textuelles du panel (les trois principales), afin que le marketing puisse y répondre.

## Règles

- Les réponses de prix provenant d'acheteurs simulés servent à choisir ce qu'il faut tester. Elles ne constituent pas une preuve.
- Ne fixez jamais un prix inférieur au coût variable pour « acheter » des clients sans le préciser explicitement, ni sans indiquer combien de temps le DAF estime que l'entreprise peut se le permettre.
- Pas de faux prix d'ancrage : pas de prix « au lieu de X $ » qui n'a jamais été réellement facturé.

## Résultat

`founder/pricing-curve.md`, `founder/pricing.md`. Si le prix a changé, mettez à jour `founder/numbers.json` et réexécutez `/founder-cfo`. Ensuite : `/founder-offer`.
