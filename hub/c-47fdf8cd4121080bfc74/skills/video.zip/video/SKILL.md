---
name: video
description: >-
  Lorsque l'utilisateur souhaite créer, générer ou produire du contenu vidéo à l'aide
  d'outils d'IA ou de frameworks programmatiques. À utiliser également lorsque l'utilisateur
  mentionne « production vidéo », « vidéo IA », « Remotion », « Hyperframes », « HeyGen », «
  Synthesia », « Veo », « Sora », « Runway », « Kling », « Seedance », « Hailuo », « MiniMax
  », « Pika », « Hunyuan », « Wan », « génération vidéo », « avatar IA », « vidéo face
  caméra », « vidéo programmatique », « template vidéo », « vidéo explicative », « démo
  produit vidéo », « enregistrer une démo produit », « vidéo de démonstration de
  fonctionnalité », « démo in-app », « pipeline vidéo », « copier ce montage », « reproduire
  ce style vidéo », « faire du reverse-engineering sur cette vidéo », « monter comme cette
  référence » ou « fais-moi une vidéo ». Utilisez ceci pour les flux de création, de
  génération et de production vidéo. Pour les créations publicitaires vidéo payantes,
  consultez ad-creative.
metadata:
  version: 2.2.1
---

# Vidéo

Vous êtes un producteur vidéo expert qui aide à créer des vidéos marketing à l'aide de modèles de génération par IA, d'avatars IA et de frameworks vidéo programmatiques. Votre objectif est d'aider les utilisateurs à produire efficacement du contenu vidéo professionnel — des démonstrations de produits et vidéos explicatives aux clips pour les réseaux sociaux et publicités.

## Avant de commencer

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y sont pas déjà traitées ou qui sont spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Objectif de la vidéo
- Quel type de vidéo ? (Démo produit, explicative, témoignage, clip pour les réseaux sociaux, publicité, tutoriel)
- Quelle est la plateforme cible ? (YouTube, TikTok/Reels/Shorts, site web, publicités, présentation commerciale)
- Quelle est la durée souhaitée ?

### 2. Approche de production
- Avez-vous besoin d'un présentateur humain ? (Avatar IA vs voix off vs enregistrement d'écran)
- Disposez-vous de séquences ou d'éléments existants ? (Captures d'écran, logos, interface produit)
- Avez-vous besoin de séquences générées ? (Scènes générées par IA, plans de coupe/B-roll)
- S'agit-il d'une vidéo unique ou d'un template destiné à être réutilisé ?

### 3. Contexte technique
- Quelle est votre stack technique ? (Node.js, Python, etc.)
- Disposez-vous de clés API pour des outils vidéo ?
- Contraintes budgétaires ? (Certains outils facturent à la minute de vidéo)

---

## Choisir votre approche

Choisissez le bon outil pour la tâche :

| Approche | Idéal pour | Outils | Quand l'utiliser |
|----------|------------|--------|------------------|
| **Programmatique** | Vidéos basées sur des templates, des données, génération par lots | Remotion, Hyperframes | Mises à jour produit, vidéos personnalisées, contenu récurrent |
| **Génération IA** | Séquences originales créées à partir de prompts texte/image | Veo 3, Runway, Kling, Seedance | B-roll, plans phares, visuels créatifs impossibles à filmer |
| **Avatars IA** | Présentateur face caméra sans tournage | HeyGen, Synthesia | Vidéos explicatives, tutoriels, contenu multilingue |
| **Montage / Recyclage** | Découpage de formats longs en clips courts | Descript, Opus Clip, CapCut | Podcast/webinaire → clips pour réseaux sociaux |

---

## Vidéo programmatique

Créez des vidéos avec du code. Idéal pour les vidéos reproductibles, basées sur des templates ou pilotées par la donnée à grande échelle.

### Hyperframes (HTML/CSS — recommandé pour les agents)

Open-source, licence Apache 2.0, développé par HeyGen. Utilise du HTML/CSS/JS standard — aucun DSL de framework à apprendre. Natif pour les LLM : les modèles d'IA génèrent un meilleur code HTML que des composants React.

```bash
npx hyperframes init my-video && cd my-video
npx hyperframes preview               # aperçu en direct
npx hyperframes render -o output.mp4  # rendu de index.html
```

**Concept clé :** Une composition est un fichier HTML unique. L'élément racine définit la zone d'affichage et la durée (`data-composition-id`, `data-duration`, `data-width`, `data-height`), chaque élément à l'écran est un clip (`class="clip"` avec `data-start`, `data-duration`, `data-track-index`), et une timeline GSAP en pause enregistrée dans `window.__timelines` pilote l'animation. Le package `hyperframes` est utilisable uniquement en CLI ; pour effectuer le rendu via du code, utilisez `@hyperframes/producer` (`createRenderJob` + `executeRenderJob`). Syntaxe complète et exemple fonctionnel : [guide d'intégration Hyperframes](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/hyperframes.md).

**Idéal pour :** Annonces de produits, changelogs, rapports basés sur des données, vidéos de prospection personnalisées.

**Pourquoi les agents le préfèrent :** Le HTML/CSS standard signifie que n'importe quel agent de code peut rédiger une composition sans avoir à apprendre un framework. Rendu déterministe — une même entrée produit toujours une sortie identique.

### Remotion (React)

Framework open-source mature. Plus puissant qu'Hyperframes, mais nécessite des connaissances en React.

```bash
npx create-video@latest
```

**Concept clé :** Les composants React représentent les images (frames). Les props pilotent le contenu. Rendu en local ou via Remotion Lambda (AWS) pour monter en charge.

```tsx
export const ProductDemo: React.FC<{ title: string; features: string[] }> = ({
  title, features
}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "#000", color: "#fff" }}>
      <h1>{title}</h1>
      {features.map((f, i) => (
        <Sequence from={i * 30} key={i}>
          <p>{f}</p>
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
```

**Idéal pour :** Animations complexes, aperçus interactifs, rendu par lots à grande échelle (Lambda).

### Comment choisir entre les deux

| Facteur | Hyperframes | Remotion |
|---------|-------------|----------|
| Compatibilité avec les agents | Meilleure (HTML standard) | Bonne (React) |
| Complexité des animations | Timelines GSAP (plus CSS) | Avancée (Spring, interpolate) |
| Rendu par lots | Local | Lambda (AWS) pour l'échelle |
| Courbe d'apprentissage | Minimale | Modérée (React + API Remotion) |
| Licence | Apache 2.0 | Licence commerciale requise pour les entreprises |

---

## Génération vidéo par IA

Générez des séquences originales à partir de prompts textuels ou d'images. À utiliser pour les plans de coupe (B-roll), les visuels d'accroche et les scènes impossibles à filmer concrètement.

### Comparatif des modèles

| Modèle | Résolution | Durée max | Idéal pour | Coût |
|--------|------------|-----------|------------|------|
| **Veo 3** (Google) | Jusqu'à 1080p (4K variable) | Variable | Meilleure qualité globale, audio synchronisé | À l'API |
| **Runway Gen-4** | Jusqu'à 4K | ~10 sec/gén | Contrôle du mouvement, cohérence temporelle, flux axés montage | 12-76 $/mois |
| **Kling 2.5/3.0** (Kuaishou) | Jusqu'à 1080p | Jusqu'à 2 min | Génération de plans-séquences longs, coût par seconde réduit | ~0,03 $/sec |
| **Seedance** (ByteDance) | Jusqu'à 1080p | Clips courts | Génération rapide, grande fidélité de mouvement à faible coût, adapté aux lots | Par crédit |
| **Hailuo / MiniMax** | Jusqu'à 1080p | Clips courts | Cohérence des personnages d'un plan à l'autre | Par crédit |
| **Pika 2.x** | 1080p | Clips courts | Effets rapides, image-to-video, prise en main facile | Par crédit |
| **Hunyuan Video / Wan 2** | 720p–1080p | Variable | Open-source auto-hébergé ; contrôle total, pas de frais d'API | Gratuit (GPU) |

**Sélection rapide** :
- **Qualité maximale + audio** : Veo 3
- **Génération par lots / volume / coût** : Kling, Seedance
- **Cohérence des personnages sur plusieurs plans** : Hailuo
- **Auto-hébergé, contrôlé par la marque** : Hunyuan Video ou Wan 2 (poids ouverts)
- **Workflow Storyboard → vidéo** : Runway, LTX Studio
- **Image-to-video à partir d'une image fixe existante** : Kling, Pika, Runway

### Rédiger des prompts pour les modèles vidéo

Les bons prompts vidéo précisent : **sujet + action + caméra + style + ambiance**

```
A close-up shot of hands typing on a laptop keyboard,
shallow depth of field, warm office lighting,
camera slowly pulls back to reveal a modern workspace,
cinematic color grading, 4K
```

**Erreurs fréquentes :**
- Trop vague (« une personne qui travaille ») — ajoutez des précisions
- Oublier le mouvement de caméra — précisez travelling (dolly), panoramique (pan), plan fixe
- Oublier le style — « cinématique », « documentaire », « publicitaire »
- Demander du texte dans la vidéo — les modèles d'IA ont du mal à générer du texte lisible

**Pour des guides de prompting détaillés** : voir [references/ai-video-prompting.md](references/ai-video-prompting.md)

### Quand utiliser la génération par IA plutôt que des banques de vidéos (stock)

| Cas d'usage | Génération par IA | Banque de vidéos |
|-------------|:---:|:---:|
| Scène exacte que vous avez imaginée | Oui | Correspond rarement |
| Style cohérent entre les clips | Oui | Difficile à assortir |
| Lieux réels reconnaissables | Non (hallucinations) | Oui |
| Produits/marques spécifiques | Non (utiliser le programmatique) | Non |
| B-roll rapide | Les deux fonctionnent | Plus rapide |

---

## Avatars IA

Créez des vidéos face caméra sans tournage. Un avatar IA récite votre script avec une synchronisation labiale, des expressions et des gestes réalistes.

### HeyGen (recommandé — dispose d'un serveur MCP)

Meilleure synchronisation labiale et micro-expressions. Plus de 230 avatars, plus de 140 langues.

**Intégration d'agents :** HeyGen propose un serveur MCP officiel — les agents IA peuvent générer des vidéos d'avatars directement.

| Forfait | Vidéos | Durée |
|---------|--------|-------|
| Gratuit | 3/mois | 3 min max |
| Creator | Illimité | 5 min |
| Business | Illimité | 20 min |

Consultez [heygen.com/pricing](https://www.heygen.com/pricing) pour les tarifs actuels.

**Idéal pour :** Vidéos explicatives de produits, annonces de fonctionnalités, prospection commerciale personnalisée, contenu multilingue.

**Avatars personnalisés :** Téléversez une vidéo de vous-même de 2 à 5 minutes pour créer un clone numérique. Il reproduit votre apparence et votre voix, et génère des vidéos à partir de scripts textuels.

### Synthesia

Avatars plein corps avec un langage corporel expressif. Génération intégrée de scripts à partir d'URL ou de documents.

**Idéal pour :** Formations en entreprise, vidéos de conformité, présentations corporate où le ton professionnel prime sur le photoréalisme.

### Quand utiliser des avatars plutôt que d'autres approches

| Scénario | Utiliser un avatar | Utiliser une alternative |
|----------|:---:|--------------------------|
| Contenu récurrent (mises à jour hebdomadaires) | Oui | — |
| Versions multilingues | Oui | — |
| Prospection personnalisée à grande échelle | Oui | — |
| Contenu authentique incarné par le fondateur | Non | Filmez-vous |
| Démonstration pas à pas de l'interface produit | Non | Enregistrement d'écran |
| Vidéo créative/artistique | Non | Génération par IA |

---

## Outils de montage et de recyclage de contenu

Transformez vos contenus existants en de multiples formats vidéo.

| Outil | Fonction | Idéal pour |
|-------|----------|------------|
| **Descript** | Montage basé sur la transcription — modifiez la vidéo en éditant le texte | Nettoyage d'interviews, podcasts, webinaires |
| **Opus Clip** | Découpe automatique de vidéos longues, évaluation du potentiel viral | Formats longs → formats courts à grande échelle |
| **CapCut** | Effets visuels, sous-titres, styles adaptés aux plateformes | Finition et polish pour TikTok/Reels |
| **Captions.ai** | Sous-titres automatiques, correction du contact visuel, doublage par IA | Contenu solo face caméra |

### Workflow de recyclage de contenu

```
Contenu long (podcast, webinaire, démo)
    ↓
Descript : Nettoyer, supprimer les hésitations, peaufiner
    ↓
Opus Clip : Extraire automatiquement les 5 à 10 meilleurs moments
    ↓
CapCut : Ajouter des sous-titres, des effets, adapter aux codes de la plateforme
    ↓
Distribuer : TikTok, Reels, Shorts, LinkedIn
```

### Rétro-ingénierie d'un montage viral

Pour reproduire le *style* d'un montage vidéo qui vous inspire — le rythme des coupes, le traitement des sous-titres, les zooms percutants (punch-ins), le texte à l'écran, le design sonore — décomposez-le en une **spécification de montage** réutilisable (une beat sheet) et appliquez-la à vos propres séquences. Récupérez la référence avec **watch-video** (le mode visuel/multimodal extrait les images aux points de coupe) ou **social-fetch**, extrayez l'anatomie du montage plan par plan, et générez un tableau par temps fort ainsi que les 3 à 5 éléments signatures qui rendent le montage identifiable. Examinez la beat sheet une fois avant de l'exécuter (dans Remotion/Hyperframes, CapCut ou un outil de restylage IA). L'objectif est de reproduire la grammaire du montage, jamais les séquences, le script ou la musique de référence. Méthode complète : [references/edit-anatomy.md](references/edit-anatomy.md).

---

## Flux de travail de production vidéo

### Vidéo de démonstration produit

1. **Rédigez le script** des fonctionnalités clés et des propositions de valeur (utilisez la compétence de copywriting)
2. **Enregistrez l'écran** montrant le parcours dans le produit
3. **Incrustation programmatique** — utilisez Hyperframes/Remotion pour les titres, annotations et transitions
4. **B-roll IA** — générez des plans d'ensemble ou des scènes de mise en situation avec Veo/Runway
5. **Voix off** — enregistrez votre propre voix ou utilisez un avatar IA pour la narration
6. **Exportez** selon les spécifications adaptées à la plateforme

**Enregistrement in-app scripté :** pour une démo reproductible d'un parcours dans une application web (réenregistrée à chaque version, exécutée sur un build local), pilotez l'application avec Playwright et ajoutez des sous-titres, un curseur visible et une narration TTS facultative. Consultez [references/product-demo-recording.md](references/product-demo-recording.md) pour découvrir le flux de travail, les modes d'étapes et les pièges liés aux applications locales.

### Vidéo explicative

1. **Rédigez le script** selon l'arc narratif : problème → solution → CTA
2. **Choisissez le présentateur** — avatar IA (HeyGen) ou voix off + visuels
3. **Concevez les visuels** — diapositives programmatiques, enregistrements d'écran, scènes générées par IA
4. **Ajoutez des sous-titres** — systématiquement, pour l'accessibilité et l'engagement
5. **Exportez** — format paysage pour YouTube/site web, format vertical pour les réseaux sociaux

### Lots de clips pour les réseaux sociaux

1. **Créez un template maître** dans Hyperframes/Remotion
2. **Injectez les données** — fonctionnalités produit, témoignages, statistiques
3. **Générez le lot** — un seul template, de multiples variations
4. **Ajoutez des sous-titres adaptés à chaque plateforme** via CapCut ou Captions.ai
5. **Planifiez la diffusion** sur les différentes plateformes

---

## Pipeline vidéo natif pour agents

La configuration la plus performante combine des outils que les agents peuvent piloter directement :

```
L'agent rédige le script (à partir du contexte produit)
    ↓
Hyperframes : Génère la vidéo basée sur un template (HTML → MP4)
    et/ou
HeyGen MCP : Génère la vidéo avec avatar à partir du script
    et/ou
API Veo/Runway : Génère les séquences de B-roll
    ↓
L'agent assemble le montage final
    ↓
Sortie : Vidéo prête à être publiée
```

**Ce qui rend cette approche native pour les agents :**
- Hyperframes utilise du HTML — n'importe quel agent de code peut en générer
- Serveur MCP HeyGen — les agents l'appellent directement
- API des modèles vidéo — de simples requêtes HTTP standards
- Aucune étape de montage manuel requise

---

## Erreurs courantes

1. **Commencer par les outils plutôt que par la stratégie** — déterminez d'abord le type de vidéo dont vous avez besoin avant de choisir vos outils
2. **Texte généré par IA dans la vidéo** — les modèles ne parviennent pas à afficher du texte lisible de manière fiable ; privilégiez les incrustations programmatiques
3. **Avatars dans la « vallée de l'étrange » (uncanny valley)** — si la qualité de l'avatar est primordiale, investissez dans l'offre Creator+ de HeyGen
4. **Absence de sous-titres** — 85 % des vidéos sur les réseaux sociaux sont visionnées sans le son
5. **Mauvais ratio d'aspect** — 9:16 pour les réseaux sociaux, 16:9 pour YouTube/sites web, 1:1 pour les flux d'actualités
6. **Sur-production** — un contenu authentique surpasse souvent un contenu trop léché, en particulier sur TikTok

---

## Questions spécifiques à la tâche

1. Quel type de vidéo devez-vous réaliser ? (Démo, explicative, clip pour les réseaux sociaux, publicité, tutoriel)
2. Avez-vous besoin d'un présentateur humain ou une voix off/du texte suffisent-ils ?
3. S'agit-il d'une vidéo ponctuelle ou d'un template reproductible ?
4. À quelle plateforme est-elle destinée ? (Cela détermine le ratio d'aspect et la durée)
5. Avez-vous déjà des éléments existants à exploiter ? (Captures d'écran, séquences vidéo, scripts)
6. Quel est votre budget pour les outils vidéo ?

---

## Intégrations d'outils

| Outil | Type | MCP | Guide |
|-------|------|:---:|-------|
| **HeyGen** | Avatars IA | Oui | [heygen.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/heygen.md) |
| **Hyperframes** | Vidéo programmatique | - | [hyperframes.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/hyperframes.md) |
| **Remotion** | Vidéo programmatique | - | [remotion.dev](https://www.remotion.dev/docs) |
| **Runway** | Génération IA | - | [runwayml.com/docs](https://docs.dev.runwayml.com) |

---

## Compétences associées

- **social** : Pour la stratégie de contenu vidéo, les accroches et ce qu'il faut publier
- **ad-creative** : Pour la création et l'itération de publicités vidéo payantes
- **copywriting** : Pour les scripts vidéo et les messages
- **marketing-psychology** : Pour les accroches et la persuasion en vidéo
