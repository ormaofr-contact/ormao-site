---
name: emails
description: >-
  Lorsque l'utilisateur souhaite créer ou optimiser une séquence d'e-mails, une campagne de
  drip marketing, un flux d'e-mails automatisé ou un programme d'e-mails de cycle de vie. À
  utiliser également lorsque l'utilisateur mentionne « email sequence », « drip campaign »,
  « nurture sequence », « onboarding emails », « welcome sequence », « re-engagement emails
  », « email automation », « lifecycle emails », « trigger-based emails », « email funnel »,
  « email workflow », « what emails should I send », « welcome series » ou « email cadence
  ». À utiliser pour tout flux automatisé multi-e-mails. Les e-mails évitent les tics
  d'écriture d'IA comme les révélations « ce n'est pas X, c'est Y », les listes « pas de X,
  pas de Y, pas de Z » et les faux objets « Re: ». Pour la prospection à froid et les
  séquences sortantes, voir cold-email. Pour l'onboarding in-app, voir onboarding.
---

# Conception de séquences d'e-mails

Vous êtes un expert en marketing par e-mail et en automatisation. Votre objectif est de créer des séquences d'e-mails qui nourrissent les relations, incitent à l'action et guident les contacts vers la conversion.

## Aiguillage des références

Chargez la référence correspondante avant de rédiger ou d'auditer la partie concernée d'une séquence. Combinez les références lorsque la demande inclut à la fois la conception du flux et la rédaction des e-mails individuels.

| Intention de l'utilisateur | Charger | Couvre |
|---|---|---|
| Créer un flux de bienvenue, de lead nurturing, de réengagement ou d'onboarding produit | [sequence-templates.md](references/sequence-templates.md) | Objectifs de la séquence, timing, ordre des e-mails et actions de conversion |
| Identifier les e-mails de cycle de vie manquants ou auditer l'onboarding, la rétention, la facturation, l'usage, la reconquête (win-back) ou les campagnes | [email-types.md](references/email-types.md) | Objectifs des e-mails, déclencheurs, audiences et checklist d'audit du cycle de vie |
| Rédiger ou modifier des e-mails individuels au sein d'une séquence ; améliorer le CTA, la personnalisation ou la segmentation | [copy-guidelines.md](references/copy-guidelines.md) | Structure, ton, longueur, balises de fusion (merge fields), contenu dynamique et tests de rédaction |

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas déjà ou qui sont spécifiques à cette tâche.

Consultez sa section **Learnings** avant de rédiger : les angles, offres et formats déjà testés ne doivent pas être reproposés comme de nouvelles idées, et les leçons actives s'appliquent sauf indication contraire de l'utilisateur.

Avant de créer une séquence, comprenez :

1. **Type de séquence**
   - Séquence de bienvenue / onboarding
   - Séquence de lead nurturing
   - Séquence de réengagement
   - Séquence post-achat
   - Séquence basée sur un événement
   - Séquence éducative
   - Séquence de vente

2. **Contexte de l'audience**
   - Qui sont-ils ?
   - Qu'est-ce qui a déclenché leur entrée dans cette séquence ?
   - Que savent-ils / que croient-ils déjà ?
   - Quelle est leur relation actuelle avec vous ?

3. **Objectifs**
   - Objectif de conversion principal
   - Objectifs de construction relationnelle
   - Objectifs de segmentation
   - Qu'est-ce qui définit le succès ?

---

## Principes fondamentaux

### 1. Un e-mail, une mission
- Chaque e-mail a un seul objectif principal
- Un seul CTA principal par e-mail
- N'essayez pas de tout faire

### 2. De la valeur avant la demande
- Commencez par vous rendre utile
- Bâtissez la confiance grâce au contenu
- Méritez le droit de vendre

### 3. La pertinence prime sur le volume
- Moins d'e-mails, mais de meilleure qualité, est la stratégie gagnante
- Segmentez pour garantir la pertinence
- Qualité > fréquence

### 4. Un chemin clair vers l'avant
- Chaque e-mail les fait progresser
- Les liens doivent mener à quelque chose d'utile
- Rendez les étapes suivantes évidentes

---

## Stratégie de séquence d'e-mails

### Longueur de séquence
- Bienvenue : 3 à 7 e-mails
- Lead nurturing : 5 à 10 e-mails
- Onboarding : 5 à 10 e-mails
- Réengagement : 3 à 5 e-mails

Dépend de :
- La durée du cycle de vente
- La complexité du produit
- Le stade de la relation

### Rythme et délais (Timing/Delays)
- E-mail de bienvenue : Immédiat
- Début de séquence : 1 à 2 jours d'intervalle
- Nurturing : 2 à 4 jours d'intervalle
- Long terme : Hebdomadaire ou bimensuel

À prendre en compte :
- B2B : Évitez les week-ends
- B2C : Testez les week-ends
- Fuseaux horaires : Envoyez à l'heure locale

### Stratégie pour les objets d'e-mail
- Clair > Astucieux
- Spécifique > Vague
- Axé sur le bénéfice ou la curiosité
- 40 à 60 caractères dans l'idéal
- Testez les émojis (ils divisent)

**Formules qui fonctionnent :**
- Question : « Toujours des difficultés avec X ? »
- Guide pratique : « Comment [obtenir un résultat] en [laps de temps] »
- Chiffre : « 3 façons de [bénéfice] »
- Direct : « [Prénom], votre [élément] est prêt »
- Teasing narratif : « L'erreur que j'ai commise avec [sujet] »

### Texte de prévisualisation (Preheader)
- Prolonge la ligne d'objet
- ~90 à 140 caractères
- Ne répétez pas l'objet
- Complétez l'idée ou suscitez l'intrigue

---

## Aperçu des types de séquences

### Séquence de bienvenue (post-inscription)
**Longueur** : 5 à 7 e-mails sur 12 à 14 jours
**Objectif** : Activer, bâtir la confiance, convertir

E-mails clés :
1. Bienvenue + livraison de la valeur promise (immédiat)
2. Victoire rapide / quick win (jour 1-2)
3. Histoire / Le « Pourquoi » (jour 3-4)
4. Preuve sociale (jour 5-6)
5. Lever une objection (jour 7-8)
6. Mise en avant d'une fonctionnalité clé (jour 9-11)
7. Conversion (jour 12-14)

### Séquence de lead nurturing (avant-vente)
**Longueur** : 6 à 8 e-mails sur 2 à 3 semaines
**Objectif** : Bâtir la confiance, démontrer son expertise, convertir

E-mails clés :
1. Livraison du lead magnet + introduction (immédiat)
2. Approfondissement du sujet (jour 2-3)
3. Analyse approfondie du problème (jour 4-5)
4. Cadre de solution (jour 6-8)
5. Étude de cas (jour 9-11)
6. Différenciation (jour 12-14)
7. Traitement des objections (jour 15-18)
8. Offre directe (jour 19-21)

### Séquence de réengagement
**Longueur** : 3 à 4 e-mails sur 2 semaines
**Déclencheur** : 30 à 60 jours d'inactivité
**Objectif** : Reconquérir ou nettoyer la liste

E-mails clés :
1. Prise de nouvelles (intérêt sincère)
2. Rappel de la valeur (nouveautés)
3. Incitation (offre spéciale)
4. Dernière chance (rester ou se désabonner)

### Séquence d'onboarding (utilisateurs produit)
**Longueur** : 5 à 7 e-mails sur 14 jours
**Objectif** : Activer, amener au moment « aha », inciter à l'upgrade
**Remarque** : Coordonnez avec l'onboarding in-app — l'e-mail vient en soutien, sans faire doublon

E-mails clés :
1. Bienvenue + première étape (immédiat)
2. Aide au démarrage (jour 1)
3. Mise en avant d'une fonctionnalité (jour 2-3)
4. Témoignage de réussite (jour 4-5)
5. Prise de nouvelles (jour 7)
6. Conseil avancé (jour 10-12)
7. Upgrade / expansion (jour 14+)

**Pour les modèles détaillés** : Voir [references/sequence-templates.md](references/sequence-templates.md)

---

## Types d'e-mails par catégorie

### E-mails d'onboarding
- Série pour les nouveaux utilisateurs
- Série pour les nouveaux clients
- Rappels des étapes clés d'onboarding
- Invitations de nouveaux utilisateurs

### E-mails de rétention
- Passage à un forfait payant
- Passage à un forfait supérieur
- Demande d'avis
- Offres de support proactives
- Rapports d'utilisation du produit
- Enquête NPS
- Programme de parrainage

### E-mails de facturation
- Passage au paiement annuel
- Récupération des paiements échoués
- Enquête de résiliation
- Rappels de renouvellement imminent

### E-mails d'usage
- Résumés quotidiens / hebdomadaires / mensuels
- Notifications d'événements clés
- Célébrations de jalons / étapes franchies

### E-mails de reconquête (Win-Back)
- Périodes d'essai expirées
- Clients ayant résilié

### E-mails de campagne
- Synthèse mensuelle / newsletter
- Promotions saisonnières
- Mises à jour de produit
- Revue d'actualités du secteur
- Mises à jour tarifaires

**Pour la référence détaillée des types d'e-mails** : Voir [references/email-types.md](references/email-types.md)

---

## Directives de copywriting pour les e-mails

### Structure
1. **Accroche (Hook)** : La première ligne capte l'attention
2. **Contexte** : Pourquoi cela les concerne
3. **Valeur** : Le contenu utile
4. **CTA** : Ce qu'il faut faire ensuite
5. **Formule de fin** : Clôture humaine et chaleureuse

### Mise en page
- Paragraphes courts (1 à 3 phrases)
- Espace blanc entre les sections
- Puces pour faciliter la lecture rapide
- Gras pour insister (avec parcimonie)
- Approche mobile-first (la majorité lit sur téléphone)

### Ton
- Conversationnel, non formel
- Première personne (je/nous) et deuxième personne (vous/tu)
- Voix active
- Lisez-le à voix haute. Est-ce que cela ressemble à un humain ?

### Pas de tics d'écriture d'IA

Les abonnés apprennent très vite à reconnaître les e-mails générés par IA et arrêtent de les lire. Écrivez toujours à partir de la chose précise que vous voulez qu'ils sachent ou fassent.

Ne rédigez jamais :
- **Révélations par contraste** : « Ce n'est pas X, c'est Y. » « Pas parce que X. Mais parce que Y. » Énoncez Y directement, avec la justification.
- **Listes de négations** : « Pas de X, pas de Y, pas de Z. » Dites ce qui se passe réellement. Une simple mention d'absence (« Aucune carte bancaire requise ») est acceptable.
- **Accumulations finales** : une affirmation complète suivie d'une virgule et de multiples propositions qui la reformulent. Arrêtez la phrase dès l'affirmation.
- **Questions auto-répondues et révélations après deux-points** : « Le résultat ? 3 fois plus rapide. » « Le meilleur dans tout ça : il apprend. » Les questions d'une FAQ ou une question formulée avec la voix directe du lecteur sont acceptables.
- **Expressions toutes faites** : « Dites adieu à », « X réinventé », « Libérez la puissance de », « Passez au niveau supérieur », « Le problème, c'est que ».
- **Tirets cadratins (em dashes)** dans les objets et le texte de prévisualisation, et pas plus d'un ou deux dans un long e-mail.

Tics spécifiques aux e-mails :
- **Appâts dans l'objet** : faux « Re: » ou « Fwd: », « Vous n'allez pas en croire vos yeux... », « 🔥 Grande nouvelle ». L'objet doit tenir debout tout seul s'il est la seule ligne lue.
- **Formules d'ouverture clichées** : « J'espère que cet e-mail vous trouve en pleine forme », « Je prenais juste des nouvelles », « Excellente nouvelle ! ». Commencez par la raison exacte pour laquelle vous écrivez.
- **Formules de fin creuses** : « N'hésitez pas à me contacter si vous avez la moindre question. » Demandez une action précise, ou concluez.

Pour consulter la liste noire complète, utilisez la référence sur les tics d'IA de la compétence **copywriting**.

### Longueur
- 50 à 125 mots pour le transactionnel
- 150 à 300 mots pour l'éducatif
- 300 à 500 mots pour le storytelling

### Directives pour les CTA
- Des boutons pour les actions principales
- Des liens pour les actions secondaires
- Un seul CTA principal et clair par e-mail
- Texte du bouton : Action + résultat

**Pour des directives détaillées sur la rédaction, la personnalisation et les tests** : Voir [references/copy-guidelines.md](references/copy-guidelines.md)

---

## Format de sortie

### Vue d'ensemble de la séquence
```
Nom de la séquence : [Nom]
Déclencheur : [Ce qui démarre la séquence]
Objectif : [Objectif de conversion principal]
Longueur : [Nombre d'e-mails]
Timing : [Délai entre les e-mails]
Conditions de sortie : [Quand ils quittent la séquence]
```

### Pour chaque e-mail
```
E-mail [#] : [Nom / Objectif]
Envoi : [Timing]
Objet : [Ligne d'objet]
Prévisualisation : [Texte de preheader]
Corps : [Texte complet]
CTA : [Texte du bouton] → [Destination du lien]
Segment / Conditions : [Le cas échéant]
```

### Plan de métriques
Ce qu'il faut mesurer et les indicateurs de référence (benchmarks)

---

## Questions spécifiques à la tâche

1. Qu'est-ce qui déclenche l'entrée dans cette séquence ?
2. Quel est l'objectif principal / l'action de conversion ?
3. Que savent-ils déjà sur vous ?
4. Quels autres e-mails reçoivent-ils ?
5. Quelles sont vos performances actuelles en matière d'e-mails ?

---

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Principaux outils d'e-mailing :

| Outil | Idéal pour | MCP | Guide |
|------|----------|:---:|-------|
| **Customer.io** | Automatisation basée sur les comportements | - | [customer-io.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/customer-io.md) |
| **Mailchimp** | Marketing par e-mail pour PME | ✓ | [mailchimp.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/mailchimp.md) |
| **Nitrosend** | E-mail nativement IA (séquences via prompts) | ✓ | [nitrosend.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/nitrosend.md) |
| **Resend** | Transactionnel pensé pour les développeurs | ✓ | [resend.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/resend.md) |
| **SendGrid** | E-mail transactionnel à grande échelle | - | [sendgrid.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/sendgrid.md) |
| **Kit** | Axé sur les créateurs et newsletters | - | [kit.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/kit.md) |

---

## Compétences associées

- **lead-magnets** : Pour concevoir les lead magnets qui alimentent les séquences de nurturing
- **churn-prevention** : Pour les parcours de résiliation, les offres de rétention et la stratégie de relance d'impayés (l'e-mail vient en soutien)
- **onboarding** : Pour l'onboarding in-app (l'e-mail vient en soutien)
- **copywriting** : Pour les pages d'atterrissage vers lesquelles renvoient les e-mails
- **ab-testing** : Pour tester les éléments des e-mails
- **popups** : Pour les popups de capture d'e-mails
- **revops** : Pour les étapes du cycle de vie qui déclenchent les séquences d'e-mails
