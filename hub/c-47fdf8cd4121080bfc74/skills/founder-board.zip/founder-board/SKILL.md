---
name: founder-board
description: >-
  Votre conseil d'administration. Soumet une idée d'entreprise à un conseil de trois membres, chacun étant un sous-agent analysant l'idée à travers un cadre théorique publié : la perspective Offres (tirée de $100M Offers d'Alex Hormozi), la perspective Monopole (tirée de Zero to One de Peter Thiel) et la perspective Produit (tirée de la biographie de Steve Jobs par Walter Isaacson). Chaque membre évalue l'idée, identifie les risques fatals et vote pour financer, financer sous conditions ou rejeter. À utiliser lorsque l'utilisateur dit « teste mon idée de business », « est-ce que ça marcherait », « mets ça à l'épreuve », « qu'en dirait un conseil d'administration », « est-ce une bonne affaire », ou lorsqu'il démarre le founder pack sur une nouvelle idée.
argument-hint: "<the business idea, or leave blank to use the conversation>"
---

# founder-board

La première réunion. Avant que quiconque ne crée un site web ou ne signe un bail, trois membres du conseil d'administration décortiquent l'idée, chacun sous un angle différent, et votent.

Ce que l'utilisateur a saisi après `/founder-board` : `$ARGUMENTS`. Si ce champ est vide, récupérez l'idée à partir de la conversation.

## La règle concernant les trois noms

Les perspectives sont des synthèses de **cadres méthodologiques publiés**, rien de plus. Les membres du conseil ne sont pas ces personnes, ne s'expriment jamais en leur nom, ne les citent jamais et ne prétendent jamais qu'elles approuveraient quoi que ce soit. Écrivez « la perspective Offres », jamais « Alex Hormozi dit ». Si l'utilisateur demande ce que l'un d'eux pense réellement, répondez que vous pouvez uniquement appliquer leurs cadres publics.

## Étape 0 : le fichier d'idée

Chaque élément du founder pack lit `founder/idea.md` dans le projet de l'utilisateur. S'il n'existe pas, rédigez-le maintenant à partir de la conversation :

```markdown
# <business name, or a working name>

- What it is: one sentence.
- Who it is for: the target customer, as specific as the user can make it.
- What it sells, at what price: the core product and its price.
- Where and how: city or online, how customers find it, how it is delivered.
- Budget and constraints: money, time, skills, anything already decided.
```

Si le nom, le client, le produit ou le prix est manquant, demandez-les (au maximum trois questions en un seul message), puis rédigez le fichier. N'inventez pas de budget, de taille de marché ou de concurrent.

## Étape 1 : briefer le conseil

Rédigez `founder/board/brief.md` : le fichier d'idée accompagné de tout autre élément mentionné par l'utilisateur dont une personne extérieure aurait besoin. **Les sous-agents ne peuvent pas voir cette conversation**, le brief doit donc être totalement autonome. N'y ajoutez pas votre propre opinion sur l'idée.

## Étape 2 : réunir le conseil

Lancez trois sous-agents en UN SEUL message (outil Agent, `subagent_type: general-purpose`, un par membre), avec pour consigne à chacun : `Read founder/board/brief.md and founder-board's lenses.md (path below), apply ONLY the <lens> lens, and write your memo to founder/board/<lens>.md.` Le fichier de perspectives est `lenses.md` dans le dossier de ce skill (`${CLAUDE_SKILL_DIR}/lenses.md` ; si ce chemin n'est pas résolu, utilisez le répertoire de base affiché par Claude Code pour ce skill).

Chaque mémo, sous cette forme :

```markdown
# <Lens> lens
Score: <1-10> | Vote: FUND / FUND IF / PASS
## What is strong
## What would kill it (the top 3, most dangerous first)
## The questions I would ask the founder
## If FUND IF: the conditions
```

## Étape 3 : la synthèse du président

Lisez les trois mémos (ils sont courts) et rédigez `founder/board.md` :

1. Le vote, par ex. « 2 fund if, 1 pass », et la note moyenne.
2. Les risques soulevés par plus d'un membre : placez-les en premier.
3. Toutes les conditions, fusionnées sous la forme d'une checklist que le reste du pack pourra cocher (le CFO, le panel de consommateurs et la tarification en testeront la plupart).
4. Un paragraphe : la version la plus solide de ce business que le conseil puisse envisager. Elle peut différer de ce que l'utilisateur a présenté ; dites-le clairement.

Conservez les désaccords entre les membres. Un conseil qui s'accorde sur tout ne fait pas son travail.

## Règles

- Évaluez le business, pas le fondateur.
- Aucun fait inventé. Si une perspective a besoin d'un chiffre que personne ne possède encore (taille du marché, coût d'acquisition client), formulez-le comme une question ouverte et précisez quel skill y répond (`/founder-competitors`, `/founder-consumer`, `/founder-cfo`).
- Un PASS est un résultat, pas un échec. Dites-le clairement.

## Résultat

`founder/idea.md`, `founder/board/` (brief et trois mémos), `founder/board.md`. Indiquez ensuite le vote en une seule ligne et suggérez l'étape suivante : `/founder-competitors` pour voir qui est déjà en place, ou `/founder-consumer` pour le confronter à 100 acheteurs simulés.

## Où le pack se dirige ensuite

```
board -> competitors -> consumer -> pricing -> offer -> cfo -> marketing -> brand -> ops -> launch -> plan
```

Chaque skill peut également fonctionner de manière autonome ; chacun lit ce qui se trouve déjà dans `founder/`.
