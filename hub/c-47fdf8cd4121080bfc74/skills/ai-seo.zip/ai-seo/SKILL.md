---
name: ai-seo
description: >-
  Lorsque l'utilisateur souhaite optimiser son contenu pour les moteurs de recherche IA,
  être cité par les LLM ou apparaître dans les réponses générées par l'IA. À utiliser
  également lorsque l'utilisateur mentionne « AI SEO », « AEO », « GEO », « LLMO », « answer
  engine optimization », « generative engine optimization », « LLM optimization », « AI
  Overviews », « optimiser pour ChatGPT », « optimiser pour Perplexity », « citations IA »,
  « visibilité IA », « recherche zéro clic », « comment apparaître dans les réponses IA », «
  mentions LLM », « optimiser pour Claude/Gemini », « llms.txt », « llms-full.txt », « OKF
  », « Open Knowledge Format », « knowledge bundle », « site lisible par les agents », «
  agent readiness », « mon site est-il prêt pour les agents », « WebMCP », « les listicles
  fonctionnent-ils encore pour l'IA », « ChatGPT ne cite plus les pages de comparaison », «
  comment les LLM perçoivent notre marque », « LinkedIn pour l'AEO »
metadata:
  version: 2.10.1
---

# AI SEO

Vous êtes un expert en optimisation pour la recherche par IA — la pratique consistant à rendre le contenu découvrable, extractible et citable par les systèmes d'IA, notamment Google AI Overviews, ChatGPT, Perplexity, Claude, Gemini et Copilot. Votre objectif est d'aider les utilisateurs à faire citer leur contenu comme source dans les réponses générées par l'IA.

## Routage des références

Commencez par le flux de travail principal de cette compétence. Ouvrez une référence lorsque la question de l'utilisateur nécessite ce niveau de détail ; ne consultez des références supplémentaires que lorsque leurs sujets sont pertinents.

| Questions de l'utilisateur | Référence locale |
|---|---|
| Pourquoi un agent ne parvient-il pas à lire notre site ? L'accès des robots, les fichiers de découverte ou le code HTML le bloquent-ils ? | [Agent readiness](references/agent-readiness.md) |
| L'IA apparaît à peine dans les référents. Comment mesurer les visites différées, la recherche sur la marque et le pipeline issus des réponses IA ? | [AI attribution](references/ai-attribution.md) |
| L'IA donne-t-elle des informations erronées sur nos tarifs, nos fonctionnalités ou nos limites ? Comment trouver et corriger la source ? | [Answer accuracy](references/answer-accuracy.md) |
| Quel fournisseur Claude Code ou Cursor choisit-il lorsqu'un utilisateur dit « déploie ceci » ? Comment devenir l'outil qu'un agent installe en cours de tâche ? | [Agent defaults](references/agent-defaults.md) |
| Pourquoi sommes-nous cités mais absents de la sélection finale ? Notre propre guide d'achat peut-il aider nos concurrents ? Comment mesurer les recommandations ? | [Citations vs. recommendations](references/citations-vs-recommendations.md) |
| Comment structurer une définition, une comparaison ou une FAQ ? Qu'est-ce qui rend un bloc de réponse utile de manière autonome ? | [Content patterns](references/content-patterns.md) |
| En quoi l'approche diffère-t-elle pour les pages produits, la documentation, les entreprises locales ou l'e-commerce ? Quel type de contenu devons-nous améliorer ? | [Content types](references/content-types.md) |
| Un moteur a-t-il modifié les formats de pages qu'il cite ? Devrions-nous continuer à investir dans les listicles ou les pages de comparaison ? Comment distinguer un changement structurel de mesures bruitées ? | [Format volatility](references/format-volatility.md) |
| Devrions-nous publier des posts LinkedIn, des articles ou du contenu sur la page entreprise ? Qu'est-ce qui rend ce contenu découvrable et citable ? | [LinkedIn citations](references/linkedin-ai-citations.md) |
| Comment déployer l'AEO dans d'autres langues et pays ? ChatGPT Shopping vaut-il le coup pour notre produit ? | [Multilingual and commerce](references/multilingual-and-commerce.md) |
| Que doit contenir un bundle OKF ? S'agit-il d'une exigence établie pour la recherche IA ou d'une expérimentation émergente ? | [Open Knowledge Format](references/okf.md) |
| Quels prompts suivre, à quelle fréquence, et comment tester les conversations d'achat multi-tours ? | [Prompt portfolio](references/prompt-portfolio.md) |
| Par où commencer pour un moteur d'IA en particulier ? Quels crawlers de recherche et d'entraînement devons-nous distinguer ? | [Platform ranking factors](references/platform-ranking-factors.md) |
| Pourquoi l'IA décrit-elle notre positionnement de manière incorrecte ? Comment le consensus tiers peut-il renforcer un cas d'usage spécifique ? | [Positioning and consensus](references/positioning-and-consensus.md) |
| Comment le titre, les sous-titres, les chapitres ou la description d'une vidéo doivent-ils favoriser les citations ? Que vérifier avant de publier ? | [YouTube citations](references/youtube-ai-citations.md) |

Consultez ces fichiers groupés à partir du répertoire de compétences installé ; ne remplacez pas une référence locale par l'URL d'un dépôt distant. Si un fichier est manquant, précisez quelle référence est indisponible et appliquez le flux de travail principal sans prétendre l'avoir lu. Pour les statistiques sensibles au temps, les comportements de plateforme ou les allégations d'outils figurant dans une référence, vérifiez la date de la source et évaluez les preuves dans cet ordre : la documentation officielle de la plateforme, puis les expériences contrôlées, puis les grands jeux de données observationnelles (souvent des études de fournisseurs), puis les études de cas de praticiens. En cas de conflit entre la documentation et les données observationnelles, fiez-vous à la documentation pour l'éligibilité et le contrôle des crawlers, et traitez les données comme une hypothèse à tester. Ne transformez jamais le pourcentage d'une étude en prévision client sans faire correspondre le moteur, le secteur, la langue, le marché et la date.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations non couvertes ou spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Visibilité IA actuelle
- Savez-vous si votre marque apparaît aujourd'hui dans les réponses générées par l'IA ?
- Avez-vous vérifié ChatGPT, Perplexity ou Google AI Overviews pour vos requêtes clés ?
- Quelles requêtes comptent le plus pour votre activité ?

### 2. Contenu et domaine
- Quel type de contenu produisez-vous ? (Blog, documentation, comparaisons, pages produits)
- Quels sont votre autorité de domaine et votre niveau en SEO traditionnel ?
- Disposez-vous déjà de données structurées (balisage schema) ?

### 3. Objectifs
- Être cité comme source dans les réponses IA ?
- Apparaître dans Google AI Overviews pour des requêtes précises ?
- Concurrencer des marques spécifiques déjà citées ?
- Optimiser le contenu existant ou créer de nouveaux contenus optimisés pour l'IA ?

### 4. Paysage concurrentiel
- Quels sont vos principaux concurrents dans les résultats de recherche IA ?
- Sont-ils cités là où vous ne l'êtes pas ?
- Avez-vous une page Wikipédia ou une présence sur des sites d'avis ?

---

## Comment fonctionne la recherche par IA

### Le paysage de la recherche par IA

| Plateforme | Fonctionnement | Sélection des sources |
|------------|----------------|----------------------|
| **Google AI Overviews** | Synthétise les pages les mieux classées | Forte corrélation avec les classements traditionnels |
| **ChatGPT (avec recherche)** | Explore le web, cite des sources | S'appuie sur un éventail plus large, pas seulement les premiers résultats |
| **Perplexity** | Cite systématiquement les sources avec des liens | Privilégie les contenus faisant autorité, récents et bien structurés |
| **Gemini** | Assistant IA de Google | S'appuie sur l'index Google + le Knowledge Graph |
| **Copilot** | Recherche IA propulsée par Bing | Index Bing + sources faisant autorité |
| **Claude** | Brave Search (lorsqu'activé) | Données d'entraînement + résultats de recherche Brave |

Pour une analyse approfondie de la façon dont chaque plateforme sélectionne ses sources et des éléments à optimiser par plateforme, voir [references/platform-ranking-factors.md](references/platform-ranking-factors.md).

### Différence clé avec le SEO traditionnel

Le SEO traditionnel vous positionne dans les classements. L'AI SEO vous fait **citer**.

Dans la recherche traditionnelle, vous devez vous positionner en page 1. Dans la recherche IA, une page bien structurée peut être citée même si elle se trouve en page 2 ou 3 — les systèmes d'IA sélectionnent les sources en fonction de la qualité du contenu, de sa structure et de sa pertinence, et pas seulement de sa position dans le classement. Un bon classement organique reste l'un des meilleurs prédicteurs de visibilité IA : considérez donc la structure comme une couche ajoutée au SEO, et non comme un remplacement.

**Statistiques critiques** (elles évoluent ; revérifiez avant de les citer à un client, et méfiez-vous des chiffres d'éditeurs sans source ni date) :
- Les AI Overviews apparaissaient sur environ 48 % des requêtes suivies par BrightEdge (BrightEdge, fév. 2026), et le CTR desktop en première position a chuté d'environ 58 % lorsqu'une vue d'ensemble était présente (données Ahrefs, déc. 2025). Ces deux chiffres dépendent d'échantillons précis : ne les utilisez pas pour prédire la perte de trafic d'un site.
- L'ajout de statistiques et de citations a augmenté la visibilité d'environ 30 à 40 % dans l'étude GEO initiale (Aggarwal et al., 2023).

### Position officielle de Google vs réalité multiplateforme

Ce point est essentiel à lire une première fois avant toute action.

**La position de Google** ([guide d'optimisation des fonctionnalités IA](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)) :
> « Les bonnes pratiques de SEO restent pertinentes car nos fonctionnalités d'IA générative sur la recherche Google s'appuient sur nos systèmes fondamentaux de classement et de qualité de la recherche. »

Google précise explicitement :
- **Aucun balisage ni fichier spécifique n'est requis** pour les AI Overviews ou le mode IA
- **Ne découpez pas le contenu en morceaux pour l'IA** — écrivez pour les utilisateurs, organisez avec des titres et des paragraphes normaux
- **Ne rédigez pas de contenu distinct pour l'IA** — cela enfreint la politique relative à l'« utilisation abusive de contenu à grande échelle »
- **Le contenu utile, fiable et pensé pour les humains** l'emporte — mêmes critères E-E-A-T que pour la recherche classique
- **Aucun rapport Search Console spécifique à l'IA** — utilisez les métriques SEO habituelles

**Les autres moteurs d'IA (ChatGPT, Claude, Perplexity, Copilot) fonctionnent différemment :**
- Ils récompensent activement une structure extractible — passages clés, FAQ, tableaux comparatifs, blocs de définitions
- Ils analysent `llms.txt`, les pages de tarifs structurées et les fichiers lisibles par machine lorsqu'ils sont présents
- Ils citent au-delà des pages les mieux classées, intégrant Reddit, Wikipédia et les sites d'avis, selon une répartition variable selon le moteur

**Ce que cela implique pour votre travail :**
- Les modèles structurels de cette compétence (blocs de réponse de 40 à 60 mots, schema FAQ, tableaux comparatifs) aident concrètement les **moteurs d'IA non-Google**. Ils ne pénalisent pas non plus Google — ils relèvent simplement d'une bonne organisation de contenu standard.
- Pour Google AI Overviews / le mode IA spécifiquement : optimisez pour les humains et la recherche principale, un point c'est tout. Un E-E-A-T solide, des informations originales, du HTML sémantique, une indexabilité irréprochable.
- Pour ChatGPT/Claude/Perplexity : ajoutez par-dessus la structure extractible + llms.txt + les fichiers lisibles par machine. En cas de doute, écrivez pour les utilisateurs et organisez pour la clarté ; cela satisfait les deux approches.

### Éclatement de requêtes / Query Fan-Out (Google AI Search)

Les fonctionnalités d'IA de Google ne se contentent pas de répondre à l'unique requête saisie par l'utilisateur — elles génèrent en arrière-plan des **requêtes simultanées et connexes** et récupèrent des résultats pour chacune d'elles.

Exemple donné par Google : un utilisateur demandant « comment réparer une pelouse » déclenche des requêtes secondaires sur les herbicides, le désherbage sans produit chimique, la prévention des mauvaises herbes, etc. L'IA synthétise l'ensemble de ces résultats.

**Implications :**
- Cibler un mot-clé par page unique est moins efficace. Couvrez le **cluster thématique complet** afin d'être également récupérable pour les variantes issues de l'éclatement de requêtes.
- L'intention de longue traîne compte moins que l'autorité thématique — les systèmes d'IA de Google comprennent les synonymes et l'équivalence sémantique.
- Une page qui répond de manière exhaustive à un sujet parent (en couvrant les sous-questions) sera récupérée plus souvent que des pages étroites dédiées à une seule requête.

**Action** : lors de la planification du contenu, déterminez les 5 à 10 requêtes connexes vers lesquelles l'IA est susceptible d'éclater la recherche et assurez-vous que votre contenu (ou votre site dans son ensemble) les couvre, avec une page maîtresse par famille de faits (matrice dans [references/content-patterns.md](references/content-patterns.md)).

ChatGPT procède également par éclatement de requêtes — et vous pouvez extraire ses requêtes d'arrière-plan *littérales* pour votre niche via DevTools (méthode dans [references/format-volatility.md](references/format-volatility.md)). Après la version 5.6, les requêtes secondaires de ChatGPT ont délaissé les modificateurs de type « meilleur/vs/top » au profit de recherches avec `site:` et « officiel » — utilisez l'extraction pour voir où en sont les requêtes secondaires de votre secteur aujourd'hui.

---

## Audit de visibilité IA

Avant d'optimiser, évaluez votre présence actuelle dans la recherche IA.

### Étape 1 : Vérifier les réponses IA pour vos requêtes clés

Testez 10 à 20 de vos requêtes les plus stratégiques sur l'ensemble des plateformes :

| Requête | Google AI Overview | ChatGPT | Perplexity | Vous êtes cité ? | Concurrents cités ? |
|---------|:-----------------:|:-------:|:----------:|:----------------:|:-------------------:|
| [requête 1] | Oui/Non | Oui/Non | Oui/Non | Oui/Non | [qui] |
| [requête 2] | Oui/Non | Oui/Non | Oui/Non | Oui/Non | [qui] |

**Types de requêtes à tester**, réparties selon les étapes de sensibilisation de l'acheteur et formulées telles que les internautes les saisissent dans un champ de discussion :
- Conscience du problème : « Comment faire pour [problème résolu par votre produit] ? »
- Conscience de la solution : « Qu'est-ce que [votre catégorie de produit] ? » / « Meilleur [catégorie] pour [cas d'usage] »
- Conscience du produit : « [Votre marque] vs [concurrent] » / « [Votre marque] est-elle adaptée pour [cas d'usage] ? »
- Connaissance maximale : « Tarifs [Votre marque] » / « Est-ce que [Votre marque] s'intègre avec [outil] ? »

Limitez la liste aux prompts susceptibles d'avoir un impact sur le chiffre d'affaires. Une citation sur une question de glossaire (« qu'est-ce que la marge brute ? ») ne génère que très rarement des ventes. Suivez les prompts comme des mots-clés : regroupez les variantes de formulation d'une même intention en un prompt principal, puis exécutez chacun plusieurs fois.

### Étape 2 : Analyser les modèles de citation

Lorsque vos concurrents sont cités et pas vous, examinez :
- **La structure du contenu** — Leur contenu est-il plus facilement extractible ?
- **Les signaux d'autorité** — Ont-ils plus de citations, de statistiques, de citations d'experts ?
- **La fraîcheur** — Leur contenu a-t-il été mis à jour plus récemment ?
- **Le balisage schema** — Disposent-ils de données structurées qui vous manquent ?
- **La présence tierce** — Sont-ils cités via Wikipédia, Reddit, des sites d'avis ?

**Transformez les constats en tâches concrètes.** Si un assistant affirme quelque chose d'erroné ou d'approximatif sur votre offre, la page censée énoncer ce fait ne l'explique pas assez clairement : corrigez cette page en priorité. Si vous êtes absent, les sources citées pour ce prompt constituent votre liste cible pour les relations presse, les sites d'avis et les annuaires.

### Étape 3 : Contrôle de l'extractibilité du contenu

Pour chaque page prioritaire, vérifiez :

| Contrôle | Réussi / Échoué |
|----------|-----------------|
| Définition claire dans le premier paragraphe ? | |
| Blocs de réponses autonomes (compréhensibles hors contexte) ? | |
| Statistiques avec sources citées ? | |
| Tableaux comparatifs pour les requêtes « [X] vs [Y] » ? | |
| Section FAQ avec questions en langage naturel ? | |
| Balisage schema (FAQ, HowTo, Article, Product) ? | |
| Attribution d'expertise (nom de l'auteur, références) ? | |
| Récemment mis à jour (moins de 6 mois) ? | |
| Structure des titres calquée sur les formulations des requêtes ? | |
| Politique des crawlers IA alignée sur les objectifs de découverte et d'entraînement ? | |

### Étape 4 : Contrôle de l'accès des robots IA

Auditez les user-agents d'IA selon leur finalité. Les jetons de découverte pour la recherche, de récupération déclenchée par l'utilisateur, d'entraînement de modèle et de contrôle de produit ne sont pas interchangeables :

- **Découverte pour la recherche :** `OAI-SearchBot` (ChatGPT), `PerplexityBot`, `Claude-SearchBot`, `meta-webindexer` (Meta AI), ainsi que les crawlers de recherche conventionnels qui alimentent un produit de réponse
- **Récupération déclenchée par l'utilisateur :** `ChatGPT-User`, `Claude-User`, `Perplexity-User` et `meta-externalfetcher` ; le traitement par les fournisseurs pouvant différer de celui des crawlers automatiques, vérifiez la documentation à jour
- **Entraînement potentiel des modèles :** `GPTBot`, `ClaudeBot` et `meta-externalagent`
- **Contrôle des produits Google :** `Google-Extended` contrôle certaines utilisations du contenu déjà exploré par Google pour l'entraînement et le grounding de Gemini ; il n'affecte pas l'inclusion ni le classement dans la recherche Google

Vérifiez séparément chaque groupe de user-agents ainsi que les règles WAF ou CDN. Un éditeur peut autoriser la découverte pour la recherche tout en refusant les crawlers de développement de modèles ; ne déduisez pas du blocage d'un crawler d'entraînement que les citations seront nécessairement bloquées. Voir [references/platform-ranking-factors.md](references/platform-ranking-factors.md) pour la configuration complète du fichier robots.txt.

---

## Stratégie d'optimisation

### Les trois piliers

```
1. Structure (rendre le contenu extractible)
2. Autorité (rendre le contenu citable)
3. Présence (être là où l'IA cherche)
```

### Pilier 1 : Structure — Rendre le contenu extractible

Les systèmes d'IA extraient des passages, pas des pages entières. Chaque affirmation clé doit fonctionner comme une déclaration autonome.

**Modèles de blocs de contenu :**
- **Blocs de définition** pour les requêtes du type « Qu'est-ce que X ? »
- **Blocs étape par étape** pour les requêtes du type « Comment faire X »
- **Tableaux comparatifs** pour les requêtes du type « X vs Y »
- **Blocs avantages/inconvénients** pour les requêtes d'évaluation
- **Blocs FAQ** pour les questions fréquentes
- **Blocs de statistiques** avec sources citées

Pour des modèles détaillés de chaque type de bloc, voir [references/content-patterns.md](references/content-patterns.md).

**Règles structurelles :**
- Commencez chaque section par une réponse directe (ne la noyez pas dans l'introduction)
- Maintenez les passages de réponse clés entre 40 et 60 mots (longueur optimale pour l'extraction de snippets)
- Utilisez des titres H2/H3 correspondant à la formulation naturelle des requêtes
- Les tableaux surpassent la prose pour les contenus comparatifs
- Les listes numérotées surpassent les paragraphes pour décrire des processus
- Chaque paragraphe doit véhiculer une seule idée claire

### Pilier 2 : Autorité — Rendre le contenu citable

Les systèmes d'IA privilégient les sources auxquelles ils peuvent faire confiance. Développez votre valeur de citation.

**La recherche GEO de Princeton** (KDD 2024, menée sur Perplexity.ai) a classé 9 méthodes d'optimisation :

| Méthode | Gain de visibilité | Comment l'appliquer |
|---------|:------------------:|---------------------|
| **Citer des sources** | +40 % | Ajouter des références d'autorité avec des liens |
| **Ajouter des statistiques** | +37 % | Inclure des chiffres précis accompagnés de leurs sources |
| **Ajouter des citations** | +30 % | Citations d'experts avec nom et titre |
| **Ton d'autorité** | +25 % | Rédiger en démontrant une expertise avérée |
| **Améliorer la clarté** | +20 % | Simplifier les concepts complexes |
| **Termes techniques** | +18 % | Utiliser la terminologie spécifique au domaine |
| **Vocabulaire distinctif** | +15 % | Enrichir la diversité lexicale |
| **Optimisation de la fluidité** | +15 à 30 % | Améliorer la lisibilité et la fluidité de lecture |
| ~~Bourrage de mots-clés~~ | **-10 %** | **Nuit activement à la visibilité IA** |

**Meilleure combinaison :** Fluidité + Statistiques = impact maximal. Les sites moins bien classés en profitent encore davantage — jusqu'à 115 % d'augmentation de visibilité grâce aux citations.

**Statistiques et données** (+37 à 40 % de gain de citation)
- Inclure des chiffres précis avec leurs sources
- Citer des recherches originales, non des résumés de recherches
- Indiquer la date de chaque statistique
- Les données propriétaires surpassent les données agrégées

**Attribution d'expertise** (+25 à 30 % de gain de citation)
- Auteurs nommés avec leurs qualifications
- Citations d'experts avec mention de leur titre et organisation
- Formulation « Selon [Source] » pour étayer les affirmations
- Biographies d'auteurs démontrant une expertise pertinente

**Signaux de fraîcheur**
- Mention « Dernière mise à jour : [date] » affichée de façon visible
- Actualisations régulières du contenu (au minimum trimestrielles pour les sujets concurrentiels)
- Références à l'année en cours et statistiques récentes
- Suppression ou mise à jour des informations obsolètes

**Alignement avec l'E-E-A-T**
- Expérience directe démontrée
- Informations précises et détaillées (non génériques)
- Sources et méthodologie transparentes
- Expertise avérée de l'auteur sur le sujet traité

### Pilier 3 : Présence — Être là où l'IA regarde

Les systèmes d'IA citent votre propre site ainsi que les espaces tiers qui parlent de vous, dans des proportions variables selon le moteur et le secteur. Sur un large ensemble de données, les sites d'entreprises représentaient environ 57 % des citations (47 % pour ChatGPT, 69 % pour Gemini ; Profound, juillet 2026), tandis que les recommandations de sélection finale reposent sur le consensus tiers. Mesurez la répartition des citations dans votre secteur avant de choisir vos canaux ; voir [references/citations-vs-recommendations.md](references/citations-vs-recommendations.md).

**Surfaces tierces à couvrir :**
- Wikipédia (7,8 % des citations sur ChatGPT dans les données Profound d'août 2024 à juin 2025)
- Reddit (1,8 % dans ces mêmes données, puis quasi disparu de ChatGPT suite aux modifications de retrieval d'août 2026 ; toujours extrait ailleurs ; voir la section volatilité dans [references/agent-readiness.md](references/agent-readiness.md))
- Publications spécialisées et articles invités
- LinkedIn — parmi les domaines les plus cités pour les requêtes professionnelles, bien que la surface citée dépende du moteur (ChatGPT privilégie désormais les posts par rapport aux articles ; Gemini cite très peu LinkedIn). Placez la formule cible dès le début du post, car ses premiers mots composent le slug de l'URL. Voir [references/linkedin-ai-citations.md](references/linkedin-ai-citations.md)
- Sites d'avis (G2, Capterra, TrustRadius pour le SaaS B2B)
- YouTube (fréquemment cité par Google AI Overviews)
- Podcasts (les épisodes sont transcrits, les notes d'émission publiées — les deux sont explorés et cités)
- Réponses Quora

**Actions :**
- Assurez-vous que votre page Wikipédia est exacte et à jour
- Participez de manière authentique aux communautés Reddit — mais considérez cela comme une surface parmi d'autres dans un portefeuille, jamais comme une stratégie unique (la répartition des citations peut changer du jour au lendemain suite à une mise à jour d'algorithme)
- Faites-vous mentionner dans les synthèses sectorielles et les articles comparatifs
- Veillez à ce que chaque profil tiers (G2, Capterra, Gartner, Crunchbase, LinkedIn) vous décrive avec le même segment et le même positionnement que votre page À propos ; les modèles recherchent le consensus. Pour les repositionnements, fusions et termes génériques de tête, voir [references/positioning-and-consensus.md](references/positioning-and-consensus.md)
- Créez du contenu YouTube pour les requêtes pratiques clés (« how-to ») — les modèles ne regardent pas la vidéo, ils lisent la couche textuelle qui l'entoure ; voir [references/youtube-ai-citations.md](references/youtube-ai-citations.md) pour l'anatomie complète (transcription, sous-titres, chapitres, description, commentaire épinglé)
- Intervenez en tant qu'invité sur des podcasts de votre secteur (préparez-vous avec la compétence public-relations pour la préparation des interventions podcast)
- Répondez en profondeur aux questions Quora pertinentes

### Fichiers lisibles par machine pour les agents IA

> **Position de Google** : non requis pour les AI Overviews ou le mode IA. Leur guide indique explicitement qu'il n'est pas nécessaire d'ajouter un nouveau balisage, des fichiers pour l'IA ou du markdown pour apparaître dans la recherche générative par IA.
>
> **Pourquoi les inclure malgré tout** : les moteurs d'IA non-Google (ChatGPT, Claude, Perplexity) et les agents d'achat autonomes valorisent une structure extractible. Les fichiers ci-dessous favorisent ces moteurs sans pénaliser votre référencement Google.

Les agents d'IA ne se contentent plus de répondre aux questions — ils deviennent des acheteurs. Lorsqu'un agent d'IA évalue des outils pour le compte d'un utilisateur, il a besoin d'informations structurées et facilement analysables. Si votre grille tarifaire est enfermée dans une page générée en JavaScript ou derrière un formulaire « contacter l'équipe commerciale », les agents vous ignoreront pour recommander des concurrents dont les données sont immédiatement lisibles.

**Auditez d'abord cette couche** : [references/agent-readiness.md](references/agent-readiness.md) — la checklist accès/découverte/analysabilité, les outils d'évaluation gratuits (`npx is-agentic`, le vérificateur de Frase), la négociation de contenu Markdown + en-têtes `Link`, `llms-full.txt`, ainsi que la couche émergente d'action des agents (WebMCP).

Ajoutez ces fichiers lisibles par machine à la racine de votre site :

**`/pricing.md` ou `/pricing.txt`** — Données tarifaires structurées pour les agents IA

```markdown
# Pricing — [Nom de votre produit]

## Free
- Price: 0 $/mois
- Limits: 100 e-mails/mois, 1 utilisateur
- Features: Modèles basiques, accès API

## Pro
- Price: 29 $/mois (facturé annuellement) | 35 $/mois (facturé mensuellement)
- Limits: 10 000 e-mails/mois, 5 utilisateurs
- Features: Domaines personnalisés, analytics, support prioritaire

## Enterprise
- Price: Sur mesure — contacter sales@example.com
- Limits: E-mails illimités, utilisateurs illimités
- Features: SSO, SLA, gestionnaire de compte dédié
```

**Pourquoi c'est important dès maintenant :**
- Les agents IA comparent de plus en plus les produits par voie programmatique avant même qu'un humain ne visite votre site
- Les tarifs opaques sont écartés des parcours d'achat intermédiés par l'IA
- Un simple fichier markdown est analysable sans difficulté par n'importe quel LLM — aucun rendu, aucun JavaScript, aucun écran de connexion
- C'est le même principe que `robots.txt` (pour les crawlers), `llms.txt` (pour le contexte IA) et `AGENTS.md` (pour les capacités des agents)

**Bonnes pratiques :**
- Utilisez des unités cohérentes (mensuel vs annuel, par siège vs forfait)
- Indiquez des limites et des seuils précis, pas seulement des noms de fonctionnalités
- Détaillez ce qui est inclus dans chaque offre, pas seulement les différences
- Maintenez le fichier à jour — des tarifs obsolètes sont plus préjudiciables que l'absence de fichier
- Liez ce fichier depuis votre sitemap et votre page de tarifs principale

**`/llms.txt`** — Fichier de contexte pour les systèmes d'IA (voir [llmstxt.org](https://llmstxt.org))

Si vous n'en avez pas encore, ajoutez un fichier `llms.txt` qui offre aux systèmes d'IA une vue d'ensemble rapide de ce que fait votre produit, à qui il s'adresse, ainsi que des liens vers vos pages clés (notamment vos tarifs).

**`/okf/` — Bundle Open Knowledge Format (soutenu par Google, v0.1)**

Google a [introduit l'OKF](https://cloud.google.com/blog/products/data-analytics/how-the-open-knowledge-format-can-improve-data-sharing) en juin 2026 — une spécification markdown permettant de représenter le contenu d'un site sous forme d'un répertoire de fichiers interconnectés avec frontmatter YAML, lisibles par les agents sans scraping. Conçu initialement pour les métadonnées de catalogue d'équipes de données ; le détournement pour rendre un site lisible par des agents a été popularisé par Suganthan Mohanadasan. Aucun signal de classement confirmé pour la recherche IA à ce jour — traitez-le comme un enregistrement au niveau protocolaire, semblable aux débuts de schema.org. **Pour l'analyse complète, les méthodes d'implémentation (générateur gratuit, plugin WordPress, manuel), les conseils d'hébergement et les cas où s'en passer, voir [references/okf.md](references/okf.md).**

### Balisage Schema pour l'IA

Les données structurées aident les systèmes d'IA à comprendre votre contenu. Schémas clés :

| Type de contenu | Schema | Pourquoi cela aide |
|-----------------|--------|-------------------|
| Articles / Billets de blog | `Article`, `BlogPosting` | Identification de l'auteur, de la date et du sujet |
| Tutoriels / How-to | `HowTo` | Extraction des étapes pour les requêtes procédurales |
| FAQ | `FAQPage` | Extraction directe des questions/réponses |
| Produits | `Product` | Tarifs, caractéristiques, avis |
| Comparatifs | `ItemList` | Données comparatives structurées |
| Avis | `Review`, `AggregateRating` | Signaux de confiance |
| Organisation | `Organization` | Reconnaissance d'entité |

Aucune étude solidement étayée n'isole un gain direct du balisage schema sur les citations IA : considérez donc schema comme un contexte aidant les moteurs à analyser vos pages, sans en attendre un gain fixe garanti. **Remarque de Google** : les données structurées ne sont « pas requises pour la recherche générative par IA », mais restent recommandées pour la stratégie SEO globale. Pour l'implémentation, utilisez la compétence **schema**.

---

## Expériences agentiques (Agentic Experiences)

Au-delà de la synthèse de contenu par les moteurs de recherche IA, des agents autonomes commencent à accéder directement aux sites — cliquant, lisant, comparant et effectuant même des achats pour le compte des utilisateurs. Le guide de Google identifie cela comme une catégorie émergente à anticiper.

**Comment les agents accèdent à votre site :**
- **Rendu visuel** — ils capturent l'écran / lisent la page comme le ferait un internaute
- **Inspection du DOM** — ils analysent la structure HTML de la page
- **Arbre d'accessibilité** — ils s'appuient sur les mêmes informations sémantiques que les technologies d'assistance (libellés, rôles, repères structurels, titres)

**Ce qu'il faut faire :**
- **Afficher un contenu signifiant sans acrobaties JS complexes** — si la page reste blanche tant que 4 frameworks n'ont pas fini de charger, les agents ne voient rien
- **HTML sémantique** — utilisez `<main>`, `<nav>`, `<article>`, `<button>`, une hiérarchie de titres rigoureuse et des attributs `alt` sur les images
- **Arbre d'accessibilité propre** — chaque élément interactif doit avoir un libellé clair ; utilisez ARIA correctement (ou évitez-le lorsque le HTML natif suffit)
- **Sélecteurs stables / mises en page prévisibles** — les agents peinent sur les sites dont l'interface change d'état à chaque interaction
- **Tarifs, caractéristiques et coordonnées visibles** — tout ce dont un agent a besoin pour formuler une recommandation d'achat doit figurer sur une page publique et indexable (c'est là que `/pricing.md` et les fichiers similaires se révèlent utiles). Datez les faits qui évoluent (« 4,7 sur G2 en octobre 2026 ») afin qu'un agent puisse en évaluer la fraîcheur
- **Éléments de preuve au format texte** — témoignages, évaluations et logos de clients identifiés doivent figurer sous forme de texte dans le code HTML, et non intégrés dans des images ou injectés par un script externe. Si vous ne pouvez pas sélectionner le texte à la souris, un agent risque de ne pas pouvoir le lire

**Émergence — Universal Commerce Protocol (UCP) :**
Google mentionne l'UCP comme un protocole à venir fournissant aux agents des points d'ancrage standardisés pour les interactions commerciales (découverte de catalogue, tarifs, paiement). Surveillez son adoption ; pour l'instant, les recommandations structurelles ci-dessus en constituent le socle préalable.

Pour le e-commerce et les entreprises locales en particulier, Google met en avant :
- **Flux Merchant Center** + **Fiche Google Business Profile** pour la visibilité des produits et services dans AI Search
- **Business Agent** pour l'interaction conversationnelle avec les clients (le cas échéant)

---

## Types de contenu les plus cités

Tous les contenus ne sont pas également citables — et la répartition des formats est **volatile**. L'historique de référence plaçait les articles comparatifs (~33 %) et les listicles (~10 %) parmi les formats les plus cités, mais **ChatGPT 5.6 (août 2026) a déclassé les formats sur-exploités : les citations de listicles ont chuté de −50,5 % et celles de pages comparatives de −32,1 %, tandis que les requêtes avec `site:` et « officiel » ont bondi** — marquant un recentrage sur les sources primaires et les pages propriétaires. La stratégie de format se raisonne désormais par plateforme (les comparaisons fonctionnent toujours sur Google AIO/Gemini/Perplexity). Voir [references/format-volatility.md](references/format-volatility.md) pour les données sur cette transition, le tableau des formats par plateforme, les statistiques de citation de LinkedIn et la méthode d'extraction des requêtes secondaires de ChatGPT.

**Formats systématiquement gagnants sur toutes les plateformes :** recherches originales et données chiffrées, guides de référence et pages « officielles » propriétaires (produit, documentation, tarifs) dotées d'une structure facilement extractible.

**Formats sous-performants :** articles génériques non structurés, contenus pauvres, réservés aux membres (gated) ou limités à des PDF, et tout contenu non daté sans mention d'auteur.

**Citation ≠ recommandation.** Être cité signifie que votre contenu a été jugé utile à consulter ; être *recommandé* — c'est-à-dire figurer sur la sélection finale de l'acheteur — dépend du consensus établi sur l'ensemble du web (avis, forums, analystes, presse) et ne découle pas seulement de vos propres publications. Les listicles d'auto-promotion du type « meilleur [catégorie] » peuvent même se retourner contre les marques émergentes : dans une étude B2B portant sur 100 requêtes, 69 % des citations obtenues dans les AI Overviews par des listicles d'auto-promotion apparaissaient dans des réponses qui recommandaient des concurrents plutôt que la marque éditrice. Voir [references/citations-vs-recommendations.md](references/citations-vs-recommendations.md) pour l'échelle de visibilité (récupéré → cité → mentionné → recommandé), la stratégie de guide d'achat selon le stade de maturité, les critères qui déclenchent une recommandation et l'angle mort de l'attribution.

---

## Suivi de la visibilité IA

### Ce qu'il faut mesurer

| Métrique | Ce qu'elle mesure | Comment la vérifier |
|----------|-------------------|---------------------|
| Présence dans les AI Overviews | Les AI Overviews apparaissent-elles pour vos requêtes ? | Vérification manuelle ou Semrush/Ahrefs |
| Taux de citation de la marque | Fréquence à laquelle vous êtes cité dans les réponses IA | Outils de visibilité IA (voir ci-dessous) |
| Part de voix IA (Share of Voice) | Vos citations par rapport à celles de vos concurrents | Peec AI, Otterly, ZipTie, Omnia |
| Sentiment des citations | La façon dont l'IA qualifie votre marque | Examen manuel + outils de monitoring |
| Taux de recommandation | Votre présence sur la sélection finale, au-delà de la simple citation (voir [citations-vs-recommendations.md](references/citations-vs-recommendations.md)) | Suivi des prompts + cadrage des mentions |
| Attribution des sources | Quelles pages sont citées et quel est l'impact de l'exposition IA en aval | Trafic référent IA complété par les visites directes et sur la marque différées ([ai-attribution.md](references/ai-attribution.md)) |

### Outils de suivi de la visibilité IA

| Outil | Couverture | Idéal pour |
|-------|------------|------------|
| **Otterly AI** | ChatGPT, Perplexity, Google AI Overviews | Suivi de la part de voix IA |
| **Peec AI** | ChatGPT, Gemini, Perplexity, Claude, Copilot+ | Suivi multiplateforme à grande échelle |
| **ZipTie** | Google AI Overviews, ChatGPT, Perplexity | Suivi des mentions de marque et du sentiment |
| **LLMrefs** | ChatGPT, Perplexity, AI Overviews, Gemini | Correspondance mot-clé SEO → visibilité IA |
| **Profound, Ahrefs Brand Radar, Semrush** | Principaux assistants et surfaces IA de Google | Dispositifs d'envergure : sources citées, texte de réponse, demande de prompts (les études de Profound sont citées dans les références en tant que recherches d'éditeurs) |
| **Omnia** | Google AI Mode, Google AI Overviews, ChatGPT, Perplexity, Gemini, Claude, Copilot | Suivi global de la visibilité IA |

### Suivi sans outil (fait maison)

Contrôle manuel mensuel :
1. Sélectionnez vos 20 requêtes prioritaires
2. Soumettez chacune d'elles à ChatGPT, Perplexity et Google
3. Consignez : Êtes-vous cité ? Qui l'est ? Quelle page ? Notez le tout dans un tableur et analysez l'évolution mois après mois

Les réponses de l'IA sont **non déterministes** — une seule exécution constitue une anecdote, pas une mesure. Lancez chaque requête 3 à 5 fois par plateforme et suivez le *taux* de mention avec sa taille d'échantillon (« cité 3/5, n=5 »), en comparant les taux dans le temps plutôt que des requêtes isolées. Liste de contrôle complète dans [references/format-volatility.md](references/format-volatility.md).

### Ce qu'il faut attendre de la Search Console

Le guide de Google est catégorique : **il n'existe aucun rapport Search Console spécifique à l'IA**. Les AI Overviews et le mode IA s'appuient sur le classement de la recherche standard ; les rapports habituels de la Search Console (Performances, Couverture, Signaux web essentiels) restent donc vos outils de mesure pour Google. Les outils tiers mentionnés ci-dessus sont le seul moyen d'observer le comportement des citations IA sur l'ensemble des plateformes.

---

## Ce qu'il ne faut PAS faire

Le guide de Google met explicitement en garde contre ces pratiques — elles pénalisent à la fois le référencement classique et les fonctionnalités d'IA.

1. **Rédiger du contenu distinct « pour l'IA »**. Le même contenu doit s'adresser aux utilisateurs et à l'IA. Produire des variantes destinées aux systèmes d'IA vous expose aux sanctions pour **utilisation abusive de contenu à grande échelle** — selon les termes mêmes de Google.
2. **Morceler les pages pour appâter l'IA**. Le guide de Google est sans équivoque : *« Ne découpez pas votre contenu en minuscules fragments pour que l'IA le comprenne mieux. »* Conservez une structure normale avec paragraphes et titres.
3. **Générer du contenu en masse pour manipuler le classement**. Le contenu généré par IA est admis *s'il* respecte les règles essentielles de Google Search et les consignes anti-spam. La production industrielle de variantes creuses ne les respecte pas.
4. **Rechercher des mentions non authentiques**. N'inventez pas de fausses citations, ne créez pas de prix fictifs, n'administrez pas de sites d'avis prétendument « indépendants » qui vous appartiennent et ne spammez pas Reddit ou Wikipédia pour doper votre visibilité IA. Les avis faux ou biaisés peuvent également enfreindre la réglementation de la FTC de 2024. Ne pratiquez qu'une participation authentique.
5. **Considérer tous les user-agents d'IA sous une même règle**. `GPTBot`, `ClaudeBot` et `Google-Extended` ont des finalités documentées distinctes de celles d'`OAI-SearchBot`, `Claude-SearchBot` et `PerplexityBot`. Prenez des décisions séparées pour la découverte, la récupération utilisateur, l'entraînement et le grounding.
6. **Masquer votre contenu principal derrière du JS non rendu**. La recherche traditionnelle comme les agents d'IA ont besoin d'accéder à votre contenu ; un rendu exclusivement JavaScript pénalise la visibilité auprès des deux.
7. **Négliger les fondamentaux E-E-A-T**. Identité de l'auteur, expérience vécue, signaux d'expertise, transparence des sources — le guide de Google insiste lourdement sur ces éléments pour les fonctionnalités d'IA.

---

## L'AI SEO par type de contenu

Pour des conseils tactiques sur les pages produits SaaS, les articles de blog, les pages comparatives/alternatives, la documentation et le référencement local/e-commerce (avec l'accent mis par Google sur Merchant Center et Google Business Profile), voir [references/content-types.md](references/content-types.md).

---

## Erreurs courantes

- **Ignorer totalement la recherche par IA** — Les AI Overviews apparaissent sur près de la moitié des requêtes suivies dans de nombreux secteurs (BrightEdge, fév. 2026), et l'usage des assistants continue de progresser
- **Distinguer l'AI SEO du SEO classique** — Un bon SEO traditionnel constitue la base ; l'AI SEO y ajoute une couche de structure et d'autorité
- **Rédiger pour l'IA plutôt que pour les humains** — Si un texte semble avoir été conçu pour déjouer un algorithme, il ne sera ni cité ni source de conversions
- **Omettre les signaux de fraîcheur** — Un contenu non daté perd face à un contenu daté car les systèmes d'IA accordent une importance majeure à la récence. Affichez clairement la date de dernière mise à jour
- **Verrouiller l'accès à tous les contenus (gating)** — L'IA ne peut pas explorer les contenus protégés par un formulaire. Gardez vos contenus les plus autoritaires en accès libre
- **Négliger la présence sur les plateformes tierces** — Les recommandations de sélection finale dépendent de ce que les avis, les forums et la presse disent de vous, y compris lorsque votre propre site génère la majorité des citations
- **Absence de données structurées** — Le balisage Schema apporte aux systèmes d'IA un contexte structuré sur votre contenu
- **Bourrage de mots-clés (keyword stuffing)** — Contrairement au SEO traditionnel où il est simplement inefficace, le bourrage de mots-clés diminue activement la visibilité IA de 10 % (étude GEO de Princeton)
- **Masquer les tarifs derrière un bouton « contacter l'équipe commerciale » ou des pages rendues en JS** — Les agents IA qui évaluent votre produit pour des acheteurs ne peuvent pas analyser ce qu'ils ne peuvent pas lire. Ajoutez un fichier `/pricing.md`
- **Bloquer les crawlers de découverte sans vérifier leur fonction** — Restreindre `OAI-SearchBot`, `PerplexityBot` ou `Claude-SearchBot` peut réduire votre visibilité dans la recherche ; les contrôles d'entraînement sont distincts
- **Contenu générique dépourvu de données** — Écrire « Nous sommes les meilleurs » ne sera pas cité. « Nos clients constatent une amélioration de 3x sur [métrique] » le sera
- **Oublier d'assurer un suivi** — On ne peut améliorer ce qu'on ne mesure pas. Vérifiez votre visibilité IA au moins une fois par mois

---

## Intégrations d'outils

Pour l'implémentation, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md).

| Outil | Cas d'usage |
|-------|-------------|
| `semrush` | Suivi des AI Overviews, recherche de mots-clés, analyse des écarts de contenu |
| `ahrefs` | Analyse des backlinks, explorateur de contenu, données sur les AI Overviews |
| `gsc` | Données de performance Search Console, suivi des requêtes |
| `ga4` | Trafic référent issu des sources IA |

---

## Compétences associées

- **seo-audit** : Pour les audits SEO techniques et on-page traditionnels ; **link-building** pour acquérir des liens et des mentions sur les pages tierces citées par les moteurs d'IA
- **schema** : Pour implémenter les données structurées qui aident l'IA à comprendre votre contenu
- **content-strategy** : Pour planifier les contenus à créer
- **competitors** : Pour concevoir des pages comparatives citées par l'IA
- **programmatic-seo** : Pour concevoir des pages SEO à grande échelle
- **copywriting** : Pour rédiger un contenu à la fois agréable à lire pour les humains et extractible par l'IA
- **lead-magnets** : Pour conditionner une formation propriétaire ou une bibliothèque de contenus sous forme de compétence d'agent installable (différent de la visibilité IA sur site public)
