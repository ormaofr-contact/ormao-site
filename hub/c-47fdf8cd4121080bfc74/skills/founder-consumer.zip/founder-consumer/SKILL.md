---
name: founder-consumer
description: >-
  Le panel de consommateurs. Lance un essaim de sous-agents acheteurs (100 par
  défaut, --quick pour 20) modélisés d'après la cible de l'utilisateur, chacun
  ayant un revenu, un âge, un comportement d'achat et une objection différents,
  soumet à chacun le même pitch, et teste l'entreprise à travers 100 scénarios
  d'acheteurs pour voir qui achète, qui refuse et pourquoi. Compile les réponses
  en taux d'achat par segment, les raisons de refus avec leurs propres mots, ce
  qui ferait basculer un non, et les réponses de prix pour founder-pricing. À
  utiliser quand l'utilisateur dit "est-ce que les gens achèteraient ça",
  "teste-le sur des clients", "lance le panel de consommateurs", "simule des
  acheteurs", "qui est mon client", ou "valide la demande".
argument-hint: "[--n 100 | --quick] [--seed S]"
---

# founder-consumer

La partie la plus impressionnante du pack. Au lieu de deviner si les gens achèteront,
vous le demandez à cent d'entre eux, chacun étant un sous-agent incarnant un acheteur
spécifique issu de votre clientèle cible. Vous êtes le modérateur. Vous ne répondez
jamais à la place d'un acheteur.

Ce que l'utilisateur a tapé après `/founder-consumer` : `$ARGUMENTS`

## L'outil

Toute la gestion passe par `panel.py` dans le dossier de cette compétence :

```bash
python3 "${CLAUDE_SKILL_DIR}/panel.py" <command>
```

Ci-dessous, `PANEL` désigne exactement cela. Si le chemin n'est pas développé, utilisez
le répertoire de base que Claude Code a affiché pour cette compétence. L'état se trouve
dans `founder/panel/`.

## Étape 1 : le client cible

Rédigez `founder/customer.json` (format : `customer.example.json` dans ce dossier) :

- `business`, et `target` : qui est le client, en une ligne précise.
- `segments` : 2 à 4 groupes avec une part (`share`) et une fourchette de revenus (`income`) [bas, haut].
- `behaviours` : 4 à 8 comportements d'achat avec une part (`share`) et une ligne explicative `how`
  (client fidèle quotidien, chasseur de promos, lit chaque avis, fidèle à un concurrent...).
- `objections` : les 4 à 8 doutes que ce type d'acheteur a réellement.
- `habits` (facultatif) : des éléments de contexte du quotidien qui rendent l'acheteur concret.

Ancrez cela dans du concret. Utilisez ce que l'utilisateur sait de ses clients, et
si `/founder-competitors` a été exécuté, les plaintes dans `founder/competitors.md`. Si
l'utilisateur dispose de données réelles sur ses clients (entretiens, avis, réponses à des
sondages), privilégiez-les à vos suppositions et précisez quelles parties sont des hypothèses.
Présentez le profil à l'utilisateur en quelques lignes et laissez-le le corriger avant de
distribuer les cartes : un mauvais profil client fausse l'ensemble du panel.

## Étape 2 : le pitch

Rédigez `founder/pitch.md` : ce qu'un acheteur verrait concrètement. Le produit, le prix,
où et comment l'obtenir, une éventuelle offre de lancement. Trois à six lignes simples,
aucun superlatif, rien que l'entreprise ne puisse livrer. Chaque acheteur voit exactement cela.

## Étape 3 : distribution et exécution

```bash
PANEL init --customer founder/customer.json --pitch founder/pitch.md --n 100
PANEL prompts
```

`init` distribue les cartes de persona (même graine, mêmes cartes ; la graine est enregistrée).
`prompts` génère un brief par acheteur et les liste par vagues de 10. Pour chaque vague,
envoyez UN SEUL message contenant un appel d'outil Agent par acheteur de cette vague (l'outil
Agent s'appelle Task dans les versions plus anciennes de Claude Code) :

- `subagent_type`: `general-purpose`
- `description`: `panel <id>`
- `prompt`: `Read <brief path> and follow it exactly. It is your whole brief.`

Attendez que la vague entière se termine avant de lancer la suivante. Claude Code exécute
environ 10 appels d'outils à la fois par défaut, donc 100 acheteurs correspondent à 10 vagues.
Après la dernière vague :

```bash
PANEL check      # liste les réponses manquantes ou corrompues
PANEL prompts    # réécrit les briefs uniquement pour celles-ci ; relancez-les une fois
PANEL tally
```

Si un acheteur a affiché son JSON dans sa réponse au lieu d'écrire le fichier (cela arrive),
enregistrez sa réponse avec `PANEL save <id>` en passant la réponse sur stdin ; `save` refuse
tout ce qui n'est pas une réponse valide. Un acheteur qui échoue deux fois est exclu et
comptabilisé dans les résultats. N'écrivez jamais vous-même une réponse pour un acheteur.

Avant une exécution à 100 acheteurs, prévenez l'utilisateur qu'il s'agit de 100 appels de
sous-agents et suggérez `--quick` (20 acheteurs) pour un premier aperçu. Les sous-agents écrivent
chacun un fichier dans `founder/panel/answers/` ; avec le mode de permission par défaut, cela
nécessite une approbation par fichier, suggérez donc le mode d'acceptation automatique des
modifications (Shift+Tab) pour la session.

## Étape 4 : présenter les résultats à l'utilisateur

`PANEL tally` génère `founder/panel/results.md` et `results.json`. Transmettez à l'utilisateur :

1. Le chiffre clé : "40 achètent · 60 passent leur tour" et le taux d'achat.
2. Qui achète et qui n'achète pas : les lignes de segments et de comportements qui divergent le plus.
3. Pourquoi ils passent leur tour : les trois principales raisons avec une citation chacune, telles qu'écrites.
4. Ce qui ferait basculer un non : les réponses les plus fréquentes.
5. Une phrase sur ce qu'il faut modifier avant de dépenser de l'argent, et quelle compétence s'en charge
   (tarification, offre, marketing).

## Limites honnêtes, à mentionner une fois

Ce sont des acheteurs simulés. Ils sont très utiles pour faire émerger des objections, des segments
et des formulations auxquels vous n'aviez pas pensé, mais peu fiables pour prédire la conversion
réelle : les modèles de langage ont tendance à être complaisants, considérez donc le taux d'achat
comme un plafond optimiste. Validez les décisions majeures auprès de vraies personnes (liste d'attente,
pré-vente, page d'atterrissage avec un prix) avant de vous engager financièrement. Ne présentez pas
les citations du panel comme des témoignages clients.

## Le brief que chaque acheteur reçoit

`panel.py` injecte les données de la carte dans un modèle fixe (voir `BRIEF` dans le script) : qui
est l'acheteur (nom, âge, segment, revenu, comportement d'achat, une habitude, le doute qui lui
vient à l'esprit), le pitch au mot près, une consigne de ne pas être complaisant et de ne pas inventer
de faits, ainsi que le JSON exact à écrire : achète (oui/non), volume d'achats le premier mois, un code
de motif, la raison avec ses propres mots, sa principale objection, ce qui le ferait changer d'avis,
et quatre réponses sur le prix (trop bon marché, une bonne affaire, commence à être cher, trop cher).
Ne modifiez jamais un brief pour un acheteur individuel.

## Sortie

`founder/customer.json`, `founder/pitch.md`, `founder/panel/` (cartes, briefs,
réponses, résultats). Ensuite : `/founder-pricing` exploite les réponses sur les prix,
`/founder-offer` et `/founder-marketing` exploitent les objections.
