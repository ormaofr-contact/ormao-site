---
name: yt-script
description: >-
  Rédiger un script de vidéo YouTube à partir d'une idée brute : options d'accroche
  basées sur 21 formules, évaluées, puis le script parlé complet avec indication
  des temps forts de rétention. À utiliser dès que l'utilisateur veut un script vidéo,
  une accroche, une phrase d'ouverture, demande « qu'est-ce que je devrais dire »,
  « écris ma prochaine vidéo », ou s'apprête à enregistrer sans avoir encore ses
  quinze premières secondes.
---

# yt-script

Transformer une idée en un script que l'on regarde jusqu'au bout.

Deux outils se trouvent dans ce dossier et fonctionnent réellement. Utilisez-les. Ne jugez pas l'accroche au pifomètre.

```bash
python3 hookscore.py hooks.txt              # rank your hook options
python3 hookscore.py --hook "one line"      # score a single one
```

## Avant d'écrire

1. Lisez `~/.claude/youtube/voice.md` s'il existe. Il s'agit du profil vocal de l'utilisateur : sa façon de s'exprimer face caméra, les mots qu'il n'utilise jamais, à qui il s'adresse, ce qu'il refusera d'affirmer. S'il n'existe pas, demandez **trois de ses propres vidéos**, lisez-les ou transcrivez-les, déduisez-en la voix, et rédigez le fichier. Un script qui n'adopte pas la bonne voix est pire que pas de script du tout, car l'utilisateur doit le lire à voix haute.
2. N'inventez jamais un chiffre, un résultat ou une source. Si une donnée chiffrée renforcerait le propos et que vous n'en avez pas, demandez-la ou rédigez la phrase sans elle.

## La structure

**Les 15 premières secondes font tout le travail.** Elles accomplissent trois choses, sans quoi la vidéo perd son audience : confirmer le clic promis par le titre, ouvrir une question que le spectateur ne peut pas refermer, et prouver que la promesse sera tenue.

1. **Accroche.** Rédigez CINQ options selon [les 21 formules](hooks.json), passez-les dans `hookscore.py`, conservez les deux meilleures, et montrez les deux à l'utilisateur avec leurs scores. Ne donnez jamais une seule accroche.
2. **Le pivot** (0:15-0:45). Dites ce que la vidéo va faire, en une phrase, et commencez à le faire. Pas d'intro de chaîne, pas de « avant de commencer », pas d'appel à s'abonner. C'est la cause numéro un de la chute d'audience à 0:30.
3. **Le corps.** Une idée par temps fort. Indiquez pour chaque temps fort ce qui est À L'ÉCRAN, pas seulement ce qui est dit — une tête qui parle sans rien à regarder, c'est un podcast.
4. **La récompense.** Livrez explicitement ce que l'accroche a promis, et dites clairement que vous le livrez : « voici le prompt, il est dans la description ».
5. **La conclusion.** Un seul appel à l'action. Pas trois.

## Ce qu'il faut livrer

- les deux meilleures accroches avec leurs grilles d'évaluation
- le script, temps fort par temps fort, avec `[ON SCREEN: ...]` à chaque étape
- l'estimation de durée sur une base de 150 mots par minute
- une ligne précisant la formule utilisée par l'accroche retenue et la raison pour laquelle elle correspond à cette idée

## Le sas de validation

Rien n'est publié directement ici. Cette compétence rédige et vous publiez. Chaque réponse se termine par un bloc que l'utilisateur peut copier, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
