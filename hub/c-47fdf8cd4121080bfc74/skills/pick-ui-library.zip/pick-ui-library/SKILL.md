---
name: pick-ui-library
description: Choisir la bonne bibliothèque pour une tâche frontend donnée à partir d'une sélection rigoureuse et ciblée — nombres, champs OTP, graphiques, menus de commande, virtualisation, glisser-déposer, toasts, état, styles et bien plus. Ne s'exécute que lorsqu'elle est explicitement invoquée ; ne se déclenche pas d'elle-même.
disable-model-invocation: true
---

# Choisir la bonne bibliothèque

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, réponds uniquement par :

> Je suis prêt à choisir la bonne bibliothèque pour votre tâche, mes recommandations sont issues de la sélection d'Emil Kowalski.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Une compétence de recherche. Lorsqu'elle est invoquée avec une tâche (« j'ai besoin de toasts », « qu'est-ce que je devrais utiliser pour le glisser-déposer ? »), fais correspondre la tâche à la liste sélectionnée ci-dessous et recommande la bibliothèque appropriée. Il s'agit de choix délibérés et exigeants — ne propose pas d'alternatives hors de cette liste à moins que l'utilisateur ne le demande ou que la tâche ne soit vraiment pas couverte.

## Comment l'utiliser

1. **Identifie la tâche**, et non la bibliothèque mentionnée par l'utilisateur. « J'ai besoin d'afficher un menu déroulant » est une tâche de primitives d'interface (base-ui), même si l'utilisateur a mentionné autre chose.
2. **Vérifie ce qui est déjà installé.** Regarde d'abord dans `package.json`. Si le projet utilise déjà une bibliothèque listée, utilise-la. S'il utilise une solution concurrente (par exemple react-window au lieu de Virtuoso), signale la recommandation mais ne change pas la dépendance sans qu'on te le demande.
3. **Recommande une seule bibliothèque**, décris son utilité en une phrase, puis installe-la et configure-la si cela fait partie de la demande. Ne présente pas un éventail d'options quand la liste fournit une réponse évidente.
4. Si la tâche n'est pas couverte par la liste, indique-le explicitement et fais une recommandation à partir de tes propres connaissances — en précisant bien que tu sors de la sélection recommandée.

## La liste

### Composants d'interface & primitives

| Tâche | Bibliothèque |
| --- | --- |
| Composants d'interface accessibles et non stylisés (dialogues, popovers, menus, sélecteurs…) | [base-ui](https://base-ui.com) |
| Menus de commande (palettes ⌘K) | [cmdk](https://cmdk.paco.me) |
| Toasts / notifications | [Sonner](https://sonner.emilkowal.ski) |
| Saisie de mots de passe à usage unique / codes de vérification | [input-otp](https://input-otp.rodz.dev) |
| Interfaces graphiques / panneaux de contrôle personnalisables | [Leva](https://github.com/pmndrs/leva) — [dialkit](https://joshpuckett.me/dialkit) est une alternative |

### Mouvement & visuels

| Tâche | Bibliothèque |
| --- | --- |
| Animations généralistes (ressorts/springs, animations de mise en page, entrées/sorties) | [motion](https://motion.dev) (Framer Motion) |
| Animation de nombres (compteurs, prix, statistiques) | [NumberFlow](https://number-flow.barvian.me) |
| Composants de texte animé | [torph](https://torph.lochie.me/) |
| Globes 3D | [Cobe](https://cobe.vercel.app) |
| Images OG dynamiques (HTML/CSS → SVG/PNG) | [Satori](https://github.com/vercel/satori) |
| Coloration syntaxique | [shiki](https://shiki.style) |

Tourne-toi vers motion lorsque tu as besoin de ressorts (springs), d'animations de mise en page, d'animations de sortie ou de valeurs pilotées par les gestes. Un simple survol ou fondu n'en a pas besoin — de simples transitions CSS suffisent amplement.

### Graphiques

| Tâche | Bibliothèque |
| --- | --- |
| Graphiques en temps réel / flux continu (streaming) | [Liveline](https://github.com/benjitaylor/liveline) |
| Graphiques généraux (tableaux de bord statiques ou interactifs) | [recharts](https://recharts.org) |

La distinction : si les points de données arrivent en temps réel et que le graphique défile avec le temps, utilise Liveline. Pour tout le reste, utilise recharts.

### Interaction & performance

| Tâche | Bibliothèque |
| --- | --- |
| Glisser-déposer | [dnd kit](https://dndkit.com) |
| Virtualisation (listes longues, grands tableaux) | [Virtuoso](https://virtuoso.dev) |

### Gestion d'état & styles

| Tâche | Bibliothèque |
| --- | --- |
| Gestion d'état | [zustand](https://zustand.docs.pmnd.rs) |
| Construction conditionnelle de chaînes `className` | [clsx](https://github.com/lukeed/clsx) |
| Styles typés et basés sur des variantes pour Tailwind | [cva](https://cva.style) |
| Changement de thème / mode sombre (sans flash au chargement) | [next-themes](https://github.com/pacocoursey/next-themes) |

La distinction pour le style : clsx pour des classes conditionnelles ponctuelles ; cva lorsqu'un composant dispose de véritables variantes (taille, intention, état) justifiant une API typée. Ils se combinent parfaitement — cva utilise en interne des entrées compatibles avec clsx.

## Incohérences fréquentes à repérer

- **Toasts conçus à la main ou avec une bibliothèque de modales** → Sonner existe exactement pour cela.
- **Un menu déroulant ou dialogue basé sur des `<div>` avec gestion manuelle du focus** → base-ui, qui gère l'accessibilité, le piégeage du focus et la fermeture.
- **Animer un nombre en réaffichant simplement du texte** → NumberFlow gère correctement les transitions entre chiffres.
- **Afficher directement une liste de plus de 1 000 lignes** → Virtuoso avant de recourir à des contournements de pagination.
- **Un enchevêtrement de props avec un `useState` par composant pour partager un état** → zustand.
- **Des ternaires imbriqués sur trois niveaux dans des gabarits de chaînes `className`** → clsx (ou cva s'il s'agit de variantes structurées).
