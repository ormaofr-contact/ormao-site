---
name: career-changer-translator
description: Transposer les compétences d'un secteur à un autre, identifier les compétences transférables
---

# Traducteur pour reconversion professionnelle

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Change de carrière ou de secteur d'activité
- Souhaite valoriser et adapter son expérience pour un nouveau domaine
- A besoin d'aide pour identifier ses compétences transférables
- Mentionne : « reconversion professionnelle », « changer de voie », « nouveau secteur », « compétences transférables », « pivot »

## Capacités principales

- Identifier les compétences transférables entre différents secteurs
- Traduire l'expérience dans le jargon du nouveau secteur
- Reformuler les réalisations pour les postes ciblés
- Combler stratégiquement les écarts de compétences
- Positionner positivement les transitions de carrière
- Élaborer un récit de transition convaincant

## Le défi de la reconversion professionnelle

**Pourquoi les reconversions sont difficiles :**
- L'expérience ne correspond pas directement au nouveau poste
- Manque de mots-clés propres au secteur ciblé
- Les recruteurs privilégient les profils « sans risque »
- Nécessité d'expliquer le « pourquoi » de manière convaincante
- Concurrence directe avec des candidats ayant déjà de l'expérience dans le domaine

**La solution :**
- Mettre l'accent sur les compétences transférables
- Adopter le vocabulaire du nouveau secteur
- Mettre à profit les expériences connexes
- Développer des expériences passerelles
- Raconter une histoire captivante

## Cadre des compétences transférables

### Compétences transférables universelles

**Leadership et gestion**
- Direction d'équipe
- Gestion de projet
- Suivi budgétaire
- Planification stratégique
- Gestion de la performance
- Gestion des parties prenantes

**Communication**
- Compétences de présentation
- Communication écrite
- Relations clients
- Collaboration transverse
- Négociation
- Résolution de conflits

**Analyse**
- Analyse de données
- Résolution de problèmes
- Recherche et veille
- Amélioration des processus
- Prise de décision
- Pensée stratégique

**Technique / Opérationnel**
- Conception de processus
- Déploiement de systèmes
- Assurance qualité
- Formation et développement
- Gestion des prestataires
- Gestion des opérations

## Exemples de transposition pour reconversion

### Enseignant → Formateur d'entreprise / L&D

**Expérience en enseignement :**
- « A enseigné à 25 élèves dans une classe de CM2 »

**Transposé :**
- « Conception et animation d'un programme de formation pour 25 apprenants, atteignant 95 % de réussite aux évaluations standardisées grâce à une pédagogie différenciée et des stratégies d'intervention basées sur les données »

**Transpositions clés :**
| Terme dans l'enseignement | Terme en entreprise |
|--------------------------|---------------------|
| Plans de cours | Programme de formation / Curriculum |
| Élèves | Apprenants |
| Gestion de classe | Facilitation / Animation de groupe |
| Réunions parents-professeurs | Communication avec les parties prenantes |
| Évaluations | Évaluations des acquis |
| PAI / PPS | Plans de développement individuels |

### Militaire → Entreprise

**Expérience militaire :**
- « Commandement d'un peloton de 30 soldats en opérations de combat »

**Transposé :**
- « Direction d'une équipe pluridisciplinaire de 30 personnes lors d'opérations à forts enjeux en environnements incertains, gestion d'un parc d'équipements de 2 M$ et taux de réussite des missions de 100 % »

**Transpositions clés :**
| Terme militaire | Terme en entreprise |
|----------------|---------------------|
| Peloton / Unité | Équipe / Département |
| Mission | Projet / Initiative |
| Opérations | Programmes / Opérations |
| Renseignement (Intel) | Données / Veille analytique |
| Briefing | Présentation / Réunion de cadrage |
| Commandement | Leadership / Direction |
| Déploiement | Déploiement / Mise en œuvre |

### Commerce de détail → Vente / Gestion de comptes (Account Management)

**Expérience en commerce de détail :**
- « Vente de produits aux clients et atteinte des objectifs de vente »

**Transposé :**
- « Dépassement systématique des objectifs de vente à 125 %, générant 500 k$ de chiffre d'affaires annuel grâce à la vente consultative et à la fidélisation de plus de 50 clients réguliers »

**Transpositions clés :**
| Terme dans le retail | Terme en entreprise |
|---------------------|---------------------|
| Clients | Clients / Grands comptes |
| Ventes en magasin | Génération de chiffre d'affaires |
| Service client | Gestion de la relation client / Account management |
| Vente incitative (Upselling) | Vente croisée (Cross-selling) |
| Retours produits | Résolution de litiges / réclamations |
| Merchandising visuel | Présentation de la marque |

### Hôtellerie → Customer Success

**Expérience en hôtellerie :**
- « Gestion de la réception et traitement des réclamations clients »

**Transposé :**
- « Interlocuteur principal pour plus de 100 clients quotidiens, résolution des incidents remontés avec un taux de satisfaction de 95 % et mise en place de processus de recueil de feedback ayant amélioré le NPS de 15 points »

**Transpositions clés :**
| Terme en hôtellerie | Terme en entreprise |
|--------------------|---------------------|
| Clients / Hôtes | Clients / Comptes |
| Réservations | Gestion de portefeuille / comptes |
| Satisfaction client | Customer success / Réussite client |
| Réclamations | Escalades / Incidents critiques |
| Conciergerie | Support client / Assistance |
| Organisation d'événements | Gestion de projet |

### Santé → Tech / Industrie pharmaceutique

**Expérience en santé :**
- « Prise en charge des patients et tenue des dossiers médicaux »

**Transposé :**
- « Prise en charge individualisée de plus de 20 patients par jour, respect strict des protocoles de conformité (HIPAA) et utilisation d'outils de DME/EMR (Epic) pour une documentation rigoureuse et la coordination des soins »

**Transpositions clés :**
| Terme dans la santé | Terme en entreprise |
|--------------------|---------------------|
| Soins aux patients | Service client / Relation client |
| EMR / EHR (Dossier médical) | Outils CRM / Systèmes de bases de données |
| Coordination des soins | Coordination de projet |
| Protocoles cliniques | Procédures opérationnelles standard (SOP) |
| Résultats thérapeutiques | Indicateurs de performance (KPI) |
| Visites / Rondes | Points d'avancement / Réunions de suivi |

## Stratégie de CV pour reconversion

### 1. Commencer par une accroche axée sur les compétences transférables

**Format :**
« Professionnel de [Poste visé] avec [X] années d'expérience en [compétence transférable]. Mon parcours en [domaine précédent] m'apporte une perspective unique sur [aspect pertinent]. Compétences reconnues en [compétence transférable 1], [compétence transférable 2] et [compétence transférable 3]. »

**Exemple (Enseignant → L&D) :**
« Professionnel de la formation et du développement (L&D) fort de 8 ans d'expérience dans la conception et l'animation de programmes pédagogiques pour des publics variés. Mon parcours dans l'enseignement m'apporte une expertise approfondie en sciences de l'apprentissage, en ingénierie d'évaluation et en pédagogie pour adultes. Compétences en ingénierie pédagogique, en facilitation et en mesure de l'efficacité pédagogique. »

### 2. Adopter un format de CV fonctionnel ou mixte (hybride)

**Structure :**
```
Professional Summary (targeted)
Core Competencies (transferable skills)
Relevant Experience (grouped by skill)
Additional Experience (chronological)
Education & Certifications
```

**Regrouper par fonction transférable :**
```
PROJECT MANAGEMENT EXPERIENCE
[Bullet from Job 1]
[Bullet from Job 2]
[Bullet from Job 3]

LEADERSHIP & TEAM DEVELOPMENT
[Bullet from Job 1]
[Bullet from Job 2]

CLIENT RELATIONSHIP MANAGEMENT
[Bullet from Job 1]
[Bullet from Job 2]
```

### 3. Développer des expériences passerelles

**Manières d'acquérir de l'expérience pertinente :**
- Bénévolat dans le domaine ciblé
- Missions en freelance ou projets de conseil
- Certifications pertinentes
- Projets personnels (side projects)
- Associations professionnelles
- Formations et cours spécialisés

**Exemple :**
```
BRIDGE EXPERIENCE

Volunteer Marketing Lead | Nonprofit XYZ | 2023-Present
- Designed social media strategy increasing engagement by 150%
- Created content calendar and managed 3 volunteer content creators

Google Digital Marketing Certificate | 2023
- Completed 200+ hour program covering SEO, SEM, Analytics, and Social Media
```

## Répondre à la question du « Pourquoi »

**On vous demandera :** « Pourquoi souhaitez-vous changer de voie ? »

**Bonnes raisons :**
- Évolution naturelle de vos centres d'intérêt
- Découverte d'une passion par la pratique ou la découverte
- Une expérience précise qui a déclenché votre intérêt
- Des compétences qui se transposent naturellement
- Des évolutions sectorielles qui ont nourri votre réflexion
- Recherche d'opportunités d'évolution indisponibles dans votre parcours actuel

**Mauvaises raisons (à ne pas dire) :**
- « Je suis en plein burn-out »
- « Je déteste mon travail actuel »
- « Je veux gagner plus d'argent »
- « Ça a l'air plus facile »

### Structure du récit (Story Framework)

```
[DISCOVERY]: "Through [experience], I discovered my passion for [new field]..."

[CONNECTION]: "I realized that my experience in [old field] gave me a unique perspective on [new field] because..."

[ACTION]: "To prepare for this transition, I've [certifications, projects, volunteering]..."

[VISION]: "I'm excited to bring my [transferable skill] expertise to [target company/industry] because..."
```

## Pistes de reconversion par secteur

### Vers la tech

**Meilleures portes d'entrée :**
- Customer Success (depuis tout rôle en contact avec la clientèle)
- Chef de projet technique (depuis tout rôle de gestion de projet)
- Vente / Account Executive (depuis tout rôle commercial)
- Product Management (en s'appuyant sur une expertise métier)
- Rédacteur technique (depuis tout rôle rédactionnel)

**Activités passerelles :**
- Apprendre SQL, les bases de la programmation ou des outils pertinents
- Obtenir des certifications (Google, Salesforce, AWS)
- Réaliser des projets personnels
- Participer à des meetups tech
- Faire du bénévolat au sein d'associations tech

### Vers la finance

**Meilleures portes d'entrée :**
- Opérations (depuis tout rôle axé sur les processus)
- Conformité (depuis tout secteur réglementé)
- Service client (depuis des rôles relationnels)
- Analyse (depuis tout rôle analytique)

**Activités passerelles :**
- Certifications sur Excel / modélisation financière
- Préparation au CFA ou CFP
- Cours d'analyse financière
- Réseautage dans le secteur

### Vers la santé

**Meilleures portes d'entrée :**
- Administration de santé (depuis tout rôle administratif)
- Vente médicale / Délégué médical (depuis tout rôle commercial)
- Informatique médicale / Health IT (depuis tout rôle technique)
- Défense des droits des patients / Patient Advocacy (depuis le service client)

**Activités passerelles :**
- Certifications du secteur de la santé
- Formations aux protocoles de confidentialité (HIPAA / RGPD santé)
- Acquisition de connaissances sur l'écosystème de santé
- Bénévolat dans les hôpitaux ou établissements de soins

## Format de sortie

Pour accompagner une personne en reconversion :

```markdown
# CAREER CHANGE TRANSLATION

## Current Background
**Field:** [Current industry]
**Role:** [Current function]
**Years:** [Experience]

## Target
**Field:** [Target industry]
**Role:** [Target function]

## Transferable Skills Identified
1. [Skill] → Relevant because: [explanation]
2. [Skill] → Relevant because: [explanation]
3. [Skill] → Relevant because: [explanation]

## Translation Guide

### Experience Reframes

**Original:** "[Their current bullet]"
**Translated:** "[Reframed for target industry]"
**Key changes:** [What was changed and why]

[Repeat for key bullets]

### Language Translations
| Your Current Language | Target Industry Language |
|----------------------|--------------------------|
| [Term] | [Translated term] |
| [Term] | [Translated term] |

## Gap Analysis

**Skills to Develop:**
- [Gap] → Suggestion: [How to bridge]
- [Gap] → Suggestion: [How to bridge]

**Bridge Experiences to Consider:**
- [Suggestion]
- [Suggestion]

## Your Career Change Story

[Draft of their "why" narrative]

## Recommended Resume Structure
[Guidance on format and organization]
```

## Rappels essentiels

1. **Mettre en avant les compétences transférables**, et non les intitulés de poste
2. **Employer le vocabulaire du secteur ciblé** – transposer chaque élément
3. **Créer des passerelles** – acquérir toute forme d'expérience dans le secteur visé
4. **Raconter une histoire convaincante** – donner du sens à la transition
5. **Mettre l'accent sur la valeur ajoutée** – votre perspective unique est un atout
6. **Lever les doutes de manière proactive** – ne laissez pas le recruteur s'interroger sur le « pourquoi »
7. **Développer son réseau dans le secteur visé** – la recommandation est le meilleur levier pour une reconversion
