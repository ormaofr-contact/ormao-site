---
name: frontend-design
description: Conseils pour concevoir un design visuel distinctif et intentionnel lors de la création d'une nouvelle interface utilisateur ou de la refonte d'une interface existante. Aide à définir la direction esthétique, la typographie et à faire des choix qui évitent l'aspect générique ou standardisé.
license: Complete terms in LICENSE.txt
---

# Design Frontend

Aborde cette tâche comme le directeur artistique d'un studio de design réputé pour offrir à chaque client une identité visuelle unique, impossible à confondre avec une autre. Ce client a déjà rejeté des propositions jugées clichées ou standardisées, et il paie pour un point de vue singulier : fais des choix délibérés et affirmés concernant la palette, la typographie et la mise en page, spécifiques à ce brief, et prends des risques esthétiques si cela est justifié.

## Ancre tes designs dans le sujet réel

Si le brief n'indique pas quel est le produit ou le sujet, identifie-le toi-même avant de concevoir, et confirme-le auprès du client. Tu peux proposer un sujet concret, le public cible du design et son objectif principal en guise de point de départ. Si ta mémoire contient des informations sur les préférences du client ou le contexte de son projet, utilise-les comme indices. C'est dans le secteur d'activité, le sujet, les matériaux et le vocabulaire propre au domaine que naissent les choix visuels distinctifs — le design d'un jouet pour des filles de 8 à 11 ans sera esthétiquement très différent d'un tableau de bord pour des analystes financiers. Conçois d'un bout à l'autre en intégrant le contenu réel et le sujet du brief.

## Principes de design

Pour les designs web, le hero est le premier élément que les visiteurs verront. Ouvre avec l'élément le plus emblématique de l'univers du sujet, sous la forme la plus pertinente : un titre fort, une image, une animation, une démonstration interactive, un moment immersif ou d'autres approches. Fais ton choix de manière délibérée : un grand chiffre accompagné d'un petit libellé, de statistiques secondaires et d'un accent en dégradé représente le traitement générique par défaut ; ne l'utilise que si c'est véritablement la meilleure option.

La typographie porte la personnalité de la page. Nul besoin d'une police différente pour les titres/textes d'accroche et le corps de texte : utilise une ou deux familles, et si tu en utilises deux, veille à ce qu'elles soient nettement distinctes.

Choisis tes polices avec soin, pas les familles habituelles vers lesquelles tu te tournerais sur n'importe quel autre projet, et établis une échelle typographique claire en suivant les recommandations de *The Elements of Typographic Style*, avec des graisses, des chasses et des espacements intentionnels. Lorsque la typographie sert de titre ou d'élément visuel, traite-la comme un acteur à part entière de la composition, et non comme un simple véhicule neutre pour le contenu.

Par défaut, limite les longueurs de ligne à moins de 80 caractères. Les polices à empattements (serif) tolèrent des longueurs de ligne légèrement supérieures ; accorde au corps de texte en serif une hauteur de ligne (`line-height`) un peu plus généreuse qu'à un sans-serif.

Évite ces automatismes typographiques par défaut, qui sont les marqueurs les plus évidents d'une page générée par IA :
- Mettre en valeur un seul mot ou une seule expression dans un titre, par exemple en passant un mot en italique/gras ou dans une autre couleur.
- Utiliser les majuscules intégrales (tout en capitales) pour les étiquettes.
- Ajouter des surtitres typographiques superflus au-dessus du contenu.

La structure visuelle est de l'information. Les artifices structurels comme les contours, les bordures, la numérotation, les surtitres, les séparateurs, les étiquettes, etc., transmettent une information utile sur le contenu plutôt que de simplement le décorer. Beaucoup de designs génériques utilisent des marqueurs numérotés (01 / 02 / 03), mais cela n'a de sens que si le contenu forme réellement une séquence — comme les étapes d'un processus ou une chronologie. Avant d'ajouter des marqueurs chiffrés, assure-toi que le contenu constitue véritablement une séquence.

Utilise les animations non déclenchées par l'utilisateur avec parcimonie et de façon délibérée, uniquement pour attirer l'attention. Un moment orchestré unique — une seule séquence au chargement de la page ou une seule révélation progressive — aura bien plus d'impact qu'une constellation d'effets dispersés ; les apparitions en fondu glissant vers le haut sur chaque section et les transitions au survol sur chaque carte sont le cliché par défaut et trahissent une génération par IA. En revanche, le mouvement qui répond à l'action d'une personne (ouvrir, déployer, confirmer) est bienvenu dès lors qu'il illustre ce qui a changé.

Porte une attention rigoureuse aux textes. Souvent, un brief de design ne contient pas de texte réel, et c'est à toi de concevoir les rédactions et le contenu de substitution. Un texte générique peut donner à un design une allure tout aussi standardisée que le graphisme lui-même. Consulte la section ci-dessous consacrée à la rédaction pour plus de précisions.

## Méthode : planifier, confronter au brief, concevoir, critiquer

À titre de repère, les designs générés par IA convergent actuellement autour de plusieurs tics récurrents :
1. un arrière-plan crème chaud (proche de #F4F1EA) avec une police serif à fort contraste pour les titres et une touche terracotta ou argile chaude (souvent proche de #D97757 — l'accent propre à l'interface Claude d'Anthropic, qui apparaît donc sur le brief d'un utilisateur comme une signature évidente) ;
2. un arrière-plan presque noir avec une unique touche vert acide vif ou vermillon ;
3. une mise en page style grand format de presse (broadsheet) avec des filets ultra-fins, aucun arrondi d'angle (`border-radius: 0`) et des colonnes denses façon journal papier ;
4. le kit de cartes SaaS classique : un contenu découpé en cartes arrondies identiques, un même rayon d'arrondi sur tout indépendamment de la hiérarchie, la même ombre portée douce et grise (`rgba(0,0,0,.1)`) sous chaque élément, et des voiles en dégradé comme décoration ;
5. des éléments d'habillage standardisés qui surgissent quel que soit le sujet : un surtitre en TOUT EN CAPITALES avec un interlettrage forcé au-dessus de chaque titre ; des suites de métadonnées reliées par des points médians (« A · B · C ») ; des étiquettes formatées comme « MOT — fragment » avec un tiret cadratin espacé ; un faux noir teinté (#0B0B0B, #111) substitué au noir pur ; une police à chasse fixe (monospace) pour les petits libellés de données ; une flèche « → » systématiquement accolée aux textes des liens et des boutons.

Chacun de ces traits peut être légitime pour certains briefs, mais ce sont des automatismes plutôt que de vrais choix, et ils apparaissent indistinctement quel que soit le sujet. Lorsque le brief impose une direction visuelle, respecte-la scrupuleusement — les mots du brief priment toujours, y compris s'il réclame l'une de ces esthétiques. En revanche, là où le brief laisse de la liberté, ne gaspille pas cette latitude dans l'un de ces stéréotypes. Tout comme pour un designer humain, l'équilibre consiste à exploiter ses forces tout en abordant chaque projet comme une occasion d'expérimenter et d'apprendre.

Travaille en deux temps. D'abord, élabore un plan de design synthétique fondé sur le brief du client : crée un système de design tokens compact comprenant la couleur, la typographie, la mise en page et les principes directeurs.
- Couleur : décris la palette principale à travers 4 à 6 valeurs hexadécimales nommées.
- Typographie : les polices retenues et leurs rôles respectifs.
- Mise en page : un concept d'agencement, formulé par des descriptions d'une phrase et des maquettes filaires en ASCII pour concevoir et comparer. Inclus des directives d'alignement : le contenu doit-il être aligné à gauche, centré, justifié ?
- Principes : les grandes lignes directrices qui rendent cette page unique.

Confronte ensuite ce plan au brief avant de passer au code : si la moindre composante ressemble au modèle par défaut que tu produirais pour n'importe quelle page similaire (imagine une consigne équivalente pour vérifier si tu obtiendrais un résultat semblable) plutôt qu'à un parti pris conçu pour ce brief spécifique, révise cette partie, puis explicite ce que tu as modifié et pourquoi. C'est seulement après avoir validé le caractère distinctif de ton plan que tu dois commencer à écrire le code, en suivant ce plan révisé.

Lors de la rédaction du code, fais particulièrement attention à la gestion de la spécificité de tes sélecteurs CSS. Il est fréquent de générer des classes CSS qui s'annulent mutuellement (notamment entre un sélecteur de type comme `.section` et un sélecteur d'élément comme `.cta`). Ce problème survient régulièrement avec les marges internes et externes (`padding`/`margin`) entre les sections.

## Sobriété et autocritique

Place ton audace au bon endroit. Fais en sorte qu'un seul élément soit véritablement mémorable, garde tout le reste sobre et discipliné, et supprime tout ornement qui ne sert pas le brief. Atteins un niveau de qualité irréprochable sans l'annoncer : responsive jusqu'au mobile, indicateur de focus clavier visible, respect de la préférence de réduction de mouvement (`prefers-reduced-motion`), accessibilité visuelle, palettes chromatiques harmonieuses. Porte un regard critique sur ton travail au fil de la réalisation, en prenant des captures d'écran pour évaluer le rendu si ton environnement le permet — une image vaut mille tokens. Retiens le conseil de Coco Chanel : avant de sortir, regarde-toi dans le miroir et retire un accessoire. Les créateurs humains possèdent une mémoire et cherchent constamment à se renouveler ; disposer d'un espace pour noter rapidement les pistes déjà explorées t'évitera de te répéter lors des prochaines itérations.

## Approfondir la rédaction dans le design

Les mots n'ont qu'une seule raison d'exister dans un design : faciliter la compréhension et l'usage. Ils font partie intégrante du contenu du design, ce ne sont pas des ornements. Applique au copywriting la même intentionnalité et la même exigence de sobriété qu'aux espacements et à la couleur. Avant d'écrire quoi que ce soit, demande-toi ce que l'interface a besoin d'exprimer et quelle est la meilleure manière de le formuler pour guider la personne dans son parcours.

Adopte le point de vue de l'utilisateur final. Nomme les éléments en utilisant des termes clairs et immédiatement compréhensibles pour lui, et non selon l'architecture technique du système. Un utilisateur gère des notifications, pas une configuration de webhooks. Décris la nature ou la fonction d'un élément avec des mots simples plutôt qu'avec un argumentaire commercial. La précision et la clarté pour un nouvel arrivant l'emportent toujours sur les formules d'esprit.

Privilégie la voix active par défaut. Un bouton d'appel à l'action (CTA) indique précisément ce qui se passe lorsqu'on clique dessus : « Enregistrer les modifications », et non « Soumettre ». Une action conserve le même intitulé d'un bout à l'autre du parcours : ainsi, le bouton « Publier » déclenche une notification éphémère (toast) indiquant « Publié ». Le lexique d'une interface constitue la signalétique de l'utilisateur dans le produit. C'est grâce à la cohérence et à la continuité des termes que l'on s'oriente naturellement.

Considère les erreurs et les états vides comme des opportunités de guidage, et non comme de simples nuances d'ambiance. Explique ce qui ne s'est pas déroulé comme prévu et la manière d'y remédier, avec la voix propre à l'interface plutôt qu'avec un ton artificiellement humain. Les messages d'erreur ne s'excusent pas et restent précis sur la cause. Un écran vide est une invitation à agir.

Conserve un ton direct et naturel : des verbes simples, une casse de phrase standard (majuscule uniquement en début de phrase), aucun mot superflu, le tout accordé à la marque et à son public. Assure-toi que chaque élément rédigé n'accomplisse qu'une seule fonction bien précise.
