---
name: yt-retention
description: >-
  Lit un export de rétention de l'audience de YouTube Studio pour identifier où
  les spectateurs décrochent réellement, puis indique quoi modifier. À utiliser
  pour « pourquoi les gens arrêtent de regarder », « ma rétention est
  mauvaise », un graphique de rétention ou un CSV collé, ou « corrige mon
  rythme ».
---

# yt-retention

Le graphique de rétention est le seul retour honnête que YouTube vous donne. Presque personne ne l'exporte.

```bash
python3 retention.py retention.csv --duration 600
python3 retention.py retention.csv --transcript transcript.srt
```

Obtenir le fichier : Studio -> une vidéo -> Données d'analyse -> Engagement -> le graphique de rétention de l'audience -> l'icône de téléchargement -> « Rétention de l'audience ».

## Trois problèmes distincts

- **HOOK LEAK (fuite de l'accroche)** - ce qui est perdu dans les 30 premières secondes. En dessous de 25 %, c'est sain. C'est toujours la première chose à corriger et cela concerne toujours les quinze premières secondes du script, jamais le montage.
- **CLIFFS (chutes brutales)** - des baisses abruptes et isolées. Une falaise correspond à un moment précis : un changement de sujet sans annonce claire, un placement de sponsor, une mise en place trop longue. Avec `--transcript`, l'outil affiche ce qui était dit à cet instant, ce qui rend le rapport directement exploitable au lieu d'être simplement intéressant.
- **SLIDE (érosion continue)** - la perte régulière tout au long du milieu de la vidéo. Une érosion plate est une question de rythme. La solution consiste à couper, pas à réécrire.

## Ce qu'il faut renvoyer

Identifiez la plus grosse fuite et un seul changement pour y remédier. Pas une liste de cinq. Ensuite, seulement si on vous le demande, donnez le reste. Et si la fuite de l'accroche est saine et que l'érosion reste stable, dites que la vidéo va très bien et que le problème vient du packaging — redirigez-les vers `/yt-package`.

## Le point de contrôle

Rien n'est publié d'ici. Cette compétence rédige et vous publiez. Chaque réponse se termine par un bloc que l'utilisateur copie, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
