---
name: to-tickets
description: Découpe un plan, une spécification ou la conversation actuelle en un ensemble de tickets tracer-bullet, chacun déclarant ses dépendances bloquantes, publiés sur le gestionnaire configuré (dépendances sous forme de texte dans un fichier par ticket en local, ou liens bloquants natifs sur un véritable gestionnaire).
disable-model-invocation: true
---

# To Tickets

Découpe un plan, une spécification ou une conversation en un ensemble de **tickets** : des tranches verticales de type *tracer bullet*, chacune déclarant les tickets qui la **bloquent**.

Le gestionnaire de tickets et le vocabulaire des étiquettes de triage devraient vous avoir été fournis. Si ce n'est pas le cas, demandez à l'utilisateur d'exécuter `/setup-matt-pocock-skills`.

## Processus

### 1. Rassembler le contexte

Travaillez à partir de ce qui se trouve déjà dans le contexte de la conversation. Si l'utilisateur transmet une référence (un chemin de spécification, un numéro d'issue ou une URL) en argument, récupérez-la et lisez l'intégralité de son contenu et de ses commentaires.

### 2. Explorer la base de code (optionnel)

Si vous n'avez pas encore exploré la base de code, faites-le pour comprendre l'état actuel du code. Les titres et descriptions de tickets doivent utiliser le vocabulaire du glossaire métier du projet et respecter les ADR dans la zone concernée.

Recherchez des opportunités de pré-refactorisation du code pour faciliter l'implémentation. « Rendez le changement facile, puis faites le changement facile. » (*Make the change easy, then make the easy change.*)

### 3. Ébaucher des tranches verticales

Découpez le travail en tickets de type **tracer bullet**.

<vertical-slice-rules>

- Chaque tranche trace un chemin étroit mais COMPLET à travers toutes les couches (schéma, API, interface utilisateur, tests) : verticale, et NON une tranche horizontale d'une seule couche
- Une tranche terminée est démontrable ou vérifiable de manière autonome
- Chaque tranche est dimensionnée pour tenir dans une seule nouvelle fenêtre de contexte
- Toute pré-refactorisation doit être effectuée en premier

</vertical-slice-rules>

Attribuez à chaque ticket ses **dépendances bloquantes** : les autres tickets qui doivent être terminés avant qu'il ne puisse commencer. Un ticket sans dépendance bloquante peut démarrer immédiatement.

**Les refactorisations larges font exception au découpage vertical.** Une **refactorisation large** est une modification mécanique unique (renommer une colonne, modifier le type d'un symbole partagé) dont le **rayon d'impact** (*blast radius*) s'étend à l'ensemble de la base de code, de sorte qu'une seule modification casse des milliers de points d'appel à la fois et qu'aucune tranche verticale ne peut être intégrée au vert. Ne la forcez pas sous forme de *tracer bullet* ; séquencez-la selon le modèle **expand–contract** (expansion–contraction). D'abord expand : ajoutez la nouvelle forme à côté de l'ancienne afin que rien ne casse. Ensuite, migrez les points d'appel par lots dimensionnés selon le rayon d'impact (par paquet, par répertoire), chaque lot constituant son propre ticket bloqué par l'étape expand, ce qui maintient la CI au vert de lot en lot puisque l'ancienne forme existe toujours. Enfin contract : supprimez l'ancienne forme dès qu'il ne reste plus aucun appelant, dans un ticket bloqué par chaque lot de migration. Lorsque même les lots ne peuvent pas rester au vert isolément, conservez la séquence mais faites-les partager une branche d'intégration qui bloque un ticket final d'intégration et de vérification ; le passage au vert n'est promis qu'à ce niveau.

### 4. Interroger l'utilisateur

Présentez le découpage proposé sous la forme d'une liste numérotée. Pour chaque ticket, indiquez :

- **Titre** : nom court et descriptif
- **Bloqué par** : quels autres tickets (le cas échéant) doivent être terminés en premier
- **Ce qu'il livre** : le comportement de bout en bout que ce ticket rend fonctionnel

Demandez à l'utilisateur :

- La granularité semble-t-elle adéquate ? (trop grossière / trop fine)
- Les dépendances bloquantes sont-elles correctes : chaque ticket ne dépend-il que des tickets qui le bloquent réellement ?
- Certains tickets devraient-ils être fusionnés ou divisés davantage ?

Itérez jusqu'à ce que l'utilisateur approuve le découpage.

### 5. Publier les tickets sur le gestionnaire configuré

Publiez les tickets approuvés. La **méthode** dépend du gestionnaire configuré par `/setup-matt-pocock-skills` ; les tickets sont identiques dans les deux cas, seule la forme des dépendances bloquantes change :

- **Fichiers locaux** → écrivez un fichier par ticket sous `.scratch/<feature-slug>/issues/<NN>-<slug>.md`, numéroté à partir de `01` dans l'ordre de dépendance (les bloqueurs en premier). La mention « Bloqué par » de chaque fichier liste les numéros/titres dont il dépend. Utilisez le modèle de fichier par ticket ci-dessous : un ticket par fichier, jamais un seul fichier combiné.
- **Un véritable gestionnaire de tickets (GitHub, Linear, …)** → publiez une issue par ticket dans l'ordre de dépendance (les bloqueurs en premier) afin que les dépendances bloquantes de chaque ticket puissent référencer des identifiants réels. Utilisez la relation de blocage native de la plateforme lorsqu'elle existe ; sinon, définissez le champ « Bloqué par » de chaque ticket avec les issues bloquantes. Si la source était une issue existante, faites de chaque ticket une sous-issue de celle-ci (selon l'opération du gestionnaire). Appliquez l'étiquette de triage `ready-for-agent` sauf instruction contraire ; les tickets sont, par construction, prêts à être pris en charge par un agent.

Travaillez sur la **frontière** : tout ticket dont tous les bloqueurs sont terminés. Pour une chaîne purement linéaire, cela signifie de haut en bas.

Ne fermez et ne modifiez AUCUNE issue parente.

<local-ticket-template>

# <NN>: <Titre du ticket>

**Ce qu'il faut construire :** le comportement de bout en bout que ce ticket rend fonctionnel, du point de vue de l'utilisateur, et non une liste d'implémentation couche par couche.

**Bloqué par :** les numéros/titres des tickets qui bloquent celui-ci, ou "None (can start immediately)".

**Statut :** ready-for-agent

- [ ] Critère d'acceptation 1
- [ ] Critère d'acceptation 2

</local-ticket-template>

<issue-template>

## Parent

Une référence à l'issue parente sur le tracker (si la source était une issue existante, sinon omettez cette section).

## Ce qu'il faut construire

Le comportement de bout en bout que ce ticket rend fonctionnel, du point de vue de l'utilisateur, et non une implémentation couche par couche.

## Critères d'acceptation

- [ ] Critère 1
- [ ] Critère 2

## Bloqué par

- Une référence à chaque ticket bloquant, ou "None (can start immediately)". Omettez cette section lorsque les bloqueurs ont été configurés en tant que dépendances natives.

</issue-template>

Dans les deux formats, évitez les chemins de fichiers spécifiques ou les extraits de code : ils deviennent rapidement obsolètes. Exception : si un prototype a produit un extrait qui formalise une décision plus précisément que du texte brut (machine à états, reducer, schéma, structure de type), intégrez-le directement et mentionnez brièvement qu'il provient d'un prototype. Réduisez-le aux parties riches en décisions, sans en faire une démo fonctionnelle, seulement les éléments essentiels.
