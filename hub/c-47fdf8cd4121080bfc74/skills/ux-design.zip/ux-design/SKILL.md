---
name: design
description: "Compétence de design complète : identité de marque, design tokens, style d'interface utilisateur, génération de logos (55 styles, IA Gemini, Atlas Cloud ou MuAPI), programme d'identité d'entreprise (50 livrables, maquettes CIP), présentations HTML (Chart.js), conception de bannières (22 styles, réseaux sociaux/publicités/web/print), création d'icônes (15 styles, SVG, Gemini 3.1 Pro), photos pour réseaux sociaux (HTML→capture d'écran, multiplateforme). Actions : concevoir un logo, créer un CIP, générer des maquettes, créer des diapositives, concevoir une bannière, générer une icône, créer des photos pour réseaux sociaux, images pour réseaux sociaux, identité de marque, design system. Plateformes : Facebook, Twitter, LinkedIn, YouTube, Instagram, Pinterest, TikTok, Threads, Google Ads."
argument-hint: "[design-type] [context]"
license: MIT
metadata:
  author: claudekit
  version: "2.1.0"
---

# Design

Compétence de design unifiée : marque, tokens, UI, logo, CIP, diapositives, bannières, photos pour réseaux sociaux, icônes.

## Quand l'utiliser

- Identité de marque, tonalité, ressources
- Tokens et spécifications de design system
- Style d'interface utilisateur avec shadcn/ui + Tailwind
- Conception et génération de logos par IA
- Livrables de programme d'identité d'entreprise (CIP)
- Présentations et pitch decks
- Conception de bannières pour réseaux sociaux, publicités, web, print
- Photos pour réseaux sociaux destinées à Instagram, Facebook, LinkedIn, Twitter, Pinterest, TikTok

## Routage des sous-compétences

| Tâche | Sous-compétence | Détails |
|-------|-----------------|---------|
| Identité de marque, tonalité, ressources | `brand` | Sous-compétence sœur intégrée |
| Tokens, spécifications, variables CSS | `design-system` | Sous-compétence sœur intégrée |
| shadcn/ui, Tailwind, code | `ui-styling` | Sous-compétence sœur intégrée |
| Création de logo, génération par IA | Logo (intégré) | `references/logo-design.md` |
| Maquettes CIP, livrables | CIP (intégré) | `references/cip-design.md` |
| Présentations, pitch decks | Slides (intégré) | `references/slides.md` |
| Bannières, couvertures, en-têtes | Banner (intégré) | `references/banner-sizes-and-styles.md` |
| Images/photos pour réseaux sociaux | Social Photos (intégré) | `references/social-photos-design.md` |
| Icônes SVG, ensembles d'icônes | Icon (intégré) | `references/icon-design.md` |

## Chemins des scripts

Les chemins de scripts dans cette compétence et ses `references/` sont relatifs au répertoire contenant ce fichier SKILL.md, et non au projet : `scripts/<file>` correspond au propre dossier `scripts/` de cette compétence, et `../<skill>/scripts/<file>` correspond à une sous-compétence sœur installée à ses côtés. Construisez le chemin complet à partir de ce répertoire (Claude Code l'indique comme répertoire de base de la compétence lors de son chargement) et conservez le répertoire de travail à la racine du projet — les scripts lisent et écrivent des fichiers de projet tels que `docs/brand-guidelines.md`, `assets/design-tokens.json` ou `src/` par rapport à celui-ci.

## Conception de logos (Intégré)

Plus de 55 styles, 30 palettes de couleurs, 25 guides sectoriels. Génération d'images avec Gemini Nano Banana, Atlas Cloud et MuAPI.

### Logo : Générer un brief de conception

```bash
python3 scripts/logo/search.py "tech startup modern" --design-brief -p "BrandName"
```

### Logo : Rechercher des styles/couleurs/secteurs

```bash
python3 scripts/logo/search.py "minimalist clean" --domain style
python3 scripts/logo/search.py "tech professional" --domain color
python3 scripts/logo/search.py "healthcare medical" --domain industry
```

### Logo : Générer avec l'IA

Générez **TOUJOURS** les images de logo finales avec un fond blanc.

```bash
python3 scripts/logo/generate.py --brand "TechFlow" --style minimalist --industry tech
python3 scripts/logo/generate.py --prompt "coffee shop vintage badge" --style vintage
python3 scripts/logo/generate.py --brand "TechFlow" --provider atlas
python3 scripts/logo/generate.py --brand "TechFlow" --provider muapi
python3 scripts/logo/generate.py --brand "TechFlow" --provider muapi --muapi-model nano-banana-pro
```

**IMPORTANT :** En cas d'échec des scripts, essayez de les corriger directement.

Après la génération, demandez **TOUJOURS** à l'utilisateur s'il souhaite un aperçu HTML via `AskUserQuestion`. Si oui, utilisez la compétence intégrée `ui-ux-pro-max` pour la galerie.

## Conception de CIP (Intégré)

Plus de 50 livrables, 20 styles, 20 secteurs. Gemini Nano Banana (Flash/Pro).

### CIP : Générer un brief

```bash
python3 scripts/cip/search.py "tech startup" --cip-brief -b "BrandName"
```

### CIP : Rechercher des domaines

```bash
python3 scripts/cip/search.py "business card letterhead" --domain deliverable
python3 scripts/cip/search.py "luxury premium elegant" --domain style
python3 scripts/cip/search.py "hospitality hotel" --domain industry
python3 scripts/cip/search.py "office reception" --domain mockup
```

### CIP : Générer des maquettes

```bash
# Avec logo (RECOMMANDÉ)
python3 scripts/cip/generate.py --brand "TopGroup" --logo /path/to/logo.png --deliverable "business card" --industry "consulting"

# Ensemble CIP complet
python3 scripts/cip/generate.py --brand "TopGroup" --logo /path/to/logo.png --industry "consulting" --set

# Modèle Pro (texte en 4K)
python3 scripts/cip/generate.py --brand "TopGroup" --logo logo.png --deliverable "business card" --model pro

# Sans logo
python3 scripts/cip/generate.py --brand "TechFlow" --deliverable "business card" --no-logo-prompt
```

Modèles : `flash` (par défaut, `gemini-2.5-flash-image`), `pro` (`gemini-3-pro-image`). Remplacez les identifiants avec `GEMINI_FLASH_IMAGE_MODEL` / `GEMINI_PRO_IMAGE_MODEL`.

### CIP : Générer la présentation HTML

```bash
python3 scripts/cip/render-html.py --brand "TopGroup" --industry "consulting" --images /path/to/cip-output
```

**Conseil :** Si aucun logo n'existe, utilisez d'abord la section Conception de logos ci-dessus.

## Diapositives (Intégré)

Présentations HTML stratégiques avec Chart.js, design tokens, formules de rédaction.

Chargez `references/slides-create.md` pour le flux de travail de création.

### Diapositives : Base de connaissances

| Sujet | Fichier |
|-------|---------|
| Guide de création | `references/slides-create.md` |
| Modèles de mise en page | `references/slides-layout-patterns.md` |
| Modèle HTML | `references/slides-html-template.md` |
| Rédaction | `references/slides-copywriting-formulas.md` |
| Stratégies | `references/slides-strategies.md` |

## Conception de bannières (Intégré)

22 styles de direction artistique pour réseaux sociaux, publicités, web et print. Ce flux de travail ne nécessite aucun élément extérieur au bundle : `references/banner-sizes-and-styles.md` et la compétence intégrée `ui-ux-pro-max` pour les conseils de style et de palette. La recherche dans le navigateur, la génération d'images et la capture d'écran sont des capacités d'exécution optionnelles ; lorsqu'elles ne sont pas disponibles, utilisez les ressources fournies, des éléments visuels conçus en CSS, ainsi que le flux standard de prévisualisation ou de capture de l'environnement d'exécution.

Chargez `references/banner-sizes-and-styles.md` pour la référence complète des tailles et styles.

### Bannière : Flux de travail

1. **Recueillir les exigences** via `AskUserQuestion` — objectif, plateforme, contenu, marque, style, quantité
2. **Recherche** — Consultez `references/banner-sizes-and-styles.md` et utilisez la compétence intégrée `ui-ux-pro-max` pour des conseils de style et de palette ; si la recherche par navigateur est disponible et autorisée, collectez 3 à 5 références
3. **Conception** — Créez la bannière HTML/CSS aux dimensions exactes de la plateforme ; utilisez les ressources fournies ou des visuels créés en CSS, ou une capacité de génération d'images autorisée si l'environnement d'exécution en fournit une
4. **Exportation** — Capturez le PNG aux dimensions exactes avec la fonctionnalité de navigateur ou de capture d'écran de l'environnement d'exécution ; si non disponible, livrez le code source HTML/CSS et marquez l'exportation PNG comme en attente
5. **Présentation** — Présentez toutes les options côte à côte, effectuez des itérations selon les retours

### Bannière : Référence rapide des formats

| Plateforme | Type | Taille (px) |
|------------|------|-------------|
| Facebook | Couverture | 820 x 312 |
| Twitter/X | En-tête | 1500 x 500 |
| LinkedIn | Personnel | 1584 x 396 |
| YouTube | Bannière de chaîne | 2560 x 1440 |
| Instagram | Story | 1080 x 1920 |
| Instagram | Post | 1080 x 1080 |
| Google Ads | Rectangle moyen | 300 x 250 |
| Site Web | Hero | 1920 x 600-1080 |

### Bannière : Principaux styles artistiques

| Style | Idéal pour |
|-------|------------|
| Minimalist | SaaS, tech |
| Bold Typography | Annonces |
| Gradient | Marques modernes |
| Photo-Based | Lifestyle, e-commerce |
| Geometric | Tech, fintech |
| Glassmorphism | SaaS, applications |
| Neon/Cyberpunk | Gaming, événements |

### Bannière : Règles de conception

- Zones de sécurité : contenu critique dans les 70-80 % centraux
- Un seul CTA par bannière, en bas à droite, hauteur min. de 44px
- 2 polices au maximum, corps de texte min. 16px, titre ≥ 32px
- Texte inférieur à 20 % pour les publicités (pénalisé par Meta)
- Impression : 300 DPI, CMJN, fond perdu de 3 à 5 mm

## Conception d'icônes (Intégré)

15 styles, 12 catégories. Gemini 3.1 Pro Preview génère un résultat textuel SVG.

### Icône : Générer une seule icône

```bash
python3 scripts/icon/generate.py --prompt "settings gear" --style outlined
python3 scripts/icon/generate.py --prompt "shopping cart" --style filled --color "#6366F1"
python3 scripts/icon/generate.py --name "dashboard" --category navigation --style duotone
```

### Icône : Générer des variations par lot

```bash
python3 scripts/icon/generate.py --prompt "cloud upload" --batch 4 --output-dir ./icons
```

### Icône : Export multi-tailles

```bash
python3 scripts/icon/generate.py --prompt "user profile" --sizes "16,24,32,48" --output-dir ./icons
```

### Icône : Meilleurs styles

| Style | Idéal pour |
|-------|------------|
| outlined | Interfaces utilisateur, applications web |
| filled | Applications mobiles, barres de navigation |
| duotone | Marketing, pages de destination |
| rounded | Applications conviviales, santé |
| sharp | Tech, fintech, entreprise |
| flat | Material design, style Google |
| gradient | Marques modernes, SaaS |

**Modèle :** `gemini-3.1-pro-preview` — sortie textuelle uniquement (le SVG est du texte XML). Aucune API de génération d'images n'est requise.

## Photos pour réseaux sociaux (Intégré)

Conception d'images multiplateformes pour réseaux sociaux : HTML/CSS → export par capture d'écran. Utilise les compétences intégrées `ui-ux-pro-max`, `brand` et `design-system` ; l'exportation par capture d'écran s'effectue via Chrome headless, Playwright ou Puppeteer (voir la référence).

Chargez `references/social-photos-design.md` pour les dimensions, modèles et bonnes pratiques.

### Photos pour réseaux sociaux : Flux de travail

1. **Orchestrer** — Suivez les étapes ci-dessous à l'aide de la liste de tâches native de l'environnement d'exécution ; sous-agents parallèles pour le travail indépendant
2. **Analyser** — Analysez le prompt : sujet, plateformes, style, contexte de marque, éléments de contenu
3. **Idéation** — 3 à 5 concepts, présentés via `AskUserQuestion`
4. **Conception** — compétences intégrées `brand` → `design-system` → `ui-ux-pro-max` ; HTML par idée × taille
5. **Exportation** — Capture d'écran Chrome headless, Playwright ou Puppeteer aux dimensions exactes en px (facteur d'échelle de l'appareil 2x lorsque l'outil le supporte ; voir la référence)
6. **Vérification** — Ouvrez les PNG exportés dans un navigateur ou un visualiseur d'images disponible et inspectez-les ; corrigez les problèmes de mise en page/style et réexportez
7. **Rapport** — Résumé dans `plans/reports/` détaillant les décisions de conception
8. **Organisation** — Classez les fichiers de sortie et les rapports dans les répertoires de ressources du projet

### Photos pour réseaux sociaux : Formats clés

| Plateforme | Taille (px) | Plateforme | Taille (px) |
|------------|-------------|------------|-------------|
| Post IG | 1080×1080 | Post FB | 1200×630 |
| Story IG | 1080×1920 | Post X | 1200×675 |
| Carrousel IG | 1080×1350 | LinkedIn | 1200×627 |
| Miniature YT | 1280×720 | Pinterest | 1000×1500 |

## Flux de travail

### Pack complet d'identité de marque

1. **Logo** → `scripts/logo/generate.py` → Générer des variantes de logo
2. **CIP** → `scripts/cip/generate.py --logo ...` → Créer des maquettes de livrables
3. **Présentation** → Charger `references/slides-create.md` → Créer le pitch deck

### Nouveau Design System

1. **Marque** (compétence brand) → Définir les couleurs, la typographie, le ton
2. **Tokens** (compétence design-system) → Créer les couches de tokens sémantiques
3. **Implémentation** (compétence ui-styling) → Configurer Tailwind, shadcn/ui

## Références

| Sujet | Fichier |
|-------|---------|
| Routage du design | `references/design-routing.md` |
| Guide de conception de logo | `references/logo-design.md` |
| Styles de logo | `references/logo-style-guide.md` |
| Couleurs de logo | `references/logo-color-psychology.md` |
| Prompts de logo | `references/logo-prompt-engineering.md` |
| Guide de conception de CIP | `references/cip-design.md` |
| Livrables CIP | `references/cip-deliverable-guide.md` |
| Styles CIP | `references/cip-style-guide.md` |
| Prompts CIP | `references/cip-prompt-engineering.md` |
| Création de diapositives | `references/slides-create.md` |
| Mises en page de diapositives | `references/slides-layout-patterns.md` |
| Modèle de diapositives | `references/slides-html-template.md` |
| Rédaction de diapositives | `references/slides-copywriting-formulas.md` |
| Stratégie de diapositives | `references/slides-strategies.md` |
| Formats et styles de bannières | `references/banner-sizes-and-styles.md` |
| Guide des photos pour réseaux sociaux | `references/social-photos-design.md` |
| Guide de conception d'icônes | `references/icon-design.md` |

## Scripts

| Script | Rôle |
|--------|------|
| `scripts/logo/search.py` | Rechercher des styles de logo, couleurs, secteurs |
| `scripts/logo/generate.py` | Générer des logos avec l'IA Gemini |
| `scripts/logo/core.py` | Moteur de recherche BM25 pour les données de logo |
| `scripts/cip/search.py` | Rechercher des livrables CIP, styles, secteurs |
| `scripts/cip/generate.py` | Générer des maquettes CIP avec Gemini |
| `scripts/cip/render-html.py` | Générer une présentation HTML à partir de maquettes CIP |
| `scripts/cip/core.py` | Moteur de recherche BM25 pour les données CIP |
| `scripts/icon/generate.py` | Générer des icônes SVG avec Gemini 3.1 Pro |

## Prérequis

**Python :** Cette compétence utilise des scripts Python. Sous Windows, utilisez `python` au lieu de `python3` (par ex., `python scripts/logo/search.py` au lieu de `python3 scripts/logo/search.py`).

Vérifiez si Python est installé :
```bash
python3 --version || python --version
```

## Configuration

```bash
export GEMINI_API_KEY="votre-cle"  # https://aistudio.google.com/apikey
pip install google-genai pillow

# Fournisseur MuAPI optionnel (aucun paquet Python supplémentaire requis)
export MUAPI_API_KEY="votre-cle"
```

MuAPI utilise le point de terminaison de modèle asynchrone et l'API de résultat de prédiction. Consultez la
[référence de l'API MuAPI](https://muapi.ai/docs/api-reference) pour l'authentification
et le [contrat de modèle nano-banana](https://api.muapi.ai/api/v1/models/nano-banana)
ou le [contrat de modèle nano-banana-pro](https://api.muapi.ai/api/v1/models/nano-banana-pro)
pour les schémas actuels propres à chaque modèle. Le générateur de logos prend en charge les deux slugs de modèles
documentés et envoie leur champ obligatoire commun `prompt` ainsi que les champs optionnels `aspect_ratio` ;
le modèle Pro accepte également un champ optionnel `resolution` que ce flux de travail ciblé sur les logos laisse
à la valeur par défaut du fournisseur.

> **Remarque pour Windows :** Utilisez `python` au lieu de `pip` si nécessaire (par ex., `python -m pip install ...`).

## Intégration

**Sous-compétences intégrées :** brand, design-system, ui-styling
**Compétences associées :** ui-ux-pro-max
