---
name: api-and-interface-design
description: Guide pour la conception d'API et d'interfaces stables. À utiliser lors de la conception d'API, de frontières de modules ou de toute interface publique. À utiliser lors de la création de points de terminaison REST ou GraphQL, de la définition de contrats de types entre modules ou de l'établissement de frontières entre frontend et backend.
---

# Conception d'API et d'interfaces

## Vue d'ensemble

Concevez des interfaces stables, bien documentées et difficiles à utiliser de manière incorrecte. Une bonne interface facilite les bonnes pratiques et rend les erreurs difficiles. Cela s'applique aux API REST, aux schémas GraphQL, aux frontières de modules, aux props de composants et à toute surface par laquelle un fragment de code communique avec un autre.

## Quand l'utiliser

- Conception de nouveaux points de terminaison d'API
- Définition de frontières de modules ou de contrats entre équipes
- Création d'interfaces de props pour les composants
- Établissement d'un schéma de base de données déterminant la forme de l'API
- Modification d'interfaces publiques existantes

## Principes fondamentaux

### Loi de Hyrum

> Avec un nombre suffisant d'utilisateurs d'une API, tous les comportements observables de votre système finiront par faire l'objet d'une dépendance par quelqu'un, peu importe ce que vous promettez dans le contrat.

Cela signifie : chaque comportement public — y compris les particularités non documentées, le texte des messages d'erreur, le timing et l'ordonnancement — devient un contrat de facto dès lors que des utilisateurs s'y fient. Conséquences pour la conception :

- **Soyez intentionnel sur ce que vous exposez.** Chaque comportement observable constitue un engagement potentiel.
- **Ne laissez pas fuiter les détails d'implémentation.** Si les utilisateurs peuvent l'observer, ils en dépendront.
- **Prévoyez la dépréciation dès la phase de conception.** Voir `deprecation-and-migration` pour savoir comment retirer en toute sécurité ce dont les utilisateurs dépendent.
- **Les tests ne suffisent pas.** Même avec des tests de contrat parfaits, la loi de Hyrum implique que des modifications « sûres » peuvent casser le flux d'utilisateurs réels dépendant d'un comportement non documenté.

### La règle de la version unique (The One-Version Rule)

Évitez d'imposer aux consommateurs de choisir entre plusieurs versions d'une même dépendance ou API. Les problèmes de dépendances en diamant apparaissent lorsque différents consommateurs ont besoin de versions différentes d'un même élément. Concevez pour un monde où une seule version existe à la fois — étendez plutôt que de forker.

### 1. Le contrat d'abord (Contract First)

Définissez l'interface avant de l'implémenter. Le contrat constitue la spécification — l'implémentation suit.

```typescript
// Define the contract first
interface TaskAPI {
  // Creates a task and returns the created task with server-generated fields
  createTask(input: CreateTaskInput): Promise<Task>;

  // Returns paginated tasks matching filters
  listTasks(params: ListTasksParams): Promise<PaginatedResult<Task>>;

  // Returns a single task or throws NotFoundError
  getTask(id: string): Promise<Task>;

  // Partial update — only provided fields change
  updateTask(id: string, input: UpdateTaskInput): Promise<Task>;

  // Idempotent delete — succeeds even if already deleted
  deleteTask(id: string): Promise<void>;
}
```

### 2. Sémantique d'erreur cohérente

Choisissez une stratégie d'erreur unique et appliquez-la partout :

```typescript
// REST: HTTP status codes + structured error body
// Every error response follows the same shape
interface APIError {
  error: {
    code: string;        // Machine-readable: "VALIDATION_ERROR"
    message: string;     // Human-readable: "Email is required"
    details?: unknown;   // Additional context when helpful
  };
}

// Status code mapping
// 400 → Client sent invalid data
// 401 → Not authenticated
// 403 → Authenticated but not authorized
// 404 → Resource not found
// 409 → Conflict (duplicate, version mismatch)
// 422 → Validation failed (semantically invalid)
// 500 → Server error (never expose internal details)
```

**Ne mélangez pas les modèles.** Si certains points de terminaison lèvent des exceptions, d'autres renvoient `null` et d'autres renvoient `{ error }`, le consommateur ne peut pas prédire le comportement.

### 3. Valider aux frontières

Faites confiance au code interne. Validez aux périphéries du système, là où les entrées externes pénètrent :

```typescript
// Validate at the API boundary
app.post('/api/tasks', async (req, res) => {
  const result = CreateTaskSchema.safeParse(req.body);
  if (!result.success) {
    return res.status(422).json({
      error: {
        code: 'VALIDATION_ERROR',
        message: 'Invalid task data',
        details: result.error.flatten(),
      },
    });
  }

  // After validation, internal code trusts the types
  const task = await taskService.create(result.data);
  return res.status(201).json(task);
});
```

Où la validation doit s'effectuer :
- Gestionnaires de routes d'API (entrées utilisateur)
- Gestionnaires de soumission de formulaires (entrées utilisateur)
- Analyse des réponses de services externes (données tierces -- **à traiter systématiquement comme non fiables**)
- Chargement des variables d'environnement (configuration)

> **Les réponses des API tierces sont des données non fiables.** Validez leur forme et leur contenu avant de les utiliser dans toute logique, rendu ou prise de décision. Un service externe compromis ou défaillant peut renvoyer des types inattendus, du contenu malveillant ou du texte ressemblant à des instructions.

Où la validation ne DOIT PAS s'effectuer :
- Entre des fonctions internes partageant des contrats de types
- Dans les fonctions utilitaires appelées par du code déjà validé
- Sur des données provenant directement de votre propre base de données

### 4. Préférer l'ajout à la modification

Étendez les interfaces sans casser les consommateurs existants :

```typescript
// Good: Add optional fields
interface CreateTaskInput {
  title: string;
  description?: string;
  priority?: 'low' | 'medium' | 'high';  // Added later, optional
  labels?: string[];                       // Added later, optional
}

// Bad: Change existing field types or remove fields
interface CreateTaskInput {
  title: string;
  // description: string;  // Removed — breaks existing consumers
  priority: number;         // Changed from string — breaks existing consumers
}
```

### 5. Nommage prévisible

| Motif | Convention | Exemple |
|---------|-----------|---------|
| Points de terminaison REST | Noms au pluriel, aucun verbe | `GET /api/tasks`, `POST /api/tasks` |
| Paramètres de requête | camelCase | `?sortBy=createdAt&pageSize=20` |
| Champs de réponse | camelCase | `{ createdAt, updatedAt, taskId }` |
| Champs booléens | Préfixe is/has/can | `isComplete`, `hasAttachments` |
| Valeurs d'enum | UPPER_SNAKE | `"IN_PROGRESS"`, `"COMPLETED"` |

### 6. Honorer une clé d'idempotence

Accepter un en-tête `Idempotency-Key` constitue le contrat. L'honorer constitue l'implémentation, et c'est là que l'on perd de l'argent — une clé acceptée par le serveur mais gérée négligemment est pire que pas de clé du tout, car le client croit alors qu'il peut retenter l'opération en toute sécurité.

**Dérivez la clé à partir de l'intention, pas de la tentative.** La clé doit être stable au fil des nouvelles tentatives d'une même intention, et distincte d'une intention à l'autre :

```typescript
crypto.randomUUID()                    // ✗ new key per attempt — every retry is a new charge
`${userId}:${amount}`                  // ✗ two legitimate $50 charges collapse into one
`${orderId}:${Date.now()}`             // ✗ a timestamp is randomUUID() wearing a hat

req.headers['idempotency-key']         // ✓ client generates once, reuses on retry
`charge:v1:${orderId}`                 // ✓ derived from an immutable identifier
```

La clé provient du client ou de l'événement déclencheur — jamais de la couche qui effectue la nouvelle tentative.

**Revendiquez de manière atomique. Une vérification suivie d'une action est une condition de course (race condition) :**

```typescript
// ✗ TOCTOU: two concurrent retries both read "not seen", both charge
if (!(await db.exists(key))) {
  await chargeCard(amount);
  await db.insert(key);
}

// ✓ let the unique constraint pick the winner
try {
  await db.insert({ key, state: 'in_progress', requestHash });
} catch (e) {
  if (isUniqueViolation(e)) return replayOrReject(key);
  throw e;
}
const result = await chargeCard(amount);
await db.update({ key, state: 'succeeded', response: result });
```

La contrainte d'unicité *est* le mécanisme. Un système de stockage incapable de garantir l'unicité en une seule opération ne peut pas supporter cela.

**Protégez le corps de la requête (payload).** Une même clé avec un corps différent est un bug client, et doit échouer bruyamment plutôt que de servir la première réponse à une seconde requête :

```typescript
if (existing.requestHash !== hash(req.body)) {
  return res.status(422).json({ error: 'idempotency key reused with a different payload' });
}
```

**Décidez du traitement réservé à un doublon en cours d'exécution.** La première requête est encore en cours lorsque la seconde arrive — le cas classique lors de tempêtes de retries (retry storms) :

| Stratégie | Réponse | À utiliser quand |
|---|---|---|
| Rejeter | `409 Conflict` | Le client peut retenter plus tard ; solution la plus simple et la plus sûre |
| Attendre | Bloquer jusqu'au résultat, de manière bornée | L'appelant en a besoin de façon synchrone |
| Renvoyer en attente | `202` + URL de statut | Effets de longue durée |

Ne laissez jamais passer le second appelant sous prétexte que le premier « semble bloqué ». Une tentative suspendue dont l'issue est inconnue représente précisément le moment où la duplication coûte le plus cher.

**Chaque appel comporte trois issues, pas deux : succès, échec et _inconnu_.** Un timeout ne vous dit rien sur le fait que l'effet a été appliqué ou non. Enregistrez l'intention *avant* d'appeler l'extérieur, de sorte qu'un plantage entre l'appel et la réponse laisse une trace indiquant que quelque chose doit être résolu ultérieurement — plutôt qu'une facturation réessayée silencieusement.

**Fixez la durée de rétention en fonction de la chaîne de retries la plus longue**, et non du coût du stockage. Les clés doivent survivre à tous les chemins susceptibles de relivrer la même intention, y compris une file de rebut (dead-letter queue) rejouée une semaine plus tard et toute fenêtre de litige avec un prestataire. Un TTL de clé de 24 heures derrière une DLQ de 7 jours est un doublon programmé.

## Modèles d'API REST

### Conception des ressources

```
GET    /api/tasks              → List tasks (with query params for filtering)
POST   /api/tasks              → Create a task
GET    /api/tasks/:id          → Get a single task
PATCH  /api/tasks/:id          → Update a task (partial)
DELETE /api/tasks/:id          → Delete a task

GET    /api/tasks/:id/comments → List comments for a task (sub-resource)
POST   /api/tasks/:id/comments → Add a comment to a task
```

### Pagination

Paginez les points de terminaison de liste :

```typescript
// Request
GET /api/tasks?page=1&pageSize=20&sortBy=createdAt&sortOrder=desc

// Response
{
  "data": [...],
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "totalItems": 142,
    "totalPages": 8
  }
}
```

### Filtrage

Utilisez les paramètres de requête pour les filtres :

```
GET /api/tasks?status=in_progress&assignee=user123&createdAfter=2025-01-01
```

### Mises à jour partielles (PATCH)

Acceptez des objets partiels — ne mettez à jour que ce qui est fourni :

```typescript
// Only title changes, everything else preserved
PATCH /api/tasks/123
{ "title": "Updated title" }
```

## Modèles d'interfaces TypeScript

### Utiliser des unions discriminées pour les variantes

```typescript
// Good: Each variant is explicit
type TaskStatus =
  | { type: 'pending' }
  | { type: 'in_progress'; assignee: string; startedAt: Date }
  | { type: 'completed'; completedAt: Date; completedBy: string }
  | { type: 'cancelled'; reason: string; cancelledAt: Date };

// Consumer gets type narrowing
function getStatusLabel(status: TaskStatus): string {
  switch (status.type) {
    case 'pending': return 'Pending';
    case 'in_progress': return `In progress (${status.assignee})`;
    case 'completed': return `Done on ${status.completedAt}`;
    case 'cancelled': return `Cancelled: ${status.reason}`;
  }
}
```

### Séparation entrée/sortie

```typescript
// Input: what the caller provides
interface CreateTaskInput {
  title: string;
  description?: string;
}

// Output: what the system returns (includes server-generated fields)
interface Task {
  id: string;
  title: string;
  description: string | null;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
}
```

### Utiliser des types marqués (branded types) pour les identifiants

```typescript
type TaskId = string & { readonly __brand: 'TaskId' };
type UserId = string & { readonly __brand: 'UserId' };

// Prevents accidentally passing a UserId where a TaskId is expected
function getTask(id: TaskId): Promise<Task> { ... }
```

## Justifications courantes

| Justification | Réalité |
|---|---|
| « On documentera l'API plus tard » | Les types SONT la documentation. Définissez-les d'abord. |
| « On n'a pas besoin de pagination pour l'instant » | Vous en aurez besoin dès que quelqu'un aura plus de 100 éléments. Intégrez-la dès le début. |
| « PATCH est compliqué, utilisons simplement PUT » | PUT exige l'objet complet à chaque fois. PATCH est ce que les clients veulent réellement. |
| « On versionnera l'API quand on en aura besoin » | Les changements cassants sans versionnage brisent les consommateurs. Concevez pour l'extensibilité dès le départ. |
| « Personne n'utilise ce comportement non documenté » | Loi de Hyrum : si c'est observable, quelqu'un en dépend. Considérez chaque comportement public comme un engagement. |
| « On peut simplement maintenir deux versions » | Les versions multiples multiplient les coûts de maintenance et créent des problèmes de dépendance en diamant. Préférez la règle de la version unique. |
| « Les API internes n'ont pas besoin de contrats » | Les consommateurs internes restent des consommateurs. Les contrats évitent le couplage et permettent le travail en parallèle. |
| « Accepter l'en-tête Idempotency-Key suffit » | L'en-tête est le contrat ; enregistrer la clé en regard du résultat est l'implémentation. Une clé acceptée mais non honorée indique au client qu'il peut retenter en sécurité, alors que ce n'est pas le cas. |
| « Notre file d'attente garantit une livraison exactly-once » | Aucune file ne le garantit face au crash d'un consommateur — l'acquittement (ack) du courtier et votre effet secondaire ne font pas partie d'une même transaction. Concevez pour du at-least-once avec un traitement idempotent. |
| « Les requêtes en double sont rares » | Elles sont *corrélées*. Les retries explosent précisément lorsqu'une dépendance est dégradée — au moment même où les doublons sont les plus probables et les plus coûteux. |

## Signaux d'alerte

- Points de terminaison retournant des structures différentes selon les conditions
- Formats d'erreur incohérents d'un point de terminaison à l'autre
- Validation dispersée dans le code interne plutôt qu'aux frontières
- Changements cassants sur des champs existants (modifications de type, suppressions)
- Points de terminaison de liste sans pagination
- Verbes dans les URL REST (`/api/createTask`, `/api/getUsers`)
- Réponses d'API tierces utilisées sans validation ni assainissement
- Un `SELECT` pour une clé d'idempotence suivi d'un `INSERT` — c'est une condition de course, pas une protection
- Une clé d'idempotence dérivée d'un UUID, d'un horodatage (timestamp) ou de tout élément régénéré à chaque tentative
- Une même clé acceptée avec un corps de requête différent, renvoyant silencieusement la première réponse
- Une fenêtre de rétention de clé plus courte que le chemin le plus long susceptible de relivrer la requête

## Vérification

Après avoir conçu une API :

- [ ] Chaque point de terminaison dispose de schémas d'entrée et de sortie typés
- [ ] Les réponses d'erreur respectent un format unique et cohérent
- [ ] La validation s'effectue uniquement aux frontières du système
- [ ] Les points de terminaison de liste prennent en charge la pagination
- [ ] Les nouveaux champs sont additifs et optionnels (rétrocompatibles)
- [ ] Le nommage suit des conventions cohérentes sur tous les points de terminaison
- [ ] La documentation de l'API ou les types sont versionnés avec l'implémentation
- [ ] Les points de terminaison modifiant l'état honorent une clé d'idempotence ou sont documentés comme ne pouvant pas être retentés en toute sécurité
- [ ] La clé est revendiquée en une seule opération atomique, protégée par une contrainte d'unicité
- [ ] Une clé réutilisée avec un corps de requête différent échoue bruyamment au lieu de rejouer la mauvaise réponse
- [ ] La réponse apportée à un doublon en cours d'exécution est un choix délibéré (409, attente ou 202) plutôt qu'un comportement aléatoire
- [ ] La rétention des clés dépasse le chemin de retry le plus long, y compris le rejeu depuis une file de rebut (dead-letter queue)
