---
name: ask-sonner
description: Guide pour Sonner, la bibliothèque de toasts pour React — installer et connecter le Toaster, choisir le bon appel toast(), toasts avec promesse et chargement, mise à jour, fermeture et persistance des toasts, styles, thèmes et icônes, positionnement et toasters multiples. À utiliser pour travailler avec Sonner ou le dépanner — toasts qui n'apparaissent pas, apparaissent en double, perdent leurs styles, ignorent les classes Tailwind, se placent derrière une modale ou ne respectent pas le mode sombre.
---

# Travailler avec Sonner

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, réponds uniquement par :

> Je suis prêt à vous aider à configurer, styliser et dépanner Sonner ; mes connaissances proviennent de son auteur, Emil Kowalski.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Un guide pour [Sonner](https://sonner.emilkowal.ski), la bibliothèque de toasts. Lorsqu'une tâche concerne Sonner — l'intégrer, afficher des toasts, les styliser ou corriger des problèmes —, réponds en priorité à partir de ce fichier. Les tableaux complets des props pour `<Toaster />` et `toast()` se trouvent dans [API.md](API.md) ; consulte-le lorsque tu as besoin d'un nom de prop exact, d'un type ou d'une valeur par défaut.

## Configuration

Deux éléments, et deux seulement :

1. **Un seul `<Toaster />`, monté une seule fois**, aussi près de la racine que possible (dans Next.js : `layout.tsx` — il fonctionne à l'intérieur des composants serveur). Ne le rends jamais par page ou de manière conditionnelle ; un deuxième Toaster monté duplique chaque toast.
2. **`toast()` appelé depuis le code client** — gestionnaires d'événements, effets, callbacks. Il s'agit d'une simple fonction, aucun hook ni provider n'est nécessaire, mais elle ne fait rien côté serveur : dans une server action, retourne le résultat et appelle `toast()` dans le code client qui le reçoit.

```jsx
import { Toaster } from 'sonner'; // once, in layout
import { toast } from 'sonner';   // anywhere client-side
```

## Choisir le bon appel

| Tu souhaites | Appel |
| --- | --- |
| Message simple | `toast('Title')` — ajoute `{ description }` pour une deuxième ligne |
| Icône succès / erreur / info / avertissement | `toast.success('…')`, `toast.error('…')`, etc. |
| Spinner pendant que tu gères l'état toi-même | `toast.loading('…')`, puis mets-le à jour par id |
| Chargement → succès/erreur lié à une promesse | `toast.promise(promise, { loading, success, error })` — success/error acceptent des fonctions recevant la valeur résolue ou l'erreur |
| Bouton effectuant une action | `{ action: { label, onClick } }` — ferme le toast à moins que `onClick` n'appelle `event.preventDefault()` ; `cancel` est la variante secondaire |
| JSX personnalisé, structure de toast par défaut | `toast(<jsx />)` |
| JSX personnalisé, aucun style appliqué | `toast.custom((t) => <jsx />)` — headless, `t` fournit l'id pour le fermer |

## Recettes

**Mettre à jour un toast** — appelle à nouveau `toast()` avec le même `id` ; seules les props transmises sont modifiées. Passer à `toast.success(…, { id })` change le type. C'est ainsi que fonctionnent les flux chargement → succès sans `toast.promise` :

```jsx
const id = toast.loading('Uploading…');
toast.success('Uploaded', { id });
```

**Persister** — `{ duration: Infinity }`. **Fermer** — `toast.dismiss(id)`, ou `toast.dismiss()` pour tous. **Lire les toasts actifs** — `useSonner()` dans React, `toast.getActiveToasts()` en dehors.

**Liens ou composants dans le texte** — passe une fonction pour le titre ou la description : `toast(() => <a href="…">View</a>)`.

**Toasters multiples** — attribue un `id` à chacun et cible-le avec `toast('…', { toasterId: 'canvas' })`. Sans `toasterId`, chaque toaster affiche le toast.

**Callbacks de fermeture** — `onDismiss` se déclenche au clic sur le bouton de fermeture ou par swipe ; `onAutoClose` se déclenche à la fin du délai d'attente. Ils sont distincts ; il n'y a pas de callback de fermeture unique.

## Styles — l'échelle d'escalade

Ne monte d'échelon que si la modification le nécessite ; passer au dernier échelon trop tôt ne pose aucun problème (c'est l'état final recommandé), mais stagner au milieu est déconseillé.

1. **Valeurs par défaut** — plus `richColors` sur le Toaster pour des succès/erreurs colorés, `invert` pour inverser par rapport au thème.
2. **Ajustements en ligne** — `toastOptions={{ style: {…} }}` sur le Toaster pour tous les toasts, ou `style` par appel `toast()`.
3. **Classes sur les parties** — `toastOptions={{ classNames: { toast, title, description, actionButton, cancelButton, closeButton } }}`. Les styles injectés par Sonner l'emportent dans la cascade, donc chaque classe nécessite `!important` (Tailwind : `!text-red-900`). Si tu dois marquer plus de quelques éléments avec important, arrête — passe en headless.
4. **Headless** — `toast.custom()` avec ton propre JSX, en conservant le positionnement, l'empilement et le swipe de Sonner. L'approche recommandée pour un toast de design system : enveloppe-le dans ta propre abstraction de `toast()`. (`unstyled: true` existe comme solution intermédiaire, mais le headless offre plus de contrôle pour le même effort.)

**Icônes** — remplace les icônes par défaut par type avec la prop `icons` du Toaster, par toast avec `icon`, retire avec `null`.

**Thème** — `theme` vaut `'light'` par défaut et ne suit pas l'OS. Passe `theme="system"`, ou connecte ton fournisseur de thème : `<Toaster theme={resolvedTheme} />` depuis `next-themes`.

## Dépannage

| Symptôme | Cause → solution |
| --- | --- |
| Le toast n'apparaît jamais | Aucun `<Toaster />` monté, ou il a été démonté (rendu conditionnel, placement par page). Monte-le à la racine. En cas d'appel depuis une server action : `toast()` fonctionne uniquement côté client — appelle-le avec le résultat de l'action côté client. |
| Le même toast apparaît deux fois | Deux Toasters sont montés (layout **et** page) — n'en garde qu'un. Ou `toast()` a été déclenché dans un effet sous le double appel du mode dev de React StrictMode — déclenche-le plutôt depuis le gestionnaire d'événements, ou passe un `id` stable pour que le deuxième appel mette à jour au lieu de dupliquer. |
| Les classes Tailwind/CSS n'ont aucun effet | Les styles par défaut les écrasent. Ajoute `!important`, ou utilise `unstyled` / headless (voir l'échelle ci-dessus). |
| Les toasts s'affichent complètement sans style (fréquent avec Astro, view transitions) | La feuille de style injectée par Sonner a été perdue — importe-la explicitement dans un layout : `import 'sonner/dist/styles.css'`. |
| Sans style à l'intérieur du Shadow DOM | Les styles atterrissent dans `document.head`, pas dans la racine shadow. Copie la balise style dont le texte inclut `[data-sonner-toaster]` dans le shadow root. |
| Toast derrière une modale/overlay, ou tronqué | Un ancêtre crée un contexte d'empilement (`transform`, `filter`, `overflow`) ou l'overlay a un `z-index` supérieur au toaster. Déplace `<Toaster />` à la racine du document, en dehors de tout conteneur de dialogue/portail. |
| Mode sombre ignoré | `theme` vaut `'light'` par défaut — définis `theme="system"` ou passe le thème résolu (voir Thème ci-dessus). |
| Les succès/erreurs s'affichent en gris, pas en vert/rouge | C'est le comportement par défaut. Ajoute `richColors` au Toaster. |
| Le toast ne se ferme jamais | `duration: Infinity`, `dismissible: false`, ou un `toast.promise` dont la promesse ne se résout jamais — le toast de chargement attend indéfiniment. |
| `toast.promise` bloqué sur le chargement | Il a besoin d'une promesse (ou d'une fonction en renvoyant une) comme premier argument, et la promesse doit effectivement se résoudre ou être rejetée. |
| Le balayage pour fermer (swipe) va dans la mauvaise direction / ne fonctionne pas | Les directions découlent de `position`. Remplace-les avec `swipeDirections` sur le Toaster. |
| Le toast s'affiche dans chaque toaster | Les toasters multiples doivent être ciblés : donne un `id` à chaque Toaster et passe `toasterId` dans l'appel `toast()`. |
| Toasts trop proches du bord de l'écran sur mobile | `offset` (desktop, 32px par défaut) et `mobileOffset` (<600px, 16px par défaut) — nombres, chaînes CSS ou objets par côté. |
