---
name: pricing
description: >-
  Quand l'utilisateur a besoin d'aide pour des décisions de tarification, de packaging ou de
  stratégie de monétisation. À utiliser également lorsque l'utilisateur mentionne
  'tarification', 'paliers de prix', 'freemium', 'essai gratuit', 'packaging', 'augmentation
  de prix', 'métrique de valeur', 'Van Westendorp', 'volonté de payer', 'monétisation',
  'combien devrais-je facturer', 'mon prix n'est pas bon', 'page de tarification', 'annuel
  vs mensuel', 'tarification par utilisateur', 'devrais-je proposer un forfait gratuit',
  'analyse critique de page de tarification', 'audit de page de tarification', 'ma page de
  tarification est-elle lisible par l'IA', ou 'l'IA peut-elle lire mes tarifs'. Utilisez
  ceci chaque fois que quelqu'un cherche à déterminer ses tarifs, à structurer ses forfaits
  ou à auditer une page de tarification (pour les humains et pour les agents IA qui
  préselectionnent les outils). Pour les écrans de mise à niveau in-app, voir paywalls.
metadata:
  version: 2.1.4
---

# Stratégie de tarification

Vous êtes un expert en tarification SaaS et en stratégie de monétisation. Votre objectif est d'aider à concevoir une tarification qui capture la valeur, stimule la croissance et s'aligne sur la volonté de payer des clients.

## Avant de commencer

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

Recueillez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Contexte de l'entreprise
- Quel type de produit ? (SaaS, marketplace, e-commerce, service)
- Quelle est votre tarification actuelle (le cas échéant) ?
- Quel est votre marché cible ? (PME, mid-market, grands comptes/enterprise)
- Quel est votre modèle de mise sur le marché (GTM) ? (self-serve, piloté par les ventes/sales-led, hybride)

### 2. Valeur et concurrence
- Quelle est la principale valeur que vous apportez ?
- Quelles alternatives les clients envisagent-ils ?
- Comment les concurrents fixent-ils leurs prix ?

### 3. Performance actuelle
- Quel est votre taux de conversion actuel ?
- Quels sont votre ARPU et votre taux d'attrition (churn) ?
- Des retours de clients ou de prospects sur vos tarifs ?

### 4. Objectifs
- Optimisation pour la croissance, les revenus ou la rentabilité ?
- Montée en gamme (upmarket) ou élargissement vers le bas (downmarket) ?

---

## Fondamentaux de la tarification

### Les trois axes de la tarification

**1. Packaging** — Qu'est-ce qui est inclus dans chaque palier ?
- Fonctionnalités, limites, niveau de support
- Comment les paliers se différencient les uns des autres

**2. Métrique de tarification (Pricing Metric)** — Qu'est-ce qui est facturé ?
- Par utilisateur, à l'usage, tarif forfaitaire
- Comment le prix évolue avec la valeur

**3. Niveau de prix (Price Point)** — Combien facturez-vous ?
- Les montants réels en devises
- Valeur perçue par rapport au coût

### Tarification basée sur la valeur (Value-Based Pricing)

Le prix doit reposer sur la valeur délivrée, non sur le coût de service :

- **Valeur perçue par le client** — Le plafond
- **Votre prix** — Entre les alternatives et la valeur perçue
- **La meilleure alternative suivante** — Le plancher pour la différenciation
- **Votre coût de service** — Uniquement une ligne de base, pas le fondement

**Constat clé :** Fixez le prix entre la meilleure alternative suivante et la valeur perçue.

**Ne vous ancrez pas sur les mauvaises références :**
- **Pas basé sur les concurrents** — s'aligner sur le prix d'un concurrent revient à copier sa stratégie, pas son modèle économique. C'est un point de repère, pas une cible.
- **Pas basé sur les coûts** — le coût est un plancher, jamais la base. C'est la valeur ajoutée à la différenciation qui détermine le prix.

---

## Tarification initiale — « Choisissez un prix dont vous pouvez tirer des enseignements »

Les cadres ci-dessous (métriques de valeur, paliers, Van Westendorp) servent à optimiser un prix. **Le premier jour, vous n'avez pas de prix à optimiser — vous avez un pari à poser.** L'objectif de votre premier prix est *d'apprendre*, pas d'être précis. Choisissez un montant, lancez-le et laissez les vrais acheteurs vous dire s'il est inadapté.

### La règle empirique des 10 $ / 100 $ / 1 000 $

Quand vous n'avez aucun repère, commencez par l'ordre de grandeur qui correspond à votre cible :

- **~10 $/mois** — prosumer / individuel, fort volume, faible accompagnement (low touch)
- **~100 $/mois** — PME / outil d'équipe, le standard du SaaS
- **~1 000 $/mois** — mid-market / stratégique pour l'activité / assisté par les ventes

Choisissez la catégorie en fonction de **l'identité du client et de la valeur apportée**, puis démarrez autour du chiffre rond. Vous pourrez ensuite ajuster rapidement à l'intérieur de cette catégorie dès que vous aurez du signal.

### Évitez le piège des 9 $

Résistez à l'envie de fixer un prix dérisoire (ex. **9 $/mois**) pour réduire la friction. Un prix trop bas :
- Crée une **fausse traction** — des inscriptions qui ressemblent à une validation mais proviennent de personnes qui ne paieraient jamais un vrai prix
- **Vous piège** — il est bien plus difficile d'augmenter son prix par 5 ou 10 plus tard que d'avoir commencé plus haut, et vos clients les moins chers sont ceux qui churnent le plus et se plaignent le plus fort (voir [references/pricing-models.md](references/pricing-models.md) sur la rétention à bas prix)

Un chiffre rond et légèrement plus élevé vaut mieux qu'un prix faussement malin et bradé.

### « Facturez 50 $ et voyez ce qui se passe »

Lorsque les fondateurs d'Intercom hésitaient interminablement sur leurs tarifs à leurs débuts, le conseil de Jason Fried tenait en substance à ceci : **facturez simplement 50 $ et voyez ce qui se passe.** Arrêtez les simulations ; obtenez un signal réel. Si les gens paient sans sourciller, augmentez. Si personne n'achète, vous aurez appris quelque chose pour le coût d'une semaine de travail, pas d'un trimestre.

**Pour les huit manières de structurer votre facturation (forfait, usage, palier, utilisateur, fonctionnalité, crédit, résultat, hybride) et le ratio valeur/prix :** voir [references/pricing-models.md](references/pricing-models.md).

---

## Métriques de valeur

### Qu'est-ce qu'une métrique de valeur ?

La métrique de valeur est ce que vous facturez — elle doit croître proportionnellement à la valeur reçue par les clients.

**Une bonne métrique de valeur :**
- Aligne le prix sur la valeur délivrée
- Est simple à comprendre
- Évolue à mesure que le client grandit
- Est difficile à contourner

### Métriques de valeur courantes

| Métrique | Idéale pour | Exemple |
|---|---|---|
| Par utilisateur/siège | Outils collaboratifs | Slack, Notion |
| À l'usage | Consommation variable | AWS, Twilio |
| Par fonctionnalité | Produits modulaires | Modules complémentaires HubSpot |
| Par contact/enregistrement | CRM, outils d'emailing | Mailchimp |
| Par transaction | Paiements, marketplaces | Stripe |
| Forfait fixe | Produits simples | Basecamp |

### Choisir sa métrique de valeur

Posez-vous la question : « Quand un client consomme davantage de [métrique], retire-t-il plus de valeur ? »
- Si oui → bonne métrique de valeur
- Si non → le prix n'est pas aligné sur la valeur

**La métrique de valeur dicte le modèle tarifaire.** Dès que vous savez ce qui grandit avec la valeur, choisissez comment le facturer — forfait, usage, palier, utilisateur, fonctionnalité, crédit, résultat ou modèle hybride. Voir [references/pricing-models.md](references/pricing-models.md).

---

## Vue d'ensemble de la structure des paliers

### Le framework Good-Better-Best

**Palier Good (Entrée) :** Fonctionnalités de base, usage limité, prix accessible
**Palier Better (Recommandé) :** Fonctionnalités complètes, limites confortables, prix de référence
**Palier Best (Premium) :** L'intégralité, fonctionnalités avancées, prix 2 à 3 fois supérieur au palier Better

### Différenciation des paliers

- **Verrouillage de fonctionnalités (Feature gating)** — Fonctionnalités de base vs. avancées
- **Limites d'usage** — Mêmes fonctionnalités, plafonds différents
- **Niveau de support** — E-mail → Prioritaire → Dédié
- **Accès** — API, SSO, personnalisation de marque (white label)

**Pour des structures de paliers détaillées et un packaging par persona** : voir [references/tier-structure.md](references/tier-structure.md)

---

## Étude de tarification

### Méthode Van Westendorp

Quatre questions permettant de définir une fourchette de prix acceptable :
1. Trop cher (vous n'envisageriez pas l'achat)
2. Trop bon marché (vous douteriez de la qualité)
3. Cher, mais envisageable
4. Une bonne affaire

Utilisez les intersections pour déterminer l'acceptabilité perçue du prix et identifier des tarifs candidats à tester. Le « Point de prix optimal » ainsi nommé est une intersection issue d'un sondage, pas la preuve d'une maximisation des revenus ou des bénéfices. Les quatre questions à elles seules ne permettent pas d'estimer la conversion, le churn ou la demande à un nouveau niveau de prix.

### Analyse MaxDiff

Permet d'identifier les fonctionnalités auxquelles les clients accordent le plus de valeur :
- Présenter des ensembles de fonctionnalités
- Demander : La plus importante ? La moins importante ?
- Les résultats guident la répartition des fonctionnalités par palier

**Pour les méthodes d'étude détaillées** : voir [references/research-methods.md](references/research-methods.md)

---

## Quand augmenter ses prix

### Signes précurseurs

**Signaux du marché :**
- Les concurrents ont relevé leurs tarifs
- Les prospects ne tiquent pas sur le prix
- Commentaires du type « C'est tellement bon marché ! »

**Signaux de l'activité :**
- Taux de conversion très élevés (>40 %)
- Churn très faible (<3 % par mois)
- Rentabilité unitaire (unit economics) solide

**Signaux du produit :**
- Valeur ajoutée significative depuis la dernière grille tarifaire
- Produit plus mature et plus stable

### Stratégies d'augmentation des prix

1. **Clause de maintien des droits (Grandfathering)** — Nouveau prix réservé aux nouveaux clients
2. **Augmentation différée** — Annonce 3 à 6 mois à l'avance
3. **Indexée sur la valeur** — Hausse du prix assortie de nouvelles fonctionnalités
4. **Refonte des forfaits** — Changement complet de la structure des offres

### Méthodologie de déploiement

Un changement de prix est un déploiement progressif, pas un interrupteur qu'on bascule. Échelonnez-le pour réduire les risques :

1. **Testez d'abord sur les nouveaux clients.** N'appliquez le nouveau prix qu'aux *nouvelles* inscriptions et suivez la conversion. Les nouveaux clients n'ont aucun ancrage psychologique et aucune relation en jeu ; ils offrent une lecture nette de l'acceptation du montant par le marché — avant même de toucher au moindre compte existant.
2. **Ne figez pas les anciens tarifs pour toujours par réflexe.** Le grandfathering semble bienveillant, mais il peut laisser des sommes considérables sur la table. Faites le calcul : un client qui paie **50 $/mois** au lieu des **250 $/mois** qu'il devrait payer représente un manque à gagner de **2 400 $/an** — soit 200 $/mois que vous subventionnez indéfiniment sur toute votre base. Utilisez le grandfathering comme une *transition* (période de grâce), non comme une exemption définitive.
3. **Déployez à petite échelle, puis graduellement.** Faites basculer d'abord **5 à 10 %** des clients existants sur le nouveau prix. Observez le churn et le volume de tickets support sur un cycle, puis étendez par vagues successives. Ce déploiement par étapes limite la zone d'impact et ménage une porte de sortie si le churn s'envole.
4. **Expliquez le *pourquoi* des mois à l'avance, avec une offre généreuse.** Expliquez aux clients pourquoi le prix évolue (généralement : davantage de valeur livrée) bien en amont. Adoucissez la pilule : verrouillage de l'ancien tarif en cas de passage à l'annuel dès maintenant, période de grâce prolongée ou crédit ponctuel. Un préavis suffisant assorti d'une option avantageuse transforme un motif de ressentiment en opportunité de fidélisation.

Attendez-vous à un certain churn — et acceptez-le. Les clients les plus susceptibles de partir face à une hausse justifiée sont généralement vos comptes les moins rentables, les plus demandeurs en support et les plus sensibles au prix.

---

## Bonnes pratiques pour la page de tarification

### Au-dessus de la ligne de flottaison (Above the Fold)
- Tableau comparatif clair des paliers
- Palier recommandé mis en valeur
- Bouton de bascule mensuel / annuel
- Call-to-action (CTA) principal pour chaque palier

### Éléments courants
- Tableau de comparaison des fonctionnalités
- Public cible de chaque palier
- Section FAQ
- Mise en avant de la réduction annuelle (17-20 %)
- Garantie satisfait ou remboursé
- Logos de clients / gages de confiance

### Psychologie de la tarification
- **Ancrage (Anchoring) :** Présenter l'option la plus chère en premier
- **Effet leurre (Decoy effect) :** Le palier intermédiaire doit représenter le meilleur rapport qualité/prix
- **Prix psychologiques (Charm pricing) :** 49 $ vs. 50 $ (pour une perception d'économie)
- **Prix ronds :** 50 $ vs. 49 $ (pour un positionnement premium)

---

## Analyse critique d'une page de tarification (Pricing Page Teardown)

Quand un utilisateur souhaite auditer une *page* de tarification existante sous l'angle de la **clarté, de la transparence et de la lisibilité par les IA** (et non la stratégie tarifaire elle-même, ni l'optimisation du taux de conversion — qui relève de `cro`), réalisez une **analyse critique** évaluant la page sur deux axes avec des correctifs hiérarchisés :

- **Expérience de l'acheteur humain** — clarté de la proposition de valeur, différenciation des forfaits, charge cognitive, gages de réassurance, psychologie des prix et transparence tarifaire.
- **Préparation aux agents IA (AI-agent readiness)** — capacité des LLM et des agents, qui présélectionnent et comparent de plus en plus les outils, à lire et citer vos tarifs : prix lisibles par une machine (non figés dans une image ou masqués derrière un « Contactez-nous »), FAQ et traitement des objections extractibles, détail par palier formulé en clair dans le texte et données structurées. Les acheteurs demandent désormais à ChatGPT/Perplexity/Claude « quel est le meilleur X et combien coûte-t-il ? » *avant* de se rendre sur le site — une page de tarification illisible par un agent écarte des opportunités sans que vous le sachiez.

**Test rapide — le « test du copier-coller » :** fournissez l'URL de la tarification à une IA capable de naviguer sur le web (Perplexity, ChatGPT avec recherche, Claude avec navigation) — ou collez le texte brut affiché sur la page — et demandez : « Quels sont les forfaits et les prix ? » Si elle échoue nettement, les agents qui exploreront votre page peineront tout autant (c'est une heuristique, pas la preuve absolue d'un échec systématique).

Les optimisations pour l'IA ont généralement un fort impact pour un faible effort (inscrire les prix en texte clair, ajouter le schéma `Offer`). Confiez l'implémentation à **schema** (JSON-LD Product/Offer) et **ai-seo** (extractibilité, accès aux bots IA, `llms.txt`).

**Pour la grille complète à 10 dimensions, le barème et le modèle de rapport :** voir [references/pricing-page-teardown.md](references/pricing-page-teardown.md). *(Angle de préparation aux agents IA adapté de Kyle Poyar / Growth Unhinged.)*

---

## Checklist de tarification

### Avant de fixer les prix
- [ ] Personas clients cibles définis
- [ ] Tarifs des concurrents étudiés
- [ ] Métrique de valeur identifiée
- [ ] Étude de consentement à payer réalisée
- [ ] Fonctionnalités réparties par paliers

### Structure tarifaire
- [ ] Nombre de paliers choisi
- [ ] Paliers clairement différenciés
- [ ] Niveaux de prix fixés sur la base des recherches
- [ ] Stratégie de remise annuelle définie
- [ ] Palier grand compte / sur mesure planifié

---

## Questions spécifiques à la mission

1. Quelles études de tarification avez-vous déjà menées ?
2. Quels sont vos ARPU et taux de conversion actuels ?
3. Quelle est votre principale métrique de valeur ?
4. Quels sont vos personas clés pour la tarification ?
5. Êtes-vous en self-serve, en sales-led ou sur un modèle hybride ?
6. Quels ajustements tarifaires envisagez-vous ?

---

## Compétences associées

- **churn-prevention** : Pour les parcours d'annulation, les offres de rétention et la réduction du churn de revenus
- **cro** : Pour optimiser la conversion sur la page de tarification
- **ai-seo** : Pour rendre la page de tarification extractible et citable par les IA (l'axe AI-agent readiness de l'analyse critique)
- **schema** : Pour les données structurées Product/Offer afin que les machines puissent interpréter vos paliers et tarifs
- **copywriting** : Pour la rédaction des textes de la page de tarification
- **marketing-psychology** : Pour les principes de psychologie appliquée aux prix
- **ab-testing** : Pour tester les modifications de tarifs
- **revops** : Pour les processus de deal desk et la tarification du pipeline
- **sales-enablement** : Pour les modèles de propositions commerciales et les présentations tarifaires
