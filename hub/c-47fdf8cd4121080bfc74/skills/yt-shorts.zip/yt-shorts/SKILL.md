---
name: yt-shorts
description: >-
  Trouve les Shorts dissimulés au sein d'une longue vidéo et les rédige, en
  utilisant la transcription pour sélectionner des moments autonomes. À utiliser
  pour « découpe ceci en shorts », « fais un clip de ceci », « recycle cette vidéo »,
  « que devrais-je clipper ».
---

# yt-shorts

Un Short extrait d'une vidéo longue n'est pas simplement un extrait du meilleur moment. C'est un moment qui **survit sans la vidéo qui l'entoure**, ce qui constitue un ensemble bien plus restreint.

## Sélection

Lis la transcription et trouve des passages de 20 à 55 secondes où ces trois conditions sont réunies :

1. Il s'ouvre sur une pensée complète. Si la première phrase a besoin de la minute précédente, ce n'est pas un Short.
2. Il comporte un pivot — une affirmation, puis un élément qui la complexifie ou la prouve.
3. Il se termine sur une phrase nette, pas en s'effilochant.

Classe les candidats et présente à l'utilisateur les cinq meilleurs avec leurs timecodes et leur première phrase, afin qu'il puisse en rejeter un sans avoir à lire toute la transcription.

## Rédaction de chaque Short

- **Une NOUVELLE première phrase.** La phrase de la vidéo longue suppose un contexte que ce spectateur n'a pas. Rédige son remplacement et passe-le dans `../yt-script/hookscore.py`.
- **Texte à l'écran pour les deux premières secondes**, avec des mots différents de la phrase prononcée à l'oral.
- **Un point de boucle** : ce que la dernière phrase prépare pour que la première phrase y réponde.
- Note de cadrage vertical — ce qui est rogné hors d'un format 16:9 et si cela pose problème.

## Le sas de validation

Rien n'est publié directement ici. Cette compétence rédige et vous publiez. Chaque résultat se termine par un bloc que l'utilisateur copie, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
