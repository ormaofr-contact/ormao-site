---
name: yt-plan
description: >-
  Planifier une semaine ou un mois de publications YouTube — quoi publier,
  quand et dans quel ordre, adapté à la capacité réelle du créateur. À
  utiliser pour « planifie ma semaine », « calendrier de contenu », « que
  devrais-je publier », « je ne sais pas du tout quoi faire ensuite ».
---

# yt-plan

Un planning qui ne rentre pas dans la semaine est une liste de regrets. Pose deux questions avant d'écrire quoi que ce soit :
**de combien d'heures disposes-tu réellement**, et **qu'est-ce qui est déjà à moitié fait**.

## Avant d'écrire

1. Lis `~/.claude/youtube/voice.md` s'il existe. C'est le profil de voix de l'utilisateur : sa façon de parler face caméra, les mots qu'il n'emploie jamais, à qui il s'adresse, ce qu'il refusera d'affirmer. S'il n'existe pas, demande **trois de ses propres vidéos**, lis-les ou transcris-les, déduis-en la voix et écris le fichier. Un script qui n'adopte pas la bonne voix est pire que pas de script du tout, car il devra le lire à voix haute.
2. N'invente jamais un chiffre, un résultat ou une source. Si une statistique pouvait renforcer le propos sans que tu en aies une sous la main, demande-la ou écris la phrase sans elle.

## La structure d'une semaine

- **Un pilier.** La vidéo principale de la semaine. C'est elle qui demande le plus de temps et elle sort le jour que les analytics de la chaîne indiquent comme étant le meilleur — demande cette information, ne présume pas que c'est le mardi.
- **Une vidéo rapide.** Conçue à partir de quelque chose qui existe déjà : un extrait, une réaction, une suite donnée au commentaire qui a généré le plus de réponses la semaine passée.
- **Des Shorts tirés du pilier.** Trois, découpés dans la vidéo longue, et non rédigés séparément. `/yt-shorts` s'occupe de les trouver.

Trois publications pour une semaine de sept jours, pas sept. Un calendrier qui prévoit de publier tous les jours n'est pas un rythme réaliste, et ce sont les jours sans publication qui permettent aux jours chargés de survivre à une mauvaise semaine.

## Ce qu'il faut livrer

Un tableau : jour, format, titre de travail, la phrase unique résumant sa promesse, et ce qui existe déjà pour ce contenu. Puis la ligne d'honnêteté en bas — combien d'heures cela coûte, et quoi abandonner en premier si la semaine dérape.

## Le garde-fou

Rien n'est publié automatiquement ici. Cette compétence rédige et vous publiez. Chaque résultat se termine par un bloc que l'utilisateur copie, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
