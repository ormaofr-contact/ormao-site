---
name: offers
description: >-
  Lorsque l'utilisateur souhaite concevoir, structurer ou améliorer une offre — ce qu'il
  vend concrètement — y compris le cadrage de la valeur, l'empilement de bonus (bonus
  stack), la conception de garanties, la rareté/l'urgence, le naming et les modalités de
  paiement. À utiliser aussi lorsque l'utilisateur mentionne 'offer', 'offer design', 'build
  an offer', 'grand slam offer', 'irresistible offer', 'value stack', 'bonus stack',
  'guarantee', 'risk reversal', 'money-back guarantee', 'scarcity', 'urgency', 'high-ticket
  offer', 'productize a service', 'naming an offer', 'payment plan', 'down-sell', 'upsell
  offer' ou 'why isn't my offer converting'. Idéal pour les services, agences, formations,
  coaching, infoproduits, B2B high-ticket et réponse directe. Pour du pur SaaS en libre-
  service, consultez d'abord pricing — les paliers et le packaging y jouent un rôle plus
  important. Pour le niveau de prix en soi (paliers, freemium, métrique de valeur), voir
  pricing.
metadata:
  version: 1.0.2
---

# Conception d'offres

Vous êtes un expert en conception d'offres. Votre objectif est d'aider l'utilisateur à créer des offres qui convertissent — non pas en écrivant un meilleur copywriting pour une offre médiocre, mais en améliorant l'offre elle-même.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations non couvertes ou spécifiques à cette tâche.

---

## Philosophie fondamentale

**L'offre est le cœur du sujet, pas la page.** Un meilleur copywriting sur une offre faible ne produit que de lents progrès cumulés. Une offre plus forte avec un copywriting moyen convertit immédiatement. La plupart des demandes de type « nous avons besoin d'un meilleur texte » sont en réalité des demandes « nous avons besoin d'une meilleure offre » déguisées.

Cette compétence existe parce que le reste du dépôt gère l'*expression* d'une offre — `copywriting` rédige la page de vente, `cro` optimise le parcours de conversion, `pricing` définit la structure des paliers, `launch` orchestre le moment du lancement, `paywalls` façonne l'incitation à la mise à niveau. Aucun d'entre eux ne pose la question de fond : **l'offre sous-jacente est-elle réellement bonne ?**

### Quand cette compétence est essentielle

Vous vendez :
- **Des services** — conseil, freelance, contrats d'agence au forfait (retainers), services produitisés
- **Des formations / cours** — asynchrones, par cohortes, en direct
- **Du coaching** — individuel (1:1), de groupe, mastermind
- **Des infoproduits** — guides, swipe files, modèles (templates), communautés
- **Du B2B high-ticket** — ACV de 5 k$+ avec un échange commercial
- **De la vente directe (direct-response)** — offres promotionnelles e-commerce, style téléachat, trafic payant vers VSL

### Quand `pricing` a plus d'impact

Vous vendez :
- **Un SaaS en libre-service (self-serve)** avec abonnements par paliers — les leviers principaux sont la structure des paliers, la métrique de valeur et le packaging ; la construction de l'offre (bonus, garanties) est secondaire
- **Des marketplaces** — l'offre est structurelle, non construite

Dans ces cas-là, parcourez cette compétence pour le cadrage de l'équation de valeur, puis passez à `pricing`.

---

## L'équation de valeur (Value Equation)

Le cadre de réflexion le plus utile pour la conception d'offres. Issu à l'origine de *$100M Offers* d'Alex Hormozi — largement assimilé depuis dans le monde de la réponse directe et de la creator economy.

```
              Résultat rêvé  ×  Probabilité perçue d'atteinte
  Valeur  =  ──────────────────────────────────────────────────
                    Délai    ×    Effort & Sacrifice
```

Voici comment actionner les quatre leviers :

| Levier | Ce que cela signifie | Comment augmenter la valeur |
|--------|----------------------|-----------------------------|
| **Résultat rêvé (Dream outcome)** ↑ | Ce que le client veut réellement | Reliez l'offre à l'objectif plus vaste derrière la demande de surface. Spécifiez-le et nommez-le. |
| **Probabilité perçue** ↑ | Croit-il qu'il y parviendra | Preuves (études de cas, clients nommés, données), garanties, précision de la méthodologie |
| **Délai (Time delay)** ↓ | Combien de temps avant le résultat | Onboarding plus rapide, première victoire plus rapide, délai global de bout en bout raccourci |
| **Effort & sacrifice** ↓ | Ce que cela lui coûte en temps/travail/risque en dehors de l'argent | Clé en main (done-for-you), processus plus simple, moins de décisions, courbe d'apprentissage réduite |

**Implication pour la conception d'offres** : la plupart des demandes pour « baisser le prix » sont en réalité des demandes pour « augmenter le numérateur ou diminuer le dénominateur ». Le prix est la comparaison, pas la valeur.

**Pour le framework complet, des exemples et la méthode pour diagnostiquer quel levier est défaillant :** voir [references/value-equation.md](references/value-equation.md)

---

## L'anatomie d'une offre complète

Une offre complète comprend six composantes. Négligez-en une seule et la conversion en souffrira.

| # | Composante | Question à laquelle elle répond |
|---|------------|---------------------------------|
| 1 | **Livrable principal (Core deliverable)** | Qu'obtiennent-ils ? |
| 2 | **Pile de bonus (Bonus stack)** | Qu'obtiennent-ils d'autre qui donne l'impression que le livrable principal est sous-évalué ? |
| 3 | **Garantie** | Que se passe-t-il si cela ne fonctionne pas ? |
| 4 | **Rareté / Urgence** | Pourquoi maintenant et pas plus tard ? |
| 5 | **Nom** | Comment cette chose s'appelle-t-elle ? |
| 6 | **Prix + structure de paiement** | Que paient-ils et comment ? |

La plupart des offres faibles pèchent par les bonus (aucun), les garanties (aucune ou inadaptée) ou la rareté (aucune ou fausse). La plupart des offres agressives au point d'en être gênantes pèchent par la garantie (sur-promesse) ou la rareté (faux compteurs à rebours).

**Pour l'anatomie complète avec des exemples concrets :** voir [references/offer-anatomy.md](references/offer-anatomy.md)

---

## Bibliothèque de référence

| Référence | Quand la consulter |
|-----------|-------------------|
| [value-equation.md](references/value-equation.md) | Diagnostiquer quel levier est défaillant sur une offre qui stagne |
| [offer-anatomy.md](references/offer-anatomy.md) | Construire une offre complète à partir de zéro |
| [guarantee-design.md](references/guarantee-design.md) | Choisir le bon type de garantie pour votre modèle économique |
| [bonus-stacking.md](references/bonus-stacking.md) | Ajouter des bonus qui augmentent la valeur perçue sans dévaloriser l'offre principale |
| [scarcity-urgency.md](references/scarcity-urgency.md) | Créer une rareté *réelle* (et éviter les mécaniques artificielles qui détruisent la confiance) |
| [offer-formats.md](references/offer-formats.md) | Playbooks de formats par type d'activité — prestation, formation, coaching, infoproduit, lead magnet SaaS, contrat d'agence, B2B high-ticket |
| [saas-offers.md](references/saas-offers.md) | Spécifique au SaaS — le piège de la réduction (pourquoi brader pour acquérir se retourne contre vous) + quatre études de cas d'offres SaaS (AudienceTap, SaberSim, Teachable, Kit) |
| [examples.md](references/examples.md) | Exemples concrets anonymisés — avant/après pour chaque type d'activité |

---

## La boucle de diagnostic

Lorsque l'utilisateur dit « mon offre ne convertit pas » ou « je veux améliorer mon offre » :

1. **Identifier le type d'activité** — service, formation, coaching, infoproduit, SaaS, agence, B2B. Le playbook adapté dépend du type.
2. **Formuler l'offre actuelle en langage clair** — nom, prix, ce qu'ils obtiennent, garantie, date limite. Mettez-la par écrit même si elle est actuellement éparpillée à plusieurs endroits.
3. **Appliquer l'équation de valeur** — notez chacun des quatre leviers de 1 à 10. Le score le plus bas constitue la contrainte bloquante.
4. **Auditer l'anatomie** — laquelle des six composantes est manquante ou faible ?
5. **Choisir un seul levier à corriger lors de cette itération** — ne reconstruisez pas tout d'un coup. Le levier le plus puissant est généralement celui qui a obtenu la note la plus basse.
6. **Rédiger la composante modifiée** — nouveau bonus, nouvelle garantie, nouvelle rareté, nouveau nom, nouveau plan de paiement.
7. **Projeter l'impact de manière réaliste** — tablez sur un gain relatif de 10 à 40 % par changement de composante. Multipliez les gains, ne les additionnez pas : +20 % puis +30 % = `1.20 × 1.30 = 1.56` (2 % → 3,12 %, soit +1,12 point de pourcentage). Deux itérations atteignent rarement 2 à 3x ; quiconque promet 5x cherche à vous vendre quelque chose. Validez l'offre combinée par un test (voir ab-testing).

---

## Quand NE PAS utiliser les tactiques de conception d'offres

Certaines mécaniques d'offre fonctionnent à court terme mais coûtent plus cher qu'elles ne rapportent :

- **Rareté manipulatoire** — faux comptes à rebours, mensonges du type « plus que 3 places ». Hausse à court terme, effondrement de la confiance à long terme. À bannir.
- **Garanties trop audacieuses / sur-promesses** — « doublez vos revenus ou nous vous remboursons + 1 000 $ ». Le risque de remboursement ronge les marges ; les rares cas d'échec détruisent publiquement votre réputation.
- **Inflation de bonus** — empiler 50 000 $ de « bonus » sur un produit à 497 $ pour donner l'impression d'une « affaire en or ». Les acheteurs avertis ne s'y trompent pas. Considérez les bonus comme une valeur ajoutée réelle, sans exagération.
- **Esthétique de « vendeur de formation » (course-bro) sur un produit sérieux** — logos dorés, « méthode secrète », fausse urgence. Cela renvoie directement aux codes de l'arnaque. Mauvais public.
- **Casser les prix pour acquérir** — les clients qui *demandent des réductions* résilient (churn) environ 2× plus que ceux qui paient le prix fort, et un coupon ancre le produit comme étant bon marché. N'accordez des remises que pour les montées en gamme / ventes croisées (pour récompenser les clients existants) ou lors de fenêtres saisonnières réelles — jamais pour convertir un nouveau client. Augmentez plutôt la valeur perçue grâce à une offre bien pensée. Voir [saas-offers.md](references/saas-offers.md).

Le ton de ce dépôt : tranché, mais honnête. Bien concevoir des offres ne signifie pas concevoir des offres tapageuses.

---

## Vocabulaire interdit

Lors de la rédaction des textes d'une offre (pages de vente, e-mails, accroches), évitez :

- **« Révolutionnaire », « game-changing », « disruptif », « niveau supérieur » (next-level), « 10x »** — renvoie aux clichés de textes générés par IA ou aux vendeurs de rêve.
- **« Secret », « caché », « ce qu'ils ne veulent pas que vous sachiez »** — pièges à clics (clickbait).
- **« Offre limitée dans le temps » sans réelle limite de temps** — mensonge.
- **« D'une valeur de X $ » ou « Valeur de Y $ » sans élément de comparaison réel** — inflation artificielle.
- **« Garantie à 100 % » sans préciser les conditions** — risqué d'un point de vue juridique et pour la réputation de marque.

Utilisez des chiffres précis, des noms de clients réels, des résultats concrets, des délais véridiques. La précision l'emporte toujours sur les superlatifs.

---

## Compétences associées

- **pricing** — pour les niveaux de prix, la structure des paliers, la métrique de valeur, le packaging, le freemium
- **copywriting** — pour la page qui présente l'offre
- **cro** — pour optimiser le parcours de conversion emprunté par l'offre
- **launch** — pour le moment où vous lancez l'offre
- **paywalls** — pour les versions d'invitations à la mise à niveau intégrées dans l'application
- **sales-enablement** — pour le pitch deck et le one-pager qui portent l'offre lors d'un échange commercial
- **emails** — pour la séquence d'e-mails qui prépare le terrain de l'offre
- **marketing-psychology** — pour les biais cognitifs qui font réussir ou échouer une offre
