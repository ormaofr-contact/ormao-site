---
name: cold-email-writer
description: Rédiger des e-mails de prise de contact personnalisés pour les responsables du recrutement et les fondateurs — précis, humains, loin d'un argumentaire commercial
---

# Rédacteur de cold emails

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Rédiger un e-mail de prise de contact directe à un responsable du recrutement, un fondateur ou un recruteur
- Prendre contact au sujet d'une offre d'emploi pour laquelle il n'a pas été recommandé
- Se présenter à une entreprise pour laquelle il souhaite travailler
- Mentions : "cold email", "reach out", "intro email", "outreach", "contact hiring manager"

## Principe fondamental

Les cold emails échouent parce qu'ils ressemblent à des lettres de motivation. L'objectif est de donner l'impression d'être une personne intelligente qui a véritablement remarqué quelque chose de précis sur l'entreprise — et non un candidat qui étale ses diplômes et états de service.

**L'e-mail doit donner l'impression de :** Un collègue qui mentionne quelque chose d'intéressant qu'il a lu, pas un argumentaire de vente.

## Structure du modèle

### Objet
```
Quick intro — [First Name Last Name]
```
Simple. Pas de piège à clics. Pas d'intitulé de poste. Juste un nom.

### Accroche — Le crochet (2 à 3 phrases)
Commencez par ce qui a véritablement attiré le candidat. Cela doit être spécifique à cette entreprise — et non un compliment générique.

```
I just came across [Company] and ended up spending more time on it than I expected.
[One specific thing that caught their attention — a stat, a product decision, a market insight from the JD or website]
```

**Ce qui fait une bonne accroche :**
- Un chiffre précis ou une statistique issue des supports de l'entreprise ("seulement 5 % du marché est en ligne")
- Une décision produit montrant que vous comprenez le secteur ("vous construisez le produit de zéro aux côtés des souscripteurs, sans vous limiter à la distribution")
- Une observation technique tirée de la fiche de poste ("améliorer l'infrastructure de données pour l'usage des LLM, et pas uniquement la couche modèle")

**Ce qui fait une mauvaise accroche :**
- Générique : "J'adore ce que vous construisez"
- Flou : "Votre mission fait écho en moi"
- Flatteur : "Vous êtes l'une des entreprises les plus passionnantes du secteur"

### Mention de la localisation (si internationale)
Si le candidat se trouve dans un autre pays que celui de l'entreprise, mentionnez-le tôt et de manière informelle :

```
Before you read further, I should mention I'm based in [country]. But if we both
feel there's a strong fit, I'd be open to figuring things out.
```

### Écart d'expérience (le cas échéant)
Si le poste demande plus d'années d'expérience que le candidat n'en possède, reconnaissez-le brièvement et réorientez l'attention :

```
The role mentions [X] years of experience — I'm at [Y], but the work I've
shipped is production-facing and I'd rather you judge that directly.
```

### Le corps du message — Qui il est (3 à 5 phrases)
Poste actuel → parcours pertinent → un ou deux projets. Gardez une approche contextuelle, pas une liste.

```
A bit about me: I currently work at [Company], [one line on what the company does],
where I [what they actually do there — not a job title]. Before that I worked
with teams in [region], mostly around [relevant domain].

On the side I've been building [Project] ([link if applicable]) — [one line: what
it is and one proof point like "got to paying clients" or "20K downloads"].
```

**Règles :**
- Mentionner le travail comme un contexte, pas comme une preuve de grandeur
- Pas d'énumération de réalisations ("J'ai augmenté X de Y %") — laisser le projet parler de lui-même
- Si l'entreprise actuelle fonctionne en télétravail avec une équipe européenne/internationale, le préciser explicitement
- Limiter les mentions de projets à un ou deux au maximum — uniquement les plus pertinents

### Le lien de correspondance (1 à 2 phrases)
Faire le pont entre son parcours et le poste ciblé. Cela doit ressembler à une observation, pas à une affirmation présomptueuse.

```
I think you're looking for [what the role actually wants] — that's the kind of
work I've been doing, and honestly I feel like I'd be a strong fit.
```

Ou plus précis :
```
My stack maps naturally to yours — [specific tech overlap]. But more than the
stack, it's the [domain/problem] that I'm genuinely interested in.
```

### Lien vers le portfolio
```
More about me: [portfolio URL]
```

Une seule ligne. Pas d'explications superflues.

### Conclusion
Terminez sur une note confiante et sans pression. Ni aux abois, ni trop formel.

```
I'm currently at [Company] and open to what's next. I think my experience lends
nicely to what you're building — so I think we'd both get something out of a
conversation.

[First Name]
[email]
```

**À éviter :**
- "Dans l'attente de votre retour"
- "Veuillez trouver ci-joint mon CV"
- "J'aimerais beaucoup avoir l'opportunité de..."
- "Je serais ravi de potentiellement rejoindre..."

## Recherches avant la rédaction

Avant de rédiger l'e-mail, rassemblez :
1. **L'angle de l'entreprise** — parcourez leur site web, la fiche de poste ou la page À propos. Trouvez un élément précis qui vaut la peine d'être mentionné.
2. **Le nom du destinataire** — LinkedIn, page d'équipe ou AngelList. "Bonjour [Prénom]" sera toujours bien plus efficace que "Bonjour Responsable du recrutement".
3. **Projets pertinents** — faites correspondre les réalisations les plus adaptées du candidat au domaine du poste.
4. **Concordance de la stack technique** — ne la mentionnez que s'il y a une réelle correspondance.

Si l'utilisateur fournit une fiche de poste mais aucun site web d'entreprise, demandez-le ou récupérez-le avant de commencer à rédiger.

## Consignes de longueur

- **Idéal :** 200 à 300 mots
- **Maximum :** 400 mots
- **Minimum :** 150 mots (ne sacrifiez pas la substance au profit de la brièveté)

Un texte plus long convient si chaque phrase y a pleinement sa place. Supprimez tout ce qui pourrait s'appliquer à n'importe quelle entreprise.

## Format de sortie

Encadrez toujours l'e-mail final dans un bloc de code brut pour faciliter le copier-coller :

```
Subject: Quick intro — [Name]

Hi [Name],

[Email body]

[First Name]
[email]
```

## Erreurs fréquentes à éviter

**Trop confiant :**
❌ "Je serais un atout exceptionnel pour votre équipe"
❌ "Mon parcours me positionne de manière unique pour ce poste"
✅ "J'ai le sentiment que mon profil correspondrait très bien" — exprime une conviction sans prétendre à une certitude absolue

**Trop humble :**
❌ "Je sais que je n'ai peut-être pas toute l'expérience recherchée, mais..."
❌ "Je vous contacte juste au cas où..."
✅ Reconnaître les manques directement et passer à la suite — sans s'excuser

**Trop long :**
❌ Trois paragraphes énumérant chaque réussite
✅ Un paragraphe sur le parcours, un paragraphe sur la correspondance avec le poste

**Trop générique :**
❌ Commencer par "Je vous écris pour vous faire part de mon intérêt pour..."
✅ Commencer par ce qui a précisément attiré le candidat vers cette entreprise

**Absence de recherche :**
❌ "J'adore votre produit et votre mission"
✅ "La statistique des 5 % — seulement 5 % d'un marché de 25 milliards de dollars en ligne — ne ressemble pas à un manque de fonctionnalités, mais à toute une industrie qui n'a pas encore opéré sa transformation numérique"

## Exemple d'e-mail

```
Subject: Quick intro — Sarah Chen

Hi Marcus,

I just came across Meridian and spent more time on your site than I planned.
What pulled me in was the framing around your data infrastructure — you're not
just building an LLM layer on top of existing records, you're rethinking how
clinical data flows through the system in the first place. That's a harder
problem and a more interesting one.

I'm based in India, flagging that upfront. Happy to figure out the rest if
there's a real fit.

I currently work at Lune, a London-based climate intelligence company, where I
build event-driven data pipelines and agentic AI workflows for emissions
compliance — regulated, data-intensive systems where reliability isn't optional.
I also built Memos, a RAG system from scratch: hybrid retrieval, reranking,
ChromaDB, FastAPI. And InframetAI, an SDK for LLM cost and latency
observability that came out of seeing what breaks when the data layer isn't
designed around how models actually work.

I think you're looking for engineers who've actually built AI systems end to
end, not just wrapped APIs. That's the work I've been doing.

More about me: yourportfolio.com/about

I'm currently at Lune and open to what's next. I think my experience maps
closely to what you're building — so I think we'd both get something out of
a conversation.

Sarah
sarah@email.com
