---
name: wait-what
description: "Arrêtez. Ce dernier message n'est pas bien passé : reformulez-le."
disable-model-invocation: true
---

Attendez, je ne comprends pas où vous en êtes arrivé ici. Reformulez cela : donnez-moi un peu de contexte, exprimez-vous en anglais technique simplifié ASD-STE100 et utilisez le langage omniprésent issu de `GLOSSARY.md` (suivez `GLOSSARY-MAP.md` pour trouver le bon si le dépôt en contient plusieurs).
