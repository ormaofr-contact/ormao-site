---
name: product-marketing
description: "Lorsque l'utilisateur souhaite créer ou mettre à jour son document de contexte marketing produit. À utiliser également lorsque l'utilisateur mentionne « contexte produit », « contexte marketing », « configurer le contexte », « positionnement », « qui est ma cible », « décrire mon produit », « ICP », « profil client idéal », « voix de la marque », « ton de la marque », « charte éditoriale », « qu'avons-nous appris », « consigner cet apprentissage », ou souhaite éviter de répéter les informations fondamentales à travers ses tâches marketing. À utiliser au début de tout nouveau projet avant d'utiliser d'autres compétences marketing — cela crée `.agents/product-marketing.md` auquel toutes les autres compétences se réfèrent pour le contexte lié au produit, à l'audience et au positionnement."
metadata:
  version: 2.2.0
---

# Contexte de marketing produit

Vous aidez les utilisateurs à créer et à maintenir un document de contexte de marketing produit. Celui-ci regroupe les informations fondamentales de positionnement et de message auxquelles les autres compétences marketing se réfèrent, afin que les utilisateurs n'aient pas à se répéter.

Le document est stocké dans `.agents/product-marketing.md`.

## Flux de travail

### Étape 1 : Vérifier le contexte existant

Vérifiez d'abord si `.agents/product-marketing.md` existe déjà. Vérifiez également `.claude/product-marketing.md` ainsi que l'ancien nom de fichier `product-marketing-context.md` (dans `.agents/` ou `.claude/`) pour les configurations antérieures — s'il est trouvé ailleurs que dans `.agents/product-marketing.md`, proposez de le déplacer vers l'emplacement canonique.

**S'il existe :**
- Lisez-le et résumez ce qui y figure — notez sa **Version du document** actuelle ainsi que les dernières entrées du **Changelog** afin que l'utilisateur voie où en est le document et ce qui a changé récemment
- Demandez quelles sections ils souhaitent mettre à jour
- Ne recueillez des informations que pour ces sections
- À chaque enregistrement de fond, incrémentez la version et ajoutez une entrée au changelog (voir Étape 4). Ce document constitue le contexte partagé lu par toutes les autres compétences marketing ; conserver un historique daté de *ce qui a changé et pourquoi* est donc essentiel.

**S'il n'existe pas, proposez deux options :**

1. **Rédiger automatiquement à partir de la base de code** (recommandé) : vous étudiez le dépôt — README, pages de destination, textes marketing, package.json, etc. — et rédigez une V1 du document de contexte. L'utilisateur examine ensuite, corrige et comble les lacunes. C'est plus rapide que de partir de zéro.

2. **Partir de zéro** : passez en revue chaque section de manière conversationnelle, en recueillant les informations une section à la fois.

La plupart des utilisateurs préfèrent l'option 1. Après avoir présenté le brouillon, demandez : « Qu'est-ce qui doit être corrigé ? Que manque-t-il ? »

### Étape 2 : Recueillir les informations

**En cas de rédaction automatique :**
1. Lisez la base de code : README, pages de destination, textes marketing, pages À propos, méta-descriptions, package.json, tous documents existants
2. Rédigez toutes les sections en vous basant sur vos découvertes
3. Présentez le brouillon et demandez ce qui doit être corrigé ou ce qui manque
4. Itérez jusqu'à ce que l'utilisateur soit satisfait

**Si vous partez de zéro :**
Passez en revue chaque section ci-dessous de manière conversationnelle, une par une. Ne déversez pas toutes les questions d'un coup.

Pour chaque section :
1. Expliquez brièvement ce que vous recueillez
2. Posez les questions pertinentes
3. Confirmez l'exactitude des informations
4. Passez à la suivante

Insistez pour obtenir les mots exacts des clients — les citations mot à mot ont bien plus de valeur que des descriptions soignées car elles reflètent la manière dont les clients pensent et s'expriment réellement, ce qui rend le texte plus percutant.

---

## Sections à documenter

### 1. Présentation du produit
- Description en une phrase
- Ce qu'il fait (2-3 phrases)
- Catégorie de produit (dans quel « rayon » vous vous situez — comment les clients vous cherchent)
- Type de produit (SaaS, marketplace, e-commerce, service, etc.)
- Modèle économique et tarification

### 2. Public cible
- Type d'entreprise cible (secteur, taille, maturité)
- Décideurs cibles (rôles, départements)
- Cas d'usage principal (le problème majeur que vous résolvez)
- Jobs to be done (2-3 missions pour lesquelles les clients vous « embauchent »)
- Cas d'usage ou scénarios spécifiques

### 3. Personas (B2B uniquement)
Si plusieurs parties prenantes interviennent dans l'achat, renseignez pour chacune :
- Utilisateur, Champion, Décideur, Acheteur financier, Influenceur technique
- Ce qui compte pour chacun, son défi, et la valeur que vous lui promettez

### 4. Problèmes et points de friction
- Défi central auquel les clients font face avant de vous trouver
- Pourquoi les solutions actuelles ne suffisent pas
- Ce que cela leur coûte (temps, argent, opportunités)
- Tension émotionnelle (stress, peur, doute)

### 5. Paysage concurrentiel
- **Concurrents directs** : Même solution, même problème (ex. : Calendly vs SavvyCal)
- **Concurrents secondaires** : Solution différente, même problème (ex. : Calendly vs planification dans Superhuman)
- **Concurrents indirects** : Approche contradictoire (ex. : Calendly vs assistant personnel)
- En quoi chacun déçoit les clients

### 6. Différenciation
- Différenciateurs clés (fonctionnalités absentes des alternatives)
- En quoi votre manière de résoudre le problème est différente
- Pourquoi c'est meilleur (bénéfices)
- Pourquoi les clients vous choisissent plutôt que les alternatives

### 7. Objections et anti-personas
- Les 3 principales objections rencontrées lors des ventes et comment y répondre
- Qui n'est PAS un bon profil (anti-persona)

### 8. Dynamique de transition (Switching Dynamics)
Les quatre forces du JTBD (Jobs to be Done) :
- **Push (Poussée)** : Quelles frustrations les éloignent de leur solution actuelle
- **Pull (Attraction)** : Ce qui les attire chez vous
- **Habit (Habitude)** : Ce qui les retient dans leur approche actuelle
- **Anxiety (Inquiétude)** : Ce qui les inquiète à l'idée de changer

### 9. Langage client
- Comment les clients décrivent le problème (mot à mot)
- Comment ils décrivent votre solution (mot à mot)
- Termes et expressions à utiliser
- Termes et expressions à éviter
- Glossaire des termes spécifiques au produit

### 10. Voix de marque
- 3 à 5 attributs de voix, chacun accompagné de ce qu'il signifie, ce qu'il ne signifie pas, et d'une phrase réelle issue d'un texte existant
- Ton selon le contexte : comment la voix s'adapte pour le support, les lancements, les erreurs, les ventes et les réseaux sociaux
- Mots de marque : termes que vous vous appropriez, mots que vous n'utilisez jamais (avec la raison)

Construisez cela à partir de textes ayant déjà fait leurs preuves et des écrits propres au fondateur, plutôt qu'à partir d'adjectifs choisis lors d'une réunion. Consultez [references/brand-voice.md](references/brand-voice.md) pour les étapes d'extraction, un exemple complet de profil, des comparatifs avant/après et des guides de voix par profil.

### 11. Éléments de preuve
- Métriques ou résultats clés à citer
- Clients / logos notables
- Extraits de témoignages
- Thèmes de valeur principaux et preuves à l'appui

### 12. Objectifs
- Objectif commercial principal
- Action de conversion clé (ce que vous voulez que les gens fassent)
- Métriques actuelles (si connues)

### 13. Publicités payantes (optionnel, uniquement s'ils diffusent des annonces)
La compétence **ads** consulte cette section afin que l'utilisateur n'ait pas à réexpliquer son compte à chaque session.
- Réalité des marges : le CPA ou ROAS cible qui maintient la rentabilité de l'entreprise, et le seuil plancher critique (le ROAS en dessous duquel, ou le CPA au-dessus duquel, alerter immédiatement)
- Budget et rythme de dépense : budget mensuel et variation quotidienne acceptable
- Réalité des conversions : quelles actions de conversion comptent et quelle est la valeur de chacune, faiblesses de suivi connues (latence, double comptage, ruptures hors ligne), et ce qui distingue un bon prospect d'un simple formulaire rempli
- Convention de nommage des campagnes et objectif de chaque campagne, en une ligne chacune
- Ce que l'agent peut faire (lire, comparer, signaler, rédiger, recommander) et ne peut pas faire sans approbation (modifier les budgets ou enchères, mettre en pause ou lancer, modifier le suivi, publier des annonces)

### 14. Apprentissages
Commencez avec cette section vide. Elle se remplira au fur et à mesure des livraisons (voir « Maintenir les apprentissages » ci-dessous).

---

## Étape 3 : Créer le document

Après avoir recueilli les informations, créez `.agents/product-marketing.md` avec cette structure :

```markdown
# Product Marketing Context

**Document version:** v1
**Last updated:** [date]

## Product Overview
**One-liner:**
**What it does:**
**Product category:**
**Product type:**
**Business model:**

## Target Audience
**Target companies:**
**Decision-makers:**
**Primary use case:**
**Jobs to be done:**
-
**Use cases:**
-

## Personas
| Persona | Cares about | Challenge | Value we promise |
|---------|-------------|-----------|------------------|
| | | | |

## Problems & Pain Points
**Core problem:**
**Why alternatives fall short:**
-
**What it costs them:**
**Emotional tension:**

## Competitive Landscape
**Direct:** [Competitor] — falls short because...
**Secondary:** [Approach] — falls short because...
**Indirect:** [Alternative] — falls short because...

## Differentiation
**Key differentiators:**
-
**How we do it differently:**
**Why that's better:**
**Why customers choose us:**

## Objections
| Objection | Response |
|-----------|----------|
| | |

**Anti-persona:**

## Switching Dynamics
**Push:**
**Pull:**
**Habit:**
**Anxiety:**

## Customer Language
**How they describe the problem:**
- "[verbatim]"
**How they describe us:**
- "[verbatim]"
**Words to use:**
**Words to avoid:**
**Glossary:**
| Term | Meaning |
|------|---------|
| | |

## Brand Voice
| Attribute | Means | Doesn't mean | Example line |
|-----------|-------|--------------|--------------|
| | | | |

**Tone by context:**
- Support:
- Launch:
- Errors:
- Sales:
- Social:
**Terms we own:**
**Never use (and why):**

## Proof Points
**Metrics:**
**Customers:**
**Testimonials:**
> "[quote]" — [who]
**Value themes:**
| Theme | Proof |
|-------|-------|
| | |

## Goals
**Business goal:**
**Conversion action:**
**Current metrics:**

## Paid Ads (optional)
**Target CPA / ROAS:**
**Hard floor:**
**Monthly budget and daily variance:**
**Conversions that count:**
| Action | Means | Value | Feeds bidding? |
|--------|-------|-------|----------------|
| | | | |
**Known tracking weaknesses:**
**Good lead vs. form fill:**
**Campaigns:** [name] — [what it's for]
**Agent may:** read, compare, flag, draft, recommend
**Agent may not (without approval):** change budgets or bids, pause or launch, edit tracking, publish ads

## Learnings
*Decisions and tested lessons. Newest first. Keep it to about 20 active entries.*
| Date | Learning | Evidence | Applies to | Status |
|------|----------|----------|------------|--------|
| | | | | |

## Changelog
*Newest first. One line per revision: what changed and why.*
- v1 ([date]) — Initial context.
```

---

## Étape 4 : Confirmer, versionner et enregistrer

- Présentez le document complété
- Demandez si des ajustements sont nécessaires
- **Définissez la version et le changelog** — c'est l'historique de traçabilité pour un document lu par toutes les autres compétences :
  - **Nouveau document :** définissez `Document version: v1` et une unique entrée dans le Changelog — `- v1 ([date du jour]) — Initial context.`
  - **Mise à jour d'un document existant :** incrémentez la version (v2 → v3…), mettez à jour `Last updated` avec la date du jour, et **insérez une nouvelle entrée au tout début du Changelog** (la plus récente en premier) résumant *ce qui a changé et pourquoi* en une ligne. Ne réécrivez ni ne réorganisez jamais les anciennes entrées.
  - Une bonne entrée mentionne les sections modifiées et la raison, plutôt que « mise à jour du doc ». Exemples :
    - `- v3 (2026-07-16) — Repositioned from "email tool" to "deliverability platform"; added RevOps to the ICP.`
    - `- v2 (2026-06-02) — Rewrote value prop and objections after 5 customer interviews; added competitor Acme.`
  - Utilisez la date du jour au format ISO (AAAA-MM-JJ) pour l'entrée et pour `Last updated`.
  - **Correction purement orthographique / typographique :** n'incrémentez pas la version et n'ajoutez pas d'entrée au changelog — enregistrez simplement la correction. Toute autre modification incrémente la version et reçoit une entrée. Lorsqu'il s'agit d'un repositionnement majeur, indiquez-le clairement — les compétences en aval généreront désormais leurs contenus en fonction de ce nouveau contexte.
- Enregistrez dans `.agents/product-marketing.md`
- Indiquez à l'utilisateur : « Les autres compétences marketing utiliseront désormais ce contexte automatiquement. Le Changelog en bas répertorie chaque révision — consultez-le pour voir l'évolution de votre positionnement. Lancez `/product-marketing` à tout moment pour le mettre à jour. »

---

## Maintenir les apprentissages

Le Changelog enregistre la façon dont le document a évolué. **Learnings** enregistre ce que l'équipe a découvert par l'action sur le terrain : quels angles ont fonctionné, quelles offres ont échoué, quelles décisions ont été prises et pourquoi. Les compétences de rédaction (copywriting, emails, ads, ad-creative, social) le consultent avant d'écrire pour que chaque nouveau brief s'appuie sur les acquis.

**Format des entrées :** une ligne par apprentissage.
- **Learning :** une phrase, suffisamment précise pour influencer une rédaction. « Les titres ancrés sur le prix surpassent les titres axés sur les résultats sur la page tarif » fonctionne. « Être plus clair » ne fonctionne pas.
- **Evidence :** le test, la campagne ou la source, avec les chiffres et la taille de l'échantillon. « Variante B +18 % de démarrages d'essai, 2 400 visiteurs par branche, 3 semaines. »
- **Applies to :** les canaux, segments ou compétences concernés.
- **Status :** `active`, `watch` (une seule donnée, mérite d'être retesté) ou `retired`.

**Ce qui mérite d'y figurer :**
- Un résultat de test ayant atteint l'échantillon prévu, ou un même schéma observé sur deux campagnes ou plus
- Une décision prise par l'utilisateur avec sa justification (positionnement, tarification, abandon d'un canal) que les futures rédactions doivent respecter
- Une correction formulée par l'utilisateur plus d'une fois (« ne l'appelez jamais une plateforme »)

**Ce qui n'y a pas sa place :** les anecdotes isolées (notez-les en `watch` ou laissez-les de côté), les notes de tâches et tout ce qui relève d'une autre section. Une nouvelle objection va dans Objections ; une nouvelle formule client va dans Customer Language.

**Quand archiver une entrée :** un test ultérieur la contredit, le produit ou le marché a évolué sous-jacent (nouvelle tarification, nouvel ICP), ou elle n'a plus été pertinente depuis deux trimestres. Passez le statut à `retired` et ajoutez une ligne explicative, plutôt que de la supprimer, afin d'éviter de retester une question déjà tranchée. Déplacez les lignes archivées vers le bas, et archivez-les définitivement dès que le tableau dépasse une vingtaine de lignes actives.

**Qui rédige :** toute compétence qui termine un test, une campagne ou un post-mortem peut proposer une ligne. Présentez la ligne proposée à l'utilisateur et ajoutez-la après validation, avec une incrémentation de version et une ligne dans le Changelog comme pour toute modification de fond. Les boucles qui s'exécutent de façon programmée le font via leur étape de fin de session (voir **marketing-loops**).

---

## Conseils

- **Soyez précis** : Demandez « Quelle est la frustration n°1 qui les amène chez vous ? » plutôt que « Quel problème résolvent-ils ? »
- **Capturez les mots exacts** : Le langage client est bien plus percutant que des formulations soignées
- **Demandez des exemples** : « Pouvez-vous me donner un exemple ? » permet d'obtenir de bien meilleures réponses
- **Validez au fur et à mesure** : Résumez chaque section et demandez confirmation avant de passer à la suite
- **Ignorez ce qui ne s'applique pas** : Tous les produits n'ont pas besoin de l'intégralité des sections (par ex., les personas pour le B2C, les annonces payantes s'ils n'en font pas)
