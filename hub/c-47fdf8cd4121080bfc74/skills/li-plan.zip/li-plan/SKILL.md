---
name: li-plan
description: >-
  Planifier la semaine sur LinkedIn : quoi publier, quand publier et avec qui
  interagir. À utiliser lorsque l'utilisateur dit « planifie ma semaine », « que
  devrais-je publier », « calendrier de contenu », « je n'ai rien à publier », ou
  souhaite un calendrier de publication et une liste d'engagement.
---

# li-plan

La tour de contrôle. Tout le reste dans ce pack exécute ; ceci décide de ce qui
doit être exécuté. Lancez-le une fois par semaine, le même jour.

## Entrée

Si `~/.claude/linkedin/voice.md` et `log.md` existent, lisez-les : le plan
ne doit pas répéter un thème des deux dernières semaines. S'ils n'existent pas,
demandez quatre choses et notez-les :

1. Ce que l'utilisateur vend, et à qui.
2. Les trois ou quatre thèmes pour lesquels il souhaite être reconnu.
3. Ce qui s'est réellement passé cette semaine : un appel client, un chiffre,
   une erreur, une réalisation concrète, un débat qu'il a eu. C'est de là que
   viennent les posts.
4. Dix à vingt personnes ou entreprises auprès desquelles il est utile d'être
   visible.

## Quoi publier

Quatre posts par semaine valent mieux que sept. La régularité est un plancher,
pas un objectif, et le cinquième post d'une semaine est presque toujours le
plus faible, celui qui tire la moyenne vers le bas.

Variez au fil de la semaine, jamais deux fois le même type consécutivement :

| type | fréquence | rôle |
| --- | --- | --- |
| **Proof** | 1 par semaine | quelque chose qui s'est produit, avec un chiffre |
| **Opinion** | 1 par semaine | une prise de position qui pourrait vous faire perdre des abonnés |
| **Teach** | 1 par semaine | une action concrète que le lecteur peut appliquer aujourd'hui |
| **Story** | 1 tous les 15 jours | une scène avec du dialogue et un coût réel |
| **Offer** | 1 tous les 15 jours | ce que vous vendez, formulé simplement, sans détours |

Pour chaque créneau, indiquez : le thème, l'angle précis tiré des événements
réels de la semaine, et le numéro de formule d'accroche de
`li-post/hooks.json` qui y correspond. Pas un sujet général, mais un angle.
« L'IA » n'est pas un plan. « La proposition que nous avons perdue parce que
notre brouillon généré par IA contenait un tiret cadratin » est un post.

## Quand publier

Publiez lorsque l'audience de l'utilisateur est derrière un bureau. Pour une
audience B2B sur un même fuseau horaire, du mardi au jeudi, entre 7h30 et 9h30
heure locale, constitue la référence par défaut, avec le lundi après-midi et le
vendredi matin en second choix. Les week-ends sont réservés aux posts de type
récit personnel, ou à l'absence de publication.

Mais affirmez-le clairement : **le jour et l'heure comptent bien moins que la
qualité de la première ligne.** Si l'utilisateur optimise les horaires de
publication avant même que ses accroches ne fonctionnent, il ne concentre pas
ses efforts au bon endroit, et vous devez le lui signaler.

Calculez les horaires selon le fuseau horaire de son audience, et non celui de
l'utilisateur, s'ils sont différents.

## Avec qui interagir

Constituez une liste de 10 personnes, réparties en trois groupes :

- **5 visibilité** : des personnes disposant d'une audience convoitée par
  l'utilisateur, et aux publications desquelles il peut apporter une vraie
  valeur ajoutée. Commentez avant qu'elles n'atteignent 20 commentaires, sinon
  personne ne le verra.
- **3 pairs** : même niveau, même domaine. C'est le groupe qui pratique la
  réciprocité.
- **2 acheteurs** : des personnes susceptibles d'acheter réellement. Commentez
  leurs publications pendant des semaines avant tout message privé, et ne faites
  jamais de pitch commercial en commentaire.

20 minutes par jour, avant de publier, pas après. Ce sont les commentaires sur
les publications des autres qui permettent aux posts de l'utilisateur de décoller.

## Sortie

```
SEMAINE DU 8 SEPTEMBRE

LUN  engagement uniquement  (20 min, liste ci-dessous)
MAR  8h15   PROOF    #17 Ancrage Temporel   - la refonte de proposition de 5h -> 20min
MER  engagement uniquement
JEU  8h00   OPINION  #1  À contre-courant   - pourquoi nous avons supprimé l'appel de découverte
VEN  8h30   TEACH    #21 Valeur Directe     - l'email de relance en 4 lignes, partagé sans retenue
SAM  -
DIM  16h00  STORY    #9  Entrée Directe     - l'email « nous avons choisi quelqu'un de moins cher »

ENGAGEMENT  (5 visibilité / 3 pairs / 2 acheteurs)
  ...

Dites « rédige mardi » et j'en préparerai le brouillon.
```

Écrivez le plan dans `~/.claude/linkedin/plan.md` pour que les autres compétences
puissent le lire. Rien n'est programmé ni publié où que ce soit : il s'agit d'un
plan, et c'est l'utilisateur qui l'exécute.
