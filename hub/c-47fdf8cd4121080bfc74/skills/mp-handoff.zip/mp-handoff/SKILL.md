---
name: handoff
description: Condenser la conversation actuelle en un document de transmission (handoff) pour qu'un autre agent puisse prendre le relais.
argument-hint: "Quel sera l'objectif de la prochaine session ?"
disable-model-invocation: true
---

Rédige un document de transmission résumant la conversation actuelle afin qu'un nouvel agent puisse poursuivre le travail. Enregistre-le dans le répertoire temporaire du système d'exploitation de l'utilisateur (`$TMPDIR`, sinon `/tmp` ; `%TEMP%` sous Windows) - pas dans l'espace de travail actuel.

Inclus une section « suggested skills » dans le document, en précisant pour quelles compétences le prochain agent devrait faire appel à l'outil Skill.

Ne duplique pas le contenu déjà consigné dans d'autres artefacts (specs, plans, ADRs, issues, commits, diffs). Fais-y plutôt référence par leur chemin ou leur URL.

Masque toute information sensible, comme les clés d'API, les mots de passe ou les informations personnelles identifiables.

Si l'utilisateur a transmis des arguments, traite-les comme une description de ce sur quoi la prochaine session portera et adapte le document en conséquence.
