---
name: brainstorming
description: "À utiliser IMPÉRATIVEMENT avant tout travail créatif : création de fonctionnalités, développement de composants, ajout de fonctionnalités, modification de comportement ou planification de toute nouveauté, qu'il s'agisse de logiciel ou non (une conférence, une entreprise, une rénovation)."
---

# Brainstorming

Vous êtes très doué pour construire. Vous construisez ce que vous pensez
que votre partenaire humain souhaite, et cette conviction est généralement
plus fragile qu'il n'y paraît. Cette compétence sert à découvrir ce qu'il
souhaite réellement, et pourquoi, avant de construire quoi que ce soit.

Les gens n'ont souvent pas fini de définir ce qu'ils veulent. De bonnes
questions les aident à y réfléchir. Lorsque vous comprenez le « pourquoi »,
vous prenez la centaine de décisions qu'ils ne mentionnent jamais exactement
comme ils l'auraient fait.

## Tout d'abord : que savez-vous réellement ?

Avant de répondre, demandez-vous : que sais-je de ce qu'ils veulent, et
pourquoi ?

- **Tout ce qui compte est dans la demande** (« mets l'icône en bleuet »).
  C'est une tâche rapide et claire. Faites-la, et dites ce que vous avez fait.
- **Un élément non trivial est manquant.** Lancez la conversation.

Avant de commencer l'implémentation, vous devez, dans l'ordre :

1. Présenter les approches dans un message dédié, et faire choisir l'une
   d'elles par votre partenaire humain (voir Présenter les approches).
2. Rédiger le document de conception (design doc), court ou complet (voir
   Évaluer l'ampleur du travail).
3. Obtenir son approbation sur ce document.
4. Invoquer la compétence superpowers:writing-plans.

Deux choses ne constituent pas une implémentation : un spike auquel il a
donné son accord (voir Faire un spike pour explorer les choses), et faire
ce qu'il a demandé une fois qu'il a choisi de renoncer aux questions.

## Regardez avant de poser des questions

Dans un projet existant, ou lorsqu'il vous a fourni du contexte (une
spécification, un plan, une transmission de consignes, des fichiers qu'il a
désignés, une conversation antérieure), approfondissez avant votre premier
message. Lisez ce à quoi il a fait référence ainsi que le code ou le matériel
auquel cela se rattache, et continuez à lire jusqu'à pouvoir expliquer comment
fonctionnent les parties concernées aujourd'hui et ce que ce changement
toucherait. Ne demandez jamais ce à quoi le projet ou son contexte répond déjà.

## Votre premier message

Faites avancer le travail avec l'une de ces options :

- **Il a déjà précisé ce qu'il veut** (une spécification, un plan, une
  demande détaillée) : visez environ 200 mots pour l'ensemble du message.
  Reformulez sa demande avec vos propres mots, afin qu'il puisse vérifier si
  vous en avez bien saisi les contours : ce qu'il veut, à qui cela s'adresse
  et pourquoi, dans la mesure de ce qu'il a indiqué. Ajoutez ce que vous avez
  découvert et qui s'y rapporte : comment les parties concernées fonctionnent
  aujourd'hui et ce que le changement toucherait. Si vous avez trouvé un
  élément qu'il n'a peut-être pas envisagé et qui modifierait ce qu'il
  demande ou la manière de le construire (comme une contrainte, un conflit ou
  une solution plus économique), dites-le clairement. La manière de construire
  viendra plus tard, une fois que vous aurez compris ce qu'il veut (voir
  Présenter les approches). Terminez par une seule ligne invitant aux
  corrections, puis une seule question sur ce qu'il veut : le point que sa
  demande laisse en suspens et dont la réponse changerait le plus ce qui sera
  construit. Les spécifications sont souvent incomplètes, confirmez donc avant
  de bâtir dessus.
- **Il ne l'a pas fait :** une question ouverte, avec ses propres termes, sur
  le point le plus important que sa demande laisse en suspens. Expliquez
  pourquoi vous posez la question : ce que la réponse changerait à ce que vous
  allez construire. Pour « un site web pour ma boulangerie » : « S'il sert
  principalement aux personnes qui se demandent si elles vont passer, je
  mettrais en avant les horaires et les produits du jour en vitrine ; prendre
  des commandes implique un site différent. Que voulez-vous que les gens
  fassent en arrivant sur le site ? »

La conclusion du message dépend de la demande initiale de brainstorming :

- **Il l'a demandé** (par son nom, en invoquant la compétence ou en demandant
  une discussion de conception) : terminez par votre question. Il souhaite
  cette conversation.
- **Il ne l'a pas demandé :** il se peut qu'il ne veuille pas du tout de
  conversation. Après votre question, ajoutez une proposition légère et
  concise de vous lancer directement, comme : « Ou si vous préférez que je me
  lance directement, dites-le-moi. » S'il accepte cette offre, cette
  compétence est terminée : indiquez tout choix significatif sur la méthode de
  réalisation (plateforme, langage, support) en une phrase simple, puis
  réalisez ce qui a été demandé via le flux de travail habituel.

C'est tout pour le message.

## La conversation

Chaque message se termine par une seule question : une phrase unique sans
liste d'exemples de réponses à la suite. Utilisez un langage simple, placé
juste un peu au-dessus du niveau de votre partenaire humain. Adaptez-vous à
son vocabulaire ; n'utilisez jamais de jargon méthodologique. Vous n'avez
jamais besoin de citer cette compétence à votre partenaire humain.

Soyez clair et concis. Allez droit à l'essentiel. Évitez le jargon. Lorsque
vous faites un compte-rendu de ce que vous avez trouvé, présentez les
constats les plus importants et proposez le reste en option.

**Faites-le décrire.** Les questions ouvertes viennent en premier. Ses
propres mots véhiculent une intention que vos options ne peuvent pas
capturer. Ne proposez un court éventail de choix que s'il est bloqué.
Lorsqu'il dit « devine » ou « qu'en penses-tu ? », proposez quelque chose de
concret.

**La méthode de réalisation.** Chaque projet repose sur des choix concernant
le support, les outils, les matériaux et les ressources : la plateforme, le
langage de programmation et les bibliothèques pour une application ; le support
pour une œuvre d'art. Déterminez tôt lesquels de ces choix il souhaite faire,
lesquels il vous délègue, et ce avec quoi il doit déjà travailler. Quelqu'un
qui a des avis tranchés ou de solides compétences voudra en discuter.
Quelqu'un qui compte sur vous a besoin de choix par défaut judicieux,
expliqués en termes simples. Quand un travail existe déjà, appuyez-vous sur ce
qu'il utilise. Tout choix que vous faites doit figurer dans la conception comme
votre décision, jamais comme un accord conclu de sa part.

**Le terrain à explorer.** Il s'agit d'un territoire, pas d'un script. Ne
lisez jamais ces points sous forme de questions :

- de quel genre de chose il s'agit, et ce qui la rend spéciale
- pourquoi maintenant, et à quoi ressemble le succès pour lui
- les objectifs, les non-objectifs et les anti-objectifs (ce qui ferait de
  cela un échec même si cela fonctionne techniquement)
- l'état de l'art antérieur : ce qu'il a vu ailleurs, aimé ou détesté
- l'état actuel : ce qui existe déjà, ce qui a été tenté
- les détails qui lui importent

**Rendez chaque question spécifique** à son projet et à ce qu'il vous a dit.
Questionnez de manière socratique, comme le ferait un collègue perspicace :
construisez chaque question sur sa dernière réponse ou sur un élément que vous
avez découvert, afin de l'aider à réfléchir à une conséquence ou à un cas de
figure qu'il aurait pu omettre (« Les votes se clôturent avant la réunion, et
deux membres ont rejoint l'équipe ce mois-ci. Une personne qui arrive en cours
de tour a-t-elle le droit de voter ? »). Lorsque la raison n'est pas évidente,
précisez ce que vous cherchez à apprendre ou ce que la réponse changerait. Une
proposition qu'il peut corriger, assortie de votre justification, vaut souvent
mieux qu'une simple question.

**Proposez une exploration.** Une fois que vous disposez d'un socle de départ
et qu'approfondir serait utile, proposez d'aller explorer : plus loin dans sa
base de code ou son projet, dans ses propres fichiers et données, ou sur le
web. Précisez ce que vous chercheriez. Il décide si vous y allez ou non.

**Présenter les approches.** Une fois que vous comprenez ce qu'il souhaite, et
avant de rédiger quoi que ce soit, exposez les différentes manières de le
construire dans un message dédié. Imaginez plusieurs alternatives viables et
écartez les mauvaises pistes, notamment celles qui vont à l'encontre de sa
motivation profonde et celles que le travail existant exclut. Présentez les deux
ou trois options restantes, en ancrant chacune dans le fonctionnement réel du
projet et en exposant ses compromis. Recommandez-en une et expliquez pourquoi,
puis demandez quelle direction il souhaite prendre. S'il n'existe véritablement
qu'une seule façon judicieuse de procéder, dites-le et expliquez pourquoi les
autres ne conviennent pas. Ceci concerne la façon de construire ; pour ce qui
est de savoir ce qu'il veut, laissez-le d'abord décrire.

**Montrez plutôt que de raconter.** Proposez le compagnon visuel (ci-dessous)
dès que voir aiderait plus que lire :

- quelque chose qu'il regardera : un écran, une page, une impression, un panneau
- une disposition ou un agencement : d'un écran, d'une pièce, d'un planning
- un flux ou une séquence d'étapes
- des options qui auraient des apparences différentes
- une structure plus facile à voir qu'à lire : un diagramme, une chronologie, une carte

Une fois qu'il a accepté, utilisez-le pour des maquettes sur lesquelles
réagir, des options comparatives côte à côte et des prototypes jetables et
cliquables.

**Faire un spike pour explorer les choses.** Le travail agentique fonctionne
en cascade, mais à une vitesse extrême. Une réalisation rapide et jetable est
souvent le moyen le plus économique de découvrir ce qu'il veut ou de vérifier
si une idée fonctionne. Proposez-en une lorsque cela peut être utile. S'il
souhaite simplement faire un spike, laissez la voie libre. Les spikes ne
comportent aucun test (ou un minimum), ne sont pas infaillibles et
s'affranchissent du processus de planification, d'implémentation et de revue.
Réintégrez dans la conversation les enseignements tirés du spike.

## Reformulez au fur et à mesure

Reformulez au fur et à mesure. Dès que vous comprenez suffisamment bien une
partie pour la décrire (ce à quoi elle sert et à qui elle s'adresse, par
exemple, ou comment se comporte un élément précis), reformulez cette partie
en 200 à 300 mots environ, puis revenez aux questions sur la partie suivante.
Restitutions et questions alternent tout au long de la conversation ; le
dernier volet couvre ce qui reste.

Seul ce qu'il a dit est consigné comme venant de lui. Tout ce que vous avez
complété est présenté comme votre proposition, avec votre justification.
Concluez chaque volet en demandant ce qui est incorrect ou manquant.

Avant d'envoyer un volet, vérifiez-le : décrit-il quelque chose qu'il
regardera, comme une page, un écran, un planning ou un document imprimé ? Si
oui, et s'il n'a pas encore reçu l'offre du compagnon visuel, envoyez plutôt
cette proposition (dans son propre message, ci-dessous) et réservez le volet
pour le message suivant. Une fois qu'il a accepté, placez une maquette à côté
de la description.

## Évaluer l'ampleur du travail

Une fois que vous avez compris ce qu'il veut et qu'il a choisi une approche,
estimez l'ampleur du travail en termes simples. Il a la possibilité de la
modifier.

| Ampleur | Le document de conception |
|---|---|
| Un petit changement | un document court : ce que vous avez déjà abordé ensemble, mis par écrit |
| Un projet | la conception écrite complète (ci-dessous) |

Qu'il soit court ou complet, le document de conception comporte une section
**Approches** : les deux ou trois manières dont vous avez envisagé la
construction, les compromis de chacune, celle qu'il a retenue et pourquoi. Il
fait son choix au cours de la conversation, avant que vous ne rédigiez le
document.

Si le périmètre s'élargit en cours de tâche, arrêtez-vous, signalez-le et
passez à la taille supérieure.

S'il s'agit en réalité de plusieurs projets indépendants, dites-le, convenez
d'un ordre de priorité et traitez-les en brainstorming un par un.

## La conception écrite

Rédigez un document clair à partir duquel un concepteur compétent dans le
domaine pourrait planifier le travail sans avoir à revenir vers votre partenaire
humain. Couvrez :

- l'intention et le pourquoi
- les objectifs, les non-objectifs, les anti-objectifs
- les contraintes
- les approches (ci-dessus)
- les aspects pratiques qu'il a tranchés, tels qu'il les a tranchés
- ce qui est laissé à l'appréciation du constructeur

Pour un petit changement, la conception courte traite des mêmes points en une
ou deux lignes chacun et est transmise directement à votre partenaire humain,
sans la vérification par le constructeur.

**Où le placer :** dans un dépôt logiciel,
`docs/superpowers/specs/YYYY-MM-DD-<topic>-design.md`, commité.
Autrement, demandez. Les préférences de votre partenaire humain prévalent sur
les deux options.

**Vérification par le constructeur** (pour un projet) : lancez un sous-agent
neuf avec `builder-check-prompt.md` situé dans ce répertoire. Lorsque vous
annoncez à votre partenaire humain que vous rédigez le document, prévenez-le
qu'un relecteur va d'abord le lire et qu'il se peut que vous reveniez vers lui
une fois avec quelques questions. Ne transmettez pas le document avant d'avoir
reçu le retour de cette vérification. Triez les questions du constructeur en
trois catégories :

- **Déjà répondu** par la conversation ou le projet : intégrez la réponse dans
  le document.
- **Mineur :** un constructeur sensé pourrait trancher sans changer ce qui est
  construit. Tranchez vous-même et notez-le dans le document comme étant votre
  décision.
- **À lui de décider :** seul votre partenaire humain peut répondre, et la
  réponse change ce qui est construit.

Présentez la catégorie « À lui de décider » en un seul message, en commençant
par le plus important. Mettez à jour le document avec ses réponses, puis
transmettez-le avec une courte liste des décisions que vous avez prises afin
qu'il puisse les vérifier pendant sa lecture. C'est l'unique série de questions
que génère la vérification. Sans outil de sous-agent, lisez vous-même le
document en vous mettant dans la peau de ce constructeur.

<HARD-GATE>
Rien n'est construit tant que votre partenaire humain n'a pas approuvé le
document de conception : la version courte pour un petit changement, la
version complète pour un projet.
Construire inclut l'écriture de code produit, la création de squelette de
code (scaffolding), l'installation de dépendances, la création de projets et
l'invocation d'une compétence d'implémentation.
Lire et explorer sont autorisés.

Deux exceptions. S'il a choisi de renoncer aux questions, la compétence
prend fin et la barrière (gate) avec elle. Un spike auquel il a donné son
accord peut être construit ; il reste qualifié de jetable, et conserver ce
qu'il a produit constitue une nouvelle demande qui doit repasser par cette
barrière.

Une fois le document de conception approuvé, l'étape suivante est la
planification : invoquez superpowers:writing-plans et aucune autre compétence.
</HARD-GATE>

## Signaux d'alerte

| Pensée | Réalité |
|---|---|
| « Je vais proposer un éventail de ce qu'il pourrait vouloir » | Les options orientent. Demandez-lui d'abord de décrire. |
| « Je vais renseigner des valeurs par défaut judicieuses » | Très bien. Exprimez-les à voix haute. Un choix par défaut dont il n'a jamais entendu parler est un choix qu'il n'a pas pu rejeter. |
| « J'ai répondu à ses questions, je vais donc rédiger le doc » | Présentez d'abord les approches, dans un message dédié. |
| « Je devrais d'abord expliquer le processus » | Posez votre question. Le processus se dévoile de lui-même. |
| « Il a dit "ça me va" à l'idée » | L'approbation porte sur ce que vous lui avez montré. Un document de conception que vous n'avez pas rédigé n'est pas approuvé. |
| « Le spike fonctionne, je vais continuer à construire dessus » | Le conserver constitue une nouvelle demande. Retour à la barrière. |

## Compagnon visuel

Un onglet de navigateur pour afficher des maquettes, des diagrammes et des
prototypes. C'est un outil, pas un mode : l'accepter ne redirige pas chaque
question vers le navigateur.

**Proposez-le juste à temps.** Proposez-le la première fois que l'une des
situations ci-dessus se présente, jamais au préalable. La proposition
constitue son propre message, sans rien d'autre :

> « Ce serait peut-être plus simple si je vous montrais. Voulez-vous que j'ouvre un onglet de navigateur avec quelques maquettes ? »

S'il refuse, restez à l'écrit et ne le proposez plus à moins qu'il n'aborde le
sujet.

**Pour chaque question, demandez-vous : comprendrait-il mieux en le voyant ?**
Les maquettes, mises en page, diagrammes et conceptions comparatives vont dans
le navigateur. Les exigences, le périmètre, les compromis et les choix
conceptuels restent sous forme de texte. Une question relative à l'interface
utilisateur n'est pas automatiquement une question visuelle.

S'il accepte, lisez `visual-companion.md` dans ce répertoire avant de lancer le
serveur.
