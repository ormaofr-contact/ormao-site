---
name: yt-comment
description: >-
  Rédiger des réponses aux commentaires YouTube avec la voix du créateur,
  triées selon leur pertinence. À utiliser pour « répondre à mes commentaires »,
  « gérer l'espace commentaires », « quelqu'un a demandé X », ou un fil de
  commentaires collé.
---

# yt-comment

L'espace commentaires est un levier de rétention, pas une corvée. Les réponses apportées dans les premières heures déterminent si un fil devient une conversation que d'autres personnes liront.

## Avant d'écrire

1. Lisez `~/.claude/youtube/voice.md` s'il existe. Il s'agit du profil vocal de l'utilisateur : sa façon de parler face caméra, les mots qu'il n'utilise jamais, à qui il s'adresse, ce qu'il refuse d'affirmer. S'il n'existe pas, demandez **trois de ses propres vidéos**, lisez-les ou transcrivez-les, déduisez-en le ton et rédigez le fichier. Un script qui n'adopte pas la bonne voix est pire que pas de script du tout, car l'utilisateur doit le lire à voix haute.
2. N'inventez jamais un chiffre, un résultat ou une source. Si un chiffre permettait de renforcer le propos et que vous n'en avez pas, demandez-le ou écrivez la phrase sans lui.

## Toujours trier en premier

Triez ce que l'utilisateur colle en quatre catégories et indiquez combien il y en a dans chacune avant d'écrire quoi que ce soit :

1. **Questions** - répondez-y. Ce sont les sujets de votre prochaine vidéo, notez donc les récurrences.
2. **Corrections** - s'ils ont raison, admettez-le clairement et remerciez-les. Ne débattez jamais d'un fait que vous ne pouvez pas vérifier.
3. **Compliments** - répondez à quelques-uns, brièvement, en mentionnant un élément précis de leur commentaire. Un mur de réponses « merci ! » identiques donne l'impression d'être automatisé parce qu'il l'est.
4. **Provocations** - ne répondez pas. Indiquez-le et passez à la suite. Ne formulez jamais de réplique cinglante, même si elle est méritée.

## Rédiger la réponse

- Moins de 30 mots. Une longue réponse dans un fil de commentaires est un article de blog que personne n'a demandé.
- Répondez à la vraie question dès la première phrase.
- Une question en retour, uniquement si elle est authentique.
- Pas d'émojis, sauf si les réponses de l'utilisateur en utilisent déjà. Vérifiez son fichier vocal.
- Ne promettez jamais une vidéo que vous n'avez pas convenu de produire.

## Le cœur et l'épingle

Indiquez QUEL commentaire unique épingler et pourquoi. Épinglez la question que le plus grand nombre de personnes se pose également, pas la plus gentille. Mettez des cœurs généreusement : cela ne coûte rien et c'est visible.

## Le sas de validation

Rien n'est publié directement ici. Cette compétence rédige et vous publiez. Chaque réponse se termine par un bloc que l'utilisateur peut copier, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
