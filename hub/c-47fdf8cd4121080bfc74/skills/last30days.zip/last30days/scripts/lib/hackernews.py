"""Hacker News search via Algolia API (free, no auth required).

Uses hn.algolia.com/api/v1 for story discovery and comment enrichment.
No API key needed - just HTTP calls via stdlib urllib.
"""

import datetime
import html
import math
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.client import HTTPException
from typing import Any, Dict, List, Optional

import re

from . import http, log
from .query import extract_core_subject
from .relevance import token_overlap_relevance

# Common HN prefixes that can cause false-positive keyword matches
_HN_PREFIXES = re.compile(r"^(Tell HN|Show HN|Ask HN|Launch HN)\s*:\s*", re.IGNORECASE)

ALGOLIA_SEARCH_URL = "https://hn.algolia.com/api/v1/search"
ALGOLIA_SEARCH_BY_DATE_URL = "https://hn.algolia.com/api/v1/search_by_date"
ALGOLIA_ITEM_URL = "https://hn.algolia.com/api/v1/items"
# Official HN Firebase item API — `kids` is in the order the thread displays
# top-level comments (Algolia's /items children do not carry useful points).
FIREBASE_ITEM_URL = "https://hacker-news.firebaseio.com/v0/item"

DEPTH_CONFIG = {
    "quick": 15,
    "default": 30,
    "deep": 60,
}

MIN_STORY_POINTS = 2
HN_OVERFETCH_MULTIPLIER = 2

ENRICH_LIMITS = {
    "quick": 3,
    "default": 5,
    "deep": 10,
}

DISCOVERY_LIMITS = {"quick": 20, "default": 40, "deep": 60}


def _log(msg: str):
    log.source_log("HN", msg, tty_only=False)


def _date_to_unix(date_str: str) -> int:
    """Convert YYYY-MM-DD to Unix timestamp (start of day UTC)."""
    parts = date_str.split("-")
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    dt = datetime.datetime(year, month, day, tzinfo=datetime.timezone.utc)
    return int(dt.timestamp())


def _unix_to_date(ts: int) -> str:
    """Convert Unix timestamp to YYYY-MM-DD."""
    dt = datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc)
    return dt.strftime("%Y-%m-%d")


def _strip_html(text: str) -> str:
    """Strip HTML tags and decode entities from HN comment text."""
    import re
    text = html.unescape(text)
    text = re.sub(r'<p>', '\n', text)
    text = re.sub(r'<[^>]+>', '', text)
    return text.strip()


def search_hackernews(
    topic: str,
    from_date: str,
    to_date: str,
    depth: str = "default",
) -> Dict[str, Any]:
    """Search Hacker News via Algolia API.

    Args:
        topic: Search topic
        from_date: Start date (YYYY-MM-DD)
        to_date: End date (YYYY-MM-DD)
        depth: 'quick', 'default', or 'deep'

    Returns:
        Dict with Algolia response (contains 'hits' list).
    """
    count = DEPTH_CONFIG.get(depth, DEPTH_CONFIG["default"])
    fetch_count = count * HN_OVERFETCH_MULTIPLIER
    from_ts = _date_to_unix(from_date)
    to_ts = _date_to_unix(to_date) + 86400  # Include the end date

    # Use extracted core subject instead of raw topic for cleaner Algolia matching
    core = extract_core_subject(topic)
    # Hyphens and commas tokenize awkwardly in Algolia; flatten them so themed
    # queries like "ts-bun-node" or "claude, personal agents" become plain words.
    core_flat = _flatten_query_for_algolia(core)
    _log(f"Searching for '{core_flat}' (raw: '{topic}', since {from_date}, count={count})")

    # Use relevance-sorted search. The HN Algolia index only allows
    # `created_at_i` in numericFilters; `points` is NOT in its
    # `numericAttributesForFiltering`, so a `points>N` clause makes the API
    # return HTTP 400 ("invalid numeric attribute(points)") and zero stories.
    # Low-engagement stories are filtered client-side after overfetching so the
    # invalid numeric filter is not reintroduced.
    # NOTE: restrictSearchableAttributes=title omitted intentionally — it would
    # miss Ask HN/Show HN threads where the topic appears in the body.
    params = {
        "query": core_flat,
        "tags": "story",
        "numericFilters": f"created_at_i>{from_ts},created_at_i<{to_ts}",
        "hitsPerPage": str(fetch_count),
    }
    # Algolia defaults to AND across query tokens, so a 4-5 word theme query
    # matches no stories. Mark all-but-the-first token as optional so Algolia
    # ranks by how many tokens match instead of requiring every one.
    tokens = core_flat.split()
    if len(tokens) > 1:
        params["optionalWords"] = " ".join(tokens[1:])

    from urllib.parse import urlencode
    url = f"{ALGOLIA_SEARCH_URL}?{urlencode(params)}"

    try:
        response = http.request("GET", url, timeout=30)
    except http.HTTPError as e:
        _log(f"Search failed: {e}")
        return {"hits": [], "error": str(e)}
    except Exception as e:
        _log(f"Search failed: {e}")
        return {"hits": [], "error": str(e)}

    raw_hits = response.get("hits", [])
    qualifying_hits = [
        hit for hit in raw_hits
        if (hit.get("points") or 0) > MIN_STORY_POINTS
    ]
    hits = qualifying_hits[:count]
    dropped_low_engagement = len(raw_hits) - len(qualifying_hits)
    if dropped_low_engagement:
        _log(f"Filtered {dropped_low_engagement}/{len(raw_hits)} low-engagement stories")
    if len(hits) != len(raw_hits):
        response = {**response, "hits": hits}
    _log(f"Found {len(hits)} stories")
    return response


def fetch_discovery_listings(
    from_date: str,
    to_date: str,
    depth: str = "default",
) -> Dict[str, Any]:
    """Fetch topic-less HN front-page and best-in-window story listings."""
    limit = DISCOVERY_LIMITS.get(depth, DISCOVERY_LIMITS["default"])
    from_ts = _date_to_unix(from_date)
    to_ts = _date_to_unix(to_date) + 86400
    from urllib.parse import urlencode

    urls = [
        f"{ALGOLIA_SEARCH_URL}?{urlencode({'tags': 'front_page', 'hitsPerPage': str(limit)})}",
        f"{ALGOLIA_SEARCH_URL}?{urlencode({
            'tags': 'story',
            'numericFilters': f'created_at_i>{from_ts},created_at_i<{to_ts}',
            'hitsPerPage': str(limit),
        })}",
    ]
    hits: list[dict[str, Any]] = []
    errors: list[str] = []
    for url in urls:
        try:
            response = http.request("GET", url, timeout=30)
            hits.extend(response.get("hits") or [])
        except Exception as exc:
            errors.append(str(exc))

    seen: set[str] = set()
    unique_hits: list[dict[str, Any]] = []
    for hit in hits:
        object_id = str(hit.get("objectID") or "")
        if not object_id or object_id in seen:
            continue
        seen.add(object_id)
        unique_hits.append(hit)

    items = parse_hackernews_response({"hits": unique_hits}, query="")
    return {"items": items, "errors": errors}


_WORD_BOUNDARY_RE_CACHE: Dict[str, "re.Pattern[str]"] = {}


def _flatten_query_for_algolia(text: str) -> str:
    """Normalise query for Algolia + post-filter comparison.

    Multi-keyword theme queries frequently contain commas (delimiters) or
    hyphens (compound terms like ``ts-bun-node``); both tokenize awkwardly.
    Flatten them to spaces and collapse runs of whitespace so the search
    parameter and the post-filter operate on the same shape.
    """
    return " ".join(text.replace(",", " ").replace("-", " ").split())


def _title_matches_query(title: str, query: str, author: str = "") -> bool:
    """Check if any query token appears as a whole word in the title.

    Returns True when the query is empty (no filter), or when at least one
    query token matches as a whole word in the title after stripping
    "Tell HN:", "Show HN:", "Ask HN:", "Launch HN:" prefixes.

    We previously required *every* token to appear (all-words), which killed
    every Algolia hit on multi-keyword themes like "claude, personal agents,
    agentic infra" because real HN titles never contain all five tokens
    verbatim. Relaxing to any-word matches Algolia's `optionalWords` behaviour
    in `search_hackernews`. Token-overlap relevance scoring at parse time
    demotes hits where only one weak token matched, so the loosened gate
    won't surface noise to the top of the ranking.

    Word-boundary matching (rather than naive substring) prevents short
    tokens like ``ai`` or ``ts`` from matching unrelated words like
    ``email`` or ``artists``.
    """
    if not query:
        return True
    stripped = _HN_PREFIXES.sub("", title).strip()
    check_text = stripped.lower()
    # Normalise the query the same way search_hackernews does so post-filter
    # tokens line up with what Algolia actually saw.
    query_words = [w for w in _flatten_query_for_algolia(query.lower()).split() if w]
    if not query_words:
        return True
    for word in query_words:
        pattern = _WORD_BOUNDARY_RE_CACHE.get(word)
        if pattern is None:
            pattern = re.compile(rf"\b{re.escape(word)}\b")
            _WORD_BOUNDARY_RE_CACHE[word] = pattern
        if pattern.search(check_text):
            return True
    return False


def parse_hackernews_response(response: Dict[str, Any], query: str = "") -> List[Dict[str, Any]]:
    """Parse Algolia response into normalized item dicts.

    Args:
        response: Algolia search response
        query: Original search query for token-overlap relevance scoring

    Returns:
        List of item dicts ready for normalization.
    """
    hits = response.get("hits", [])
    # Post-filter: remove items where query only matched an HN prefix like "Tell HN:"
    if query:
        before = len(hits)
        hits = [
            h for h in hits
            if _title_matches_query(h.get("title", ""), query, h.get("author", ""))
        ]
        dropped = before - len(hits)
        if dropped:
            _log(f"Prefix filter removed {dropped}/{before} false-positive hits for '{query}'")
    items = []

    for i, hit in enumerate(hits):
        object_id = hit.get("objectID", "")
        points = hit.get("points") or 0
        num_comments = hit.get("num_comments") or 0
        created_at_i = hit.get("created_at_i")

        date_str = None
        if created_at_i:
            date_str = _unix_to_date(created_at_i)

        # Article URL vs HN discussion URL
        article_url = hit.get("url") or ""
        hn_url = _hn_item_url(object_id)

        # Relevance: blend Algolia rank with token-overlap content matching
        rank_score = max(0.3, 1.0 - (i * 0.02))  # 1.0 -> 0.3 over 35 items
        engagement_boost = min(0.2, math.log1p(points) / 40)
        if query:
            content_score = token_overlap_relevance(query, hit.get("title", ""))
            relevance = min(1.0, 0.6 * rank_score + 0.4 * content_score + engagement_boost)
        else:
            relevance = min(1.0, rank_score * 0.7 + engagement_boost + 0.1)

        items.append({
            "id": object_id,
            "title": hit.get("title", ""),
            "url": article_url,
            "hn_url": hn_url,
            "author": hit.get("author", ""),
            "date": date_str,
            "engagement": {
                "points": points,
                "comments": num_comments,
            },
            "relevance": round(relevance, 2),
            "why_relevant": f"HN story about {hit.get('title', 'topic')[:60]}",
        })

    return items


def _hn_item_url(item_id: Any) -> str:
    """HN discussion/comment permalink for an item id."""
    return f"https://news.ycombinator.com/item?id={item_id}"


# Ordering is optional, so a slow Firebase must not hold up the report.
FIREBASE_KIDS_TIMEOUT = 5
FIREBASE_KIDS_RETRIES = 2
FIREBASE_KIDS_BUDGET = 8.0


def _fetch_hn_kids(object_id: str) -> Optional[List[Any]]:
    """Return HN's display order for a story's top-level comments, or None on failure.

    Algolia's `/items/<id>` children list is effectively id-order with `points`
    always null, so sorting by points is a no-op (#1285). The Firebase item
    endpoint returns `kids` in the same order the HN thread UI shows.
    """
    url = f"{FIREBASE_ITEM_URL}/{object_id}.json"
    # Comment order is a refinement over comments Algolia already returned, so a
    # Firebase failure must not reach the pipeline's sink and mark HN degraded.
    try:
        with http.capture_failures():
            data = http.request(
                "GET",
                url,
                timeout=FIREBASE_KIDS_TIMEOUT,
                retries=FIREBASE_KIDS_RETRIES,
                deadline_monotonic=time.monotonic() + FIREBASE_KIDS_BUDGET,
            )
    # http.request wraps HTTP and socket errors, but a truncated or non-UTF-8
    # body escapes as IncompleteRead or UnicodeDecodeError.
    except (http.HTTPError, HTTPException, UnicodeDecodeError) as e:
        _log(f"Failed to fetch HN kids for {object_id}: {e}")
        return None
    if not isinstance(data, dict):
        return None
    kids = data.get("kids")
    if not isinstance(kids, list):
        return None
    return kids


def _order_comments_by_kids(
    comments: List[Dict[str, Any]],
    kids: List[Any],
) -> List[Dict[str, Any]]:
    """Reorder Algolia children to match HN `kids` order; unknowns keep relative order."""
    by_id: Dict[Any, Dict[str, Any]] = {}
    for comment in comments:
        cid = comment.get("id")
        if cid is not None and cid not in by_id:
            by_id[cid] = comment
    ordered: List[Dict[str, Any]] = []
    seen = set()
    for kid in kids:
        comment = by_id.get(kid)
        if comment is not None:
            ordered.append(comment)
            seen.add(kid)
    for comment in comments:
        cid = comment.get("id")
        if cid not in seen:
            ordered.append(comment)
    return ordered


def _fetch_item_comments(object_id: str, max_comments: int = 5) -> Dict[str, Any]:
    """Fetch top-level comments for a story from Algolia items endpoint.

    Args:
        object_id: HN story ID
        max_comments: Max comments to return

    Returns:
        Dict with 'comments' list and 'comment_insights' list.
    """
    url = f"{ALGOLIA_ITEM_URL}/{object_id}"

    try:
        data = http.request("GET", url, timeout=15)
    except Exception as e:
        _log(f"Failed to fetch comments for {object_id}: {e}")
        return {"comments": [], "comment_insights": []}

    children = data.get("children", [])

    # Filter to actual comments. Prefer HN's Firebase `kids` order (#1285);
    # Algolia children have null points, so a points sort is a no-op and leaves
    # earliest-posted replies first. Fall back to points only when kids is unavailable.
    real_comments = [
        c for c in children
        if c.get("text") and c.get("author")
    ]
    kids = _fetch_hn_kids(object_id)
    if kids is not None:
        real_comments = _order_comments_by_kids(real_comments, kids)
    else:
        real_comments.sort(key=lambda c: c.get("points") or 0, reverse=True)

    comments = []
    insights = []
    # A quote links to where it was said: the comment's own permalink, else the
    # story's discussion page -- never the article URL.
    discussion_url = _hn_item_url(object_id)
    for c in real_comments[:max_comments]:
        text = _strip_html(c.get("text", ""))
        excerpt = text[:300] + "..." if len(text) > 300 else text
        comment_id = c.get("id")
        comments.append({
            "author": c.get("author", ""),
            "text": excerpt,
            "points": c.get("points"),
            "url": _hn_item_url(comment_id) if comment_id else discussion_url,
        })
        # First sentence as insight
        first_sentence = text.split(". ")[0].split("\n")[0][:200]
        if first_sentence:
            insights.append(first_sentence)

    return {"comments": comments, "comment_insights": insights}


def enrich_top_stories(
    items: List[Dict[str, Any]],
    depth: str = "default",
) -> List[Dict[str, Any]]:
    """Fetch comments for top N stories by points.

    Args:
        items: Parsed HN items
        depth: Research depth (controls how many to enrich)

    Returns:
        Items with top_comments and comment_insights added.
    """
    if not items:
        return items

    limit = ENRICH_LIMITS.get(depth, ENRICH_LIMITS["default"])

    # Sort by points to enrich the most popular stories
    by_points = sorted(
        range(len(items)),
        key=lambda i: items[i].get("engagement", {}).get("points") or 0,
        reverse=True,
    )
    to_enrich = by_points[:limit]

    _log(f"Enriching top {len(to_enrich)} stories with comments")

    with ThreadPoolExecutor(max_workers=5) as executor:
        # submit_with_context, not executor.submit: a plain submit drops the
        # pipeline's capture_failures() sink, so failed or rate-limited item
        # fetches would vanish and the HN source would look fully enriched.
        futures = {
            http.submit_with_context(
                executor,
                _fetch_item_comments,
                items[idx]["id"],
            ): idx
            for idx in to_enrich
        }

        for future in as_completed(futures):
            idx = futures[future]
            try:
                result = future.result(timeout=15)
                items[idx]["top_comments"] = result["comments"]
                items[idx]["comment_insights"] = result["comment_insights"]
            except (KeyError, TypeError, OSError) as exc:
                _log(f"Comment enrichment failed for story {items[idx].get('id', '?')}: {type(exc).__name__}: {exc}")
                items[idx]["top_comments"] = []
                items[idx]["comment_insights"] = []

    return items
