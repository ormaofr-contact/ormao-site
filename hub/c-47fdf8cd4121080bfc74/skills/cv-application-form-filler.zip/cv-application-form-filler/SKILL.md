---
name: application-form-filler
description: Remplir les champs des formulaires de candidature avec des réponses contextuelles et personnalisées, basées sur le CV du candidat et l'offre d'emploi
---

# Remplisseur de formulaires de candidature

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Répondre à des questions spécifiques sur un formulaire de candidature
- Remplir des champs de texte sur Greenhouse, Lever, Ashby, Workday ou tout autre ATS
- Rédiger des réponses aux questions de type « parlez-nous de vous » ou « pourquoi voulez-vous travailler ici »
- Obtenir des réponses claires, prêtes à être copiées-collées, pour des questions de candidature
- Mentionne : « remplis ceci », « qu'est-ce que j'écris ici », « réponds à cette question », « formulaire de candidature », « champ de formulaire »

## Principe fondamental

Les réponses aux formulaires de candidature doivent être directes et précises — il ne s'agit pas d'une lettre de motivation condensée dans une zone de texte. Chaque champ a un objectif précis. Répondez clairement à cet objectif, puis arrêtez-vous.

**La réponse doit donner l'impression :** qu'une vraie personne l'a rédigée, et non qu'un modèle a été rempli.

## Avant de répondre

Lisez toujours :
1. **L'offre d'emploi** — reprenez ses termes et ses priorités
2. **Le CV / profil du candidat** — extrayez de vrais projets, rôles et métriques
3. **La question précise** — répondez exactement à ce qui est demandé, et non à ce que vous auriez aimé qu'on vous demande

Si l'utilisateur n'a pas fourni de CV ou d'offre d'emploi, demandez-les avant de commencer à rédiger.

## Types de questions et comment les traiter

---

### Type 1 : Questions sur l'expérience et le parcours

**Exemples :**
- « Combien d'années d'expérience avez-vous avec [technologie] ? »
- « Décrivez votre expérience avec [domaine] »
- « Quels frameworks backend avez-vous utilisés ? »

**Format :**
```
[Technology/skill] — [X years]. [One sentence on what you used it for, with a
specific project or context]. [Optional: secondary tools in the same category].
```

**Règles :**
- Commencez par la technologie la plus utilisée ou la plus pertinente
- Indiquez honnêtement le nombre d'années — ne gonflez pas les chiffres
- Raccordez chaque affirmation à un projet ou un poste réel
- Pour les questions de type « décrivez votre expérience » : 2 à 4 phrases maximum, un projet par phrase
- Si l'expérience est indirecte (domaine connexe), précisez-le et faites le lien avec ce qui est pertinent

---

### Type 2 : Pourquoi cette entreprise / Ce qui vous intéresse

**Exemples :**
- « Pourquoi souhaitez-vous travailler chez [Entreprise] ? »
- « Qu'est-ce qui vous intéresse dans ce poste ? »
- « Pourquoi êtes-vous un bon candidat pour ce poste ? »

**Format :**
```
[Specific thing about the company/role that's genuinely interesting — not generic].
[How that connects to something the candidate has actually worked on].
[Optional: one line on why this domain, not just this company].
```

**Règles :**
- Doit être spécifique à cette entreprise — pas de formule générique
- Renseignez-vous sur l'entreprise avant de répondre si nécessaire
- Faites le lien avec du travail concret, pas des aspirations vagues
- Restez sous la barre des 150 mots pour un champ de formulaire
- Ne paraphrasez pas bêtement l'offre d'emploi

---

### Type 3 : Portfolio / Exemples de réalisations

**Exemples :**
- « Incluez d'autres exemples de réalisations dont vous êtes fier »
- « Ajoutez des liens vers des projets ou dépôts pertinents »
- « Décrivez un projet que vous avez conçu de bout en bout »

**Format :**
Listez les projets avec une description d'une ligne et des liens. Commencez par le plus pertinent.

```
[Project Name] ([live URL] | [github URL]) — [one line: what it is and one
proof point]. [Stack if relevant].
```

**Règles :**
- N'incluez que des projets pertinents pour le poste
- Incluez toujours des liens (démo en ligne > GitHub > rien)
- Si le projet a des utilisateurs payants ou un usage mesurable, mentionnez-le — une seule fois
- Ne meublez pas avec des projets hors sujet pour paraître prolifique

---

### Type 4 : Questions sur les compétences techniques

**Exemples :**
- « Quels frameworks frontend avez-vous le plus utilisés ? »
- « Évaluez votre niveau de maîtrise en Python »
- « Décrivez votre expérience avec les infrastructures cloud »

**Format :**
Pour les champs de texte libre :
```
[Primary skill] — [X years]. [Specific use: what you built with it, in what context].
[Secondary skill] — [X years]. [Same].
[Note any relevant gaps honestly].
```

Pour les champs d'évaluation ou listes déroulantes : choisissez le niveau honnête — ne cherchez pas à maximiser la note si elle n'est pas exacte.

**Règles :**
- Années d'expérience + contexte est bien meilleur que les années seules
- Reconnaissez vos lacunes plutôt que de les cacher
- Si l'on vous demande de vous noter, faites-le honnêtement — les évaluations surévaluées posent problème lors des entretiens techniques
- Pour les stacks technologiques utilisées par le passé mais pas récemment, précisez-le

---

### Type 5 : Questions ouvertes / « Parlez-nous de vous »

**Exemples :**
- « Parlez-nous de vous »
- « Décrivez votre parcours professionnel »
- « Que recherchez-vous dans votre prochain poste ? »

**Format :**
```
Current role + what you do there (1 sentence).
Relevant prior experience, briefly (1 sentence).
What you're looking for / why this role (1-2 sentences — specific to the company).
Optional: one project or side work that's relevant (1 sentence).
```

**Règles :**
- Commencez par votre poste actuel, pas par vos études
- Limitez-vous à 100-200 mots pour la plupart des champs de formulaire
- Terminez sur une note tournée vers l'avenir (ce que vous recherchez, et non d'où vous venez)
- Pas d'affirmations sur vos traits de caractère (« Je suis passionné par... ») — uniquement des faits et des projets

---

### Type 6 : Questions situationnelles / comportementales

**Exemples :**
- « Décrivez une situation où vous avez résolu un problème technique complexe »
- « Parlez-nous d'un projet que vous avez mené de bout en bout »
- « Comment gérez-vous le travail entre plusieurs équipes ? »

**Format :** Méthode STAR condensée (sans libellés, uniquement le déroulement fluide)

```
[Context in one sentence]. [What you specifically did — 2 sentences]. [Outcome
with a metric if possible — 1 sentence].
```

**Règles :**
- Soyez précis — nommez le projet, les technologies, la taille de l'équipe
- Ne généralisez pas (« J'aborde toujours les problèmes en... »)
- Tenez-vous-en à 150-250 mots
- Première personne et voix active du début à la fin
- Terminez par le résultat obtenu, pas par la leçon apprise (gardez cela pour les entretiens)

---

### Type 7 : Questions d'opinion / de vision

**Exemples :**
- « Quelles technologies considérez-vous comme les plus importantes pour l'avenir ? »
- « Qu'apprendriez-vous si vous disposiez d'un temps illimité ? »
- « Où voyez-vous l'IA / [domaine] dans 5 ans ? »

**Format :**
Répondez avec un avis authentique. Choisissez un ou deux éléments et expliquez brièvement votre raisonnement.

**Règles :**
- Ayez un vrai point de vue — les réponses vagues s'oublient vite
- Fondez vos opinions sur une expertise du domaine ou une expérience concrète
- Restez entre 100 et 150 mots
- Ne nuancez pas tout à l'excès — assumez une position, tout en reconnaissant qu'il s'agit d'une perspective parmi d'autres

---

## Format de sortie

Encadrez toujours la réponse dans un bloc de code simple afin qu'elle soit facile et propre à copier-coller :

```
[Answer text here]
```

Si vous fournissez plusieurs réponses (une par champ), utilisez des blocs de code séparés avec un libellé au-dessus de chacun :

**Années d'expérience avec React :**
```
4 years. Used it across Screenr (agentic hiring SaaS), a Tauri-based POS
system, and several client projects. Also used Next.js where SSR was needed.
```

**Décrivez votre expérience en backend :**
```
...
```

## Calibrage de la longueur

| Type de champ | Longueur cible |
|---------------|----------------|
| Texte sur une seule ligne | 1 phrase |
| Réponse courte | 2 à 4 phrases |
| Réponse longue / zone de texte | 100 à 250 mots |
| « Décrivez votre expérience » | 150 à 300 mots |
| « Parlez-nous de vous » | 100 à 200 mots |
| Section portfolio / liens | Format liste, pas de texte rédigé |

En cas de doute, la concision l'emporte. Les recruteurs parcourent les réponses en diagonale. L'objectif est d'être clair et mémorable, pas exhaustif.

## Erreurs courantes à éviter

**Répéter l'offre d'emploi :**
❌ « Je suis intéressé par ce poste car vous recherchez quelqu'un pour concevoir des systèmes backend évolutifs... »
✅ « Ce qui a retenu mon attention, c'est la contrainte de temps réel — traiter des données de santé avec une latence de l'ordre de la milliseconde est un défi d'un tout autre ordre que la plupart des projets backend. »

**Revendications de traits de caractère génériques :**
❌ « J'apprends vite et je m'épanouis dans les environnements collaboratifs »
✅ [Décrivez simplement le travail réel — les qualités transparaîtront d'elles-mêmes]

**Se justifier excessivement :**
❌ « Bien que je n'aie peut-être pas exactement 5 ans d'expérience, j'estime que mon parcours... »
✅ « L'offre mentionne 5 ans — j'en ai 3, mais les systèmes que j'ai déployés sont en production réelle. »

**Lister sans donner de contexte :**
❌ « React, Vue, Angular, Next.js, TypeScript, Node.js... »
✅ « React est mon framework frontend principal — 4 ans d'expérience sur Screenr et plusieurs projets clients. Vue et Angular depuis environ 3 ans chacun, principalement sur des tableaux de bord et des outils d'administration. »

**Meubler pour remplir l'espace :**
❌ Ajouter des projets ou des expériences hors sujet uniquement pour paraître prolifique
✅ N'incluez que ce qui est pertinent pour ce poste spécifique
