---
name: ai-writing-detector
version: 3.38.0
license: MIT
description: À utiliser lorsque l'utilisateur demande de détecter, analyser, auditer, noter ou signaler des schémas d'écriture IA sans réécrire le texte, y compris les demandes de résultat d'un détecteur local déterministe lorsque l'hôte peut exécuter Node.
---

# Détecteur d'écriture IA

Exécutez un examen de détection uniquement à l'aide des règles originales d'Avoid AI Writing. Ne réécrivez jamais le texte à moins que l'utilisateur ne modifie sa demande.

## Autorité

Le guide de règles canonique est `../avoid-ai-writing/SKILL.md`. Ses mises en garde concernant les faux positifs, le contexte, les contenus protégés et les affirmations relatives à la paternité s'appliquent ici.

Pour le travail transversal entre Skills, suivez `../avoid-ai-writing-router/references/handoff-contract.md` ainsi que les arêtes typées dans `../avoid-ai-writing-router/references/skill-graph.json`.

## Contrat de connexion

### Entrant

Acceptez les tâches de détection provenant de :

- `avoid-ai-writing-router` via `ROUTE` pour les demandes de détection uniquement, l'étape d'audit d'une demande en plusieurs étapes ou la collecte de nouveaux signaux après qu'une autre étape terminale a rendu le contrôle au routeur.
- `preservation-verifier` via un `RECHECK` délimité uniquement lorsque la convergence ou l'audit résiduel faisait partie de la demande.

N'acceptez pas de transmission directe depuis `false-positive-reviewer`. Cette Skill est terminale dans le graphe et doit rendre le contrôle à `avoid-ai-writing-router` lorsqu'une nouvelle collecte de signaux est nécessaire. Cela empêche un cycle entre réviseur et détecteur.

Transmettez le `context_profile` canonique séparément du `context_mode` du détecteur, ainsi que les contraintes protégées, l'état de validation et les indicateurs de risque. Ne les fusionnez pas et ne les réinitialisez pas.

### Sortant (Production)

Mettez à jour l'enveloppe de transmission avec :

- `execution_evidence.detector` : `executed` uniquement si le détecteur intégré a réellement été exécuté, sinon `model_only`.
- `detector_summary.score` et `label` uniquement lorsqu'ils sont produits par du code de détecteur exécuté.
- `detector_summary.issue_types` à partir des constatations réelles.
- tout indicateur de risque `consequential_authorship_claim` observé dans la demande de l'utilisateur.

### Sortant (Aiguillage)

- Transmettez via `FEED` les constatations à `voice-preserving-rewriter` uniquement si l'utilisateur a également demandé une réécriture du texte renvoyé.
- Transmettez via `FEED` les constatations à `file-edit-in-place` uniquement si l'utilisateur a explicitement demandé la modification d'un fichier nommé.
- Transmettez via `ESCALATE` à `false-positive-reviewer` lorsque l'utilisateur demande ce que les constatations peuvent établir concernant la paternité de l'auteur ou toute autre conclusion lourde de conséquences.
- Sinon, arrêtez-vous après le résultat de détection seule.

Les correspondances déterministes sont des occurrences candidates. Conservez intacts les scores et les types de problèmes publics du moteur, puis appliquez les exceptions de contexte et les conditions de validation canoniques pour déterminer quelles occurrences constituent des constatations éditoriales justifiées. Aucun de ces deux types de résultats ne constitue une instruction de modification obligatoire ni n'autorise une altération.

## Prisme d'analyse factuelle en ingénierie de l'IA

Appliquez le prisme `agency-ai-engineer` décrit dans `../avoid-ai-writing-router/references/agency-role-lenses.md` :

- séparez les résultats déterministes des observations issues uniquement du modèle,
- préservez le profil de contexte sélectionné et le mode du détecteur lors des transmissions en aval,
- traitez le score et le label comme des signaux plutôt que comme une vérité absolue,
- prenez en compte les faux positifs ainsi que les effets de genre et de registre,
- ne transformez jamais la détection de schémas en une affirmation de classification d'auteur.

## Chemin privilégié

Lorsque l'hôte actuel peut exécuter Node en toute sécurité :

1. Transmettez le texte fourni à `scripts/detect.js`.
2. Utilisez `--context technical` pour la prose technique ou adjacente au code le cas échéant. Sinon, utilisez `general`.
3. Utilisez `--source-mode rendered-markdown` pour le Markdown contenant un frontmatter YAML ou des commentaires HTML, afin que les métadonnées non modifiées ne soient pas notées comme faisant partie de la prose de l'auteur. Sinon, conservez la valeur par défaut `plain`.
4. Indiquez le score, le label, les types de problèmes, la sévérité, le texte correspondant et les suggestions du détecteur.
5. Séparez les correspondances candidates déterministes des constatations éditoriales justifiées et des observations qui n'existent que dans le guide de règles complet.
6. Ne prétendez jamais qu'une exécution a eu lieu à moins que la commande n'ait réellement été lancée.

Exemple :

```bash
printf '%s' "$TEXT" | node scripts/detect.js --context general
```

Pour un fichier :

```bash
node scripts/detect.js --file path/to/draft.md --context general
```

Pour du Markdown avec un frontmatter ou des commentaires HTML :

```bash
node scripts/detect.js --file path/to/draft.md --source-mode rendered-markdown
```

Si l'exécution de Node ou du shell n'est pas disponible, appliquez le flux de travail de détection seule issu de la Skill canonique `avoid-ai-writing` et indiquez explicitement que le détecteur déterministe n'a pas été exécuté.

## Conditions d'arrêt

Arrêtez-vous ici lorsque la demande porte uniquement sur la détection. Ne poursuivez pas vers une réécriture, une modification de fichier ou une interprétation simplement parce que ces Skills sont disponibles.

Un `RECHECK` résiduel peut être exécuté une seule fois s'il est demandé. Il s'effectue en lecture seule et ne consomme pas de passe d'édition ; toute modification qu'il suscite doit respecter la limite demandée de passes d'édition (plafonnée à deux) ainsi que la politique de boucle du graphe.

## Sortie

Renvoyez le label global et le score en cas d'exécution, les correspondances candidates détectées regroupées par niveau de gravité, une brève évaluation contextuelle distinguant les constatations justifiées des faux positifs plausibles, l'état d'exécution, et aucune version réécrite à moins que le contrôle n'ait été explicitement transféré à un responsable de la réécriture.
