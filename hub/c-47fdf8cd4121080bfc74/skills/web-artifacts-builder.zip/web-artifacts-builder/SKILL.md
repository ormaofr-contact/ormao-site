---
name: web-artifacts-builder
description: Suite d'outils pour créer des artefacts HTML claude.ai élaborés et multi-composants à l'aide de technologies web frontend modernes (React, Tailwind CSS, shadcn/ui). À utiliser pour les artefacts complexes nécessitant une gestion d'état, du routage ou des composants shadcn/ui — pas pour les simples artefacts HTML/JSX en un seul fichier.
license: Conditions complètes dans LICENSE.txt
---

# Web Artifacts Builder

Pour créer des artefacts frontend claude.ai puissants, suivez ces étapes :
1. Initialisez le dépôt frontend à l'aide de `scripts/init-artifact.sh`
2. Développez votre artefact en modifiant le code généré
3. Empaquetez tout le code dans un fichier HTML unique à l'aide de `scripts/bundle-artifact.sh`
4. Affichez l'artefact pour l'utilisateur
5. (Optionnel) Testez l'artefact

**Stack** : React 18 + TypeScript + Vite + Parcel (bundling) + Tailwind CSS + shadcn/ui

## Directives de design et de style

TRÈS IMPORTANT : Pour éviter ce que l'on appelle souvent la « bouillie d'IA » (AI slop), évitez les mises en page excessivement centrées, les dégradés violets, les arrondis uniformes et la police Inter.

## Démarrage rapide

### Étape 1 : Initialiser le projet

Exécutez le script d'initialisation pour créer un nouveau projet React :
```bash
bash scripts/init-artifact.sh <project-name>
cd <project-name>
```

Cela crée un projet entièrement configuré avec :
- ✅ React + TypeScript (via Vite)
- ✅ Tailwind CSS 3.4.1 avec le système de thèmes shadcn/ui
- ✅ Alias de chemin (`@/`) configurés
- ✅ Plus de 40 composants shadcn/ui préinstallés
- ✅ Toutes les dépendances Radix UI incluses
- ✅ Parcel configuré pour le bundling (via .parcelrc)
- ✅ Compatibilité Node 18+ (détecte automatiquement et fige la version de Vite)

### Étape 2 : Développer votre artefact

Pour créer l'artefact, modifiez les fichiers générés. Consultez les **Tâches de développement courantes** ci-dessous pour obtenir des instructions.

### Étape 3 : Empaqueter dans un fichier HTML unique

Pour empaqueter l'application React dans un artefact HTML unique :
```bash
bash scripts/bundle-artifact.sh
```

Cela crée `bundle.html` — un artefact autonome avec tout le JavaScript, le CSS et les dépendances intégrés en ligne. Ce fichier peut être directement partagé dans les conversations Claude en tant qu'artefact.

**Prérequis** : Votre projet doit contenir un fichier `index.html` dans le répertoire racine.

**Ce que fait le script** :
- Installe les dépendances d'empaquetage (parcel, @parcel/config-default, parcel-resolver-tspaths, html-inline)
- Crée la configuration `.parcelrc` avec la prise en charge des alias de chemin
- Compile avec Parcel (sans source maps)
- Intègre tous les assets dans un fichier HTML unique à l'aide de html-inline

### Étape 4 : Partager l'artefact avec l'utilisateur

Enfin, partagez le fichier HTML empaqueté dans la conversation avec l'utilisateur afin qu'il puisse le visualiser sous forme d'artefact.

### Étape 5 : Tester/Visualiser l'artefact (Optionnel)

Remarque : Il s'agit d'une étape entièrement facultative. Ne l'effectuez que si nécessaire ou si cela est demandé.

Pour tester/visualiser l'artefact, utilisez les outils disponibles (y compris d'autres Skills ou des outils intégrés comme Playwright ou Puppeteer). En général, évitez de tester l'artefact au préalable, car cela ajoute de la latence entre la requête et le moment où l'artefact terminé peut être visualisé. Testez plus tard, après avoir présenté l'artefact, si cela est demandé ou si des problèmes surviennent.

## Références

- **Composants shadcn/ui** : https://ui.shadcn.com/docs/components
