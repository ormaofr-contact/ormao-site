---
name: performance-optimization
description: Optimise les performances applicatives sur le frontend, le backend, les requêtes et les bases de données. À utiliser lorsque des exigences de performance existent, en cas de suspicion de régression, lorsque les Core Web Vitals ou les temps de chargement doivent être améliorés, pour corriger les requêtes N+1, ou lorsque le profilage révèle des goulots d'étranglement.
---

# Optimisation des performances

## Vue d'ensemble

Mesurez avant d'optimiser. Travailler sur la performance sans mesurer revient à deviner — et deviner conduit à des optimisations prématurées qui ajoutent de la complexité sans améliorer ce qui compte réellement. Profilez d'abord, identifiez le véritable goulot d'étranglement, corrigez-le, puis mesurez à nouveau. N'optimisez que ce que les mesures prouvent être déterminant.

## Quand l'utiliser

- Des exigences de performance existent dans les spécifications (budgets de temps de chargement, SLA de temps de réponse)
- Les utilisateurs ou le monitoring signalent des lenteurs
- Les scores des Core Web Vitals sont sous les seuils cibles
- Vous soupçonnez qu'une modification a introduit une régression
- Développement de fonctionnalités traitant de grands volumes de données ou un fort trafic

**Quand NE PAS l'utiliser :** N'optimisez pas avant d'avoir la preuve concrète d'un problème. L'optimisation prématurée ajoute une complexité dont le coût dépasse les gains de performance obtenus.

## Objectifs pour les Core Web Vitals

| Métrique | Bon | À améliorer | Médiocre |
|----------|-----|-------------|----------|
| **LCP** (Largest Contentful Paint) | ≤ 2.5s | ≤ 4.0s | > 4.0s |
| **INP** (Interaction to Next Paint) | ≤ 200ms | ≤ 500ms | > 500ms |
| **CLS** (Cumulative Layout Shift) | ≤ 0.1 | ≤ 0.25 | > 0.25 |

## Le workflow d'optimisation

```
1. MEASURE  → Establish baseline with real data
2. IDENTIFY → Find the actual bottleneck (not assumed)
3. FIX      → Address the specific bottleneck
4. VERIFY   → Measure again; keep or revert
5. GUARD    → Add monitoring or tests to prevent regression
```

### Étape 1 : Mesurer

Deux approches complémentaires — utilisez les deux :

- **Mesures synthétiques (Lighthouse, onglet Performance des DevTools) :** Conditions contrôlées, reproductibles. Idéal pour la détection des régressions en CI et l'isolation de problèmes spécifiques.
- **RUM (bibliothèque web-vitals, CrUX) :** Données d'utilisateurs réels en conditions réelles. Indispensable pour valider qu'un correctif a réellement amélioré l'expérience utilisateur.

**Frontend :**
```javascript
// Synthetic: Lighthouse in Chrome DevTools (or CI)
// Chrome DevTools → Performance tab → Record
// Chrome DevTools MCP → Performance trace

// RUM: Web Vitals library in code
import { onLCP, onINP, onCLS } from 'web-vitals';

onLCP(console.log);
onINP(console.log);
onCLS(console.log);
```

**Backend :**
```javascript
// Response time logging
// Application Performance Monitoring (APM)
// Database query logging with timing

// Simple timing
console.time('db-query');
const result = await db.query(...);
console.timeEnd('db-query');
```

### Par où commencer les mesures

Fondez-vous sur le symptôme pour décider quoi mesurer en premier :

```
What is slow?
├── First page load
│   ├── Large bundle? --> Measure bundle size, check code splitting
│   ├── Slow server response? --> Measure TTFB in DevTools Network waterfall
│   │   ├── DNS long? --> Add dns-prefetch / preconnect for known origins
│   │   ├── TCP/TLS long? --> Enable HTTP/2, check edge deployment, keep-alive
│   │   └── Waiting (server) long? --> Profile backend, check queries and caching
│   └── Render-blocking resources? --> Check network waterfall for CSS/JS blocking
├── Interaction feels sluggish
│   ├── UI freezes on click? --> Profile main thread, look for long tasks (>50ms)
│   ├── Form input lag? --> Check re-renders, controlled component overhead
│   └── Animation jank? --> Check layout thrashing, forced reflows
├── Page after navigation
│   ├── Data loading? --> Measure API response times, check for waterfalls
│   └── Client rendering? --> Profile component render time, check for N+1 fetches
└── Backend / API
    ├── Single endpoint slow? --> Profile database queries, check indexes
    ├── All endpoints slow? --> Check connection pool, memory, CPU
    └── Intermittent slowness? --> Check for lock contention, GC pauses, external deps
```

### Étape 2 : Identifier le goulot d'étranglement

Goulots d'étranglement courants par catégorie :

**Frontend :**

| Symptôme | Cause probable | Investigation |
|----------|----------------|---------------|
| LCP lent | Images volumineuses, ressources bloquant le rendu, serveur lent | Vérifier le waterfall réseau, la taille des images |
| CLS élevé | Images sans dimensions, contenu chargé tardivement, décalages liés aux polices | Vérifier l'attribution des décalages de mise en page (layout shift attribution) |
| INP médiocre | JavaScript lourd sur le thread principal, mises à jour massives du DOM | Vérifier les tâches longues (long tasks) dans la trace de performance |
| Chargement initial lent | Bundle volumineux, nombreuses requêtes réseau | Vérifier la taille du bundle, le code splitting |

**Backend :**

| Symptôme | Cause probable | Investigation |
|----------|----------------|---------------|
| Réponses d'API lentes | Requêtes N+1, index manquants, requêtes non optimisées | Vérifier les logs de requêtes de base de données |
| Consommation mémoire croissante | Références non libérées (fuites), caches non bornés, payloads volumineux | Analyse de snapshots de tas (heap snapshot) |
| Pics de CPU | Calculs lourds synchrones, backtracking de regex | Profilage CPU |
| Latence élevée | Absence de mise en cache, calculs redondants, sauts réseau (network hops) | Tracer les requêtes à travers la stack |

### Étape 3 : Corriger le goulot d'étranglement

Corrigez uniquement l'élément identifié à l'Étape 2, rien d'autre. Les anti-patterns ci-dessous sont les suspects habituels ; chaque entrée donne la règle et la signature pour le reconnaître, et renvoie vers un exemple de correction dans [references/optimization-patterns.md](references/optimization-patterns.md). N'ouvrez celui dont vous avez besoin que lorsque vous intervenez sur ce code, pas avant.

**Backend**

- **Requêtes N+1.** Une requête par ligne est le goulot d'étranglement backend le plus fréquent. Récupérez la relation dans la même requête (join/include) plutôt qu'au sein d'une boucle. [Modèle](references/optimization-patterns.md#n1-queries-backend).
- **Récupération de données non bornée (unbounded).** Chaque endpoint de type liste doit être paginé avec une limite et un ordre de tri stable. [Modèle](references/optimization-patterns.md#unbounded-data-fetching).
- **Requêtes ignorant leur index.** « Ajouter un index » n'est qu'une supposition ; `EXPLAIN ANALYZE` apporte la mesure. Un `Seq Scan` là où vous attendiez un index, une estimation `rows=` décalée d'un ordre de grandeur, et un nœud `Sort` au-dessus du scan nécessitent chacun une correction différente ; une mauvaise estimation de `rows=` révèle des statistiques obsolètes, lancez donc `ANALYZE` plutôt que d'ajouter un index. Indexez selon la forme de la requête (colonnes d'égalité d'abord, puis colonne d'intervalle ou de tri). Un index standard n'aidera pas une requête portant sur une valeur dominante à faible sélectivité (un index partiel répondra à la valeur rare), un préfixe avec troncature/joker en tête (nécessite du trigramme ou du full-text), ou une fonction appliquée à la colonne (indexez l'expression, comme dans `WHERE lower(email) = ?`), et chaque index pénalise chaque écriture. Réexécutez le plan par la suite ; un index qui ne l'a pas modifié doit être annulé. [Modèle](references/optimization-patterns.md#queries-that-ignore-their-index).
- **Épuisement du pool de connexions.** Signature : *tous* les endpoints ralentissent en même temps, le temps est passé à attendre une connexion plutôt qu'à exécuter, et la base de données montre principalement des sessions inactives. Un pool par processus, dimensionné de sorte que `instances × max` reste sous le plafond de connexions de la base de données. Plus grand ne signifie pas plus rapide ; cela ne fait que déplacer la file d'attente vers la base de données où elle est plus difficile à observer. Avec un nombre d'instances non borné (serverless, autoscaling), multiplexez via un proxy (pgbouncer, RDS Proxy) au lieu d'augmenter `max`. [Modèle](references/optimization-patterns.md#connection-pool-exhaustion).
- **Absence de cache.** Mettez en cache ce qui est coûteux à produire et lu bien plus souvent que modifié ; mettre en cache une requête déjà rapide ajoute un saut réseau et un risque de données obsolètes sans rien apporter en retour. Choisissez la couche délibérément (in-process, partagé, CDN). Chaque paramètre influençant la réponse doit figurer dans la clé (tenant, locale, permissions, feature flags) : omettre l'utilisateur consultant la ressource dans la clé risque de servir les données d'un utilisateur à un autre. Choisissez une stratégie d'invalidation unique (TTL, basée sur des événements ou tags, clés versionnées) et définissez explicitement la fenêtre de tolérance d'obsolescence. Protégez les clés très sollicitées contre les ruées (stampede / thundering herd) : servez du contenu périmé pendant qu'une requête recalcule, ou regroupez les requêtes concurrentes en échec de cache derrière une unique promesse en cours (coalescing). Ne mettez jamais en cache ce qui doit impérativement être à jour (soldes, permissions, inventaire au moment du paiement). [Modèle](references/optimization-patterns.md#missing-caching-backend) ; coalescing de requêtes, stratégies d'écriture et mise en cache négative dans `../../references/performance-checklist.md`.

**Frontend**

- **Absence d'optimisation des images.** Chaque image déclare un `width` et un `height` (CLS). L'image LCP reçoit `fetchpriority="high"`, des formats modernes (AVIF, WebP) via `<picture>`, et `srcset`/`sizes` pour s'adapter à la résolution ; les images sous la ligne de flottaison reçoivent `loading="lazy"` et `decoding="async"`. [Modèle](references/optimization-patterns.md#missing-image-optimization-frontend).
- **Re-rendus inutiles.** Un objet ou une fonction créé lors du rendu génère une nouvelle référence à chaque exécution et re-rend chaque enfant qui le reçoit. Sortez les constantes du composant (hoisting) ; réservez `React.memo` et `useMemo` aux traitements dont le profilage démontre le coût, car leur surutilisation engendre son propre coût. [Modèle](references/optimization-patterns.md#unnecessary-re-renders-react).
- **Taille excessive du bundle.** Les bundlers modernes gèrent d'eux-mêmes le tree-shaking des imports nommés ESM ; les gains réels proviennent du code splitting au niveau des routes et du lazy loading des fonctionnalités lourdes et rarement utilisées derrière `Suspense`. Profilez avant de modifier les syntaxes d'importation. [Modèle](references/optimization-patterns.md#large-bundle-size).

### Étape 4 : Vérifier (conserver ou annuler)

Une correction reste une hypothèse tant qu'elle n'a pas été re-mesurée. Cette étape détermine si elle doit être conservée.

**Mesurez à nouveau exactement comme vous avez mesuré la référence initiale :** même commande, mêmes conditions, même budget fixe (durée réelle, nombre d'échantillons ou volume de requêtes). Une référence prise sur un cache froid comparée à un résultat sur cache chaud mesure le cache, pas votre modification.

**Ne modifiez qu'une seule chose à la fois.** Trois optimisations intégrées ensemble produisent un chiffre unique sans attribution possible. Si elles doivent être livrées ensemble, mesurez d'abord chacune isolément.

**Dépassez le bruit, pas seulement la moyenne.** Répétez la mesure et comparez le delta à la variance entre les exécutions. Un gain de 3 % au sein d'une variance de ±5 % n'est pas un gain ; c'est juste un échantillon différent.

Puis tranchez, de manière stricte :

| Résultat vs référence | Action |
|---|---|
| Seuil dépassé, tests au vert | **Conserver.** Commiter avec les chiffres avant/après dans le message. |
| Dans le bruit (aucun changement mesurable) | **Annuler.** |
| Dégradation | **Annuler.** |
| Amélioration, mais un test passe au rouge | **Annuler.** Une régression déguisée en victoire. |

**« Neutre » signifie annuler, pas conserver.** C'est l'étape que les équipes négligent : la modification étant déjà écrite, l'abandonner semble être du gâchis, elle est donc intégrée sans mesure, et la base de code accumule une complexité inutile. Tout code conservé est du code à maintenir pour toujours. Exigez qu'il justifie sa présence.

**La conformité fonctionnelle conditionne la métrique.** La suite de tests doit rester au vert *et* la métrique doit progresser. Une « optimisation » qui gagne en supprimant un traitement fonctionnel nécessaire au produit (sauter une validation, mettre en cache une donnée qui devait rester fraîche, retirer un `await` indispensable) est une régression, pas une victoire.

#### Consignez chaque tentative, y compris celles annulées

Le travail annulé ne laisse aucune trace dans l'historique git, ce qui explique précisément pourquoi la même fausse bonne idée est retentée au trimestre suivant. Tenez un registre succinct pour qu'une idée écartée le reste définitivement :

| Idée | Référence → Résultat | Verdict | Raison |
|---|---|---|---|
| Mémoïser le composant de ligne | INP 240ms → 235ms | annulé | Dans le bruit (±15ms). Les lignes n'étaient pas le goulot d'étranglement. |
| Virtualiser la liste | INP 240ms → 90ms | conservé | Disparition des tâches longues (long tasks) de la trace. |
| Préconnecter à l'origine de l'API | LCP 2.8s → 2.8s | annulé | Déjà sur la même origine (same-origin). |

Une section dans la description de la PR ou un fichier `PERF.md` dans le dépôt font parfaitement l'affaire. L'essentiel est que la personne suivante (ou le prochain agent) puisse le lire avant de proposer une expérimentation, évitant ainsi de reproduire un échec passé.

### Étape 5 : Prévenir les régressions

Surveillez la métrique que l'utilisateur ressent concrètement, pas chaque chiffre disponible. Utilisez le même LCP, INP, latence p95 ou toute autre métrique principale ayant justifié le correctif.

Mettez en place deux couches complémentaires lorsque l'interface est tournée vers l'utilisateur :

- **Garde-fou synthétique en CI :** Détectez les régressions reproductibles avant le merge grâce à un budget de performance. Répétez les mesures sujettes au bruit ou comparez une médiane/tendance afin que la variance normale n'entraîne pas de faux positifs (tests instables/flaky).
- **Monitoring terrain (Real User Monitoring) :** Déclenchez des alertes sur une évolution significative du p75 dans les données RUM. Utilisez les données attribuées de `web-vitals` pour localiser la cause ; considérez la fenêtre glissante de CrUX comme une confirmation plutôt que comme une alerte immédiate.

Lorsque l'un de ces garde-fous s'active, revenez à l'Étape 1 et établissez une nouvelle base de référence avant de proposer un autre correctif.

**Définissez des budgets et faites-les respecter :**

```
JavaScript bundle: < 200KB gzipped (initial load)
CSS: < 50KB gzipped
Images: < 200KB per image (above the fold)
Fonts: < 100KB total
API response time: < 200ms (p95)
Time to Interactive: < 3.5s on 4G
Lighthouse Performance score: ≥ 90
```

**Appliquez en CI :**
```bash
# Bundle size check
npx bundlesize --config bundlesize.config.json

# Lighthouse CI
npx lhci autorun
```

## Voir aussi

Pour des checklists de performance détaillées, les commandes d'optimisation et la référence des anti-patterns, consultez `../../references/performance-checklist.md`.


## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « On optimisera plus tard » | La dette de performance s'accumule. Corrigez les anti-patterns évidents dès maintenant, différez les micro-optimisations. |
| « C'est rapide sur ma machine » | Votre machine n'est pas celle de l'utilisateur. Profilez sur du matériel et des réseaux représentatifs. |
| « Cette optimisation est évidente » | Sans mesure, vous ne savez rien. Profilez d'abord. |
| « Les utilisateurs ne remarqueront pas 100 ms » | Les études montrent qu'un délai de 100 ms affecte les taux de conversion. Les utilisateurs remarquent bien plus de choses qu'on ne le pense. |
| « Le framework gère la performance » | Les frameworks évitent certains écueils, mais ne peuvent pas corriger les requêtes N+1 ni les bundles démesurés. |
| « La requête est lente, ajoutons un index » | Analysez d'abord le plan d'exécution. L'index existe peut-être déjà sans pouvoir être exploité, et chaque index pénalise les écritures de façon permanente. |
| « Il suffit de mettre en cache » | Mettre en cache un appel déjà peu coûteux n'apporte rien et introduit des risques d'obsolescence. Mettez en cache ce qui est coûteux *et* relu beaucoup plus souvent qu'écrit. |
| « Augmentons la taille du pool, nous manquons de connexions » | Un pool plus grand que ce que la base peut traiter ne fait que déplacer la file d'attente vers un endroit moins visible. Identifiez ce qui retient les connexions. |
| « Ça n'a pas beaucoup aidé, mais ça ne fait pas de mal » | Tout changement neutre doit être annulé. Vous en paierez la maintenance pour toujours sans aucun bénéfice en retour. |
| « On l'a déjà écrit, autant le garder » | Biais des coûts irrécupérables. Les mesures se moquent du temps passé à coder la modification. |
| « L'amélioration est évidente, pas besoin de re-mesurer » | Dans ce cas, re-mesurer est rapide et le prouvera. Les gains non mesurés sont la porte d'entrée de la complexité inutile. |

## Signaux d'alerte

- Optimisation sans données de profilage pour la justifier
- Schémas de requêtes N+1 lors de la récupération de données
- Ajout d'un index sans plan d'exécution avant/après pour le justifier
- Clé de cache omettant un paramètre dont dépend la réponse (tenant, locale, viewer)
- Cache sans fenêtre d'obsolescence définie ni stratégie d'invalidation
- Augmentation de la taille du pool de connexions face à la saturation, sans chercher ce qui retient les connexions
- Endpoints de liste sans pagination
- Images sans dimensions, sans lazy loading ou sans dimensions responsives
- Augmentation de la taille du bundle sans revue
- Absence de monitoring des performances en production
- Présence excessive de `React.memo` et `useMemo` partout (la surutilisation est tout aussi néfaste que la sous-utilisation)
- Optimisations conservées sans nouvelle mesure pour les justifier
- Plusieurs optimisations regroupées dans une seule mesure, rendant impossible l'attribution d'un changement individuel
- Une prétendue « victoire » ayant nécessité de modifier, d'ignorer ou de supprimer un test
- Tentative répétée d'une optimisation ayant déjà échoué parce que personne n'avait consigné le premier échec

## Vérification

Après toute modification liée à la performance :

- [ ] Des mesures avant et après existent (chiffres précis)
- [ ] Le résultat a été re-mesuré de la même façon que la référence (même commande, mêmes conditions)
- [ ] L'amélioration dépasse la variance entre exécutions, et pas seulement la moyenne
- [ ] Les modifications n'ayant pas surpassé la référence ont été annulées, et non conservées par neutralité
- [ ] Les tentatives sont consignées, qu'elles soient conservées ou annulées, pour éviter de retenter une idée vouée à l'échec
- [ ] Le goulot d'étranglement spécifique est identifié et traité
- [ ] Les Core Web Vitals se situent dans les seuils « Bon »
- [ ] La taille du bundle n'a pas augmenté de manière significative
- [ ] Aucune requête N+1 dans le nouveau code de récupération de données
- [ ] Tout nouvel index est justifié par un plan d'exécution avant/après, et son coût en écriture a été pris en compte
- [ ] Tout nouveau cache précise ses clés et son mécanisme d'obsolescence
- [ ] La métrique mesurée orientée utilisateur dispose d'un budget synthétique ou d'un monitoring terrain capable de détecter une régression
- [ ] Les tests existants passent toujours (l'optimisation n'a pas altéré le comportement)
