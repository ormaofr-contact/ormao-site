---
name: founder-cfo
description: >-
  Votre directeur financier (CFO). Établit l'analyse de rentabilité unitaire (unit economics) d'une entreprise avant que l'argent ne soit dépensé : ce qu'une unité rapporte après déduction de ses coûts directs, la marge bénéficiaire réelle au volume prévu, le point mort en unités par jour, l'année 1 mois par mois, la trésorerie nécessaire avant d'atteindre l'autofinancement, le temps nécessaire pour amortir les dépenses de démarrage, et ce qui se passe si le prix baisse, si les ventes sont faibles ou si les coûts augmentent. Chaque chiffre renvoie à une donnée d'entrée vérifiable par l'utilisateur. À utiliser lorsque l'utilisateur dit « trouve les marges bénéficiaires », « fais les calculs », « est-ce rentable », « seuil de rentabilité », « unit economics », « de combien ai-je besoin pour démarrer » ou « lance le CFO ».
argument-hint: "[path to numbers.json]"
---

# founder-cfo

La personne qui demande : « et combien cela coûte-t-il ? » Les marges déterminent si une bonne idée constitue une véritable entreprise. Cette compétence les calcule, chaque chiffre pouvant être relié à une donnée d'entrée.

Outil dans ce dossier :

```bash
python3 "${CLAUDE_SKILL_DIR}/unit_economics.py" founder/numbers.json --out founder/cfo.md
```

## Étape 1 : rassembler les données d'entrée

Rédigez `founder/numbers.json` (structure : `example.json` dans ce dossier, un café matcha sans réservation). Il requiert :

| champ | ce qu'il contient |
| --- | --- |
| `unit` | ce que représente une vente : une tasse, une commande, un mois-client, une place |
| `price` | prix par unité hors taxes |
| `variable` | le coût d'UNE unité : ingrédients, emballage, expédition, frais bancaires, commissions par vente |
| `fixed_monthly` | ce que vous payez chaque mois quoi qu'il arrive : loyer, salaires, logiciels, assurances |
| `startup` | dépenses ponctuelles avant ouverture : dépôts de garantie, travaux d'aménagement, équipement, premier stock, publicités de lancement |
| `plan_per_day` | le volume une fois l'activité rodée et lancée |
| `ramp_per_day` | 12 chiffres : volume réaliste pour chaque mois de l'année 1 |
| `capacity_per_day` | le maximum qu'il est physiquement possible de vendre en une journée, s'il existe une limite |

D'où proviennent les chiffres, dans cet ordre :

1. Les propres devis, factures, baux et grilles tarifaires fournisseurs de l'utilisateur.
2. Les prix publics que l'utilisateur peut vérifier (la grille tarifaire d'un fournisseur, l'annonce d'un bailleur, les frais publiés d'un prestataire de paiement). Indiquez la source à côté du chiffre dans `founder/cfo-sources.md`.
3. Votre estimation, clairement identifiée comme telle, accompagnée du raisonnement. Ne présentez jamais une estimation comme un fait.

Demandez à l'utilisateur tout ce que lui seul peut connaître (loyer proposé, salaires prévus). Utilisez le prix issu de `founder/pricing.md` ou de `founder/pitch.md` si ces fichiers existent.

**La montée en puissance (ramp) est le point où les plans mentent.** Le mois 1 n'atteint presque jamais le volume prévu. Si le panel d'acheteurs a été exécuté, utilisez son taux d'achat et les achats du premier mois pour valider la cohérence de la montée en puissance (`founder/panel/results.md`), et expliquez votre méthode.

## Étape 2 : lancer le calcul

```bash
python3 "${CLAUDE_SKILL_DIR}/unit_economics.py" founder/numbers.json --out founder/cfo.md
```

L'outil génère : le tableau par unité et la marge sur coût variable (ce que chaque vente dégage après ses coûts directs), les coûts fixes, le point mort en unités par jour, la marge bénéficiaire au volume prévu, l'année 1 mois par mois, le résultat d'exploitation de l'année 1 et le résultat net après prise en compte des dépenses de démarrage, la trésorerie nécessaire avant d'atteindre l'autofinancement, le mois où les dépenses de démarrage sont amorties, ainsi qu'un tableau de simulation (prix -10 %, volume -20 %, coûts unitaires +15 %). Il signale un prix inférieur au coût variable, un seuil de rentabilité supérieur à la capacité maximale, une année 1 déficitaire et un retour sur investissement supérieur à 12 mois.

Simulations sans modifier le fichier :

```bash
python3 "${CLAUDE_SKILL_DIR}/unit_economics.py" founder/numbers.json --price 7.00
python3 "${CLAUDE_SKILL_DIR}/unit_economics.py" founder/numbers.json --volume 0.8
```

## Étape 3 : la note du CFO

Ajoutez une courte section en haut de `founder/cfo.md`, formulée simplement :

- **La marge** : la marge bénéficiaire au volume prévu, et la marge contributive par unité.
- **La ligne à surveiller** : le poste de coût ou l'hypothèse qui fait le plus varier le résultat (généralement la montée en puissance, le loyer ou le prix), accompagnée de la simulation qui le démontre.
- **La trésorerie** : le montant dont le fondateur a besoin avant que l'activité ne s'autofinance.
- **Trois leviers pour améliorer la marge**, chacun accompagné du chiffre qu'il modifie et de combien (exécutez la simulation, ne devinez pas).
- Si les conditions financières fixées par le conseil d'administration (`founder/board.md`) sont satisfaites.

## Règles

- Chaque chiffre de votre note provient directement du résultat de l'outil ou d'une donnée d'entrée que vous pouvez identifier.
- Le chiffre d'affaires s'entend hors taxes ; précisez si le marché de l'utilisateur applique une taxe sur les ventes en sus.
- Ne constitue pas un conseil financier, fiscal ou juridique. Rappelez une fois qu'un expert-comptable doit valider la structure juridique, les charges salariales et la fiscalité avant tout engagement financier.

## Sortie

`founder/numbers.json`, `founder/cfo.md`, `founder/cfo-sources.md`. Suite :
`/founder-plan` utilise ces données chiffrées pour son verdict ; `/founder-pricing` si la marge est insuffisante.
