---
name: interview-prep-generator
description: Générer des récits STAR, des questions d'entraînement et des points clés à partir d'un CV
---

# Générateur de préparation aux entretiens

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Se préparer à un entretien d'embauche
- S'entraîner à répondre à des questions d'entretien
- Créer des récits STAR à partir de son expérience
- Anticiper les questions pour un poste spécifique
- Mentionne : « préparation entretien », « préparer un entretien », « récits STAR », « questions d'entretien », « questions comportementales »

## Fonctionnalités principales

- Générer des questions d'entretien spécifiques au poste
- Créer des récits STAR à partir des points clés du CV
- Prédire les questions en fonction de la fiche de poste
- Préparer des réponses aux questions fréquentes
- Élaborer des points de discussion pour chaque expérience
- Identifier les points de préoccupation potentiels et préparer les réponses

## Cadre de préparation aux entretiens

### Phase 1 : Analyse du poste
- Extraire les questions probables à partir de la fiche de poste
- Identifier les compétences qui seront évaluées
- Se renseigner sur le style d'entretien de l'entreprise

### Phase 2 : Constitution de la réserve de récits
- Convertir les points du CV en récits STAR
- Créer des histoires pour les compétences courantes
- S'entraîner à une restitution concise

### Phase 3 : Préparation aux simulations
- S'entraîner sur les questions fréquentes
- Préparer les questions à poser
- Se renseigner sur des sujets spécifiques à l'entreprise

## La méthode STAR en détail

### Structure
- **S**ituation : Poser le contexte (1 à 2 phrases)
- **T**âche : Décrire votre responsabilité (1 phrase)
- **A**ction : Expliquer ce que VOUS avez fait (2 à 3 phrases)
- **R**ésultat : Partager l'aboutissement avec des indicateurs chiffrés (1 à 2 phrases)

### Modèle de récit STAR

```
SITUATION: "At [Company], we faced [specific challenge/context]..."

TASK: "I was responsible for [specific ownership]..."

ACTION: "I [specific action 1], [specific action 2], and [specific action 3]..."

RESULT: "As a result, [quantified outcome]. This led to [business impact]."
```

### Exemple de récit STAR

**Question :** « Parlez-moi d'une fois où vous avez dirigé une équipe sur un projet difficile. »

**Réponse :**
```
SITUATION: "At TechCorp, our main product was losing customers to a competitor who had launched a better mobile experience. We were seeing 5% monthly churn, up from our normal 2%."

TASK: "As the product manager, I was responsible for turning around our mobile product to stop the bleeding and win back customers."

ACTION: "I started by interviewing 30 churned customers to understand exactly why they left. Based on that research, I prioritized 5 critical features that would achieve parity with competitors. I then worked with engineering to restructure our roadmap, negotiated with leadership to add 2 contract developers, and implemented weekly sprint reviews to keep the project on track. I also started a beta program with 50 of our best customers to get feedback before full launch."

RESULT: "We launched the improved mobile app in 3 months, reducing churn from 5% back to 2% within 60 days. We recovered 35% of churned customers and the NPS for our mobile app increased from 32 to 58. This project was recognized in our company all-hands as a turnaround success."
```

**Durée :** 90 secondes à 2 minutes

## Processus de constitution de la réserve de récits

### Étape 1 : Identifier les compétences clés

**Récits de leadership nécessaires :**
- Avoir dirigé une équipe face à un défi
- Avoir géré un conflit
- Avoir pris une décision difficile
- Avoir délégué efficacement
- Avoir encadré/mentoré quelqu'un

**Récits de résolution de problèmes nécessaires :**
- Avoir résolu un problème technique complexe
- Avoir réparé un processus défaillant
- Avoir géré un obstacle imprévu
- Avoir pris une décision avec des informations incomplètes
- Avoir amélioré quelque chose de manière proactive

**Récits de collaboration nécessaires :**
- Avoir travaillé avec un collègue difficile
- Avoir aligné des parties prenantes transverses
- Avoir suscité le consensus
- Avoir collaboré avec d'autres équipes
- Avoir exercé une influence sans autorité hiérarchique

**Récits de réussite nécessaires :**
- Avoir dépassé les objectifs/attentes
- Avoir livré des résultats sous pression
- S'être surpassé
- Avoir pris des initiatives
- Avoir accompli quelque chose dont on est fier

**Récits d'échec / d'apprentissage nécessaires :**
- Avoir commis une erreur et en avoir tiré des leçons
- Avoir reçu un retour critique
- Avoir échoué puis rebondi
- Avoir changé d'approche en fonction des leçons apprises

### Étape 2 : Relier le CV aux récits

Pour chaque puce du CV, créer un récit STAR complet :

```
RESUME BULLET: "Led cross-functional team of 12 to deliver $2M product launch"

STAR EXPANSION:

SITUATION: Our company was losing market share to a competitor, and leadership decided we needed to launch a new product line within 6 months.

TASK: As Product Manager, I was tasked with leading the product from concept to launch, coordinating across engineering, design, marketing, and sales teams (12 people total).

ACTION: 
- I established weekly cross-functional syncs and a shared Notion workspace
- Created a detailed project plan with milestones and dependencies
- Implemented a rapid prototyping process with 2-week design sprints
- Personally resolved 3 major conflicts between engineering and marketing
- Presented monthly updates to leadership to maintain alignment

RESULT: 
- Launched on time and under budget
- Generated $2M revenue in first year
- Acquired 50 new enterprise customers
- Team received company innovation award
```

### Étape 3 : Créer plusieurs versions

Chaque histoire doit comporter :
- **Version intégrale :** 2 minutes (pour « parlez-moi d'une fois où... »)
- **Version courte :** 60 secondes (pour les questions de relance)
- **Version en une phrase :** 15 secondes (pour « donnez-moi un exemple »)

## Questions d'entretien fréquentes par catégorie

### Questions comportementales

**Leadership :**
- « Parlez-moi d'une fois où vous avez dirigé une équipe. »
- « Décrivez une situation où vous avez dû prendre une décision impopulaire. »
- « Comment avez-vous fait progresser les membres de votre équipe ? »
- « Racontez-moi une situation où vous avez dû gérer un membre d'équipe difficile. »

**Résolution de problèmes :**
- « Décrivez un problème complexe que vous avez résolu. »
- « Parlez-moi d'une fois où les choses ne se sont pas déroulées comme prévu. »
- « Comment abordez-vous les problèmes lorsque les informations sont incomplètes ? »
- « Donnez un exemple de solution innovante que vous avez développée. »

**Collaboration :**
- « Parlez-moi d'une collaboration avec une personne difficile. »
- « Décrivez une situation où vous avez dû influencer quelqu'un sans lien d'autorité. »
- « Comment gérez-vous les désaccords avec des collègues ? »
- « Racontez-moi un projet transverse réussi. »

**Réussite :**
- « Quelle est votre plus grande fierté professionnelle ? »
- « Parlez-moi d'une fois où vous avez dépassé les attentes. »
- « Décrivez un objectif que vous avez atteint contre toute attente. »
- « Quel a été le plus grand impact de votre carrière ? »

**Échec / Évolution :**
- « Parlez-moi d'une fois où vous avez échoué. »
- « Quelle est la plus grosse erreur que vous ayez commise au travail ? »
- « Comment gérez-vous la critique ? »
- « Que feriez-vous différemment dans votre parcours ? »

### Questions spécifiques au poste

**Gestion de produit (Product Management) :**
- « Comment priorisez-vous les fonctionnalités ? »
- « Expliquez-moi comment vous aborderiez [problème produit]. »
- « Comment mesurez-vous le succès d'un produit ? »
- « Parlez-moi d'un produit que vous avez mené de 0 à 1. »

**Ingénierie :**
- « Décrivez votre expérience avec [technologie spécifique]. »
- « Comment abordez-vous les revues de code ? »
- « Parlez-moi d'un défi technique que vous avez résolu. »
- « Comment trouvez-vous l'équilibre entre dette technique et fonctionnalités ? »

**Marketing :**
- « Comment mesurez-vous le succès d'une campagne ? »
- « Parlez-moi d'une campagne qui n'a pas fonctionné. »
- « Comment répartissez-vous le budget entre les différents canaux ? »
- « Décrivez votre approche de la construction de marque. »

**Vente :**
- « Présentez-moi votre processus de vente. »
- « Parlez-moi d'une affaire que vous avez perdue et expliquez pourquoi. »
- « Comment traitez-vous les objections ? »
- « Décrivez la plus grosse vente que vous ayez conclue. »

### Questions classiques

**À propos de vous :**
- « Parlez-moi de vous. » (pitch de 2 min)
- « Présentez-moi votre parcours. »
- « Pourquoi cherchez-vous un nouveau poste ? »
- « Où vous voyez-vous dans 5 ans ? »

**À propos du poste :**
- « Pourquoi ce poste ? »
- « Qu'est-ce qui vous intéresse dans cette opportunité ? »
- « Que pensez-vous que ce poste implique ? »
- « Que feriez-vous au cours de vos 90 premiers jours ? »

**À propos de l'entreprise :**
- « Pourquoi notre entreprise ? »
- « Que savez-vous sur nous ? »
- « Pourquoi voulez-vous travailler ici ? »
- « Qu'est-ce qui vous motive dans notre mission ? »

## Questions à poser aux recruteurs

### Pour le responsable du recrutement (Hiring Manager)
- « À quoi ressemble le succès dans ce rôle à 30, 60 et 90 jours ? »
- « Quels sont les plus grands défis auxquels l'équipe est confrontée ? »
- « Comment la performance est-elle mesurée ? »
- « Quelle est la structure de l'équipe ? »

### Pour les membres de l'équipe
- « À quoi ressemble une journée ou une semaine type ? »
- « Qu'appréciez-vous le plus dans le fait de travailler ici ? »
- « Comment les équipes collaborent-elles ? »
- « Que conseilleriez-vous à une nouvelle recrue de savoir ? »

### Pour la direction
- « Quelle est la stratégie de l'entreprise pour l'année à venir ? »
- « De quelle manière cette équipe contribue-t-elle aux objectifs de l'entreprise ? »
- « Qu'est-ce qui continue de vous enthousiasmer au sein de l'entreprise ? »

### À éviter
- ❌ Questions sur le salaire ou les avantages (à réserver aux RH)
- ❌ Questions dont la réponse se trouve facilement sur Google
- ❌ Questions négatives sur les problèmes de l'entreprise
- ❌ Questions fermées appelant un oui/non (privilégier les questions ouvertes)

## Gérer les questions difficiles

### « Quel est votre plus grand défaut ? »

**Formule :** Vrai défaut + Prise de conscience + Actions d'amélioration

```
"I tend to be overly detail-oriented, which can sometimes slow me down. I've recognized this and now set time limits for tasks and ask for feedback on when good enough is good enough. In my current role, I've also learned to delegate detailed work when appropriate."
```

### « Pourquoi quittez-vous votre emploi actuel ? »

**Garder une réponse :**
- Positive (axée sur l'évolution)
- Tournée vers l'avenir (sans récriminations)
- Brève (ne pas trop en rajouter)

```
"I've learned a lot at [Company], but I'm looking for [specific opportunity] that I don't see available in my current path. This role at [Company] offers exactly that - the chance to [specific thing]."
```

### « Parlez-moi d'une fois où vous avez échoué »

**Doit inclure :**
- Un échec réel (pas une fausse modestie)
- Ce que vous avez appris
- Comment vous avez appliqué cet enseignement

```
"In my first year as a PM, I launched a feature without sufficient user research. The feature was technically sound but users found it confusing. Only 10% adopted it. I learned the hard way that building the right thing matters more than building the thing right. Since then, I never skip user research - I now always do at least 10 user interviews before major feature decisions."
```

### Questions sur le salaire

**Éluder jusqu'à ce qu'une réponse soit indispensable :**

```
"I'm flexible on compensation and more focused on finding the right role. Can you share the range budgeted for this position?"
```

**En cas d'insistance :**
```
"Based on my research and experience, I'm looking for something in the range of $X-$Y, but I'm open to discussing the full compensation package."
```

## Format de sortie

Lors de la génération d'un dossier de préparation aux entretiens :

```markdown
# INTERVIEW PREP: [POSITION] AT [COMPANY]

## Role Analysis
**Key competencies they'll test:**
1. [Competency] - Evidence: [From JD]
2. [Competency] - Evidence: [From JD]
3. [Competency] - Evidence: [From JD]

## Predicted Questions

### High Probability (prepare thoroughly)
1. [Question] → Use story: [Story name]
2. [Question] → Use story: [Story name]
3. [Question] → Use story: [Story name]

### Medium Probability
1. [Question]
2. [Question]

## Your STAR Story Bank

### Story 1: [Name - e.g., "Product Launch Success"]
**Use for:** Leadership, Achievement, Cross-functional
**STAR:**
- S: [Situation]
- T: [Task]
- A: [Action]
- R: [Result with metrics]
**Short version:** [60 second version]

### Story 2: [Name]
[Same structure]

## "Tell Me About Yourself" Script
[2-minute pitch tailored to this role]

## Questions to Ask
**For Hiring Manager:**
1. [Question]
2. [Question]

**For Team:**
1. [Question]
2. [Question]

## Company Research Notes
- Recent news: [Item]
- Key facts to reference: [Facts]
- Potential concerns: [Items to be ready for]

## Red Flag Answers to Avoid
- Don't mention: [Topics]
- Don't criticize: [Past employer aspects]
- Watch out for: [Potential trap questions]
```

## Liste de contrôle de mise en œuvre

Pour une préparation complète à l'entretien :
1. ✅ Analyser la fiche de poste pour identifier les compétences
2. ✅ Créer 8 à 10 récits STAR couvrant l'ensemble des compétences
3. ✅ Rédiger le pitch « parlez-moi de vous »
4. ✅ Préparer les réponses aux questions probables
5. ✅ Se renseigner en profondeur sur l'entreprise
6. ✅ Préparer des questions pertinentes à poser
7. ✅ S'entraîner à voix haute (en se chronométrant)
8. ✅ Préparer la logistique (tenue, itinéraire, vérification technique)
9. ✅ Réviser la veille de l'entretien
10. ✅ Envoyer des messages de remerciement après l'entretien
