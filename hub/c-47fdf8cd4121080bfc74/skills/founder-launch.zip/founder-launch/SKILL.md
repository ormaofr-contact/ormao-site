---
name: founder-launch
description: >-
  Votre responsable de lancement. Élabore un plan de lancement planifié, étape
  par étape : d'abord un test réel et peu coûteux (une liste d'attente, une
  prévente ou un pop-up avec un prix réel, afin que de vrais acheteurs confirment
  ce que le panel simulé a indiqué), puis le compte à rebours jusqu'au jour de
  l'ouverture avec les responsables et les échéances, le déroulé heure par heure du
  jour de lancement, et les 30 premiers jours définissant quoi mesurer et quoi
  ajuster. À utiliser lorsque l'utilisateur dit « comment lancer », « plan de
  lancement », « quand puis-je ouvrir », « checklist de lancement », « mise en
  ligne » ou « ouverture en douceur ».
argument-hint: "[date de lancement cible]"
---

# founder-launch

Un lancement est un projet assorti d'une date. Cette compétence transforme tout
le reste du pack en un plan daté, et commence par le moyen le moins coûteux de
vérifier si de vraies personnes sont prêtes à payer avant d'engager de grosses
dépenses.

## Étape 1 : tester avant de dépenser

Choisissez le test réel le moins coûteux adapté à votre activité, et réalisez-le
avant d'engager les dépenses importantes figurant dans `founder/numbers.json` :

| activité | le test |
| --- | --- |
| boutique physique ou café | un pop-up, un stand de marché ou une liste de précommandes avec un prix et une date |
| produit en ligne | une landing page avec le prix et un bouton « précommander » ou « rejoindre la liste d'attente » |
| service ou agence | trois clients pilotes payants au prix prévu |
| abonnement | une offre membre fondateur, payée d'avance |

Définissez le seuil de réussite avant de lancer le test (par exemple : 50 précommandes
en deux semaines à 6,50 $), et comparez le résultat avec le taux d'achat du panel. Si les
vrais acheteurs sont bien en deçà des prévisions du panel, fiez-vous aux vrais acheteurs
et revenez à `/founder-offer` ou `/founder-pricing`.

## Étape 2 : le compte à rebours

D'aujourd'hui jusqu'au jour du lancement, avec des dates réelles (demandez la date
cible ; par défaut, retenez la date réaliste la plus proche compte tenu des délais
dans `founder/ops.md`). Blocs hebdomadaires, chaque tâche ayant un responsable et
une échéance :

- Juridique et financier : immatriculation, compte bancaire, autorisations issues de `founder/ops.md`.
- Réalisation : aménagement ou site web, fournisseurs classés selon leurs délais de livraison.
- Marque : enseigne, packaging, profils issus de `founder/brand.md`.
- Marketing : le calendrier dans `founder/marketing.md` à partir de J-14 avant le lancement.
- Équipe : recrutement et formation aux SOPs.
- Une ouverture en douceur (soft open) ou une journée proches et famille avant le lancement public.

Identifiez le chemin critique : les tâches qui décalent la date de lancement en cas de retard.

## Étape 3 : le jour du lancement

Un déroulé heure par heure : qui est où, ce qui est publié sur chaque canal,
l'offre d'ouverture, la marche à suivre si quelque chose ne fonctionne pas
(d'après le registre des risques).

## Étape 4 : les 30 premiers jours

Les chiffres hebdomadaires à suivre (du directeur financier : unités par jour par
rapport au seuil de rentabilité ; du marketing : les indicateurs par canal), le
seuil qui déclenche un ajustement, et un bilan à J+7, J+14 et J+30 avec les
questions auxquelles répondre.

## Livrable

`founder/launch.md` contenant le test, le compte à rebours, le déroulé de la journée
et le bilan des 30 premiers jours. Ensuite : `/founder-plan` compile l'ensemble dans
le business plan.
