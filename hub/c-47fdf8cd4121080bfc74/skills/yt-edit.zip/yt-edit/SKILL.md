---
name: yt-edit
description: >-
  Transforme la transcription d'un enregistrement brut en liste de décisions de montage (EDL) - blancs,
  tics de langage et reprises, avec timecodes. À utiliser pour « monte ceci », « coupe les
  blancs », « dynamise cette vidéo », « je me suis éparpillé », ou toute demande visant à raccourcir
  une vidéo à partir d'une transcription.
---

# yt-edit

Une liste de décisions de montage (EDL) générée à partir d'une transcription horodatée. Elle affiche les coupes. Vous les appliquez.

```bash
python3 deadair.py transcript.srt              # srt, vtt or whisper json
python3 deadair.py transcript.srt --floor 0.35 --json
```

Pas encore de transcription ? Demandez-en une, ou produisez-en une d'abord : `whisper`, `faster-whisper`, ou la piste de sous-titres générée par YouTube lors d'une mise en ligne non répertoriée fonctionnent tous très bien. Ne devinez pas les minutages.

## Ce qu'il détecte

- **DEAD** - silences plus longs que le seuil minimal, coupés depuis le MILIEU pour que chaque côté conserve une respiration. Couper au ras de la parole donne à une prise resserrée un effet d'essoufflement.
- **FILLER** - segments qui ne contiennent rien d'autre que des « euh », « donc ouais », « en gros ».
- **REPEAT** - une phrase recommencée. Comparée au dernier segment qui était réellement de la parole, et non au segment immédiatement précédent, car la plupart des reprises comportent un « euh » entre les deux tentatives.

## Ce qu'il ne fera pas

Il ne touche pas aux fichiers médias. Il n'a aucun avis sur vos plans de coupe (B-roll). Une coupe de 40 % sur le rapport est une coupe de 40 % de la PAROLE, et si la vidéo contient une longue démonstration silencieuse, ce chiffre sera faux : comparez le rapport avec vos rushes avant de faire confiance à la durée totale indiquée en bas.

## Le garde-fou

Rien n'est publié automatiquement ici. Cette compétence rédige et vous publiez. Chaque résultat se termine par un bloc que l'utilisateur peut copier, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
