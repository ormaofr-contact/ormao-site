---
name: ig-profile
description: >-
  Évaluez un profil Instagram sur 100 points selon une grille en 12 critères et réécrivez
  les éléments qui font perdre des points : champ nom, bio, lien, stories à la une, les trois posts épinglés,
  la grille. À utiliser lorsque l'utilisateur dit « optimise mon profil », « corrige ma bio », « note mon
  Instagram », « pourquoi les gens ne s'abonnent pas », ou lorsqu'il colle son profil et demande ce qu'il dégage.
---

# ig-profile

Presque tout le monde optimise le mauvais élément ici. Le profil n'est pas une
vitrine de magasin que les gens parcourent. C'est un **écran de décision**, atteint depuis un
seul reel, et il dispose d'environ trois secondes pour répondre à une question : y a-t-il plus de
contenu de ce genre ici, et est-ce fait pour moi ?

## Données d'entrée

Demandez à l'utilisateur de coller ou de faire une capture d'écran de : le champ nom, l'identifiant (handle), la bio, ce vers quoi
pointe le lien, les noms des stories à la une, ce qui est épinglé, et les neuf premières
couvertures de la grille. Une capture d'écran du haut du profil ainsi que des deux premières
lignes de la grille suffit pour une première passe.

Ne vous connectez pas à Instagram à sa place.

## Évaluation

Lisez `rubric.json` dans ce dossier. Douze critères, 100 points, chacun indiquant à quoi ressemble
la note maximale et comment il échoue habituellement. Notez chaque critère, affichez le
tableau, donnez le total. Soyez honnête. La plupart des profils se situent entre 30 et 40 points lors de la
première passe et une note généreuse ne sert à rien.

```
SCORE DU PROFIL  38/100

  champ nom        2/12   nom uniquement, aucun mot-clé recherché
  première ligne   3/12   trois noms communs et un emoji café
  trois épinglés   0/10   rien d'épinglé
  à la une         2/8    "Divers", "Life", "2023"
  lisibilité grill 4/8    six couvertures sur neuf montrent un visage en plein milieu d'une phrase
  ...
```

## Puis réécrivez, dans cet ordre

Corrigez par ordre décroissant de points perdus. Ne réécrivez pas tout d'un coup,
l'utilisateur doit concrètement aller modifier chacun de ces éléments.

**1. Le champ nom (30 caractères).** La ligne en gras sous la photo, pas
l'identifiant. C'est le champ sur lequel la recherche Instagram effectue la correspondance, et la plupart des comptes
y mettent un nom et rien d'autre. Format qui fonctionne :
`{Nom} | {ce que vous faites, avec des mots recherchés}`. Proposez trois options.

**2. Première ligne de la bio.** À qui cela s'adresse et ce qui change. Pas un intitulé de poste, pas
d'adjectifs, pas une liste d'identités séparées par des barres verticales. Le reste des 150
caractères apporte un élément de preuve ou une offre claire.

**3. Les trois posts épinglés.** Trois emplacements, trois rôles distincts : la meilleure preuve,
l'explication la plus claire de l'offre, la meilleure présentation de la personne. C'est le
levier d'optimisation le plus puissant de tout le profil et cela prend quatre clics. Une
grille sans posts épinglés affiche simplement ce qui a été publié en dernier, ce qui revient à jouer à pile ou face.

**4. Stories à la une.** Quatre à six, nommées d'après les questions qu'un acheteur se pose : Tarifs,
Résultats, Fonctionnement, À propos. Pas « En vrac ». Supprimez le reste.

**5. Le lien.** Une seule destination qui correspond à ce que la bio vient de promettre. Cinq
sont autorisés ; deux ressemble déjà à un menu, et un menu convertit moins bien qu'une porte.

**6. Couvertures de la grille.** Les neuf premières au format vignette. Les couvertures de Reels se choisissent,
on ne laisse pas n'importe quelle image figée au hasard. Quatre mots de texte sur une couverture rendent une grille
lisible en un coup d'œil.

## Résultat attendu

Le tableau des scores, puis les réécritures sous forme de blocs prêts à être copiés, classés par ordre de priorité des corrections, chacun
passé au crible de `/ig-human`. Réévaluez à la fin et affichez l'écart en toute honnêteté. Si
la réécriture atteint 84 et non 98, indiquez 84, et expliquez ce que le reste nécessite, à savoir
généralement une grille, une habitude de publication en story et un post épinglé qui n'existe pas encore.
Rien de tout cela ne relève de la simple réécriture.

Rien n'est enregistré sur Instagram par cette compétence. L'utilisateur modifie chaque champ lui-même.
