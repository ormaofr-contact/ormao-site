---
name: yt-chapters
description: >-
  Rédiger des chapitres YouTube à partir d'une transcription, validés selon les
  propres règles de YouTube pour garantir leur affichage effectif. À utiliser pour "ajouter des chapitres", "timestamps",
  "découper cette vidéo en sections".
---

# yt-chapters

```bash
python3 chapters.py transcript.srt --target 8
```

## Les règles, qui ne sont pas facultatives

Une liste de chapitres qui enfreint l'une de ces règles échouera silencieusement et ne se transformera pas du tout en chapitres — le bloc restera simplement inerte dans la description :

- La première entrée doit être **00:00**.
- Il doit y en avoir **au moins trois**.
- Chacun doit durer **au moins 10 secondes**.

L'outil vérifie ces trois critères et vous signale si une liste est invalide au lieu de vous laisser la copier-coller.

## Renommer chaque ligne

`chapters.py` détecte très bien les LIMITES — il évalue les pauses réelles en fonction de la variation du vocabulaire d'un passage à l'autre. Les titres qu'il génère sont les mots-clés du sujet, et ne sont qu'un brouillon. Un chapitre intitulé « Thumbnails Titles Packaging » est un espace réservé. Réécrivez chacun d'eux sous la forme de la promesse de cette section, avec la voix de l'utilisateur, en trois à cinq mots.

Les chapitres sont aussi un diagnostic de rétention : si une section ne peut pas être résumée en cinq mots, c'est qu'il s'agit de deux sections distinctes ou de remplissage.

## Le point de contrôle

Rien n'est publié automatiquement ici. Cette compétence rédige et vous publiez. Chaque résultat se termine par un bloc que l'utilisateur copie, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
