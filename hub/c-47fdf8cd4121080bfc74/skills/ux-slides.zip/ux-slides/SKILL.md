---
name: slides
description: Créez des présentations HTML stratégiques avec Chart.js, des design tokens, des mises en page responsives, des formules de copywriting et des stratégies de diapositives contextuelles.
argument-hint: "[topic] [slide-count]"
metadata:
  author: claudekit
  version: "1.0.0"
---

# Slides

Conception stratégique de présentations HTML avec visualisation de données.

## Quand l'utiliser

- Présentations marketing et pitch decks
- Diapositives basées sur des données avec Chart.js
- Conception stratégique de diapositives avec des modèles de mise en page
- Contenu de présentation optimisé pour le copywriting

## Sous-commandes

| Sous-commande | Description | Référence |
|---------------|-------------|-----------|
| `create` | Créer des diapositives de présentation stratégiques | `references/create.md` |

## Chemins des scripts

Les chemins de scripts dans cette compétence et ses `references/` sont relatifs au répertoire contenant ce fichier SKILL.md, et non au projet : `scripts/<file>` correspond au propre dossier `scripts/` de cette compétence, et `../<skill>/scripts/<file>` correspond à une sous-compétence sœur installée à ses côtés. Construisez le chemin complet à partir de ce répertoire (Claude Code l'indique comme répertoire de base de la compétence lors de son chargement) et conservez le répertoire de travail à la racine du projet — les scripts lisent et écrivent des fichiers de projet tels que `docs/brand-guidelines.md`, `assets/design-tokens.json` ou `src/` par rapport à celle-ci.

## Références (Base de connaissances)

| Sujet | Fichier |
|-------|---------|
| Modèles de mise en page | `references/layout-patterns.md` |
| Modèle HTML | `references/html-template.md` |
| Formules de copywriting | `references/copywriting-formulas.md` |
| Stratégies de diapositives | `references/slide-strategies.md` |

## Routage

1. Analyser la sous-commande à partir de `$ARGUMENTS` (premier mot)
2. Charger le fichier `references/{subcommand}.md` correspondant
3. Exécuter avec les arguments restants
