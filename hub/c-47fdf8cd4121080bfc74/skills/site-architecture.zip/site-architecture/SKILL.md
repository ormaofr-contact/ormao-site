---
name: site-architecture
description: Quand l'utilisateur souhaite planifier, cartographier ou restructurer la hiérarchie des pages, la navigation, la structure des URL ou le maillage interne de son site web. À utiliser également lorsque l'utilisateur mentionne « sitemap », « plan de site », « plan de site visuel », « structure du site », « hiérarchie des pages », « architecture de l'information », « AI », « conception de la navigation », « structure des URL », « fil d'Ariane », « stratégie de maillage interne », « planification de site web », « de quelles pages ai-je besoin », « comment organiser mon site », « navigation du site », « quel créateur de site web utiliser », « migrer mon site web » ou « ajouter un blog à mon site existant ». À utiliser chaque fois que quelqu'un planifie les pages qu'un site web devrait comporter, la façon dont elles sont reliées et où les créer. Ne PAS utiliser pour les sitemaps XML (qui relèvent du SEO technique — voir seo-audit). Pour les audits SEO, voir seo-audit. Pour les données structurées, voir schema.
metadata:
  version: 2.1.0
---

# Architecture de site

Vous êtes un expert en architecture de l'information. Votre objectif est d'aider à planifier la structure d'un site web — hiérarchie des pages, navigation, modèles d'URL et maillage interne — afin que le site soit intuitif pour les utilisateurs et optimisé pour les moteurs de recherche.

## Avant de planifier

**Vérifiez d'abord le contexte marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y sont pas déjà traitées ou qui sont spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Contexte de l'entreprise
- Que fait l'entreprise ?
- Quels sont les publics cibles principaux ?
- Quels sont les 3 objectifs prioritaires du site ? (conversions, trafic SEO, éducation, support)

### 2. État actuel
- Nouveau site ou restructuration d'un site existant ?
- En cas de restructuration : qu'est-ce qui ne va pas ? (taux de rebond élevé, mauvais SEO, utilisateurs qui ne trouvent pas l'information)
- Des URL existantes doivent-elles être préservées (pour les redirections) ?
- Sur quelle plateforme repose-t-il, et un changement de plateforme est-il envisagé ? (Pour choisir une plateforme, ajouter une section à un site existant ou migrer, consultez [references/platforms-and-migration.md](references/platforms-and-migration.md).)

### 3. Type de site
- Site marketing SaaS
- Site de contenu / blog
- E-commerce
- Documentation
- Hybride (SaaS + contenu)
- Petite entreprise / local

### 4. Inventaire de contenu
- Combien de pages existent ou sont prévues ?
- Quelles sont les pages les plus importantes ? (par trafic, conversions ou valeur pour l'entreprise)
- Des sections ou des extensions sont-elles prévues ?

---

## Types de sites et points de départ

| Type de site | Profondeur typique | Sections clés | Modèle d'URL |
|--------------|-------------------|---------------|--------------|
| Marketing SaaS | 2-3 niveaux | Accueil, Fonctionnalités, Tarifs, Blog, Docs | `/features/name`, `/blog/slug` |
| Contenu / blog | 2-3 niveaux | Accueil, Blog, Catégories, À propos | `/blog/slug`, `/category/slug` |
| E-commerce | 3-4 niveaux | Accueil, Catégories, Produits, Panier | `/category/subcategory/product` |
| Documentation | 3-4 niveaux | Accueil, Guides, Référence API | `/docs/section/page` |
| Hybride SaaS + contenu | 3-4 niveaux | Accueil, Produit, Blog, Ressources, Docs | `/product/feature`, `/blog/slug` |
| Petite entreprise | 1-2 niveaux | Accueil, Services, À propos, Contact | `/services/name` |

**Pour des modèles complets de hiérarchie de pages** : Voir [references/site-type-templates.md](references/site-type-templates.md)

---

## Conception de la hiérarchie des pages

### La règle des 3 clics

Les utilisateurs doivent pouvoir atteindre n'importe quelle page importante en 3 clics maximum depuis la page d'accueil. Ce n'est pas une règle absolue, mais si des pages critiques sont enfouies à 4 niveaux de profondeur ou plus, il y a un problème.

### Plate vs Profonde

| Approche | Idéale pour | Compromis |
|----------|------------|-----------|
| Plate (2 niveaux) | Petits sites, portfolios | Simple mais ne passe pas à l'échelle |
| Modérée (3 niveaux) | La plupart des SaaS, sites de contenu | Bon équilibre entre profondeur et facilité d'accès |
| Profonde (4+ niveaux) | E-commerce, documentations volumineuses | Passe à l'échelle mais risque d'enterrer le contenu |

**Règle empirique** : Visez une structure aussi plate que possible tout en gardant une navigation claire. Si un menu déroulant de navigation compte plus de 20 éléments, ajoutez un niveau de hiérarchie.

### Niveaux de hiérarchie

| Niveau | Ce que c'est | Exemple |
|--------|-------------|---------|
| L0 | Page d'accueil | `/` |
| L1 | Sections principales | `/features`, `/blog`, `/pricing` |
| L2 | Pages de section | `/features/analytics`, `/blog/seo-guide` |
| L3+ | Pages de détail | `/docs/api/authentication` |

### Format d'arborescence ASCII

Utilisez ce format pour les hiérarchies de pages :

```
Homepage (/)
├── Features (/features)
│   ├── Analytics (/features/analytics)
│   ├── Automation (/features/automation)
│   └── Integrations (/features/integrations)
├── Pricing (/pricing)
├── Blog (/blog)
│   ├── [Category: SEO] (/blog/category/seo)
│   └── [Category: CRO] (/blog/category/cro)
├── Resources (/resources)
│   ├── Case Studies (/resources/case-studies)
│   └── Templates (/resources/templates)
├── Docs (/docs)
│   ├── Getting Started (/docs/getting-started)
│   └── API Reference (/docs/api)
├── About (/about)
│   └── Careers (/about/careers)
└── Contact (/contact)
```

**Quand utiliser ASCII vs Mermaid** :
- ASCII : ébauches rapides de hiérarchie, contextes textuels stricts, structures simples
- Mermaid : présentations visuelles, relations complexes, affichage des zones de navigation ou des schémas de maillage

---

## Conception de la navigation

### Types de navigation

| Type de nav | Objectif | Emplacement |
|-------------|----------|-------------|
| Nav d'en-tête (Header) | Navigation principale, toujours visible | Haut de chaque page |
| Menus déroulants | Organiser les sous-pages sous un parent | Se déploie depuis les éléments du header |
| Nav de pied de page (Footer) | Liens secondaires, mentions légales, plan du site | Bas de chaque page |
| Nav latérale (Sidebar) | Navigation de section (docs, blog) | Côté gauche au sein d'une section |
| Fil d'Ariane (Breadcrumbs) | Indiquer l'emplacement actuel dans la hiérarchie | Sous le header, au-dessus du contenu |
| Liens contextuels | Contenu connexe, étapes suivantes | Au sein du contenu de la page |

### Règles de navigation dans l'en-tête

- **4 à 7 éléments maximum** dans la navigation principale (au-delà, cela provoque la paralysie du choix)
- **Le bouton CTA** se place tout à droite (ex. : « Démarrer l'essai gratuit », « Commencer »)
- **Le logo** renvoie vers la page d'accueil (côté gauche)
- **Ordre par priorité** : les pages les plus importantes/visitées en premier
- Si vous avez un méga menu, limitez-le à 3 ou 4 colonnes

### Organisation du pied de page

Regroupez les liens du footer en colonnes :
- **Produit** : Fonctionnalités, Tarifs, Intégrations, Journal des modifications (Changelog)
- **Ressources** : Blog, Études de cas, Modèles, Docs
- **Entreprise** : À propos, Carrières, Contact, Presse
- **Légal** : Confidentialité, CGU, Sécurité

### Format du fil d'Ariane

```
Home > Features > Analytics
Home > Blog > SEO Category > Post Title
```

Le fil d'Ariane doit refléter la hiérarchie des URL. Chaque segment du fil d'Ariane doit être un lien cliquable, à l'exception de la page courante.

**Pour des modèles de navigation détaillés** : Voir [references/navigation-patterns.md](references/navigation-patterns.md)

---

## Structure des URL

### Principes de conception

1. **Lisibles par les humains** — `/features/analytics` et non `/f/a123`
2. **Des tirets, pas de tirets du bas** — `/blog/seo-guide` et non `/blog/seo_guide`
3. **Refléter la hiérarchie** — Le chemin d'URL doit correspondre à la structure du site
4. **Politique de barre oblique finale (trailing slash) cohérente** — choisissez-en une (avec ou sans) et appliquez-la partout
5. **Toujours en minuscules** — `/About` doit rediriger vers `/about`
6. **Courtes mais descriptives** — `/blog/how-to-improve-landing-page-conversion-rates` est trop long ; `/blog/landing-page-conversions` est préférable

### Modèles d'URL par type de page

| Type de page | Modèle | Exemple |
|--------------|--------|---------|
| Page d'accueil | `/` | `example.com` |
| Page de fonctionnalité | `/features/{name}` | `/features/analytics` |
| Tarifs | `/pricing` | `/pricing` |
| Article de blog | `/blog/{slug}` | `/blog/seo-guide` |
| Catégorie de blog | `/blog/category/{slug}` | `/blog/category/seo` |
| Étude de cas | `/customers/{slug}` | `/customers/acme-corp` |
| Documentation | `/docs/{section}/{page}` | `/docs/api/authentication` |
| Légal | `/{page}` | `/privacy`, `/terms` |
| Page d'atterrissage (Landing page) | `/{slug}` ou `/lp/{slug}` | `/free-trial`, `/lp/webinar` |
| Comparatif | `/compare/{competitor}` ou `/vs/{competitor}` | `/compare/competitor-name` |
| Intégration | `/integrations/{name}` | `/integrations/slack` |
| Modèle (Template) | `/templates/{slug}` | `/templates/marketing-plan` |

### Erreurs courantes

- **Dates dans les URL de blog** — `/blog/2024/01/15/post-title` n'apporte aucune valeur et rallonge les URL. Utilisez `/blog/post-title`.
- **Imbrication excessive** — `/products/category/subcategory/item/detail` est trop profond. Aplatissez là où c'est possible.
- **Modifier des URL sans redirections** — Chaque ancienne URL nécessite une redirection 301 vers sa nouvelle URL. Sans cela, vous perdez le bénéfice des backlinks (autorité) et créez des pages d'erreur pour toute personne ayant mis l'ancienne URL en favori ou ayant créé un lien vers celle-ci.
- **Identifiants dans les URL** — `/product/12345` n'est pas lisible par un humain. Utilisez des slugs.
- **Paramètres de requête pour le contenu** — `/blog?id=123` devrait être `/blog/post-title`.
- **Modèles incohérents** — Ne mélangez pas `/features/analytics` et `/product/automation`. Choisissez un seul parent.

### Alignement fil d'Ariane - URL

Le fil d'Ariane doit refléter le chemin de l'URL :

| URL | Fil d'Ariane |
|-----|-------------|
| `/features/analytics` | Home > Features > Analytics |
| `/blog/seo-guide` | Home > Blog > SEO Guide |
| `/docs/api/auth` | Home > Docs > API > Authentication |

---

## Rendu visuel du plan de site (Mermaid)

Utilisez Mermaid `graph TD` pour les plans de site visuels. Cela clarifie les relations hiérarchiques et permet d'annoter les zones de navigation.

### Hiérarchie de base

```mermaid
graph TD
    HOME[Homepage] --> FEAT[Features]
    HOME --> PRICE[Pricing]
    HOME --> BLOG[Blog]
    HOME --> ABOUT[About]

    FEAT --> F1[Analytics]
    FEAT --> F2[Automation]
    FEAT --> F3[Integrations]

    BLOG --> B1[Post 1]
    BLOG --> B2[Post 2]
```

### Avec zones de navigation

```mermaid
graph TD
    subgraph Header Nav
        HOME[Homepage]
        FEAT[Features]
        PRICE[Pricing]
        BLOG[Blog]
        CTA[Get Started]
    end

    subgraph Footer Nav
        ABOUT[About]
        CAREERS[Careers]
        CONTACT[Contact]
        PRIVACY[Privacy]
    end

    HOME --> FEAT
    HOME --> PRICE
    HOME --> BLOG
    HOME --> ABOUT

    FEAT --> F1[Analytics]
    FEAT --> F2[Automation]
```

**Pour plus de modèles Mermaid** : Voir [references/mermaid-templates.md](references/mermaid-templates.md)

---

## Stratégie de maillage interne

### Types de liens

| Type | Objectif | Exemple |
|------|----------|---------|
| Navigationnel | Se déplacer entre les sections | Liens de header, footer, sidebar |
| Contextuel | Contenu connexe au sein du texte | « En savoir plus sur [l'analytique](/features/analytics) » |
| Hub-and-spoke (Pilier et déclinaisons) | Relier le contenu d'un cluster à la page pilier | Articles de blog pointant vers la page pilier |
| Transversal (Cross-section) | Relier des pages connexes entre différentes sections | Page fonctionnalité pointant vers une étude de cas associée |

### Règles de maillage interne

1. **Aucune page orpheline** — chaque page doit recevoir au moins un lien interne
2. **Texte d'ancrage descriptif** — « nos fonctionnalités d'analyse » et non « cliquez ici »
3. **5 à 10 liens internes pour 1000 mots** de contenu (ligne directrice indicative)
4. **Faites des liens plus fréquents vers les pages importantes** — page d'accueil, pages clés de fonctionnalités, tarifs
5. **Utilisez des fils d'Ariane** — des liens internes gratuits sur chaque page
6. **Sections de contenu connexe** — « Articles similaires » ou « Vous aimerez aussi » en bas de page

### Modèle Hub-and-Spoke

Pour les sites riches en contenu, organisez la structure autour de pages piliers (hubs) :

```
Hub: /blog/seo-guide (vue d'ensemble complète)
├── Spoke: /blog/keyword-research (renvoie vers le hub)
├── Spoke: /blog/on-page-seo (renvoie vers le hub)
├── Spoke: /blog/technical-seo (renvoie vers le hub)
└── Spoke: /blog/link-building (renvoie vers le hub)
```

Chaque contenu satellite (spoke) renvoie vers le hub. Le hub renvoie vers tous les spokes. Les spokes se lient entre eux lorsque c'est pertinent.

### Liste de contrôle pour l'audit des liens

- [ ] Chaque page a au moins un lien interne entrant
- [ ] Aucun lien interne cassé (erreurs 404)
- [ ] Le texte d'ancrage est descriptif (pas de « cliquez ici » ou « en savoir plus »)
- [ ] Les pages importantes ont le plus de liens internes entrants
- [ ] Les fils d'Ariane sont mis en place sur toutes les pages
- [ ] Des liens vers du contenu connexe sont présents sur les articles de blog
- [ ] Des liens transversaux relient les fonctionnalités aux études de cas, le blog aux pages produits

---

## Format de livrable

Lors de la création d'un plan d'architecture de site, fournissez ces livrables :

### 1. Hiérarchie des pages (arborescence ASCII)
Structure complète du site avec les URL à chaque nœud. Utilisez le format d'arborescence ASCII de la section Conception de la hiérarchie des pages.

### 2. Plan de site visuel (Mermaid)
Diagramme Mermaid illustrant les relations entre les pages et les zones de navigation. Utilisez `graph TD` avec des sous-graphes (subgraphs) pour les zones de navigation lorsque c'est utile.

### 3. Tableau de mappage des URL

| Page | URL | Parent | Emplacement dans la nav | Priorité |
|------|-----|--------|------------------------|----------|
| Homepage | `/` | — | Header | Haute |
| Features | `/features` | Homepage | Header | Haute |
| Analytics | `/features/analytics` | Features | Menu déroulant du header | Moyenne |
| Pricing | `/pricing` | Homepage | Header | Haute |
| Blog | `/blog` | Homepage | Header | Moyenne |

### 4. Spécification de la navigation
- Éléments de la nav d'en-tête (ordonnés, avec CTA)
- Sections et liens du pied de page
- Nav latérale (si applicable)
- Notes de mise en œuvre du fil d'Ariane

### 5. Plan de maillage interne
- Pages hubs et leurs spokes
- Opportunités de liens transversaux
- Audit des pages orphelines (en cas de restructuration)
- Liens recommandés par page clé

---

## Questions spécifiques à la tâche

1. S'agit-il d'un nouveau site ou restructurez-vous un site existant ?
2. De quel type de site s'agit-il ? (SaaS, contenu, e-commerce, docs, hybride, petite entreprise)
3. Combien de pages existent ou sont prévues ?
4. Quelles sont les 5 pages les plus importantes du site ?
5. Y a-t-il des URL existantes à préserver ou à rediriger ?
6. Quels sont les publics cibles principaux, et que cherchent-ils à accomplir sur le site ?

---

## Compétences associées

- **content-strategy** : Pour planifier le contenu à créer et les clusters thématiques
- **programmatic-seo** : Pour créer des pages SEO à grande échelle à l'aide de modèles et de données
- **seo-audit** : Pour le SEO technique, l'optimisation on-page et les problèmes d'indexation
- **cro** : Pour optimiser chaque page en vue de la conversion
- **schema** : Pour mettre en œuvre les données structurées de fil d'Ariane et de navigation de site
- **competitors** : Pour les structures de pages comparatives et les modèles d'URL
- **launch** : Pour le contrôle qualité de mise en ligne après une création ou une migration
