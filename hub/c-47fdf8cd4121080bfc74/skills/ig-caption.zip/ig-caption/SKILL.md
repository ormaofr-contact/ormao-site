---
name: ig-caption
description: >-
  Rédiger la légende Instagram — la ligne visible avant le bouton « ... plus »,
  le corps du texte, l'appel à l'action unique, les termes de recherche et les
  trois hashtags — et la vérifier avec le linter avant publication. À utiliser
  lorsque l'utilisateur dit « écris la légende », « légende ceci », « que
  mettre dans la description », a un reel ou un carrousel prêt et a besoin
  du texte, ou pose des questions sur les hashtags.
---

# ig-caption

Un seul outil se trouve dans ce dossier et s'exécute ainsi :

```bash
python3 caption.py caption.txt
python3 caption.py caption.txt --keywords "client proposals,agency pricing"
```

Il affiche la légende telle qu'elle apparaît dans le fil d'actualité : les 125 premiers caractères dans un encadré, tout le reste masqué derrière le clic. Lisez cet encadré avant de lire tout autre élément rédigé.

## D'abord, déterminer le rôle de cette légende

C'est la décision qui gâche les légendes lorsqu'elle est négligée.

**Rôle A : la vidéo a déjà capté l'attention.** Un Reel porte sa propre accroche dans les deux premières secondes, à l'oral et à l'écran. La légende n'est pas une seconde accroche, et entrer en concurrence avec la vidéo est le meilleur moyen de gâcher les deux. Son rôle est l'appel à l'action, le contexte qui lui donne du sens et les termes que les utilisateurs recherchent.

**Rôle B : la légende constitue le contenu.** Une photo, une seule image, une couverture de carrousel qui ouvre une boucle. Ici, la première ligne sert d'accroche et fonctionne exactement comme l'accroche d'un Reel : concrète, courte et coupée net avant la révélation plutôt qu'au milieu d'une phrase.

Demandez quel rôle vous devez rédiger. Si l'utilisateur dispose d'un Reel avec une accroche percutante, choisissez le rôle A et expliquez pourquoi.

## La structure

```
Line 1      125 characters of visible space. Job A: the ask, plainly.
            Job B: the hook.
            Never a greeting, never a hashtag, never an emoji as the first
            character.
Body        short paragraphs, one line of white space between each. Two to six
            of them. This is where the search terms live.
The ask     one. Comment a keyword, save it, or DM. One.
Hashtags    up to five, on their own line at the bottom, or none.
```

La limite est de 2 200 caractères et presque rien ne nécessite 2 200 caractères. Une légende qui incite au clic et délivre ensuite 600 caractères surpasse une légende qui en délivre 1 800.

## Les hashtags, en toute franchise

Les hashtags ne sont plus un levier de portée, et la plateforme l'a désormais confirmé par un changement de produit. **Instagram a limité les hashtags à cinq par publication le 18 décembre 2025**, contre trente auparavant, en indiquant aux créateurs qu'« utiliser moins de hashtags plus ciblés (jusqu'à 5), plutôt que de nombreux hashtags génériques » fonctionne mieux. Adam Mosseri avait déjà affirmé en février 2025 que les hashtags ne permettent pas d'augmenter la portée et sont une étiquette, pas un levier de distribution.

Donc : jusqu'à cinq, spécifiques, comme étiquettes thématiques. Si l'utilisateur en a un bloc de vingt enregistré dans son application de notes, ce bloc est désormais un poids mort et le linter le rejettera.

`#viral`, `#fyp`, `#explorepage`, `#foryou` ne décrivent rien. Supprimez-les.

## Les termes de recherche comptent désormais plus que les hashtags

La recherche Instagram lit le texte de la légende. Par conséquent, l'expression sur laquelle l'utilisateur souhaite être trouvé doit figurer dans la légende sous la forme d'une phrase qu'un humain taperait, au sein d'une phrase qui se lit naturellement. « Client proposals » en tant que mots à la ligne trois, et non « #clientproposals » dans un bloc tout en bas.

Demandez deux ou trois de ces termes, puis transmettez-les au linter :

```bash
python3 caption.py draft.txt --keywords "client proposals,agency pricing"
```

## Règles

- **Aucun lien dans la légende.** Les légendes ne sont pas cliquables. Une URL dans le corps du texte est un texte mort qui signifie « Je n'utilise pas cette plateforme ». En bio ou par DM.
- **Un seul appel à l'action.** Deux appels reviennent à n'en faire aucun. `caption.py` les compte.
- **L'appel à l'action par mot-clé nécessite un mot-clé facile à saisir.** Un seul mot, sans espace, sans emoji, et prononcez-le aussi à voix haute dans la vidéo. `Comment CONTRACT` fonctionne. `Comment "the contract guide"` ne fonctionne pas.
- **Rédigez le premier commentaire séparément** s'il y a un lien. Mentionnez-le dans le récapitulatif.
- **L'emoji comme ponctuation, pas comme décoration.** Le linter signale tout dépassement de 4 emojis pour 100 caractères.
- **Le texte alternatif vaut bien 20 secondes.** Pour les carrousels et les photos, rédigez-le. Il est lu par les lecteurs d'écran et par Instagram.

## La boucle

1. Choisissez le Rôle A ou le Rôle B et indiquez lequel.
2. Rédigez le brouillon.
3. Exécutez `/ig-human` dessus. Les légendes sont courtes, le contenu médiocre et artificiel s'y remarque donc bien plus qu'ailleurs dans le pack.
4. Exécutez `caption.py` avec les termes de recherche de l'utilisateur. Corrigez chaque FAIL. Tranchez sur chaque WARN explicitement plutôt qu'en silence.
5. Affichez le bloc prêt à copier, puis le récapitulatif :

```
CAPTION READY
job:        A - the reel carries the hook
visible:    118 of 125 characters used before the cut
ask:        one, comment CONTRACT
hashtags:   3
search:     "client proposals" in line 3, "agency pricing" in line 5
linter:     READY
```

Rien n'est publié automatiquement. L'utilisateur se charge de le coller.
