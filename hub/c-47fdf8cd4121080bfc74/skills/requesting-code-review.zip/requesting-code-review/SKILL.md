---
name: requesting-code-review
description: À utiliser lors de l'achèvement de tâches, de l'implémentation de fonctionnalités majeures ou avant de fusionner afin de vérifier que le travail répond aux exigences
---

# Demander une revue de code

Déléguez à un sous-agent de revue de code pour détecter les problèmes avant qu'ils ne fassent boule de neige. Le réviseur reçoit un contexte précisément préparé pour son évaluation — jamais l'historique de votre session.

**Principe fondamental :** Réviser tôt, réviser souvent.

## Quand demander une revue

**Obligatoire :**
- Après chaque tâche dans le développement piloté par sous-agents
- Après avoir terminé une fonctionnalité majeure
- Avant de fusionner vers main

**Optionnel mais précieux :**
- En cas de blocage (nouvelle perspective)
- Avant un refactoring (vérification du point de référence)
- Après avoir corrigé un bug complexe

## Comment demander

**1. Récupérer les SHA git :**
```bash
BASE_SHA=$(git rev-parse HEAD~1)  # or: git merge-base origin/main HEAD
HEAD_SHA=$(git rev-parse HEAD)
```

**2. Déléguer au sous-agent de revue de code :**

Déléguez à un sous-agent `general-purpose`, en remplissant le modèle situé dans [code-reviewer.md](code-reviewer.md)

**Paramètres de substitution :**
- `{DESCRIPTION}` - Résumé succinct de ce que vous avez développé
- `{PLAN_OR_REQUIREMENTS}` - Ce que cela doit faire
- `{BASE_SHA}` - Commit de départ
- `{HEAD_SHA}` - Commit de fin

**3. Traiter les retours :**
- Corrigez immédiatement les problèmes critiques (Critical)
- Corrigez les problèmes importants (Important) avant de continuer
- Notez les problèmes mineurs (Minor) pour plus tard
- Contre-argumentez si le réviseur se trompe (en argumentant)

## Exemple

```
[Just completed Task 2: Add verification function]

You: Let me request code review before proceeding.

BASE_SHA=$(git log --oneline | grep "Task 1" | head -1 | cut -d' ' -f1)
HEAD_SHA=$(git rev-parse HEAD)

[Dispatch code reviewer subagent]
  DESCRIPTION: Added verifyIndex() and repairIndex() with 4 issue types
  PLAN_OR_REQUIREMENTS: Task 2 from docs/superpowers/plans/deployment-plan.md
  BASE_SHA: a7981ec
  HEAD_SHA: 3df7661

[Subagent returns]:
  Strengths: Clean architecture, real tests
  Issues:
    Important: Missing progress indicators
    Minor: Magic number (100) for reporting interval
  Assessment: Ready to proceed

You: [Fix progress indicators]
[Continue to Task 3]
```

## Rationalisations fréquentes

| Excuse | Réalité |
|--------|---------|
| « Je vais simplement relire le diff moi-même au lieu de déléguer à un réviseur » | Vous êtes le coordinateur — relire le diff directement consomme la fenêtre de contexte dont vous avez besoin pour continuer à piloter le travail. Déléguez à un sous-agent réviseur : le diff et l'évaluation résident dans son contexte, et seuls les résultats vous sont retournés. |
| « Le réviseur a besoin de tout l'historique de ma session pour comprendre la modification » | Fournissez-lui un contexte précisément préparé, jamais l'historique de votre session. Cela permet au réviseur de se concentrer sur le livrable et non sur votre cheminement de pensée. |

## Signaux d'alerte

**Ne jamais :**
- Sauter la revue parce que « c'est simple »
- Ignorer les problèmes critiques (Critical)
- Continuer avec des problèmes importants (Important) non résolus
- Contester un retour technique valide

**Si le réviseur a tort :**
- Contre-argumentez avec des arguments techniques
- Montrez du code ou des tests qui prouvent que cela fonctionne
- Demandez des clarifications

Voir le modèle dans : [code-reviewer.md](code-reviewer.md)
