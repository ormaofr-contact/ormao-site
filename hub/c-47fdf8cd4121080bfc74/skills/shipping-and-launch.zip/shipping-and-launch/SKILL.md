---
name: shipping-and-launch
description: Prépare les lancements en production. À utiliser lors de la préparation d'un déploiement en production ou lorsqu'on demande ce qui doit être en place avant la mise en production. À utiliser pour une checklist pré-lancement, la mise en place du monitoring, la planification d'un déploiement progressif ou l'élaboration d'une stratégie de rollback.
---

# Déploiement et lancement

## Vue d'ensemble

Déployez en toute confiance. L'objectif n'est pas seulement de déployer — c'est de déployer en toute sécurité, avec un monitoring en place, un plan de rollback prêt et une vision claire de ce à quoi ressemble le succès. Chaque lancement doit être réversible, observable et incrémental.

## Quand l'utiliser

- Déploiement d'une fonctionnalité en production pour la première fois
- Publication d'une modification importante auprès des utilisateurs
- Migration de données ou d'infrastructure
- Ouverture d'une version bêta ou d'un programme d'accès anticipé
- Tout déploiement comportant des risques (c'est-à-dire tous)

## La checklist pré-lancement

### Qualité du code

- [ ] Tous les tests passent (unitaires, intégration, e2e)
- [ ] Le build réussit sans aucun avertissement
- [ ] Le linting et la vérification des types passent
- [ ] Code revu et approuvé
- [ ] Aucun commentaire TODO ne devant être résolu avant le lancement
- [ ] Aucune instruction de débogage `console.log` dans le code de production
- [ ] La gestion des erreurs couvre les modes de défaillance attendus

### Sécurité

- [ ] Aucun secret dans le code ou le contrôle de version
- [ ] L'audit des dépendances de l'écosystème (`npm audit`, `pip-audit`, `cargo audit`, ...) ne présente aucune vulnérabilité critique ou élevée
- [ ] Validation des entrées sur tous les endpoints exposés aux utilisateurs
- [ ] Vérifications d'authentification et d'autorisation en place
- [ ] En-têtes de sécurité configurés (CSP, HSTS, etc.)
- [ ] Limitation de débit (rate limiting) sur les endpoints d'authentification
- [ ] CORS configuré pour des origines spécifiques (pas de wildcard)

### Performance

- [ ] Core Web Vitals dans les seuils « Bons » (« Good »)
- [ ] Aucune requête N+1 sur les chemins critiques
- [ ] Images optimisées (compression, dimensions responsives, lazy loading)
- [ ] Taille du bundle conforme au budget alloué
- [ ] Les requêtes de base de données disposent des index appropriés
- [ ] Mise en cache configurée pour les ressources statiques et les requêtes répétées

### Accessibilité

- [ ] La navigation au clavier fonctionne pour tous les éléments interactifs
- [ ] Le lecteur d'écran peut transmettre le contenu et la structure de la page
- [ ] Le contraste des couleurs respecte les critères WCAG 2.1 AA (4,5:1 pour le texte)
- [ ] Gestion du focus correcte pour les modales et le contenu dynamique
- [ ] Les messages d'erreur sont descriptifs et associés aux champs de formulaire
- [ ] Aucun avertissement d'accessibilité dans axe-core ou Lighthouse

### Infrastructure

- [ ] Variables d'environnement définies en production
- [ ] Migrations de base de données appliquées (ou prêtes à être appliquées)
- [ ] DNS et SSL configurés
- [ ] CDN configuré pour les ressources statiques
- [ ] Journalisation (logging) et rapport d'erreurs configurés
- [ ] L'endpoint de health check existe et répond

### Documentation

- [ ] README mis à jour avec les éventuels nouveaux prérequis de configuration
- [ ] Documentation d'API à jour
- [ ] ADR rédigés pour toute décision d'architecture
- [ ] Changelog mis à jour
- [ ] Documentation destinée aux utilisateurs mise à jour (le cas échéant)

## Stratégie de Feature Flags

Déployez derrière des feature flags pour découpler le déploiement technique de la mise à disposition utilisateur :

```typescript
// Feature flag check
const flags = await getFeatureFlags(userId);

if (flags.taskSharing) {
  // New feature: task sharing
  return <TaskSharingPanel task={task} />;
}

// Default: existing behavior
return null;
```

**Cycle de vie d'un feature flag :**

```
1. DÉPLOYER avec le flag à OFF   → Le code est en production mais inactif
2. ACTIVER pour l'équipe/bêta   → Tests internes dans l'environnement de production
3. DÉPLOIEMENT PROGRESSIF       → 5 % → 25 % → 50 % → 100 % des utilisateurs
4. SURVEILLER à chaque étape    → Suivre les taux d'erreur, les performances, les retours utilisateurs
5. NETTOYER                     → Supprimer le flag et la branche de code obsolète après le déploiement complet
```

**Règles :**
- Chaque feature flag a un propriétaire et une date d'expiration
- Nettoyer les flags dans les 2 semaines suivant le déploiement complet
- Ne pas imbriquer les feature flags (cela crée des combinaisons exponentielles)
- Tester les deux états du flag (activé et désactivé) dans la CI

## Déploiement progressif

### La séquence de déploiement

```
1. DÉPLOYER en staging
   └── Suite de tests complète dans l'environnement de staging
   └── Test de fumée (smoke test) manuel des flux critiques

2. DÉPLOYER en production (feature flag à OFF)
   └── Vérifier que le déploiement a réussi (health check)
   └── Vérifier le monitoring des erreurs (aucune nouvelle erreur)

3. ACTIVER pour l'équipe (flag à ON pour les utilisateurs internes)
   └── L'équipe utilise la fonctionnalité en production
   └── Fenêtre d'observation de 24 heures

4. DÉPLOIEMENT CANARY (flag à ON pour 5 % des utilisateurs)
   └── Surveiller les taux d'erreur, la latence, le comportement des utilisateurs
   └── Comparer les métriques : canary vs référence (baseline)
   └── Fenêtre d'observation de 24 à 48 heures
   └── Ne progresser que si tous les seuils sont respectés (voir le tableau ci-dessous)

5. AUGMENTATION PROGRESSIVE (25 % -> 50 % -> 100 %)
   └── Même surveillance à chaque étape
   └── Possibilité de revenir au pourcentage précédent à tout moment

6. DÉPLOIEMENT COMPLET (flag à ON pour tous les utilisateurs)
   └── Surveiller pendant 1 semaine
   └── Nettoyer le feature flag
```

### Seuils de décision pour le déploiement

Utilisez ces seuils pour décider s'il faut avancer, mettre en pause ou effectuer un rollback à chaque étape :

| Métrique | Avancer (vert) | Mettre en pause et investiguer (jaune) | Faire un rollback (rouge) |
|--------|-----------------|-------------------------------|-----------------|
| Taux d'erreur | Dans les 10 % de la référence | 10 à 100 % au-dessus de la référence | > 2x la référence |
| Latence P95 | Dans les 20 % de la référence | 20 à 50 % au-dessus de la référence | > 50 % au-dessus de la référence |
| Erreurs JS côté client | Aucun nouveau type d'erreur | Nouvelles erreurs sur < 0,1 % des sessions | Nouvelles erreurs sur > 0,1 % des sessions |
| Métriques métier | Neutres ou positives | Baisse < 5 % (peut être du bruit) | Baisse > 5 % |

### Quand effectuer un rollback

Effectuer un rollback immédiat si :
- Le taux d'erreur augmente de plus de 2x par rapport à la référence
- La latence P95 augmente de plus de 50 %
- Les signalements de problèmes par les utilisateurs grimpent en flèche
- Des problèmes d'intégrité des données sont détectés
- Une vulnérabilité de sécurité est découverte

## Monitoring et observabilité

### Que surveiller

```
Métriques applicatives :
├── Taux d'erreur (total et par endpoint)
├── Temps de réponse (p50, p95, p99)
├── Volume de requêtes
├── Utilisateurs actifs
└── Métriques métier clés (conversion, engagement)

Métriques d'infrastructure :
├── Utilisation du CPU et de la mémoire
├── Utilisation du pool de connexions à la base de données
├── Espace disque
├── Latence réseau
└── Profondeur des files d'attente (le cas échéant)

Métriques client :
├── Core Web Vitals (LCP, INP, CLS)
├── Erreurs JavaScript
├── Taux d'erreur des API du point de vue client
└── Temps de chargement des pages
```

### Rapport d'erreurs

```typescript
// Set up error boundary with reporting
class ErrorBoundary extends React.Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Report to error tracking service
    reportError(error, {
      componentStack: info.componentStack,
      userId: getCurrentUser()?.id,
      page: window.location.pathname,
    });
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback onRetry={() => this.setState({ hasError: false })} />;
    }
    return this.props.children;
  }
}

// Server-side error reporting
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  reportError(err, {
    method: req.method,
    url: req.url,
    userId: req.user?.id,
  });

  // Don't expose internals to users
  res.status(500).json({
    error: { code: 'INTERNAL_ERROR', message: 'Something went wrong' },
  });
});
```

### Vérification post-lancement

Durant la première heure suivant le lancement :

```
1. Vérifier que l'endpoint de health check renvoie 200
2. Vérifier le tableau de bord de monitoring des erreurs (aucun nouveau type d'erreur)
3. Vérifier le tableau de bord de latence (aucune régression)
4. Tester manuellement le parcours utilisateur critique
5. Vérifier que les logs remontent et sont lisibles
6. Confirmer que le mécanisme de rollback fonctionne (simulation à blanc si possible)
```

## Porte de release liée au budget d'erreur

Le budget d'erreur de votre service — la proportion de requêtes ou de temps que votre SLO autorise à échouer — détermine s'il est sûr de déployer. Utilisez-le comme une porte d'évaluation objective — pas comme une négociation :

```
Budget restant > 20 %  →  Déployer normalement ; surveiller de près
Budget restant 0–20 %  →  Déploiements lents uniquement ; aucun changement à haut risque
Budget épuisé          →  Geler les fonctionnalités ; se concentrer entièrement sur la fiabilité
Budget réinitialisé    →  Reprendre le rythme normal ; intégrer le correctif qui l'a restauré
```

Un taux de consommation élevé (burn rate) pendant un canary (consommant le budget plus vite que le rythme de référence) est un signal de **mise en pause** dans le tableau des seuils de déploiement ci-dessus — traitez-le de la même manière qu'un taux d'erreur élevé.

## Stratégie de rollback

Chaque déploiement a besoin d'un plan de rollback avant son exécution :

```markdown
## Plan de rollback pour [Fonctionnalité/Release]

### Conditions de déclenchement
- Taux d'erreur > 2x la référence
- Latence P95 > [X]ms
- Signalements utilisateurs concernant [problème spécifique]

### Étapes de rollback
1. Désactiver le feature flag (le cas échéant)
   OU
1. Déployer la version précédente : `git revert <commit> && git push`
2. Vérifier le rollback : health check, monitoring des erreurs
3. Communiquer : avertir l'équipe du rollback

### Considérations relatives à la base de données
- La migration [X] dispose d'un rollback : <commande vérifiée ou lien vers le runbook>
- Données insérées par la nouvelle fonctionnalité : [conservées / nettoyées]

### Temps nécessaire pour le rollback
- Feature flag : < 1 minute
- Redéploiement de la version précédente : < 5 minutes
- Rollback de la base de données : < 15 minutes
```
## Voir aussi

- Pour la Définition de Terminé (Definition of Done) globale du projet que chaque modification doit valider avant cette checklist, voir `../../references/definition-of-done.md`
- Pour les vérifications de sécurité pré-lancement, voir `../../references/security-checklist.md`
- Pour la checklist de performance pré-lancement, voir `../../references/performance-checklist.md`
- Pour la vérification de l'accessibilité avant le lancement, voir `../../references/accessibility-checklist.md`
- Pour les règles d'alerte et les seuils liés aux SLO, voir `observability-and-instrumentation`

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « Ça fonctionne en staging, ça fonctionnera en production » | La production présente des données, des schémas de trafic et des cas limites différents. Surveillez après le déploiement. |
| « Nous n'avons pas besoin de feature flags pour ça » | Chaque fonctionnalité bénéficie d'un mécanisme d'arrêt d'urgence (kill switch). Même les modifications « simples » peuvent casser des choses. |
| « Le monitoring représente une surcharge inutile » | Ne pas avoir de monitoring signifie que vous découvrirez les problèmes via les plaintes des utilisateurs plutôt que par vos tableaux de bord. |
| « Nous ajouterons le monitoring plus tard » | Ajoutez-le avant le lancement. Vous ne pouvez pas déboguer ce que vous ne pouvez pas voir. |
| « Faire un rollback, c'est admettre un échec » | Faire un rollback relève d'une ingénierie responsable. Livrer une fonctionnalité défaillante est le véritable échec. |
| « Le taux d'erreur semble correct, continuons à déployer » | Vérifiez le burn rate, pas seulement le taux d'erreur actuel. Consommer le budget plus vite que la référence est un signal de mise en pause, même si les seuils individuels sont au vert. |

## Signaux d'alerte

- Déployer sans plan de rollback
- Aucun monitoring ni rapport d'erreurs en production
- Déploiements « big-bang » (tout en une seule fois, sans staging)
- Feature flags sans date d'expiration ni propriétaire
- Personne pour surveiller le déploiement pendant la première heure
- Configuration de l'environnement de production faite de mémoire, et non par du code
- « On est vendredi après-midi, déployons ça »
- Budget d'erreur épuisé mais les développements de fonctionnalités continuent sans changement

## Vérification

Avant de déployer :

- [ ] Checklist pré-lancement complétée (toutes les sections au vert)
- [ ] Feature flag configuré (le cas échéant)
- [ ] Plan de rollback documenté
- [ ] Tableaux de bord de monitoring configurés
- [ ] Équipe informée du déploiement

Après le déploiement :

- [ ] Le health check renvoie 200
- [ ] Le taux d'erreur est normal
- [ ] La latence est normale
- [ ] Le flux utilisateur critique fonctionne
- [ ] Les logs remontent correctement
- [ ] Rollback testé ou vérifié comme prêt

Pour chaque service déployé :

- [ ] Politique de budget d'erreur en place : savoir quelles mesures prendre lorsque le budget descend sous 20 % et lorsqu'il est épuisé
