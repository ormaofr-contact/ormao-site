---
name: li-audit
description: >-
  Post-mortem sur ce que l'utilisateur a déjà publié : quels posts ont
  réellement fonctionné, pourquoi, et ce qu'il faut arrêter de faire. À utiliser
  lorsque l'utilisateur colle ses statistiques LinkedIn ou ses anciens posts et
  demande « qu'est-ce qui fonctionne », « pourquoi ce post a fait un bide »,
  « analyse mes statistiques », « audite mon contenu », ou souhaite savoir sur
  quoi redoubler d'efforts.
---

# li-audit

La seule source honnête pour savoir ce qui fonctionne pour un compte, c'est ce
compte lui-même. Chaque règle dans chaque guide LinkedIn, y compris ceux de ce
pack, n'est qu'une hypothèse de départ. Les 30 derniers posts de l'utilisateur
constituent les véritables preuves.

## Entrée

Demandez ce que l'utilisateur a sous la main :

- L'export analytique des posts (LinkedIn : Statistiques -> Contenu -> Exporter). CSV.
- Ou une capture d'écran par post avec impressions, réactions, commentaires,
  repartages.
- Ou simplement les posts et leur nombre de réactions, ce qui suffit pour une
  première passe.

Lisez également `~/.claude/linkedin/log.md` s'il existe, car il enregistre la
formule d'accroche utilisée pour chaque post.

## Ce qu'il faut réellement mesurer

Les impressions brutes sont le chiffre le moins utile de la page, car elles
dépendent principalement du nombre de personnes qui suivent déjà l'utilisateur.
Calculez plutôt ces indicateurs, et montrez le calcul :

| métrique | calcul | ce qu'elle indique |
| --- | --- | --- |
| **Engagement rate** | (réactions + commentaires + repartages) / impressions | si le post a mérité sa portée |
| **Comment ratio** | commentaires / réactions | s'il a lancé une discussion ou simplement obtenu un signe de tête |
| **Reach multiple** | impressions / nombre d'abonnés | s'il s'est diffusé au-delà de l'audience existante |
| **Save/send rate** | si disponible | le prédicteur individuel le plus fort de la portée future |

Classez par taux d'engagement et multiple de portée, pas par impressions. Un
post avec 900 impressions et 40 commentaires l'emporte sur celui à 12 000
impressions et 6 commentaires.

## Ensuite, identifier le schéma

Avec le top 5 et le flop 5 côte à côte, cherchez ce qui les sépare réellement,
et soyez prêt à formuler une conclusion qui ne plaira peut-être pas à
l'utilisateur :

- Formule d'accroche. Quels numéros de `hooks.json` figurent dans le top 5 ?
- Format. Texte, document, image, vidéo.
- Longueur.
- Thématique.
- Jour et heure — vérifiez cela en **dernier**, et uniquement si les quatre
  autres facteurs ne révèlent rien. Ce n'est presque jamais la cause, alors
  que c'est là que les gens veulent la trouver.
- Commentaires de la première heure. Posts auxquels l'utilisateur a répondu
  en moins d'une heure par rapport à ceux délaissés.

Formulez la conclusion sous forme d'affirmation appuyée par les preuves, et
indiquez votre niveau de confiance. Avec 30 posts, vous pouvez déceler un
schéma ; avec 6, c'est impossible, et vous devriez le préciser plutôt que d'en
inventer un.

## Sortie

```
AUDIT  ·  31 posts  ·  Jun 12 - Sep 5

TOP 5 BY ENGAGEMENT RATE
  8.1%  #3  Mistake      "$18,000 is what no contract cost me"      1,940 imp
  6.4%  #20 Walk-Away    "I fired my highest-paying client"         2,210 imp
  ...

BOTTOM 5
  0.4%  #5  List         "7 tools every founder needs"             11,400 imp
  ...

WHAT THE DATA SAYS
1. Posts where you were the one who looked bad: mean 6.2% vs 1.1% for
   everything else. n=6. This is your strongest signal and it is not close.
2. Tool listicles get impressions and nothing else. High reach, no comments,
   no leads. Three of your bottom five.
3. Day of week shows nothing. Your Tuesday mean and your Friday mean are
   inside the noise. Stop optimising it.

STOP: listicles about tools.
DO MORE: the ones with a cost you paid, and a number.
```

Transmettez ensuite les conclusions à `/li-plan` pour que le planning de la
semaine prochaine s'appuie sur les données concrètes de l'utilisateur plutôt
que sur des valeurs par défaut.
