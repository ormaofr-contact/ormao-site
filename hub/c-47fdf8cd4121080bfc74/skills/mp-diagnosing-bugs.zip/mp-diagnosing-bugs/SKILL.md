---
name: diagnosing-bugs
description: Boucle de diagnostic pour les bugs complexes et les régressions de performance. À utiliser lorsque l'utilisateur dit « diagnostique »/« débogue ceci », ou signale un dysfonctionnement, une exception, un échec ou une lenteur.
---

# Diagnostic des bugs

Une discipline pour les bugs difficiles. Ne sautez des phases que si c'est explicitement justifié.

Lors de l'exploration de la base de code, lisez `GLOSSARY.md` (s'il existe) pour vous forger un modèle mental clair des modules concernés, et consultez les ADR dans le domaine que vous touchez.

## Masquage des données sensibles (Redact)

Cette compétence vous amène à afficher des commandes, des sorties et des artefacts capturés. **Masquez d'abord chaque secret** : écrivez `<REDACTED>` à sa place. Construisez des boucles s'appuyant sur des variables d'environnement, afin que les identifiants restent dans l'environnement plutôt que dans ce que vous affichez. Les artefacts capturés contiennent des en-têtes d'authentification : ne citez que les lignes porteuses de signal.

Si la sortie masquée ne suffit pas à diagnostiquer le bug, signalez-le et demandez à l'utilisateur.

## Phase 1 : Construire une boucle de rétroaction

**C'est le cœur de la compétence.** Tout le reste est mécanique. Si vous disposez d'un signal de réussite/échec **serré** pour le bug (qui passe au rouge sur _ce_ bug précis), vous en trouverez la cause ; la dichotomie, les tests d'hypothèses et l'instrumentation ne font que s'appuyer dessus. Si vous n'en avez pas, passer des heures à scruter le code ne vous sauvera pas.

Consacrez-y un effort disproportionné. **Soyez agressif. Soyez créatif. Refusez d'abandonner.**

### Façons d'en construire une, à peu près dans cet ordre

1. **Test en échec** au point de jonction (seam) qui atteint le bug : unitaire, intégration, e2e.
2. **Script curl / HTTP** ciblant un serveur de développement en cours d'exécution.
3. **Appel CLI** avec une entrée de test (fixture), en comparant le diff de stdout par rapport à un instantané de référence valide.
4. **Script de navigateur headless** (Playwright / Puppeteer) pilotant l'interface utilisateur et vérifiant le DOM/la console/le réseau.
5. **Rejouer une trace capturée.** Enregistrer une véritable requête réseau / charge utile (payload) / journal d'événements sur le disque ; le rejouer à travers le chemin de code de manière isolée.
6. **Harnais jetable.** Démarrer un sous-ensemble minimal du système (un service, dépendances mockées) qui sollicite le chemin de code du bug avec un simple appel de fonction.
7. **Boucle basée sur les propriétés / fuzzing.** Si le bug est « résultat parfois incorrect », injecter 1 000 entrées aléatoires et guetter le mode d'échec.
8. **Harnais de dichotomie (bisection).** Si le bug est apparu entre deux états connus (commit, jeu de données, version), automatiser « démarrer à l'état X, vérifier, répéter » afin de pouvoir exécuter `git bisect run`.
9. **Boucle différentielle.** Passer la même entrée dans l'ancienne version par rapport à la nouvelle (ou entre deux configurations) et comparer les sorties.
10. **Script bash HITL (Human In The Loop).** Dernier recours. Si un humain doit cliquer, guidez-_le_ avec `scripts/hitl-loop.template.sh` afin que la boucle reste structurée. Les sorties capturées vous sont renvoyées.

Construisez la bonne boucle de rétroaction, et le bug est résolu à 90 %.

### Resserrez la boucle

Traitez la boucle comme un produit. Dès que vous avez _une_ boucle, **resserrez-la** :

- Puis-je la rendre plus rapide ? (Mettre en cache la configuration, ignorer les initialisations superflues, restreindre la portée du test.)
- Puis-je rendre le signal plus net ? (Faire une assertion sur le symptôme précis, pas seulement « n'a pas planté ».)
- Puis-je la rendre plus déterministe ? (Figer l'heure, initialiser la graine RNG, isoler le système de fichiers, geler le réseau.)

Une boucle instable (flaky) de 30 secondes ne vaut guère mieux que pas de boucle du tout ; une boucle déterministe de 2 secondes est serrée, c'est un véritable superpouvoir de débogage.

### Bugs non déterministes

L'objectif n'est pas une reproduction propre, mais un **taux de reproduction plus élevé**. Répétez le déclencheur 100 fois, parallélisez, ajoutez de la charge, réduisez les fenêtres temporelles, injectez des pauses (sleeps). Un bug instable à 50 % est débogable ; à 1 %, il ne l'est pas. Continuez donc à augmenter le taux jusqu'à ce qu'il devienne débogable.

### Quand vous ne pouvez vraiment pas construire de boucle

Arrêtez-vous et dites-le explicitement. Listez ce que vous avez essayé. Demandez à l'utilisateur : (a) l'accès à l'environnement qui reproduit le problème, (b) un artefact capturé et anonymisé (fichier HAR, dump de logs, core dump, enregistrement d'écran avec horodatage), ou (c) l'autorisation d'ajouter une instrumentation temporaire en production. Ne formulez **pas** d'hypothèses sans boucle.

### Critère d'achèvement : une boucle serrée qui passe au rouge

La phase 1 est terminée lorsque la boucle est **serrée** et **capable de passer au rouge** : vous pouvez nommer **une seule commande** (un chemin de script, une invocation de test, un curl) que vous avez **déjà exécutée au moins une fois** (montrez la commande et son résultat, masqué), et qui est :

- [ ] **Capable de passer au rouge (Red-capable)** : elle exécute le chemin de code réel du bug et valide le **symptôme exact de l'utilisateur**, de sorte qu'elle passe au rouge sur ce bug et au vert une fois résolu. Pas seulement « s'exécute sans erreur » ; elle doit être capable de _détecter ce bug spécifique_.
- [ ] **Déterministe** : même résultat à chaque exécution (bugs instables : un taux de reproduction élevé et stabilisé, comme indiqué ci-dessus).
- [ ] **Rapide** : quelques secondes, pas des minutes.
- [ ] **Exécutable par un agent** : vous pouvez l'exécuter de façon autonome ; une intervention humaine n'intervient que via `scripts/hitl-loop.template.sh`.

Si vous vous surprenez à lire du code pour élaborer une théorie avant que cette commande n'existe, **arrêtez-vous : sauter directement à une hypothèse est précisément l'erreur que cette compétence vise à empêcher.** Pas de commande capable de passer au rouge, pas de phase 2.

## Phase 2 : Reproduire + minimiser

Exécutez la boucle. Observez-la passer au rouge lorsque le bug apparaît.

Confirmez :

- [ ] La boucle produit le mode d'échec décrit par l'**utilisateur**, et non un échec différent situé par hasard à proximité. Mauvais bug = mauvaise correction.
- [ ] L'échec est reproductible sur plusieurs exécutions (ou, pour les bugs non déterministes, reproductible à un taux suffisamment élevé pour pouvoir être débogué).
- [ ] Vous avez capturé le symptôme exact (message d'erreur, résultat incorrect, lenteur temporelle) afin que les phases ultérieures puissent vérifier que le correctif résout effectivement le problème.

### Minimiser

Dès qu'elle est au rouge, réduisez la reproduction au **scénario le plus restreint qui reste toujours rouge**. Supprimez les entrées, les appelants, la configuration, les données et les étapes **un par un**, en réexécutant la boucle après chaque coupe, et ne conservez que ce qui est porteur (load-bearing) pour l'échec.

Pourquoi s'en préoccuper : une reproduction minimale réduit l'espace des hypothèses en phase 3 (moins de composants mobiles à suspecter) et devient le test de non-régression propre en phase 5.

Terminé lorsque **chaque élément restant est porteur** : en retirer un seul fait repasser la boucle au vert.

Ne poursuivez pas tant que vous n'avez pas reproduit **et** minimisé.

## Phase 3 : Émettre des hypothèses

Générez **3 à 5 hypothèses classées par priorité** avant d'en tester la moindre. Ne formuler qu'une seule hypothèse vous ancre sur la première idée plausible.

Chaque hypothèse doit être **falsifiable** : formulez la prédiction qu'elle implique.

> Format : « Si <X> est la cause, alors <modifier Y> fera disparaître le bug / <modifier Z> l'aggravera. »

Si vous ne pouvez pas formuler la prédiction, l'hypothèse n'est qu'une intuition vague : écartez-la ou affinez-la.

**Présentez la liste ordonnée à l'utilisateur avant d'effectuer les tests.** Il possède souvent des connaissances métier qui permettent de réordonner instantanément la liste (« nous venons de déployer un changement sur le n°3 ») ou connaît des hypothèses qu'il a déjà écartées. C'est un point de contrôle peu coûteux et un gain de temps considérable. Ne restez pas bloqué dessus ; poursuivez avec votre classement si l'utilisateur est absent.

## Phase 4 : Instrumenter

Chaque sonde doit correspondre à une prédiction spécifique de la phase 3. **Ne modifiez qu'une variable à la fois.**

Préférence d'outils :

1. **Inspection via débogueur / REPL** si l'environnement le permet. Un point d'arrêt vaut mieux que dix logs.
2. **Logs ciblés** aux frontières qui permettent de départager les hypothèses.
3. Jamais de « tout logger et faire un grep ».

**Étiquetez chaque log de débogage** avec un préfixe unique, ex. `[DEBUG-a4f2]`. Le nettoyage final se résume à un simple `grep`. Les logs non étiquetés survivent ; les logs étiquetés sont éliminés.

**Branche performance.** Pour les régressions de performance, les logs sont généralement inadaptés. À la place : établissez une mesure de référence (harnais de mesure de temps, `performance.now()`, profileur, plan d'exécution de requête), puis procédez par dichotomie. Mesurez d'abord, corrigez ensuite.

## Phase 5 : Correction + test de non-régression

Rédigez le test de non-régression **avant la correction**, mais uniquement s'il existe un **point de jonction (seam) adéquat** pour cela.

Un point de jonction adéquat est un point où le test reproduit le **véritable schéma du bug** tel qu'il se produit au point d'appel. Si le seul point de jonction disponible est trop superficiel (test à appelant unique alors que le bug nécessite plusieurs appelants, test unitaire incapable de reproduire la chaîne ayant déclenché le bug), un test de non-régression à cet endroit donne une fausse impression de confiance.

**S'il n'existe aucun point de jonction adéquat, cela constitue en soi le constat.** Notez-le. L'architecture de la base de code empêche de verrouiller le bug. Signalez-le pour la phase suivante.

S'il existe un point de jonction adéquat :

1. Transformez la reproduction minimisée en un test qui échoue à ce point de jonction.
2. Observez-le échouer. Si vous avez forcé l'échec en modifiant le code ou une fixture, faites un `diff` avec une copie intacte pour prouver que la modification a bien pris effet avant de lui faire confiance.
3. Appliquez le correctif.
4. Observez-le réussir.
5. Réexécutez la boucle de rétroaction de la phase 1 sur le scénario d'origine (non minimisé).

## Phase 6 : Nettoyage

Obligatoire avant de déclarer la tâche terminée :

- [ ] La reproduction originale ne se reproduit plus (réexécutez la boucle de la phase 1)
- [ ] Le test de non-régression réussit (ou l'absence de point de jonction est documentée)
- [ ] Toute l'instrumentation `[DEBUG-...]` est supprimée (`grep` sur le préfixe)
- [ ] Les prototypes jetables sont supprimés (ou déplacés vers un emplacement de débogage clairement identifié)
- [ ] L'hypothèse qui s'est avérée exacte est expliquée dans le message de commit / de PR, afin d'instruire le prochain débogueur
