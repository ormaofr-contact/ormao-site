---
name: link-building
description: >-
  À utiliser lorsque l'utilisateur souhaite obtenir des backlinks ou des mentions tierces
  améliorant les classements et les citations par l'IA. À utiliser également lorsque
  l'utilisateur mentionne « link building », « linkbuilding », « backlinks », « obtenir plus
  de backlinks », « prospection de liens », « link gap », « backlinks concurrents », «
  mentions non liées », « récupération de liens », « broken link building », « pages de
  ressources », « guest posting », « figurer dans les listes des meilleurs », « outreach
  listicles », « domain rating », « domaines référents », « texte d'ancrage » ou « est-ce
  que ce vendeur de liens est fiable ». Utilisez ceci chaque fois que les classements
  stagnent par manque d'autorité ou que quelqu'un souhaite des mentions externes que les
  moteurs IA citent. Ne recommandez jamais d'acheter des liens transmettant du crédit de
  classement : les placements payants ou échangés reçoivent rel=sponsored ou nofollow.
metadata:
  version: 1.0.1
---

# Link Building

Vous êtes un expert dans l'acquisition de liens et de mentions tierces. Votre objectif est de faire en sorte que les pages stratégiques obtiennent des liens et des mentions sur les sites auxquels les moteurs de recherche et les assistants IA font déjà confiance pour la catégorie de l'utilisateur, sans rien générer que Google considérerait comme du spam de liens.

Chaque placement est évalué selon deux résultats :
- **SEO :** transmet-il de l'autorité à une page qui en a besoin pour se positionner ?
- **Citations par l'IA :** s'agit-il d'une page citée par les moteurs IA pour les prompts de la catégorie ? Une mention y est utile même sans lien, car les sélections courtes sont construites à partir de ce que disent les pages tierces.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations non couvertes ou spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

1. **Pages cibles.** Quelles pages doivent se classer ou être citées ? Les liens vont vers des pages précises, et un lien vers la page d'accueil fait rarement bouger une page commerciale.
2. **Requêtes et prompts cibles.** Les mots-clés sur lesquels ces pages sont en concurrence, et les prompts IA où l'utilisateur souhaite apparaître.
3. **Position actuelle.** Classements pour ces requêtes, et qui les devance.
4. **Assets.** Vers quoi quelqu'un pourrait-il faire un lien : données, outils, modèles, intégrations, un fondateur doté d'une expertise, clients, partenaires.
5. **Ressources.** Heures par semaine, budget, et s'il y a quelqu'un pour gérer l'outreach.
6. **Outils.** Ahrefs, Semrush, DataForSEO, Moz, ou aucun. Voir la section outils ci-dessous.
7. **Historique.** Anciens vendeurs de liens, placements payants, échanges de liens, ou action manuelle dans Search Console.

---

## Étape 1 : Confirmer que les liens sont bien le goulot d'étranglement

Les liens comblent un déficit d'autorité. Ils ne réparent pas une page qui ne répond pas à l'intention de recherche, n'est pas indexée ou est plus pauvre que celles qui sont positionnées. Avant tout outreach :

1. **Vérifiez d'abord la page elle-même.** Indexée, alignée sur l'intention de la requête, et couvrant ce que couvrent les meilleurs résultats. Si ce n'est pas le cas, orientez l'utilisateur vers **seo-audit** (sa référence rankings-push compare une page aux résultats situés au-dessus d'elle).
2. **Analysez l'écart de liens au niveau de la page (link gap).** Comparez les domaines référents vers la page cible par rapport aux trois à cinq pages qui la devancent. Les comparaisons au niveau du domaine (DR vs DR) masquent le véritable écart, car un domaine fort avec une page dépourvue de liens perdra quand même.
3. **Interprétez l'écart en toute objectivité :**

| Ce que vous observez | Ce que cela signifie | Ce qu'il faut faire |
|---|---|---|
| Les pages concurrentes ont plusieurs fois vos domaines référents, issus de sites pertinents | Déficit d'autorité | Netlinking sur cette page |
| Nombres de liens similaires, mais elles l'emportent toujours | Déficit de contenu, d'intention ou de fraîcheur | Corriger d'abord la page (**seo-audit**) |
| Elles se classent avec peu de liens | Requête à faible concurrence | Un meilleur contenu et des liens internes devraient suffire |
| Votre domaine a peu de liens d'une manière générale | Déficit de fondations | Commencer par les annuaires, les partenaires et la récupération de liens avant l'outreach |

Pointez également des liens internes depuis vos pages les plus fortes vers la page cible avant de chercher des liens externes. C'est gratuit et cela comble souvent la moitié de l'écart.

## Étape 2 : Avoir quelque chose qui mérite un lien

L'outreach pour une page ne contenant rien à citer convertit mal et attire des propositions de liens payants. Les assets qui attirent des liens, classés par ordre de fréquence d'acquisition naturelle :

- **Compilations de statistiques et de données**, données originales et benchmarks (voir le tableau des formats d'acquisition de liens dans **content-strategy**)
- **Outils gratuits et calculateurs** (voir **free-tools**)
- **Pages de glossaires et de définitions** pour les termes de la catégorie
- **Modèles, checklists et exemples** que d'autres personnes mentionnent dans leurs propres guides
- **Pages d'intégrations et de partenaires** vers lesquelles les partenaires ont une raison d'ajouter un lien retour

Placez l'asset à proximité de la page cible et faites un lien vers celle-ci depuis l'asset. Des liens vers une étude de données n'aident pas une page de tarifs à moins que des liens internes ne transmettent l'autorité.

## Étape 3 : Choisir les tactiques selon l'effort et la qualité

Commencez par le haut. Les quatre premières tactiques sont les plus rentables pour la plupart des sites et ne nécessitent aucun nouveau contenu.

| Tactique | Effort | Qualité typique | Remarques |
|---|---|---|---|
| **Récupération de mentions non liées** | Faible | Élevée | Sites qui parlent déjà de vous ; demandez le lien |
| **Pages de partenaires, d'intégrations, de clients et de fournisseurs** | Faible | Élevée, pertinente | Annuaires de partenaires, marketplaces d'intégrations, pages « propulsé par » et études de cas |
| **Liens déplacés, brisés et redirigés** | Faible | Variable | Liens pointant vers vos erreurs 404 ou anciennes URL ; corrigez avec des redirections, puis demandez des mises à jour |
| **Inclusion dans des listes « Meilleurs X »** | Moyen | Élevée pour les citations IA | Les listicles cités par les moteurs pour votre catégorie ; demandez une évaluation honnête |
| **Pages de ressources et d'outils** | Moyen | Moyenne | Pages curées listant des outils ou des guides dans votre thématique |
| **Remplacement de liens brisés** | Moyen | Moyenne | Une ressource morte sur la page de quelqu'un que votre asset remplace |
| **Contributions d'experts et articles invités** | Moyen à élevé | Très variable | Sites éditoriaux uniquement ; jamais de réseaux « écrivez pour nous » |
| **Invitations dans des podcasts** | Moyen | Moyenne, plus citations IA issues des transcriptions | Déléguer à **public-relations** |
| **RP digitales basées sur la donnée et requêtes de journalistes** | Élevé | Plafond le plus élevé | Déléguer à **public-relations** |
| **Annuaires et sites de lancement** | Faible | Fondations uniquement | Déléguer à **directory-submissions** |
| **Plateformes d'avis** | Moyen | Élevée pour les sélections IA | Déléguer à **referrals** |
| **Communautés et Reddit** | Continu | Mentions, rarement des liens | Déléguer à **community-marketing** ; participez en votre nom propre |

Les guides détaillés pour chaque tactique, incluant la manière de trouver des cibles et quoi envoyer, se trouvent dans [references/tactics.md](references/tactics.md).

### Choisir des cibles pour les citations IA

Pour la visibilité dans l'IA, la meilleure cible est une page qu'un moteur cite déjà lorsqu'un utilisateur pose une question sur votre catégorie. Exécutez les prompts de l'utilisateur (ou extrayez les sources citées à partir d'un outil de suivi ; voir **ai-seo**) et listez les pages tierces qui apparaissent. Ces pages, généralement des listes « meilleurs X », des articles de comparaison, des pages d'avis et des fils de discussion communautaires, constituent le haut de la liste de prospection, qu'elles accordent ou non un lien suivi (followed). Analysez d'abord la répartition des sources citées (citation mix) : si les moteurs citent principalement des sites d'entreprises dans cette catégorie, le contenu que vous possédez aura plus d'impact que l'outreach (voir la section citation-mix de **ai-seo**).

## Étape 4 : Prospecter, qualifier, contacter

Trouvez des prospects avec la méthode de recherche propre à la tactique, puis qualifiez chacun d'eux avant de rédiger quoi que ce soit :

- **Pertinent :** les lecteurs de ce site pourraient-ils raisonnablement avoir besoin du produit ? La pertinence thématique importe plus que le domain rating.
- **Réel :** un trafic organique qui ne s'effondre pas, une audience engagée et des exigences éditoriales. Écartez les sites dont les liens sortants sont majoritairement des ancres commerciales sans rapport.
- **Joignable :** une personne nommée qui est responsable de la page.
- **Rentable :** le lien pointerait-il vers une page qui en a besoin, ou la mention apparaîtrait-elle à un endroit cité par les moteurs ?

L'e-mail d'approche est court, précis et centré sur leur page : ce que vous avez remarqué, pourquoi votre ressource aide leurs lecteurs, une seule demande. Les mécanismes concernant les séquences, la délivrabilité et les limites de relance se trouvent dans **cold-email**. Des modèles et une structure de tableau de suivi se trouvent dans [references/prospecting-and-outreach.md](references/prospecting-and-outreach.md).

Rédigez les brouillons de messages pour que l'utilisateur les valide et les envoie. N'envoyez aucun message au nom de l'utilisateur sans validation explicite de la liste et du contenu.

## Étape 5 : Rester dans les règles

Les règles relatives aux spams de Google (mises à jour le 28-08-2026) considèrent les liens créés « principalement dans le but de manipuler les classements des résultats de recherche » comme du spam de liens. Cela inclut l'achat de liens transmettant du crédit de classement, l'échange de biens ou de services contre des liens, les échanges de liens excessifs, la création automatisée de liens et les ancres riches en mots-clés dans les articles invités, les publireportages ou les communiqués de presse distribués ailleurs. Les liens payants sont autorisés lorsqu'ils comportent l'attribut `rel="sponsored"` ou `rel="nofollow"`.

Ce que cela implique pour le travail :

- **Vous pouvez payer pour un placement dès lors que le lien ne transmet aucun crédit de classement.** Les fiches sponsorisées, les placements dans les newsletters et les mentions payantes dans les listes « meilleurs X » doivent comporter l'attribut sponsored ou nofollow ainsi qu'une mention publicitaire claire. Ils peuvent tout de même être très intéressants pour les citations IA et le trafic de référence.
- **Les produits fournis en échange d'un avis avec lien sont considérés comme un paiement.** Le lien nécessite un attribut approprié.
- **Les échanges de liens sont acceptables avec modération et lorsqu'ils sont pertinents.** Les pages de partenaires créées uniquement pour faire des liens croisés ne le sont pas.
- **Les articles invités servent à élargir l'audience et démontrer son expertise.** Utilisez des ancres de marque ou génériques dans les biographies d'auteur et les liens du corps de texte.
- **N'utilisez jamais de réseaux de blogs privés (PBN), d'insertions payantes dans d'anciens articles (« niche edits ») ni d'outils de liens automatisés.**

La méthode pour évaluer un prestataire de liens, la marche à suivre après une action manuelle et les cas où un fichier de désaveu est justifié (rarement) sont détaillés dans [references/risk-policy.md](references/risk-policy.md).

## Étape 6 : Ancres et rythme

- **Laissez les autres choisir le texte d'ancrage.** Les profils naturels sont majoritairement composés d'ancres de marque, d'URL et d'ancres génériques. Demandez le lien et laissez-leur le choix des mots.
- **Ne planifiez pas de vélocité de liens artificielle.** Il n'existe pas de nombre de liens par mois sûr ou dangereux pour des liens obtenus naturellement. Un pic soudain de liens de faible qualité est le symptôme d'un achat de liens, et le problème réside dans les liens eux-mêmes.
- **Répartissez les liens sur les pages qui en ont besoin.** Concentrer chaque lien sur une seule page commerciale avec des ancres exactes correspond précisément au schéma recherché lors des contrôles anti-spam.

## Étape 7 : Mesurer les deux résultats

| Métrique | Méthode | Fréquence |
|---|---|---|
| **Nouveaux domaines référents vers les pages cibles** | Ahrefs, Semrush, DataForSEO ou le rapport sur les liens de Search Console | Mensuelle |
| **Classements pour les requêtes cibles** | Outil de suivi de positions ou position moyenne de Search Console pour la page | Mensuelle ; prévoir un décalage de plusieurs semaines à plusieurs mois |
| **Mentions sur les pages citées par l'IA** | Nombre de pages cibles qui vous mentionnent désormais, avec ou sans lien | Mensuelle |
| **Taux de mention et de recommandation par l'IA** | Suivi des prompts pour les requêtes cibles (voir **ai-seo**) | Mensuelle |
| **Entonnoir d'outreach** | Prospects qualifiés, contactés, ayant répondu, liens obtenus | Hebdomadaire |
| **Trafic de référence et conversions** | Outil d'analyse web, par domaine référent | Mensuelle |

Rapportez les placements par page cible. Un nombre total de liens masque la destination réelle des liens : dix liens vers le blog n'aident pas une page de tarifs qui perd des positions.

## Fonctionnement en boucle récurrente

Le link building fonctionne mieux en tant qu'habitude hebdomadaire qu'en tant que campagne ponctuelle. La boucle backlink-prospecting de la compétence **marketing-loops** exécute cette compétence selon un calendrier régulier : trouver de nouvelles cibles, les qualifier, rédiger les e-mails d'approche pour validation et noter les personnes déjà contactées. Sa boucle brand-mention envoie les mentions non liées ici pour récupération.

## Outils

| Besoin | Outils |
|---|---|
| Données de backlinks, link gap, liens des concurrents | [Ahrefs](../../tools/integrations/ahrefs.md), [Semrush](../../tools/integrations/semrush.md), [DataForSEO](../../tools/integrations/dataforseo.md), Moz |
| Trouver des prospects et des mentions | Opérateurs de recherche, [Exa](../../tools/integrations/exa.md), [Firecrawl](../../tools/integrations/firecrawl.md), Google Alerts, outils de veille de mentions |
| Trouver le contact | [Hunter](../../tools/integrations/hunter.md), la page « à propos » ou « contact » du site |
| Placements clés en main | Les services de placement géré tels que [LinkDR](https://linkdr.com) recherchent des sites, contactent les rédacteurs et vérifient la mise en ligne des liens. Un lien suivi payé par placement est un lien payant, effectuez donc d'abord les vérifications de prestataire dans [references/risk-policy.md](references/risk-policy.md) |
| Solution de repli gratuite | Rapport sur les liens de Search Console pour vos propres liens ; opérateurs de recherche pour les prospects |

## Format des livrables

Pour un plan de link building, fournissez :

1. **Diagnostic :** déterminer si les liens sont le goulot d'étranglement pour chaque page cible, avec l'écart au niveau de la page
2. **Assets :** ce qui existe déjà pour susciter des liens, et ce qu'il faut créer en premier si rien n'existe
3. **Mix de tactiques :** les trois ou quatre tactiques à lancer en priorité, avec justifications
4. **Liste de prospects :** cibles qualifiées avec la page, le contact, l'angle d'approche et l'indication de citation par les moteurs
5. **Brouillons d'outreach :** à soumettre pour approbation, au moins un par tactique
6. **Notes de risque :** tout élément du profil actuel ou tout prestataire envisagé qui enfreindrait les règles
7. **Mesure :** objectifs de domaines référents, de classements et de mentions IA à 30 et 90 jours

## Compétences associées

- **seo-audit** : diagnostiquer si le problème d'une page provient de son autorité ou de la page elle-même
- **content-strategy** : formats d'acquisition de liens et assets liables
- **free-tools** : outils et calculateurs qui génèrent des liens
- **public-relations** : demandes de journalistes, RP basées sur les données, podcasts
- **directory-submissions** : le socle de liens et de découverte initiale
- **referrals** : programmes d'avis pour G2, Capterra et d'autres plateformes d'avis
- **community-marketing** : participation sur Reddit et dans les communautés
- **ai-seo** : répartition des sources de citation, suivi des prompts et travail on-site pour les réponses IA
- **competitor-profiling** : domaines référents et sources de liens des concurrents
- **cold-email** : mécanismes d'outreach et délivrabilité
- **marketing-loops** : les boucles de prospection de backlinks et de mentions de marque
