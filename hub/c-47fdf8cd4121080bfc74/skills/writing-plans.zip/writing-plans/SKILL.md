---
name: writing-plans
description: À utiliser lorsque vous disposez d'une spécification ou d'exigences pour une tâche en plusieurs étapes, avant de toucher au code
---

# Rédaction de plans

## Aperçu

Rédigez des plans de mise en œuvre pour un ingénieur qui n'a jamais vu cette base de code ni cette spécification. Partez du principe qu'il écrira du code idiomatique dans le langage du projet une fois qu'il connaîtra l'interface exacte et le test exact, et qu'il fera un choix raisonnable partout où le plan en laisse un ouvert. Ce qu'il ne peut pas savoir, c'est ce que vous avez décidé : quels fichiers, quels noms et signatures, quelles valeurs issues de la spécification, quels tests prouvent chaque tâche. Documentez ces éléments. Donnez-lui l'ensemble du plan sous forme de tâches de taille réduite. DRY. YAGNI. TDD. Commits fréquents.

**Annoncez au début :** « J'utilise la compétence writing-plans pour créer le plan de mise en œuvre. »

**Contexte :** Si vous travaillez dans un worktree isolé, il aurait dû être créé via la compétence `superpowers:using-git-worktrees` au moment de l'exécution.

**Enregistrer les plans sous :** `docs/superpowers/plans/YYYY-MM-DD-<feature-name>.md`
- (Les préférences de l'utilisateur pour l'emplacement des plans prévalent sur cette valeur par défaut)

## Vérification de la portée

Si la spécification couvre plusieurs sous-systèmes indépendants, elle aurait dû être découpée en spécifications de sous-projets lors du brainstorming. Si ce n'est pas le cas, suggérez de diviser cela en plans distincts — un par sous-système. Chaque plan doit produire un logiciel fonctionnel et testable de manière autonome.

## Structure des fichiers

Avant de définir les tâches, cartographiez les fichiers qui seront créés ou modifiés et la responsabilité de chacun. C'est à ce stade que les décisions de décomposition sont fixées.

- Concevez des unités aux limites claires et aux interfaces bien définies. Chaque fichier doit avoir une responsabilité unique et claire.
- Vous raisonnez mieux sur du code que vous pouvez appréhender d'un seul coup dans son contexte, et vos modifications sont plus fiables lorsque les fichiers sont ciblés. Privilégiez des fichiers plus petits et focalisés plutôt que des fichiers volumineux qui en font trop.
- Les fichiers qui changent ensemble doivent cohabiter. Découpez par responsabilité, pas par couche technique.
- Dans les bases de code existantes, suivez les conventions établies. Si la base de code utilise de gros fichiers, ne la restructurez pas unilatéralement — mais si un fichier que vous modifiez est devenu difficile à gérer, inclure une séparation dans le plan est raisonnable.

Cette structure oriente la décomposition des tâches. Chaque tâche doit produire des modifications autonomes et cohérentes de manière indépendante.

## Dimensionnement adéquat des tâches

Une tâche est la plus petite unité qui comporte son propre cycle de tests et qui justifie une étape de révision dédiée. Pour définir les limites des tâches : regroupez les étapes d'installation, de configuration, d'échafaudage et de documentation dans la tâche dont le livrable en a besoin ; ne divisez que lorsqu'un réviseur pourrait valablement rejeter une tâche tout en approuvant la suivante. Chaque tâche se termine par un livrable testable de manière indépendante.

## Granularité des étapes

**Chaque étape est une action unique avec un résultat vérifiable :**
- « Écrire le test qui échoue » - étape
- « L'exécuter pour s'assurer qu'il échoue » - étape
- « Implémenter le code minimal pour faire passer le test » - étape
- « Exécuter les tests et s'assurer qu'ils passent » - étape
- « Commiter » - étape

## En-tête du document de plan

**Chaque plan DOIT commencer par cet en-tête :**

```markdown
# Plan de mise en œuvre de [Nom de la fonctionnalité]

> **Pour les agents de travail :** SOUS-COMPÉTENCE REQUISE : Utilisez superpowers:subagent-driven-development (recommandé) ou superpowers:executing-plans pour implémenter ce plan tâche par tâche. Les étapes utilisent la syntaxe de case à cocher (`- [ ]`) pour le suivi.

**Objectif :** [Une phrase décrivant ce qui est construit]

**Architecture :** [2 à 3 phrases sur l'approche]

**Stack technique :** [Technologies/bibliothèques clés]

**Spécification :** [chemin vers la spécification/document de conception que ce plan met en œuvre — le plan s'appuie sur la spécification, donc la spécification l'accompagne ; les exécutants lisent les deux]

## Contraintes globales

[Les exigences de la spécification à l'échelle du projet — versions minimales, limites de dépendances, règles de nommage et de rédaction, exigences de plateforme — une ligne chacune, avec les valeurs exactes recopiées textuellement depuis la spécification. Les exigences de chaque tâche incluent implicitement cette section.]

## Points d'attention pour la revue

[Les cinq classes d'entrées ou modes de défaillance que la spécification sous-entend mais qu'aucun test de tâche n'exerce, qui sont les plus susceptibles de poser problème à un utilisateur de ce logiciel — une ligne chacun, nommant l'entrée ou la condition et le comportement qu'une personne raisonnable attendrait, le plus probable en premier. La spécification est un document de vision : elle dit ce que le logiciel doit faire, pas tout ce à quoi il sera confronté, et son silence sur une entrée n'autorise pas cette entrée à faire planter le programme. Rédigez la liste ici, une seule fois, avec la spécification sous les yeux. Ensuite, pour chaque ligne, ajoutez le test qui la verrouille à la tâche propriétaire du code, dans le style d'étape propre à cette tâche.]

---
```

## Structure des tâches

````markdown
### Tâche N : [Nom du composant]

**Fichiers :**
- Créer : `exact/path/to/file.py`
- Modifier : `exact/path/to/existing.py:123-145`
- Tester : `tests/exact/path/to/test.py`

**Interfaces :**
- Consomme : [ce que cette tâche utilise des tâches précédentes — signatures exactes]
- Produit : [ce sur quoi les tâches ultérieures s'appuient — noms exacts des fonctions, types des paramètres et de retour. L'implémenteur d'une tâche ne voit que sa propre tâche ; ce bloc est la manière dont il découvre les noms et les types utilisés par les tâches voisines.]

- [ ] **Étape 1 : Écrire le test qui échoue**

```python
def test_specific_behavior():
    result = function(input)
    assert result == expected
```

- [ ] **Étape 2 : Exécuter le test pour vérifier qu'il échoue**

Exécuter : `pytest tests/path/test.py::test_name -v`
Attendu : ÉCHEC avec "function not defined"

- [ ] **Étape 3 : Implémenter `function(input: InputType) -> ResultType` dans `exact/path/to/file.py`**

Une ligne sur l'approche lorsque la signature et le test laissent un choix (quel appel de bibliothèque, quelle structure de données) ; un bloc de code uniquement pour un algorithme qu'ils ne déterminent pas.

- [ ] **Étape 4 : Exécuter le test pour vérifier qu'il réussit**

Exécuter : `pytest tests/path/test.py::test_name -v`
Attendu : SUCCÈS

- [ ] **Étape 5 : Commiter**

```bash
git add tests/path/test.py src/path/file.py
git commit -m "feat: add specific feature"
```
````

## Ce qu'une étape contient

Une étape est terminée lorsque l'implémenteur peut écrire exactement une seule chose raisonnable à partir d'elle. C'est l'exigence globale : sans ambiguïté, pas exhaustif. Chaque type d'étape apporte ce qui la rend sans ambiguïté et rien de plus :

- **Une étape de test :** le nom du test et ses assertions, sous forme de code, avec les valeurs exactes de la spécification.
- **Une étape de code :** la signature exacte (nom, paramètres, type de retour), le fichier dans lequel elle se trouve, et les valeurs spécifiques fixées par la spécification. L'implémenteur écrit le corps. Un corps n'apparaît que pour un algorithme que la signature et les tests ne déterminent pas, ou pour un texte exact fixé par la spécification.
- **Une étape de vérification :** la commande à exécuter et la sortie qui indique qu'elle a réussi.
- **Une référence à une autre tâche :** le bloc Interfaces de cette tâche indique ce qu'il faut utiliser ; le plan ne répète pas le code de cette tâche.

Un plan est l'ensemble des décisions que l'implémenteur ne peut pas prendre seul. Un plan plus long que le code qu'il décrit a écrit le code à sa place. Les lignes qui ne décident rien (« À déterminer », « gérer les cas limites », « ajouter la validation appropriée », « écrire les tests pour ce qui précède », un type ou une fonction qu'aucune tâche ne définit) constituent l'écueil inverse, et l'auto-révision permet d'intercepter les deux.

## Auto-révision

Après avoir rédigé le plan complet, examinez la spécification avec un œil neuf et confrontez le plan à celle-ci. Il s'agit d'une liste de contrôle que vous appliquez vous-même — sans solliciter de sous-agent.

**1. Couverture de la spécification :** Parcourez chaque section/exigence de la spécification. Pouvez-vous pointer vers une tâche qui la met en œuvre ? Listez les éventuelles lacunes.

**2. Balayage des étapes :** Chaque étape doit permettre à l'implémenteur d'écrire exactement une chose raisonnable, et aucune étape ne doit en contenir plus : une ligne qui ne décide de rien est une lacune, un corps de fonction que la signature et les tests déterminent déjà est une retranscription superflue. Corrigez les deux.

**3. Cohérence des types :** Les types, signatures de méthodes et noms de propriétés utilisés dans les tâches ultérieures correspondent-ils à ce que vous avez défini dans les tâches précédentes ? Une fonction appelée `clearLayers()` dans la Tâche 3 mais `clearFullLayers()` dans la Tâche 7 est un bug.

**4. Points d'attention pour la revue :** Pour chaque classe d'entrées ou mode de défaillance que la spécification implique, existe-t-il une tâche dont les tests l'exercent ? Les cinq éléments non couverts les plus susceptibles de causer des torts à un utilisateur vont dans la section Points d'attention pour la revue, et chaque ligne s'y voit attribuer son test ajouté à la tâche propriétaire. Une section vide signifie que vous avez vérifié et n'en avez trouvé aucun, non pas que vous avez sauté la vérification.

**5. Proportion :** Comparez la longueur du plan à celle de la spécification. Un plan plusieurs fois plus long que la spécification qu'il met en œuvre est une retranscription intégrale du programme, pas un plan. Si les blocs de code occupent la majeure partie du document, remplacez les corps par des signatures, des noms de tests et des assertions, puis vérifiez que chaque étape demeure sans ambiguïté.

Si vous constatez des problèmes, corrigez-les directement. Nul besoin de refaire une revue complète — corrigez simplement et avancez. Si vous trouvez une exigence de spécification sans tâche associée, ajoutez la tâche.

## Passage de relais pour l'exécution

Après avoir enregistré et auto-révisé le plan, partagez son lien pour que votre partenaire humain puisse le lire. S'il a déjà explicitement spécifié une méthode d'exécution, demandez-lui d'examiner le plan et de confirmer qu'il correspond bien à ce qu'il souhaite ; attendez cette validation avant l'implémentation, puis appliquez la méthode convenue. Sinon, demandez-lui d'examiner le plan et de choisir une méthode d'exécution avant l'implémentation.

**Lorsqu'aucune méthode d'exécution n'a encore été fournie :**

**« Plan terminé et enregistré sous `docs/superpowers/plans/<filename>.md`. Veuillez examiner le plan. Quelle approche d'exécution préférez-vous ?**

- **Pilotée par sous-agents (Subagent-driven)** - Un nouveau sous-agent implémente chaque tâche et un réviseur dédié la vérifie avant que la suivante ne commence, suivi d'une revue globale de la branche à la fin. La plus rigoureuse ; coûte un nouveau contexte par tâche et par revue.
- **Native** - J'implémente moi-même chaque tâche dans cette session, selon le fonctionnement de cet environnement d'exécution, puis un réviseur dédié utilisant le modèle le plus performant vérifie toute la branche. La plus économique et la plus rapide ; pas de revue indépendante avant la fin. Fonctionne bien avec un modèle de session intermédiaire, puisque le plan porte la conception.

**Pour ce plan, je recommande <l'une des deux>, car <une phrase issue du plan : dépendance des interfaces des tâches entre elles, nombre de tâches, coût d'une erreur en production>. Le plan correspond-il à ce que vous souhaitez, et quelle approche devons-nous adopter ? »**

**Lorsqu'une méthode d'exécution a déjà été fournie :**

**« Plan terminé et enregistré sous `docs/superpowers/plans/<filename>.md`. Veuillez examiner le plan. Correspond-il à ce que vous souhaitez ? »**

**Si Pilotée par sous-agents est choisie :**
- **SOUS-COMPÉTENCE REQUISE :** Utilisez superpowers:subagent-driven-development

**Si Native est choisie :**
- **SOUS-COMPÉTENCE REQUISE :** Utilisez superpowers:executing-plans
