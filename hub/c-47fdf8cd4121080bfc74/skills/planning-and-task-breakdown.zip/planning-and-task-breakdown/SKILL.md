---
name: planning-and-task-breakdown
description: Découpe le travail en tâches ordonnées. À utiliser lorsque vous disposez d'une spécification ou d'exigences claires et devez découper le travail en tâches réalisables. À utiliser lorsqu'une tâche semble trop vaste pour démarrer, lorsqu'il faut estimer le périmètre, ou lorsqu'un travail parallèle est possible.
---

# Planification et découpage des tâches

## Vue d'ensemble

Décomposez le travail en petites tâches vérifiables avec des critères d'acceptation explicites. Un bon découpage des tâches fait toute la différence entre un agent qui accomplit son travail de manière fiable et un agent qui produit un désordre inextricable. Chaque tâche doit être suffisamment petite pour être implémentée, testée et vérifiée au cours d'une seule session ciblée.

## Quand l'utiliser

- Vous disposez d'une spécification et devez la découper en unités réalisables
- Une tâche semble trop vaste ou trop vague pour démarrer
- Le travail doit être parallélisé entre plusieurs agents ou sessions
- Vous devez communiquer le périmètre à un humain
- L'ordre d'implémentation n'est pas évident

**Quand NE PAS l'utiliser :** Modifications d'un seul fichier avec un périmètre évident, ou lorsque la spécification contient déjà des tâches bien définies.

## Le processus de planification

### Étape 1 : Passer en mode Plan

Avant d'écrire le moindre code, opérez en mode lecture seule :

- Lisez la spécification et les sections pertinentes du codebase
- Identifiez les conventions et les patterns existants
- Cartographiez les dépendances entre les composants
- Notez les risques et les inconnues

**N'écrivez AUCUN code pendant la planification.** La sortie attendue est un document de plan enregistré dans `tasks/plan.md` et une liste de tâches consignée dans la cible de liste de tâches (voir Fichiers de sortie ; par défaut `tasks/todo.md`), et non une implémentation.

### Étape 2 : Identifier le graphe de dépendances

Cartographiez ce qui dépend de quoi :

```
Database schema
    │
    ├── API models/types
    │       │
    │       ├── API endpoints
    │       │       │
    │       │       └── Frontend API client
    │       │               │
    │       │               └── UI components
    │       │
    │       └── Validation logic
    │
    └── Seed data / migrations
```

L'ordre d'implémentation suit le graphe de dépendances de bas en haut : construisez d'abord les fondations.

### Étape 3 : Découper verticalement

Au lieu de construire toute la base de données, puis toute l'API, puis toute l'interface utilisateur — construisez un parcours de fonctionnalité complet à la fois :

**Mauvais (découpage horizontal) :**
```
Task 1: Build entire database schema
Task 2: Build all API endpoints
Task 3: Build all UI components
Task 4: Connect everything
```

**Bon (découpage vertical) :**
```
Task 1: User can create an account (schema + API + UI for registration)
Task 2: User can log in (auth schema + API + UI for login)
Task 3: User can create a task (task schema + API + UI for creation)
Task 4: User can view task list (query + API + UI for list view)
```

Chaque tranche verticale fournit une fonctionnalité opérationnelle et testable.

### Étape 4 : Rédiger les tâches

Chaque tâche suit cette structure, qu'elle soit consignée dans la liste de tâches en markdown ou sous forme d'élément dans un outil de suivi externe (voir Fichiers de sortie) :

```markdown
## Task [N]: [Short descriptive title]

**Description:** One paragraph explaining what this task accomplishes.

**Acceptance criteria:**
- [ ] [Specific, testable condition]
- [ ] [Specific, testable condition]

**Verification:**
- [ ] Tests pass: [the repository's focused-test command]
- [ ] Build succeeds: [the repository's build command]
- [ ] Manual check: [description of what to verify]

**Dependencies:** [Task numbers this depends on, or "None"]

**Files likely touched:**
- `src/path/to/file.ts`
- `tests/path/to/test.ts`

**Estimated scope:** [Small: 1-2 files | Medium: 3-5 files | Large: 5+ files]
```

### Étape 5 : Ordonner et définir des points de contrôle

Organisez les tâches de manière à ce que :

1. Les dépendances soient satisfaites (construire la fondation en premier)
2. Chaque tâche laisse le système dans un état fonctionnel
3. Des points de contrôle de vérification aient lieu toutes les 2 ou 3 tâches
4. Les tâches à haut risque soient traitées tôt (échouer rapidement)

Ajoutez des points de contrôle explicites à la cible de liste de tâches :

```markdown
## Checkpoint: After Tasks 1-3
- [ ] All tests pass
- [ ] Application builds without errors
- [ ] Core user flow works end-to-end
- [ ] Review with human before proceeding
```

## Directives de dimensionnement des tâches

| Taille | Fichiers | Périmètre | Exemple |
|---|---|---|---|
| **XS** | 1 | Fonction unique ou modification de configuration | Ajouter une règle de validation |
| **S** | 1-2 | Un composant ou un endpoint | Ajouter un nouvel endpoint d'API |
| **M** | 3-5 | Une tranche de fonctionnalité | Flux d'inscription d'un utilisateur |
| **L** | 5-8 | Fonctionnalité multi-composants | Recherche avec filtrage et pagination |
| **XL** | 8+ | **Trop grand — à découper davantage** | — |

Si une tâche est de taille L ou supérieure, elle doit être découpée en tâches plus petites. Un agent est plus performant sur des tâches S et M.

**Quand découper une tâche davantage :**
- Elle nécessiterait plus d'une session ciblée (environ plus de 2 heures de travail d'agent)
- Vous ne pouvez pas décrire les critères d'acceptation en 3 puces ou moins
- Elle touche au moins deux sous-systèmes indépendants (par exemple, authentification et facturation)
- Vous vous surprenez à écrire « et » dans le titre de la tâche (le signe qu'il s'agit de deux tâches)

## Fichiers de sortie

- **Document de plan :** Enregistrez le plan d'implémentation dans `tasks/plan.md`. Il s'agit toujours d'un fichier markdown — les décisions de conception, les risques et les questions ouvertes ne se retranscrivent pas proprement dans des tickets individuels d'un outil de suivi.
- **Liste de tâches :** Consignez chaque tâche dans la **cible de liste de tâches** (définie ci-dessous).

Créez le répertoire `tasks/` s'il n'existe pas.

**N'écrasez jamais un plan incomplet.** Avant d'écrire dans `tasks/plan.md` ou `tasks/todo.md`, vérifiez s'ils existent déjà et contiennent encore des tâches non cochées :

- Même travail en cours de replanification (l'utilisateur a demandé de réviser ou d'étendre ce plan) → mettez à jour les fichiers existants sur place.
- Travail différent → **arrêtez-vous et demandez.** Les tâches non cochées sont peut-être en cours de réalisation dans une autre session. Ne supprimez pas, n'écrasez pas et ne renommez pas les fichiers existants de votre propre chef ; présentez le conflit et laissez l'utilisateur décider (terminer l'ancien plan d'abord, l'abandonner explicitement, ou vous indiquer où le nouveau plan doit aller).

La même règle s'applique à une cible de liste de tâches externe : ne fermez jamais en masse et ne supprimez jamais les tickets ouverts d'un autre plan pour faire de la place aux nouveaux.

### Cible de la liste de tâches

La cible de liste de tâches est l'endroit où les tâches et les points de contrôle sont consignés. Elle est définie une seule fois, ici ; toute autre référence dans cette compétence s'y réfère.

- **Par défaut : un fichier markdown sous forme de checklist dans `tasks/todo.md`.** C'est la convention attendue par la commande `/build` et les autres outils en aval. Utilisez-la sauf indication contraire du projet.
- **Outil de suivi externe :** si les règles d'agent du projet (`CLAUDE.md`, `AGENTS.md`, etc.) ou l'utilisateur désignent un outil de suivi de tickets (ex. GitHub Issues, Jira, Linear, `bd`/beads), créez un ticket par tâche au lieu d'écrire dans `tasks/todo.md`. Faites correspondre la structure de l'Étape 4 avec les champs de l'outil : critères d'acceptation et étapes de vérification dans le corps du ticket, dépendances via le mécanisme de liaison de l'outil (`bd dep add`, « blocked by », etc.). Enregistrez également les points de contrôle de l'Étape 5 sous forme de tickets, ou sous forme de checklist dans le document de plan si l'outil n'a pas d'équivalent naturel.

Lors de l'utilisation d'un outil de suivi externe, notez-le dans `tasks/plan.md` (par exemple « Tâches suivies dans le projet Linear FOO ») pour que les étapes en aval et les futures sessions sachent où chercher, et conservez la section Liste de tâches du document de plan comme un index ordonné d'identifiants ou de liens vers les tickets, plutôt que comme une checklist en double.

## Modèle de document de plan

```markdown
# Implementation Plan: [Feature/Project Name]

## Overview
[One paragraph summary of what we're building]

## Architecture Decisions
- [Key decision 1 and rationale]
- [Key decision 2 and rationale]

## Task List

### Phase 1: Foundation
- [ ] Task 1: ...
- [ ] Task 2: ...

### Checkpoint: Foundation
- [ ] Tests pass, builds clean

### Phase 2: Core Features
- [ ] Task 3: ...
- [ ] Task 4: ...

### Checkpoint: Core Features
- [ ] End-to-end flow works

### Phase 3: Polish
- [ ] Task 5: ...
- [ ] Task 6: ...

### Checkpoint: Complete
- [ ] All acceptance criteria met
- [ ] Ready for review

## Risks and Mitigations
| Risk | Impact | Mitigation |
|------|--------|------------|
| [Risk] | [High/Med/Low] | [Strategy] |

## Open Questions
- [Question needing human input]
```

Lorsque les tâches résident dans un outil de suivi externe, conservez la section Liste de tâches ci-dessus comme un index ordonné d'identifiants ou de liens vers les tickets plutôt que comme une checklist en double.

## Opportunités de parallélisation

Lorsque plusieurs agents ou sessions sont disponibles :

- **Parallélisation sans risque :** Tranches de fonctionnalités indépendantes, tests pour les fonctionnalités déjà implémentées, documentation
- **Doit être séquentiel :** Migrations de base de données, modifications d'état partagé, chaînes de dépendances
- **Nécessite une coordination :** Fonctionnalités qui partagent un contrat d'API (définir d'abord le contrat, puis paralléliser)

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « Je trouverai au fur et à mesure » | C'est ainsi que l'on se retrouve avec un désordre inextricable et du travail à refaire. 10 minutes de planification permettent d'économiser des heures. |
| « Les tâches sont évidentes » | Écrivez-les quand même. Des tâches explicites font émerger des dépendances cachées et des cas limites oubliés. |
| « La planification est une perte de temps » | La planification EST la tâche. Implémenter sans plan n'est que de la frappe au clavier. |
| « Je peux tout garder en tête » | Les fenêtres de contexte sont limitées. Les plans écrits survivent aux coupures de session et au compactage de contexte. |
| « L'ancien `tasks/plan.md` est obsolète, je vais simplement le remplacer » | Les tâches non cochées sont peut-être en cours d'implémentation dans une autre session. Les écraser détruit un état de travail qui n'existe nulle part ailleurs. Arrêtez-vous et demandez. |

## Signaux d'alerte

- Démarrer l'implémentation sans liste de tâches écrite
- Écraser un `tasks/plan.md` ou `tasks/todo.md` qui contient encore des tâches non cochées pour un travail différent, sans demander
- Écrire dans `tasks/todo.md` lorsque le projet a désigné un outil de suivi externe (ou disperser les tâches entre les deux)
- Tâches qui indiquent « implémenter la fonctionnalité » sans critères d'acceptation
- Aucune étape de vérification dans le plan
- Toutes les tâches sont de taille XL
- Aucun point de contrôle entre les tâches
- L'ordre des dépendances n'est pas pris en compte

## Vérification

Avant de démarrer l'implémentation, confirmez :

- [ ] Chaque tâche dispose de critères d'acceptation
- [ ] Chaque tâche dispose d'une étape de vérification
- [ ] Les dépendances des tâches sont identifiées et ordonnées correctement
- [ ] Les tâches sont consignées dans la cible de liste de tâches (par défaut `tasks/todo.md`)
- [ ] Aucun plan incomplet préexistant n'a été écrasé sans confirmation explicite de l'utilisateur
- [ ] Aucune tâche ne touche plus d'environ 5 fichiers
- [ ] Des points de contrôle existent entre les phases majeures
- [ ] L'humain a examiné et approuvé le plan

## Voir aussi

Les critères d'acceptation s'appliquent à chaque tâche et répondent à la question « avons-nous construit ce qu'il fallait ? ». Ils s'ajoutent à la Définition de Terminé (Definition of Done) applicable à l'ensemble du projet, qui constitue le standard permanent que chaque tâche doit respecter avant d'être considérée comme terminée. Voir `../../references/definition-of-done.md`.
