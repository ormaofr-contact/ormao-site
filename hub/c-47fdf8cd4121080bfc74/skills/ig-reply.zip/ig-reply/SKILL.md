---
name: ig-reply
description: >-
  Gérer les commentaires sous les reels et publications de l'utilisateur - rédiger des réponses à
  ceux qui en valent la peine, triés par ordre de pertinence. À utiliser lorsque l'utilisateur colle
  ses commentaires, dit "réponds à ça", "gère mes commentaires", "quelqu'un a dit X
  sur mon reel", ou a affaire à un détracteur, un hater ou un prospect dans les commentaires.
---

# ig-reply

C'est dans l'espace commentaire sous votre propre publication que la portée se décide. Chaque
réponse est une interaction supplémentaire sur le post, les réponses envoyées durant la première
heure font l'essentiel du travail, et sur Instagram, une réponse peut aussi être un Reel, ce qui est
l'opportunité la plus sous-exploitée de la plateforme.

Cependant, la valeur varie grandement d'un commentaire à l'autre : cette compétence effectue donc
un tri avant de rédiger.

## Entrée

L'utilisateur colle les commentaires, idéalement avec les pseudos (@handle). Les captures d'écran
sont acceptées. Ne scrapez pas le fil à l'aide d'un outil de navigation (browser tool).

## Trier d'abord

Classez chaque commentaire dans l'une des six catégories et annoncez les décomptes à voix haute :

| catégorie | ce que c'est | ce qu'il reçoit |
| --- | --- | --- |
| **KEYWORD** | le mot-clé que vous avez demandé d'écrire en commentaire | la ressource promise, envoyée manuellement ou par votre outil validé |
| **LEAD** | quelqu'un décrivant le problème que vous résolvez | une vraie réponse publique, puis une porte ouverte |
| **SUBSTANCE** | apporte des données, exprime un désaccord, prolonge la réflexion | la réponse la plus longue du fil |
| **QUESTION** | une question que beaucoup de gens se posent | celle-ci devient un Reel, pas seulement une réponse texte |
| **SUPPORT** | "🔥", "super post", une mention d'ami | un like, et entre 3 et 8 mots au maximum |
| **NOISE** | démarchage, spam, mauvaise foi, appât à clic | rien, ou une seule ligne sans relance |

Rédigez dans cet ordre et arrêtez-vous dès qu'il n'y a plus de valeur ajoutée.

## Le geste que la plupart des gens manquent

Si une question dans les commentaires est partagée par une trentaine d'autres personnes,
**répondez-y avec un Reel**. Instagram épinglera le commentaire sur la nouvelle vidéo sous forme
d'autocollant, l'auteur de la question recevra une notification, et une question bénéficiant d'une
réelle demande devient un post dont l'accroche est déjà rédigée pour vous. Signalez chaque QUESTION
éligible et transmettez-la à `/ig-reel` sous la formule #16.

## Comment répondre

- **Répondez à la vraie question posée.** Si quelqu'un demande comment faire, expliquez-lui
  comment, directement dans la réponse. Ne le renvoyez pas vers les messages privés (DM) pour
  obtenir une réponse qu'il aurait pu lire ici.
- **Utilisez son prénom ou pseudo une seule fois**, au début, sans point d'exclamation.
- **Adaptez votre longueur à la sienne.** Un commentaire de quatre mots ne mérite pas une réponse
  de quatre lignes.
- **Face à un détracteur :** concédez d'abord la part de vérité, avec ses propres mots, puis
  maintenez votre position. Ne supprimez jamais, ne devenez jamais défensif, ne répondez jamais
  deux fois sur le même fil.
- **Face à un hater :** rien. Une réponse génère de la portée, et c'est exactement ce qu'il cherche.
  Masquez le commentaire s'il est injurieux. Les outils de modération d'Instagram existent pour cela
  et les utiliser ne signifie pas perdre.
- **Face à un prospect (lead) :** répondez de manière complète et publique. La porte ouverte se
  résume à une seule phrase à la fin : il s'agit d'une proposition d'aide, pas d'un pitch de vente.
  C'est la réponse publique qui incitera la personne suivante à vous contacter en DM.

## Commentaires avec mot-clé (Keyword comments)

Si le post demandait de commenter un mot-clé précis, ces commentaires constituent la raison d'être
de la publication. Chacun d'entre eux représente une personne qui a levé la main. Répondez à chacun,
puis envoyez ce qui a été promis. Si l'utilisateur a mis en place une automatisation via les outils
natifs d'Instagram ou un partenaire approuvé, mentionnez-le et laissez le système agir ; sinon, les
réponses se font manuellement, ce qui reste gérable à ce volume. N'envoyez jamais de messages privés
en masse à des personnes qui n'ont rien commenté.

## Format de sortie

Un seul bloc, regroupé par catégorie, chaque réponse prête à être copiée et déjà humanisée :

```
RÉPONSES  ·  84 commentaires  ·  41 KEYWORD, 2 LEAD, 3 SUBSTANCE, 2 QUESTION, 34 SUPPORT, 2 NOISE

KEYWORD  (41)  envoyer la clause. Une ligne par personne, même bienveillance, pas de copier-coller brut.

LEAD
@handle - "il nous est arrivé exactement la même chose en juin"
> Ce qui a réglé le problème pour nous, c'est de dissocier totalement le déclencheur de paiement
> de la validation. Je peux t'envoyer la formulation exacte si ça t'intéresse.

QUESTION -> REEL
@handle - "comment tu fais s'ils refusent de signer ?"
  34 likes sur ce commentaire. Ça mérite un Reel, pas juste une réponse. Formule #16.

NOISE  (2)  ignorés. Leur répondre leur donnerait de la visibilité.
```

Puis la validation : rien n'est publié tant que l'utilisateur ne donne pas son accord. C'est lui qui
copie-colle les réponses.
