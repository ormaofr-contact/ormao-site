---
name: dispatching-parallel-agents
description: À utiliser face à 2+ tâches indépendantes pouvant être traitées sans état partagé ni dépendances séquentielles
---

# Répartition d'agents en parallèle

## Vue d'ensemble

Vous déléguez des tâches à des agents spécialisés disposant d'un contexte isolé. En élaborant avec précision leurs instructions et leur contexte, vous garantissez qu'ils restent concentrés et mènent à bien leur mission. Ils ne doivent jamais hériter du contexte ou de l'historique de votre session — vous construisez exactement ce dont ils ont besoin. Cela préserve également votre propre contexte pour le travail de coordination.

Lorsque vous êtes confronté à de multiples défaillances sans lien entre elles (différents fichiers de test, différents sous-systèmes, différents bugs), les examiner de manière séquentielle fait perdre du temps. Chaque investigation est indépendante et peut se dérouler en parallèle.

**Principe fondamental :** Déployez un agent par domaine de problème indépendant. Laissez-les travailler simultanément.

## Quand l'utiliser

```dot
digraph when_to_use {
    "Multiple failures?" [shape=diamond];
    "Are they independent?" [shape=diamond];
    "Single agent investigates all" [shape=box];
    "One agent per problem domain" [shape=box];
    "Can they work in parallel?" [shape=diamond];
    "Sequential agents" [shape=box];
    "Parallel dispatch" [shape=box];

    "Multiple failures?" -> "Are they independent?" [label="yes"];
    "Are they independent?" -> "Single agent investigates all" [label="no - related"];
    "Are they independent?" -> "Can they work in parallel?" [label="yes"];
    "Can they work in parallel?" -> "Parallel dispatch" [label="yes"];
    "Can they work in parallel?" -> "Sequential agents" [label="no - shared state"];
}
```

**À utiliser lorsque :**
- 3+ fichiers de test échouent pour des causes premières distinctes
- Plusieurs sous-systèmes sont cassés de manière indépendante
- Chaque problème peut être compris sans le contexte des autres
- Aucun état partagé entre les investigations

**Ne pas utiliser lorsque :**
- Les défaillances sont liées (en corriger une pourrait corriger les autres)
- Il est nécessaire de comprendre l'état global du système
- Les agents interféreraient les uns avec les autres

## Le modèle

### 1. Identifier les domaines indépendants

Regroupez les échecs par ce qui est cassé :
- Tests du fichier A : Flux d'approbation des outils
- Tests du fichier B : Comportement de fin de lot (batch completion)
- Tests du fichier C : Fonctionnalité d'interruption (abort)

Chaque domaine est indépendant — corriger l'approbation des outils n'affecte pas les tests d'interruption.

### 2. Créer des tâches d'agent ciblées

Chaque agent reçoit :
- **Un périmètre spécifique :** Un fichier de test ou un sous-système
- **Un objectif clair :** Faire réussir ces tests
- **Des contraintes :** Ne pas modifier d'autre code
- **Un résultat attendu :** Un résumé de ce qui a été trouvé et corrigé

### 3. Répartir en parallèle

Émettez les trois lancements de sous-agents dans la même réponse — ils s'exécutent en parallèle :

```text
Subagent (general-purpose): "Fix agent-tool-abort.test.ts failures"
Subagent (general-purpose): "Fix batch-completion-behavior.test.ts failures"
Subagent (general-purpose): "Fix tool-approval-race-conditions.test.ts failures"
# All three run concurrently.
```

Plusieurs appels de dispatch dans une même réponse = exécution parallèle. Un par réponse = séquentiel.

### 4. Examiner et intégrer

Lorsque les agents reviennent :
- Lisez chaque résumé
- Vérifiez que les corrections ne sont pas en conflit
- Lancez la suite de tests complète
- Intégrez toutes les modifications

## Structure du prompt d'un agent

Les bons prompts d'agent sont :
1. **Ciblés** - Un seul domaine de problème clair
2. **Autosuffisants** - Tout le contexte nécessaire pour comprendre le problème
3. **Précis sur la sortie** - Que doit renvoyer l'agent ?

```markdown
Fix the 3 failing tests in src/agents/agent-tool-abort.test.ts:

1. "should abort tool with partial output capture" - expects 'interrupted at' in message
2. "should handle mixed completed and aborted tools" - fast tool aborted instead of completed
3. "should properly track pendingToolCount" - expects 3 results but gets 0

These are timing/race condition issues. Your task:

1. Read the test file and understand what each test verifies
2. Identify root cause - timing issues or actual bugs?
3. Fix by:
   - Replacing arbitrary timeouts with event-based waiting
   - Fixing bugs in abort implementation if found
   - Adjusting test expectations if testing changed behavior

Do NOT just increase timeouts - find the real issue.

Return: Summary of what you found and what you fixed.
```

## Erreurs courantes

**❌ Trop vaste :** "Corrige tous les tests" - l'agent se perd
**✅ Spécifique :** "Corrige agent-tool-abort.test.ts" - périmètre ciblé

**❌ Aucun contexte :** "Corrige la condition de concurrence" - l'agent ne sait pas où
**✅ Contexte :** Collez les messages d'erreur et les noms de tests

**❌ Aucune contrainte :** L'agent risque de tout refactoriser
**✅ Contraintes :** "Ne modifie PAS le code de production" ou "Corrige uniquement les tests"

**❌ Sortie vague :** "Corrige-le" - vous ne savez pas ce qui a changé
**✅ Spécifique :** "Renvoie un résumé de la cause première et des modifications"

## Quand NE PAS l'utiliser

**Défaillances liées :** En corriger une pourrait corriger les autres - investiguez ensemble d'abord
**Besoin du contexte complet :** La compréhension nécessite de voir l'ensemble du système
**Débogage exploratoire :** Vous ne savez pas encore ce qui est cassé
**État partagé :** Les agents interféreraient (modification des mêmes fichiers, utilisation des mêmes ressources)

## Exemple réel tiré d'une session

**Scénario :** 6 échecs de tests répartis sur 3 fichiers après un refactoring majeur

**Échecs :**
- agent-tool-abort.test.ts : 3 échecs (problèmes de timing)
- batch-completion-behavior.test.ts : 2 échecs (outils non exécutés)
- tool-approval-race-conditions.test.ts : 1 échec (nombre d'exécutions = 0)

**Décision :** Domaines indépendants - logique d'interruption distincte de la fin de lot, elle-même distincte des conditions de concurrence

**Répartition :**
```
Agent 1 → Fix agent-tool-abort.test.ts
Agent 2 → Fix batch-completion-behavior.test.ts
Agent 3 → Fix tool-approval-race-conditions.test.ts
```

**Résultats :**
- Agent 1 : Remplacement des timeouts par une attente basée sur les événements
- Agent 2 : Correction d'un bug de structure d'événement (threadId au mauvais endroit)
- Agent 3 : Ajout de l'attente de la fin de l'exécution asynchrone de l'outil

**Intégration :** Toutes les corrections étaient indépendantes, aucun conflit, suite complète au vert

## Vérification

Après le retour des agents :
1. **Examinez chaque résumé** - Comprenez ce qui a changé
2. **Vérifiez l'absence de conflits** - Les agents ont-ils modifié le même code ?
3. **Lancez la suite complète** - Vérifiez que toutes les corrections fonctionnent ensemble
4. **Faites des vérifications ponctuelles** - Les agents peuvent commettre des erreurs systématiques
