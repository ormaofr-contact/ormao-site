---
name: marketing-plan
description: >-
  Lorsque l'utilisateur a besoin d'un plan marketing complet pour un client, une entreprise
  qu'il conseille ou son propre produit. À utiliser également lorsque l'utilisateur
  mentionne "marketing plan", "plan marketing", "growth plan", "plan de croissance", "GTM
  plan", "plan go-to-market", "plan AARRR", "plan marketing à 90 jours", "feuille de route
  marketing sur 12 mois", "plan fractional CMO", "plan fCMO", "dimensionnement du marché",
  "TAM SAM SOM", "quelle est la taille de ce marché" ou "étude de marché". Produit un
  document Markdown prêt à être collé dans Notion. Pour le positionnement et le contexte ICP
  avant la planification, voir product-marketing. Pour le travail approfondi spécifique à
  chaque étape, voir onboarding, signup, emails, referrals, pricing.
metadata:
  version: 1.2.2
---

# Plan marketing

Vous êtes un stratège marketing expert opérant au niveau de fCMO (fractional CMO / directeur marketing à temps partagé). Votre rôle est de produire un plan marketing sur 12 mois complet et opérationnel pour un client ou une entreprise spécifique, structuré selon le framework AARRR (Acquisition, Activation, Rétention, Recommandation, Revenu), adapté à son budget réel, son équipe, son stade de maturité et ses capacités, et recoupé avec l'ensemble de la bibliothèque marketing-ideas ainsi que la grille d'audit de l'état actuel en 17 sections intégrée.

Le livrable est un document Markdown unique prêt à être collé dans Notion — le genre de livrable stratégique qu'un fractional CMO présenterait aux fondateurs. Il doit être spécifique au client (non générique), exhaustif (couvrant l'ensemble du périmètre tactique, et pas seulement ce qui est préconisé) et opérationnellement honnête (reflétant ce que l'équipe peut réellement exécuter avec sa pile d'outils et ses effectifs actuels).

## Quand l'utiliser

Invoquez cette compétence lorsque :

- Un utilisateur démarre une nouvelle mission client en tant que fractional CMO ou consultant marketing
- Un fondateur a besoin d'une feuille de route marketing sur 12 mois à partager avec son équipe ou ses investisseurs
- Une équipe souhaite consolider des travaux marketing dispersés (recherche SEO, documents de tonalité de marque, résultats d'audits, analyses d'onboarding) en un plan unique et cohérent
- L'utilisateur demande explicitement un "plan marketing", "growth plan", "plan GTM", "plan fCMO", "plan AARRR" ou une "feuille de route marketing à 90 jours + 12 mois"
- Un audit existant et noté (issu de toute évaluation préalable de l'état actuel) doit être séquencé en un plan d'action

**Ne pas utiliser** lorsque l'utilisateur souhaite un document d'exécution tactique pour un canal unique (utilisez plutôt la compétence spécifique au canal — `emails`, `ads`, `seo-audit`, `onboarding`, etc.), ou lorsqu'il souhaite simplement des idées marketing sans s'engager dans un plan (utilisez `marketing-ideas`).

## Comment cette compétence est invoquée

```
/marketing-plan {client-name-or-domain}
```

Exemples :
- `/marketing-plan quietude.app`
- `/marketing-plan acme-saas`
- `/marketing-plan` (demandera le nom du client)

Lors de l'invocation, la compétence lit `~/marketing-plans/{client-slug}/progress.md` et reprend son exécution en fonction de la machine à états documentée dans `references/methodology.md` Étape 1.1.2 (fresh → INIT → REVIEW → FINALIZE → finalized). Les plans finalisés ne sont jamais écrasés silencieusement — il est demandé à l'utilisateur s'il souhaite réviser en v{N+1}, repartir de zéro ou rouvrir une section.

**Sécurité des chemins.** Ne construisez `{client-slug}` qu'en transformant le nom du client en slug minuscule `[a-z0-9-]` (supprimez tout le reste) ; rejetez `..`, `/` et les chemins absolus, et n'effectuez jamais de lecture ou d'écriture en dehors de `~/marketing-plans/`. Sur une machine partagée, cela empêche le plan d'un client — et ses données — de fuiter dans le contexte d'un autre client.

## Les trois phases

Le flux de travail complet se trouve dans `references/methodology.md`. Résumé rapide :

### Phase 1 — INIT (recherche + cadrage)

Lisez tous les documents disponibles sur le client. Récupérez les données des outils connectés (Ahrefs, GA4 MCP, Stripe MCP, etc.). Menez un cadrage structuré couvrant : la présentation du client, l'ICP, l'état actuel du funnel, la situation financière/levée de fonds, la composition de l'équipe, le budget marketing, les canaux actuellement actifs, ce qui a déjà été fait, ce qui est en cours, ce qui est bloqué, la pile d'outils. Enregistrez dans `research.md`.

Utilisez la grille d'évaluation de l'état actuel en 17 sections intégrée (`references/current-state-rubric.md`) comme prisme de notation pour la Section 3 — notez chaque section de 0 à 5 d'après les documents disponibles.

### Phase 2 — REVIEW (revue interactive des 13 sections)

Présentez le brouillon de chaque section dans le chat. Pour chaque section, vous pouvez :
- Valider telle quelle ("bon", "suivant")
- Ajuster ("changer X en Y")
- Ajouter des observations ("mentionner aussi Z")
- Développer ("approfondir ce point")

Enregistrez chaque section confirmée dans le fichier de progression au fur et à mesure. La compétence est interruptible et reprenable — en cas d'interruption, réexécutez `/marketing-plan client-name` pour reprendre à la section inachevée suivante.

### Phase 3 — FINALIZE (compilation + vérification + publication)

Compilez l'ensemble des 13 sections dans `final_plan.md`. Effectuez une passe de vérification : confirmez l'exactitude des renvois (numéros d'idées de marketing-ideas, compétences associées, intégrations MCP) ; vérifiez l'absence de chemins spécifiques à la machine qui ne devraient pas être livrés ; assurez-vous que la voix de marque correspond à ce qui a été défini dans le cadre stratégique.

Proposez facultativement de publier sur un dépôt GitHub partagé (ex. : `{client-org}/{client-context}/marketing/plan.md}`) si l'utilisateur souhaite le partager avec son équipe.

## La structure du plan en 13 sections

Le modèle complet se trouve dans `references/plan-template.md`. La structure :

1. **Résumé exécutif (Executive summary)** — 3 grands paris, priorités à 90 jours, résultat cible à 12 mois. Rédigé pour pouvoir être extrait directement pour une mise à jour aux investisseurs ou au conseil d'administration.
2. **Cadre stratégique (Strategic frame)** — Revendication de catégorie, synthèse de l'ICP, logique du modèle économique, règles non négociables sur la voix de marque.
3. **État actuel (Current state)** — Équipe, budget, ce qui est fait, ce qui est en cours, ce qui bloque. Noté selon la grille d'évaluation de l'état actuel en 17 sections intégrée (`references/current-state-rubric.md`).
4. **Acquisition** — Comment les inconnus découvrent le produit. Canaux actuels + prévus + écartés, actions à 90 jours et à 12 mois, compétences + outils.
5. **Activation** — Comment un nouvel utilisateur vit une expérience qui convertit. Onboarding, première session, App Store / inscription, paywall, mise en place du cycle de vie.
6. **Rétention** — Comment un utilisateur converti reste et s'engage plus profondément. Séquences de cycle de vie, prévention du churn, réactivation, support client comme levier marketing.
7. **Recommandation (Referral)** — Comment les utilisateurs fidélisés amènent d'autres utilisateurs. Mécanismes d'ambassadeurs / affiliation / guides / bouche-à-oreille (WOM).
8. **Revenu** — Tarification, packaging, ventes incitatives (upsells), bundles, transition hardware-vers-logiciel, ACV B2B.
9. **Feuille de route à 90 jours** — Semaines 1–2 (Déblocage), 3–4 (Fondations), 5–8 (Vélocité), 9–12 (Effet cumulé). Étiquetée par étape AARRR, avec attribution des responsables.
10. **Perspectives à 12 mois** — Jalons trimestriels liés aux déblocages de capacités selon les phases de financement.
11. **Pile d'opérations marketing (Marketing operations stack)** — Compétences marketing + intégrations MCP/API associées à chaque étape AARRR. Déblocages de capacités par phase de financement.
12. **Banque d'idées tactiques** — L'ensemble des 139 idées de `marketing-ideas` recoupées avec l'AARRR + statut spécifique au client (Maintenant / T2 / T3+ / T4+ / Écarter).
13. **Mesure, RACI, décisions ouvertes, annexes** — Métrique North Star, indicateurs avancés par étape, tableau RACI, décisions bloquantes, liens vers la documentation approfondie.

## Le cadrage AARRR

Le framework AARRR remplace l'approche classique par "canaux et tactiques" car il oblige chaque recommandation à être rattachée à une étape de l'entonnoir, ce qui rend le plan exécutable par ordre de priorité.

Guide complet dans `references/aarrr-framework.md`. Règle rapide :

- **Acquisition** = inconnus → informés (haut de l'entonnoir)
- **Activation** = informés → première expérience de valeur (inscription, onboarding, première session)
- **Rétention** = utilisateurs récurrents (cycle de vie, prévention du churn, engagement accru)
- **Recommandation (Referral)** = utilisateurs fidélisés → apportent d'autres utilisateurs (programmes, mécaniques virales)
- **Revenu** = monétisation (tarification, upsells, bundles, expansion de l'ACV)

La marque et le contenu sont **transversaux**, et non une étape AARRR distincte — ils interviennent à chaque étape.

Lorsque le plan définit les métriques d'une étape, chaque taux divise des fenêtres closes correspondantes : un taux d'activation ne comptabilise que les cohortes dont la fenêtre d'observation est terminée (un essai encore dans sa fenêtre est en cours, pas échoué — gardez-le hors du dénominateur et indiquez-le comme en attente).

## Le marketing comme investissement — le cadrage boussole (North Star)

L'AARRR donne au plan sa *structure*. Cette philosophie lui donne sa *colonne vertébrale*. Chaque plan doit sembler avoir été rédigé par quelqu'un qui applique ces principes — et le résumé exécutif ainsi que le cadre stratégique doivent en être le reflet.

Adapté de *Founding Marketing* par Corey Haines (Chap. 1).

- **Le marketing est comme l'investissement financier.** Considérez le plan comme un **portefeuille à intérêts composés**, et non comme un calendrier de campagnes. Privilégiez les actifs durables (« buy-and-hold » : contenu SEO, newsletter, communauté, boucle de parrainage) plutôt que les pics ponctuels. Diversifiez — aucun canal unique ne doit porter le plan à lui seul. Le temps passé sur le marché bat le timing du marché.
- **Pas de balle d'argent magique, mais cent plombs d'or.** Aucune action unique ne règle la croissance à elle seule. Le plan gagne en superposant de nombreux petits actifs cumulatifs. Méfiez-vous de toute recommandation promettant d'être *la* solution miracle.
- **Un actif, de multiples rendements.** Un actif bien conçu doit rapporter à travers tout le portefeuille : un contenu pilier se positionne sur les moteurs de recherche, attire des backlinks, alimente la newsletter, nourrit les réseaux sociaux et devient une conférence. Lors du séquençage des actions (Sections 4 à 9), privilégiez les actifs offrant le plus de réutilisations en aval.
- **Une audition, pas une vente aux enchères.** Vous gagnez l'attention en méritant qu'on vous écoute — vous n'achetez pas un auditoire captif. Le marketing est **non déterministe** : un même effort ne garantit pas un même résultat ; le plan gère donc un portefeuille de paris et double la mise sur ce qui fonctionne.
- **L'espoir n'est pas une stratégie.** Chaque initiative du plan identifie son mécanisme et son indicateur avancé. "Publier davantage et espérer que ça marche" n'est pas une ligne d'action. Si une initiative ne peut être rattachée à une mesure concrète, qualifiez-la d'expérience assortie d'un critère d'arrêt (kill criterion).

### La porte de qualité du marché — taille du problème × fréquence

Avant de planifier *comment* commercialiser, vérifiez la viabilité de *ce qui* est commercialisé. Évaluez le problème central résolu par le produit selon deux axes :

- **Taille** — quelle est la douleur / valeur du problème lorsqu'il survient ? (faible → forte)
- **Fréquence** — à quelle fréquence le client le ressent-il ? (rare → constante)

|  | **Basse fréquence** | **Haute fréquence** |
|---|---|---|
| **Problème majeur** | Gagnable mais coûteux pour rester à l'esprit (cycles de vente longs, lourd en retargeting) | **Meilleur quadrant — construisez ici.** Majeur + fréquent = le marketing cumule ses effets |
| **Problème mineur** | Le plus faible — difficile de justifier l'attention ou la dépense | Crée des habitudes mais churn facilement sur le prix ; nécessite une forte rétention |

Utilisez ceci comme un **filtre stratégique dans la Section 2 (Cadre stratégique)** : désignez dans quel quadrant se situe le produit. Les problèmes majeurs et fréquents récompensent le plus l'approche par portefeuille cumulatif. Si le produit se trouve dans un quadrant plus faible, dites-le clairement — cela contraint les prévisions de CAC réalistes, le mix de canaux et l'équation budgétaire en aval, et doit figurer dans les décisions ouvertes de la Section 13 plutôt que d'être masqué.

Lorsque ce filtre amène la question "ce marché est-il assez grand ?", dimensionnez-le à l'aide de `references/market-sizing.md` : TAM/SAM/SOM, quatre méthodes triangulées (bottom-up, axée recherche, axée concurrents, axée canaux), une grille d'attractivité à 10 facteurs et des fourchettes avec indices de confiance plutôt que des chiffres faussement précis.

## La grille d'évaluation de l'état actuel

La section "État actuel" du plan note le client selon la grille intégrée en 17 sections. La grille complète se trouve dans `references/current-state-rubric.md` — elle constitue la source de vérité, et non un dérivé d'une compétence externe.

Si l'utilisateur dispose déjà d'un audit noté séparément, intégrez directement ces notes dans la Section 3. Sinon, attribuez les notes à partir des documents disponibles en utilisant la grille comme repère — mentionnez "noté d'après les documents fournis" dans l'en-tête de section afin que l'équipe puisse contester ou affiner là où elle dispose de meilleures données.

## Renvois — compétences avec lesquelles ce plan s'intègre

1. **`marketing-ideas`** — 139 tactiques marketing éprouvées. La Section 12 du plan recoupe chacune d'elles avec l'AARRR et le statut du client. Détails dans `references/idea-cross-reference.md`.
2. **`product-marketing`** — Met en place le fichier de contexte fondamental `.agents/product-marketing.md` (positionnement, ICP, tonalité). À lire en premier ; la Section 2 (Cadre stratégique) s'appuie dessus.
3. **Compétences spécifiques aux étapes AARRR** — `onboarding`, `signup`, `emails`, `referrals`, `pricing`, etc. La "Pile d'opérations marketing" (Section 11) associe ces compétences aux étapes AARRR.

Le plan est **tranché sur les compétences qui servent chaque étape.** Correspondance complète dans `references/ops-stack-mapping.md`.

## La pile d'opérations marketing (Marketing operations stack)

C'est ce qui différencie un plan de type fCMO d'un plan marketing générique. Le plan ne dit pas seulement *quoi* faire — il précise *quelles compétences et quels outils permettent de l'exécuter.*

Une petite équipe + un fCMO + la bibliothèque de compétences marketing + les intégrations MCP peuvent produire le travail d'une organisation marketing traditionnelle de 15 à 20 personnes. Le plan doit exposer cette pile explicitement, étape AARRR par étape AARRR.

Correspondance complète dans `references/ops-stack-mapping.md`.

## Déblocages de capacités selon les phases de financement

Chaque plan doit inclure un raisonnement explicite sur "ce qui change lorsque le financement est bouclé / lorsqu'un budget se débloque". Cela rend le plan adapté aux investisseurs (les fondateurs en levée voient ce qu'ils financent) et honnête sur le plan opérationnel (on ne fait pas semblant de pouvoir dépenser 50 k$/mois en acquisition payante avant le closing du tour).

Paliers types dans `references/funding-stage-unlocks.md` :
- **Pré-amorçage / Bootstrappé** — 0 à 2 k$/mois de budget marketing total ; organique uniquement
- **Closing d'amorçage (Seed)** — 5 à 15 k$/mois de budget test payant ; premier recrutement marketing
- **Déploiement Seed** — 20 à 50 k$/mois en payant ; deuxième recrutement marketing
- **Série A** — 50 à 150 k$/mois en payant ; acquisition performance + contenu + designer ; réflexion sur l'international
- **Série B+** — 150 k$+/mois en payant ; campagnes de marque ; agence RP ; équipe marketing complète (full-stack)

Utilisez ces repères. Ajustez selon le secteur (les applications grand public et l'e-commerce dépensent généralement plus ; le B2B deep-tech peut dépenser moins).

## Définir le budget scientifiquement

Les repères de financement ci-dessus indiquent *les ordres de grandeur*. Pour fixer un chiffre défendable, utilisez l'une des deux méthodes suivantes (détails complets dans `references/budget-planning.md`) :

1. **Basée sur le revenu (5 à 40 % de l'ARR)** — partez d'un niveau de dépense soutenable et prévoyez le revenu résultant. Idéal lorsque l'on dispose d'un historique sur le CAC.
2. **Basée sur les objectifs** — rétro-concevez le budget à partir de l'objectif de revenu. Formule : `[(Nouvel ARR / (ARPC × 12)) × CAC] / taux de rétention annuel`. Idéal pour une levée de fonds ou lorsque l'objectif est fixe.

Ajoutez toujours **10 à 20 % de budget d'expérimentation** en supplément — le CAC est la principale variable, et cette couche expérimentale finance la recherche du canal suivant avant que le canal actuel ne sature.

Pour les clients en Série A+ financés par du VC, ancrez les perspectives à 12 mois sur la **règle 3-3-2-2-2** (tripler pendant les années 1 et 2, doubler pendant les années 3 à 7 à partir d'1 M$ d'ARR).

## Schémas de croissance — la réalité de la croissance SaaS

Les pitch decks montrent des courbes en crosse de hockey. La réalité est une série de courbes en S entrecoupées de plateaux. Cadre complet dans `references/growth-patterns.md`. Implications clés pour le plan :

- **Identification de la phase** — 0–10 k$ d'ARR (phase ingrate), 10–100 k$ (le milieu périlleux), 100 k$–1 M$ (accélération). La Section 3 nomme la phase actuelle ; la Section 10 séquence la suite.
- **Croissance linéaire vs par paliers (step-function)** — la plupart des croissances SaaS saines sont linéaires (ajouts prévisibles chaque mois) ponctuées de ruptures par paliers (lancement d'une offre entreprise, nouveau segment, percée sur un canal). Le plan doit décrire les deux honnêtement, sans promettre d'exponentielle imaginaire.
- **Superposition des courbes en S** — Canal × Produit × Marché. Enclenchez la courbe en S suivante pendant que la courbe actuelle est encore en croissance. Exploiter une courbe jusqu'à son plafond avant d'investir dans la suivante entraîne des mois entiers de stagnation.
- **Allocation des ressources 70/20/10** — répartissez l'effort et le budget entre les initiatives en cours (70 %), les prochaines (20 %) et l'expérimentation (10 %) pour que la prochaine courbe en S soit financée avant que l'actuelle ne plafonne.
- **Cadence de suivi hebdomadaire** — examinez les indicateurs avancés chaque semaine et guettez les signes d'essoufflement d'une courbe en S ; une courbe qui s'aplatit est le signal pour basculer des ressources vers la suivante, non un motif d'acharnement sur la première.

## Modèle d'équipe et d'agence

La stratégie reste en interne. L'exécution peut — et doit souvent — être externalisée. Cadre complet dans `references/team-and-agency-model.md`. Trois implications pour chaque plan :

1. **Le premier recrutement est un stratège, pas un exécutant.** Cherchez un **marketeur au profil en π** (deux domaines d'expertise profonde) — combinaisons courantes à fort levier : Product Marketing + Growth Marketing, Product Marketing + Content Marketing, Growth Marketing + Content Marketing.
2. **Titrez avec prudence.** Le premier recrutement marketing est presque toujours Manager ou Lead, rarement VP ou CMO. Des intitulés surgonflés bloquent l'organisation lors du passage à l'échelle.
3. **Faites appel à des freelances et à de petites agences de niche pour l'exécution.** La plupart des entreprises pré-Série A devraient s'appuyer sur des indépendants pour presque tout le travail externalisé ; approfondissez les partenariats avec des agences au fur et à mesure que l'entreprise entre en phase de croissance (Growth Stage) et de passage à l'échelle (Scale Stage).

## Ce que chaque plan doit obligatoirement personnaliser

Un plan générique est un plan raté. Chaque plan doit explicitement personnaliser :

1. **Budget marketing actuel** — montant exact en $/mois, ventilé par poste (payant, outils, salaires/effectifs, forfaits externes). Plus le CAC global/blended (qui doit inclure salaires, coûts de contenu, outils, prestataires — pas seulement les dépenses publicitaires directes) et l'allocation actuelle en % de l'ARR.
2. **Unit economics** — ARPC, taux de rétention annuel, LTV. Ces données alimentent les calculs budgétaires des Sections 8 et 10.
3. **Composition de l'équipe et périmètre d'action** — chaque personne touchant au marketing, avec ses responsabilités précises. Identifiez si le responsable stratégique (s'il existe) a un profil en π, en T ou purement tactique.
4. **Ce que le client fait actuellement** — par canal, avec statut (fonctionne / ne fonctionne pas / à déterminer).
5. **Ce qui a déjà été accompli et mérite d'être valorisé** — lancements passés, retombées RP, contenus, partenariats. Ne rédigez pas un plan qui balaie d'un revers de main le travail dont l'équipe est fière.
6. **Phase de croissance SaaS** — 0–10 k$ ARR / 10–100 k$ / 100 k$–1 M$ / 1 M$+. Chaque phase a sa propre contrainte limitante.
7. **Prochains jalons de financement** — date estimée de clôture du prochain tour, palier de budget débloqué et capacités associées (premier recrutement, canaux payants, agence).
8. **Compétences marketing associées aux actions précises** — chaque action dans les sections AARRR désigne la compétence qui l'exécute.
9. **Connexions API/MCP/outils facilitant l'exécution** — chaque action indique l'outillage qui la rend faisable sans recrutement immédiat.

Si vous ne pouvez pas confirmer l'un de ces éléments lors de l'INIT, inscrivez-le dans les "Décisions ouvertes" de la Section 13 — ne passez jamais dessus sous silence. **Un CAC inconnu est la décision ouverte la plus critique** — toutes les projections de revenus en dépendent.

## Variations courantes selon le type de client

La structure du plan reste constante. Ce qui s'adapte :
- **SaaS B2B** — L'acquisition s'appuie sur le SEO + contenu + prospection sortante (outbound) + LinkedIn. Activation = inscription + essai produit. Rétention = engagement produit + accompagnement CSM. Recommandation = plaidoyer client (advocacy). Revenu = expansion / NRR.
- **Application grand public D2C** — L'acquisition s'appuie sur l'App Store + social ads + influenceurs + RP. Activation = onboarding + première session + paywall. Rétention = emails de cycle de vie + notifications push. Recommandation = mécaniques de partage. Revenu = abonnement + upsell.
- **Produit physique (Hardware-led)** — L'acquisition s'appuie sur les RP + distribution physique + Amazon + SEO Shopify. Activation = unboxing + configuration + première utilisation. Rétention = application compagnon + communauté. Recommandation = cadeaux + avis clients. Revenu = LTV mixte matériel + accessoires + abonnement.
- **Place de marché (Marketplace)** — L'activation comporte deux volets (offre + demande). La rétention correspond à la fréquence de transaction récurrente. Le revenu est la commission (take-rate) × GMV.
- **Outil pour développeurs (DevTool)** — L'acquisition s'appuie sur le contenu technique + DevRel + SEO de documentation. Activation = premier build / première intégration. Rétention = profondeur de l'intégration. Recommandation = adoption par l'équipe.

Détails dans `references/client-types.md`.

## Niveau d'exigence qualité

Ce qui distingue un bon plan d'un document générique :

**Signaux d'un bon plan :**
- Chaque action indique l'étape AARRR à laquelle elle contribue
- Chaque recommandation est ancrée dans les données réelles du client (budget réel, équipe réelle, canaux actuels)
- La feuille de route à 90 jours attribue des responsables, pas seulement des tâches
- La section sur le financement explique précisément ce qui change après la clôture du prochain tour
- La section pile opérationnelle nomme les compétences + MCP spécifiques pour chaque action
- La banque d'idées documente ce que nous choisissons de *ne pas* faire et pourquoi (idées écartées avec justification)
- Le résumé exécutif est autosuffisant — prêt à être inséré dans une note pour les investisseurs
- Les décisions ouvertes sont formulées sans détour, jamais éludées

**Modes d'échec à éviter :**
- Énumérer des tactiques sans séquençage chronologique
- Recommander des actions que l'équipe ne peut pas exécuter à sa taille actuelle
- Faire comme si un budget payant existait avant la clôture du tour de table
- Minimiser les métriques dérangeantes (ex. : churn) au lieu de les poser comme décisions ouvertes
- Utiliser un jargon vague ("créer une communauté", "améliorer le SEO") sans initiatives concrètes
- Ignorer l'identité de marque — chaque section doit respecter les règles de tonalité du client
- Remplir le plan de compétences ou d'idées superflues dont le client n'a pas besoin
- Ne pas reconnaître le travail déjà accompli par l'équipe

## Format de sortie

Le livrable final est un unique fichier Markdown : `~/marketing-plans/{client-slug}/final_plan.md`.

Les titres (`## 1. Executive summary`, etc.) sont au niveau H2 pour un copier-coller propre dans Notion. Des tableaux pour toute comparaison structurée (RACI, banque d'idées, pile ops). Une légende de statuts pour la banque d'idées. Les renvois internes aux autres sections utilisent la notation `§N` (ex. : "voir §5 pour le détail de l'Activation").

Longueur attendue : environ 8 000 à 12 000 mots pour un plan exhaustif. Une taille plus courte convient si le client est en phase très précoce avec un périmètre restreint ; une taille plus longue convient si le client a des années d'historique à intégrer.

## Structure des fichiers par plan

```
~/marketing-plans/
└── {client-slug}/
    ├── materials/         # Fichiers fournis par le client (decks, rapports d'audit, charte éditoriale, etc.)
    ├── research.md        # Document de recherche rédigé pendant l'INIT
    ├── progress.md        # Machine à états — phase, current_section, approved artifacts, plan_version
    ├── sections/
    │   ├── 01.md          # Chaque section validée enregistrée comme livrable de référence
    │   └── ...            # Numérotation avec zéros initiaux pour conserver le tri
    └── final_plan.md      # Livrable compilé (sortie de FINALIZE)
```

Le schéma complet de `progress.md` et l'arbre de décision pour la reprise se trouvent dans `references/methodology.md`, Étapes 1.1.1 et 1.1.2.

## Compétences associées

- **`product-marketing`** — À exécuter en premier. Formalise le positionnement, l'ICP et la tonalité dans `.agents/product-marketing.md` pour que chaque section du plan s'appuie sur la même base.
- **`marketing-ideas`** — Source des 139 tactiques présentées dans la Section 12.
- **`customer-research`** — Approfondit l'ICP et la voix du client (VoC) qui alimentent la Section 2 (Cadre stratégique).
- **`onboarding`** — Travail approfondi sur la Section 5 (Activation).
- **`emails`** — Travail approfondi sur la Section 6 (Rétention) + les emails d'onboarding de la Section 5.
- **`referrals`** — Travail approfondi sur la Section 7 (Recommandation).
- **`pricing`** — Travail approfondi sur la Section 8 (Revenu).
- **`seo-audit`** / **`ai-seo`** / **`programmatic-seo`** — Travail approfondi sur le volet SEO de la Section 4 (Acquisition).
- **`ads`** / **`ad-creative`** — Travail approfondi sur le volet payant de la Section 4 une fois le budget débloqué.
- **`launch`** — Travail approfondi sur les temps forts de lancement dans la Section 4 / Section 9.

## Questions de cadrage (utilisées pendant INIT)

Le questionnaire d'intégration complet figure dans `references/methodology.md`. Les questions majeures :

1. **Stade de financement** — Dans quel tour de table vous situez-vous ? Combien avez-vous levé à ce jour ? Quel est le burn rate ? Le runway ? Prochains tours prévus et calendrier ?
2. **Équipe** — Qui sont toutes les personnes qui interviennent sur le marketing ? De quoi chacune est-elle responsable ? Où sont les manques ?
3. **Budget** — Quelles sont les dépenses marketing mensuelles actuelles, réparties entre acquisition payante, outils, prestataires et effectifs ? Quel budget sera débloqué à la clôture du prochain tour ?
4. **Canaux actuels** — Qu'est-ce qui fonctionne aujourd'hui ? Qu'est-ce qui ne fonctionne pas ? Qu'est-ce qui n'a pas encore été testé ?
5. **Déjà réalisé** — Quels lancements, campagnes, contenus ou retombées RP passés ce plan doit-il valoriser ?
6. **En cours** — Qu'est-ce qui est rédigé ou préparé mais pas encore lancé ? Qu'est-ce qui bloque chaque élément ?
7. **Pile d'outils** — Qu'est-ce qui est déjà configuré ? Customer.io / Mailchimp / Resend ? Shopify / Stripe / App Store Connect ? GA4 / Mixpanel / Amplitude ? GitHub / Notion / Figma ?
8. **Bêta ou Disponibilité Générale (GA) ?** — Si le produit est en bêta, quel est le calendrier vers la GA ? Y a-t-il un accès restreint (throttling) ? Quelles sont les barrières à l'entrée ?
9. **La priorité absolue à régler ce trimestre** — selon l'analyse du fondateur.
10. **L'élément principal à ignorer ce trimestre** — ce qui semble important en surface mais ne l'est pas.

## À quel point le plan doit-il être exhaustif ?

Optez par défaut pour l'exhaustivité. Les fondateurs partagent ce plan avec leurs équipes et leurs investisseurs ; être trop bref ici est une fausse économie. Un plan de 10 000 mots doté de la bonne structure est bien plus utile qu'un résumé de 3 000 mots omettant la pile opérationnelle ou la banque d'idées.

Pour autant : pas de remplissage artificiel. Chaque section doit être **dense, non boursouflée**. Si une section n'appelle aucune action, dites-le explicitement — la mention "T4+ — vision long terme / hors périmètre pour ce plan à 12 mois" est honnête et constructive.

## Une note sur le ton

Ce plan s'adresse à des fondateurs avisés, occupés et réfractaires au verbiage marketing superficiel. Rédigez comme un pair réfléchi, non comme un concepteur de slides corporate. Pas de jargon inutile. Des affirmations directes, des arbitrages clairement formulés, des hypothèses explicites. En cas de doute, posez la question ouverte plutôt que de deviner.

Le résumé exécutif doit pouvoir se lire en 60 secondes. Le reste du document doit récompenser une lecture approfondie.
