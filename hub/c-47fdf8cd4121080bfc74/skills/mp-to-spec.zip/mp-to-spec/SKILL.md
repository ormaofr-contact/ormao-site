---
name: to-spec
description: "Transforme la conversation actuelle en une spécification et la publie sur le gestionnaire de tickets du projet : aucun entretien, seulement la synthèse de ce qui a déjà été discuté."
disable-model-invocation: true
---

Cette compétence exploite le contexte de la conversation actuelle ainsi que la compréhension du codebase pour produire une spécification. N'interrogez PAS l'utilisateur ; contentez-vous de synthétiser ce que vous savez déjà.

Le gestionnaire de tickets et le vocabulaire des étiquettes de triage auraient dû vous être fournis. Si ce n'est pas le cas, demandez à l'utilisateur d'exécuter `/setup-matt-pocock-skills`.

## Processus

1. Explorez le dépôt pour comprendre l'état actuel du codebase, si ce n'est pas déjà fait. Utilisez le vocabulaire du glossaire métier du projet tout au long de la spécification, et respectez les ADR dans le domaine concerné.

2. Esquissez les points d'ancrage (seams) auxquels vous allez tester la fonctionnalité. Les points d'ancrage existants doivent être préférés aux nouveaux. Utilisez le point d'ancrage le plus haut possible. Si de nouveaux points d'ancrage sont nécessaires, proposez-les au niveau le plus élevé possible. Moins il y a de points d'ancrage dans le codebase, mieux c'est — le nombre idéal étant un.

Vérifiez auprès de l'utilisateur que ces points d'ancrage correspondent à ses attentes.

3. Rédigez la spécification à l'aide du modèle ci-dessous, puis publiez-la sur le gestionnaire de tickets du projet. Appliquez l'étiquette de triage `ready-for-agent` — aucun triage supplémentaire n'est nécessaire.

<spec-template>

## Description du problème

Le problème auquel l'utilisateur est confronté, du point de vue de l'utilisateur.

## Solution

La solution au problème, du point de vue de l'utilisateur.

## User Stories

Une LONGUE liste numérotée de user stories. Chaque user story doit être au format suivant :

1. En tant que <acteur>, je veux <fonctionnalité>, afin de <bénéfice>

<user-story-example>
1. En tant que client d'une banque mobile, je veux voir le solde de mes comptes, afin de prendre des décisions plus éclairées concernant mes dépenses
</user-story-example>

Cette liste de user stories doit être extrêmement détaillée et couvrir tous les aspects de la fonctionnalité.

## Décisions d'implémentation

Une liste des décisions d'implémentation qui ont été prises. Cela peut inclure :

- Les modules qui seront créés/modifiés
- Les interfaces de ces modules qui seront modifiées
- Les clarifications techniques apportées par le développeur
- Les décisions architecturales
- Les modifications de schéma
- Les contrats d'API
- Les interactions spécifiques

N'incluez PAS de chemins de fichiers spécifiques ni d'extraits de code. Ils risquent de devenir obsolètes très rapidement.

Exception : si un prototype a produit un extrait qui formalise une décision plus précisément que du texte (machine à états, reducer, schéma, structure de type), intégrez-le directement dans la décision concernée et indiquez brièvement qu'il est issu d'un prototype. Réduisez-le aux éléments porteurs de décision, pas à une démonstration fonctionnelle, seulement les éléments essentiels.

## Décisions de test

Une liste des décisions de test qui ont été prises. Incluez :

- Une description de ce qui constitue un bon test (tester uniquement le comportement externe, pas les détails d'implémentation)
- Les modules qui seront testés
- L'état de l'art pour les tests (c'est-à-dire des types de tests similaires déjà présents dans le codebase)

## Hors périmètre

Une description des éléments qui sont hors périmètre pour cette spécification.

## Remarques complémentaires

Toute remarque supplémentaire concernant la fonctionnalité.

</spec-template>
