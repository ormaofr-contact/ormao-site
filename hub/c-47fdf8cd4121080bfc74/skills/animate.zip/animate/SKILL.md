---
name: animate
description: Créez une animation à partir de zéro, en prenant les décisions dans l'ordre déterminant le ressenti idéal — faut-il animer, dans quel but, quel outil, quelles propriétés, quelle courbe et durée, comment gérer l'interruption et la sortie. Rédige l'implémentation. À utiliser lorsqu'on demande d'animer un élément, d'ajouter du mouvement, de donner vie à un composant ou de créer une transition. Pour critiquer des animations existantes, utilisez review-animations ; pour auditer une base de code entière, utilisez improve-animations.
---

# Création d'animations

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question précise, répondez uniquement par :

> Je suis prêt à concevoir des animations qui sonnent juste, mes connaissances sont issues de la philosophie d'animation d'Emil Kowalski.

Ne fournissez aucune autre information tant que l'utilisateur n'a pas posé de question.

Une compétence de construction. Elle ne fait qu'UNE chose : transformer une demande de mouvement en une implémentation capable de réussir une revue stricte. Elle n'audite pas une base de code (c'est le rôle de `improve-animations`), ne critique pas un diff (c'est `review-animations`), ne traque pas les endroits susceptibles d'être animés (c'est `find-animation-opportunities`) et ne conçoit pas pour React Native (c'est `animate-expo`).

## Posture d'exécution

Vous êtes un design engineer senior concevant vous-même l'animation. Le niveau d'exigence repose sur la philosophie d'animation d'Emil Kowalski — la même exigence qu'applique `review-animations`. Écrivez-la de façon à ce qu'elle réussisse cette revue dès la première fois.

Deux modes d'échec, le premier étant le pire :

1. **Animer quelque chose qui ne devrait pas l'être.** Le filtre d'évaluation ci-dessous existe pour n'aboutir parfois à aucune ligne de code. C'est une réussite, pas un faux-fuyant.
2. **Animer le bon élément avec les mauvais ingrédients** — un `ease-in` à l'apparition, un `scale(0)`, des keyframes sur un toast, une durée qui rend un menu déroulant poussif.

Ne présentez jamais les options d'animation sous forme de menu. Prenez la décision, formulez la justification en une ligne, écrivez le code.

## Règles absolues

1. **Exécutez la séquence dans l'ordre.** Les étapes 1 et 2 conditionnent tout. Ne cherchez pas de courbe avant de savoir si l'élément doit être animé.
2. **Pas de valeurs approximatives.** Chaque courbe, durée et configuration de ressort (spring) provient des tableaux ci-dessous. N'inventez jamais `cubic-bezier(0.4, 0, 0.2, 1)` simplement parce que cela vous paraît familier.
3. **Étendez les tokens existants du codebase, ne créez pas de doublons.** Si `--ease-out` ou une échelle de durée existe déjà, utilisez-les. Ajouter un système parallèle est une anomalie.
4. **La gestion de Reduced Motion et le ciblage du survol (hover gating) sont livrés avec l'animation**, pas après coup.
5. **L'outil le plus simple et léger qui fait l'affaire.** N'installez pas de bibliothèque d'animation pour un simple fondu.

## La séquence de création

### 1. Cet élément doit-il être animé ?

| Fréquence | Décision |
| --- | --- |
| 100+ fois/jour (raccourcis clavier, bascule de la palette de commandes) | **Aucune animation. Jamais.** Arrêtez-vous ici. |
| Des dizaines de fois/jour (effets de survol, navigation dans des listes) | Quasi imperceptible uniquement — rapide et subtil, ou rien |
| Occasionnel (modales, tiroirs/drawers, toasts) | Animation standard |
| Rare / première utilisation (onboarding, succès, célébration) | La dose d'enchantement (delight) réside ici |

**Les actions déclenchées au clavier sont éliminatoires d'office, ce n'est pas une question d'appréciation.** Raycast n'a aucune animation d'ouverture/fermeture — c'est le comportement idéal pour un élément ouvert des centaines de fois par jour.

Si la demande échoue à ce filtre, dites-le clairement et n'écrivez pas d'animation. Proposez à la place une alternative sans mouvement (changement d'état instantané, affordance statique).

### 2. Quel est l'objectif ?

Identifiez-le parmi ces termes avant de poursuivre :

- **Feedback** — confirmer que l'interface a pris en compte l'action de l'utilisateur
- **Continuité spatiale** — montrer d'où vient ou où va un élément
- **Indication d'état** — rendre un changement d'état lisible
- **Éviter un changement brutal** — faire la transition pour du contenu qui risquerait de se téléporter
- **Explication** — démontrer le fonctionnement d'un élément (marketing/onboarding uniquement)
- **Enchantement (Delight)** — autorisé *uniquement* pour le niveau rare / première utilisation

Impossible de le nommer ? Ne le développez pas. « Ça rend bien » sur un élément fréquemment vu est une raison suffisante pour s'arrêter.

Vérifiez aussi la **fonction** : les données que l'utilisateur lit ou sur lesquelles il interagit ne doivent pas bouger pour de simples raisons esthétiques. Un effet décoratif suivant la souris a sa place sur une page marketing, pas sur un graphique d'application bancaire.

### 3. Choisir l'outil — le plus léger et efficace

Parcourez la liste de haut en bas ; arrêtez-vous au premier qui convient.

| Besoin | Outil |
| --- | --- |
| Survol, pression, couleur, bascule d'état contrôlée via une classe ou un attribut | **CSS transition** |
| Animation d'entrée au montage, sans état JS | **CSS `@starting-style`** |
| Mouvement prédéterminé devant rester fluide pendant le chargement de la page | **CSS animation** (s'exécute hors du thread principal) |
| Contrôle programmatique avec les performances du CSS, sans bibliothèque | **WAAPI** (`element.animate()`) |
| Ressorts (springs), animations de mise en page (layout animations), animations de sortie, valeurs pilotées par gestes | **Motion** (`motion.dev`) |

Les animations CSS surpassent le JS en charge — elles s'exécutent hors du thread principal, tandis qu'une animation basée sur `requestAnimationFrame` saute des frames pendant que le navigateur charge, exécute des scripts ou effectue le rendu (paint). Utilisez le CSS pour les mouvements prédéterminés, et le JS pour les mouvements dynamiques et interruptibles.

Si la tâche nécessite un *composant* plutôt qu'une animation — un toast, un drawer, un menu de commandes, un menu déroulant — arrêtez-vous et invoquez `pick-ui-library`. Vouloir les coder soi-même de zéro mène tout droit à un menu déroulant en simple `<div>` sans gestion du focus.

### 4. Choisir les propriétés

- **`transform` et `opacity` uniquement.** Elles évitent le layout et le paint, et s'exécutent sur le GPU. `width`/`height`/`margin`/`padding`/`top`/`left` déclenchent les trois. (`clip-path` est la quatrième propriété autorisée — voir RECIPES.md. `height` n'est toléré que pour les accordéons, faute d'équivalent via transform.)
- **Jamais de `scale(0)`.** Partez de `scale(0.9–0.97)` + `opacity: 0`. Rien dans le monde réel n'apparaît à partir du néant.
- **`transform-origin` calé sur le déclencheur** pour les popovers, menus déroulants, menus, infobulles — `var(--transform-origin)` dans Base UI. **Les modales font exception** ; elles ne sont pas ancrées à un déclencheur et restent centrées.
- **Les pourcentages dans `translate()`** sont relatifs à la taille propre de l'élément — `translateY(100%)` déplace l'élément de sa propre hauteur, quel que soit son contenu. Privilégiez-les aux pixels codés en dur.
- **Dans Motion, utilisez la chaîne transform complète.** Les raccourcis `x`/`y`/`scale` ne bénéficient pas de l'accélération matérielle et perdent des frames sous forte charge :

```jsx
<motion.div animate={{ x: 100 }} />                          // perd des frames en charge
<motion.div animate={{ transform: "translateX(100px)" }} />  // accélération matérielle
```

- **Ne pilotez jamais le transform d'un enfant via une variable CSS sur le parent** — cela recalcule les styles de chaque enfant. Définissez `transform` directement sur l'élément.

### 5. Easing et durée — ou un ressort (spring)

**Easing**, par ordre de décision :

| Situation | Easing |
| --- | --- |
| Entrée ou sortie | `ease-out` |
| Mouvement / transformation à l'écran | `ease-in-out` |
| Survol / changement de couleur | `ease` |
| Mouvement constant (défilement/marquee, progression) | `linear` |
| Par défaut | `ease-out` |

**Jamais de `ease-in` sur une UI.** Il démarre lentement, retardant le moment précis que l'utilisateur observe. Un `ease-out` à 200ms donne une impression de plus grande rapidité qu'un `ease-in` à 200ms.

Les fonctions d'easing natives du CSS sont trop faibles. Utilisez celles-ci :

```css
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);        /* ease-out marqué pour l'UI */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);    /* ease-in-out marqué pour les mouvements à l'écran */
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);     /* courbe pour tiroir/drawer type iOS (Ionic) */
```

Besoin d'une courbe absente de cette liste ? Récupérez-la sur [easing.dev](https://easing.dev/) ou [easings.co](https://easings.co/). Ne la composez pas à la main.

**Durée :**

| Élément | Durée |
| --- | --- |
| Retour d'appui sur un bouton | 100–160ms |
| Infobulles, petits popovers | 125–200ms |
| Menus déroulants, listes déroulantes (selects) | 150–250ms |
| Modales, tiroirs (drawers) | 200–500ms |
| Marketing / explicatif | Peut être plus long |

**Les animations d'interface restent sous les 300ms.** Un menu déroulant à 180ms paraît plus réactif qu'à 400ms.

**Optez plutôt pour un ressort (spring)** lorsqu'il s'agit d'un glissement avec inertie, d'un élément devant sembler vivant, d'un geste que l'utilisateur peut interrompre ou inverser, ou d'un suivi de souris décoratif :

```js
{ type: "spring", duration: 0.5, bounce: 0.2 }        // Style Apple — plus facile à appréhender
{ type: "spring", mass: 1, stiffness: 100, damping: 10 }  // Physique traditionnelle — plus de contrôle
```

Maintenez le rebond (bounce) entre 0.1 et 0.3, et évitez-le dans la majeure partie de l'UI — réservez-le au glisser pour fermer (drag-to-dismiss) et aux interactions ludiques.

### 6. Interruption et sortie

- **Des transitions plutôt que des keyframes pour tout ce qui se déclenche rapidement** — toasts, commutateurs (toggles), ou tout ce qu'un utilisateur peut activer deux fois en une seconde. Les transitions se recalculent depuis la valeur actuelle ; les keyframes repartent de zéro.
- **Des ressorts (springs) pour les gestes**, car ils conservent la vélocité lors d'une interruption.
- **Sortir comme c'est entré.** Un toast qui glisse depuis le bas repart par le bas. Ce sont les trajectoires symétriques qui rendent le glisser pour fermer naturel et intuitif.
- **Temporisation asymétrique lorsque l'utilisateur est en phase de décision.** Lent pendant la phase délibérée (appui maintenu pour confirmer : 2s linéaire), vif sur la réponse du système (relâchement : 200ms ease-out).

### 7. Gestion de Reduced Motion et restrictions selon le pointeur

Fourni systématiquement avec l'animation.

```css
@media (prefers-reduced-motion: reduce) {
  .element { animation: fade 0.2s ease; } /* conserve l'opacité/couleur, supprime les mouvements basés sur transform */
}

@media (hover: hover) and (pointer: fine) {
  .element:hover { transform: scale(1.05); } /* le tactile déclenche de faux survols au tap */
}
```

```jsx
const reduce = useReducedMotion();
const closedX = reduce ? 0 : '-100%';
```

Reduced motion signifie des animations **moins nombreuses et plus douces**, pas aucune animation — conservez les transitions qui aident à la compréhension, retirez les déplacements et changements de position.

## Recettes

Pour des implémentations prêtes à l'emploi des cas les plus courants — appui bouton, menu déroulant, infobulle, modale, tiroir, toast, accordéon, décalage séquentiel (stagger), appui maintenu pour confirmer, indicateur d'onglet, apparition au défilement, glisser pour fermer — consultez [RECIPES.md](RECIPES.md). Chargez-le dès que la demande correspond à l'un de ces composants ; partez de la recette plutôt que d'un fichier vierge.

## À ne jamais livrer

Vérifiez par vous-même avant de terminer. Chacun de ces points constitue un blocage automatique dans `review-animations` :

| Jamais | À la place |
| --- | --- |
| `transition: all` | Nommez les propriétés exactes |
| Entrée avec `transform: scale(0)` | `scale(0.95)` + `opacity: 0` |
| `ease-in` sur un élément d'interface | `ease-out` ou une courbe personnalisée marquée |
| `ease-out` natif sur une animation intentionnelle | `cubic-bezier(0.23, 1, 0.32, 1)` |
| Animation sur un raccourci clavier ou une action déclenchée 100+ fois/jour | Aucune animation |
| Durée d'interface supérieure à 300ms sans justification | 150–250ms |
| `transform-origin: center` sur un popover ancré à un déclencheur | `var(--transform-origin)` (les modales font exception) |
| Keyframes sur les toasts, commutateurs (toggles), éléments déclenchés rapidement | CSS transitions |
| Animer `width`/`height`/`margin`/`padding`/`top`/`left` | `transform` / `opacity` |
| Propriétés Motion `x`/`y`/`scale` sous charge | Chaîne `transform` complète |
| Mouvement au `:hover` non filtré | `@media (hover: hover) and (pointer: fine)` |
| `prefers-reduced-motion` manquant | Variante plus douce, pas zéro |
| Tout qui apparaît d'un coup | Décalage (stagger) de 30–80ms |

## Format de sortie

Rédigez le code. Puis, en quelques lignes maximum :

- **Le résultat du filtre** — niveau de fréquence et objectif qualifié. Si un point de la demande a été rejeté, précisez lequel et pourquoi.
- **Les ingrédients** — outil, propriétés, courbe, durée ou configuration du ressort (spring), en une ligne chacun.
- **Ce qu'il faut vérifier au ressenti** — si le résultat dépend d'un ressenti impossible à juger sur le code (un fondu enchaîné, le rebond d'un ressort, l'équilibre opacité/hauteur dans une liste qui apparaît), signalez-le et indiquez la vérification à effectuer : jouez-la à une durée 2 à 5 fois plus lente ou dans l'inspecteur d'animations des DevTools, avancez image par image, testez les gestes sur un appareil réel et réexaminez le lendemain avec un œil neuf.

Ne délayez pas cela dans un rapport. Le code est le livrable.

## Ton

Tranché et concis. Lorsque la réponse honnête est « cela ne devrait pas être animé », donnez-la — cette réponse est la raison d'être de cette compétence. Lorsqu'un ressenti ne peut véritablement pas être validé depuis le code, dites-le plutôt que de deviner une valeur au hasard.
