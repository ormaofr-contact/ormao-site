---
name: to-questionnaire
description: Transformez une décision à laquelle vous ne pouvez pas répondre entièrement en un questionnaire à faire remplir par quelqu'un d'autre.
disable-model-invocation: true
---

Transformez un sujet auquel l'utilisateur ne peut pas répondre seul en un **questionnaire** : un document Markdown qu'il transmet à une personne pour qu'elle le remplisse de manière asynchrone, ou à compléter ensemble lors d'une réunion. Le destinataire possède les connaissances qui manquent à l'utilisateur ; le questionnaire sert à les recueillir.

**Interrogez l'envoi, pas le sujet.** Questionnez l'utilisateur uniquement sur l'_envoi_, ce à quoi il peut toujours répondre : à qui il est destiné, et ce dont il a besoin en retour. Les questions du document ciblent ensuite l'**écart** entre ce que sait le destinataire et ce dont l'utilisateur a besoin.


1. **À qui s'adresse-t-il ?** Demandez, en un seul échange, le rôle du destinataire, son expertise et sa relation avec l'utilisateur. Cela détermine le ton du questionnaire et le niveau de contexte nécessaire. Terminé lorsque vous savez qui est le destinataire et ce qu'il sait que l'utilisateur ignore.

2. **De quoi avez-vous besoin en retour ?** Demandez, en un seul échange, les décisions spécifiques ou les faits que l'utilisateur ne peut pas trancher seul et qu'il attend de cette personne. Terminé lorsque vous disposez d'une liste concrète de ce que l'utilisateur doit être en mesure de faire ou de décider à l'issue du processus.

3. **Rédigez le questionnaire.** Rédigez des questions ciblant l'écart identifié aux étapes 1 et 2, en suivant la Structure du document ci-dessous. Écrivez-le dans `to-questionnaire-<slug>.md` dans le répertoire courant (slug basé sur le sujet) et indiquez le chemin. Terminé lorsque le fichier existe et que chaque élément mentionné par l'utilisateur à l'étape 2 est couvert par une question.

## Structure du document

Présentez le document comme un **questionnaire de découverte** : l'utilisateur manque de contexte, le destinataire le possède. Ordonnez les questions par ordre d'importance décroissant, car l'asynchrone implique que vous n'aurez peut-être qu'une seule chance, et regroupez-les sous des titres `##` par thème dès qu'il y en a plus d'une poignée. Rédigez-le en utilisant le modèle ci-dessous.

<questionnaire-template>

# <Titre du questionnaire>

**Objectif :** pourquoi ce questionnaire existe et la décision qui en dépend.

**De :** <l'utilisateur>, **À :** <le destinataire>, **Utilisation des réponses :** <leur destination>

## Contexte

Un paragraphe pour orienter un destinataire qui n'est pas dans la tête de l'utilisateur. Suffisamment pour bien répondre, pas une page entière.

## Comment répondre

Date limite et estimation approximative de l'effort. Les réponses partielles et les « Je ne sais pas » sont utiles : signalez tout ce dont vous n'êtes pas sûr plutôt que de l'ignorer.

## <Titre du thème>

Une section `##` par thème. Sous chacune, ses questions, de la plus importante à la moins importante. Chaque question ne porte que sur une seule idée, jamais composée, avec un espace de réponse directement en dessous, et une ligne _Pourquoi c'est important_ uniquement là où la question pourrait être mal interprétée ou susciter une réponse superficielle.

<question-example>
### Quelle charge le système doit-il supporter au lancement ?

_Pourquoi c'est important : cela détermine si nous provisionnons pour les pics de trafic dès maintenant ou si nous le reportons._

>
</question-example>

## Autre chose ?

Un point final global : y a-t-il quelque chose que nous n'avons pas demandé et que nous devrions savoir ?

</questionnaire-template>
