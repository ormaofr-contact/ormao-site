---
name: frontend-ui-engineering
description: Construit des interfaces utilisateur prêtes pour la production, accessibles et réactives. À utiliser lors de la création ou de la modification d'interfaces et de pages, de la création de composants, de la mise en œuvre de mises en page, du respect des exigences d'accessibilité WCAG, de la gestion de l'état, ou lorsque le résultat doit avoir l'apparence et la qualité d'une production professionnelle plutôt que d'un contenu généré par l'IA.
---

# Ingénierie UI Frontend

## Vue d'ensemble

Construisez des interfaces utilisateur de qualité production, accessibles, performantes et soignées visuellement. L'objectif est d'obtenir une interface qui semble avoir été conçue par un ingénieur sensibilisé au design au sein d'une entreprise de premier plan — et non générée par une IA. Cela implique une réelle adhésion au design system, une accessibilité rigoureuse, des modèles d'interaction réfléchis et l'absence totale d'« esthétique IA » générique.

## Quand l'utiliser

- Création de nouveaux composants ou pages UI
- Modification d'interfaces existantes orientées utilisateur
- Mise en œuvre de mises en page réactives (responsive)
- Ajout d'interactivité ou de gestion d'état
- Correction de problèmes visuels ou d'expérience utilisateur (UX)

## Architecture des composants

### Structure des fichiers

Regroupez tout ce qui concerne un composant au même endroit :

```
src/components/
  TaskList/
    TaskList.tsx          # Implémentation du composant
    TaskList.test.tsx     # Tests
    TaskList.stories.tsx  # Stories Storybook (le cas échéant)
    use-task-list.ts      # Hook personnalisé (si l'état est complexe)
    types.ts              # Types spécifiques au composant (si nécessaire)
```

### Modèles de composants

**Privilégiez la composition à la configuration :**

```tsx
// Bon : Composable
<Card>
  <CardHeader>
    <CardTitle>Tasks</CardTitle>
  </CardHeader>
  <CardBody>
    <TaskList tasks={tasks} />
  </CardBody>
</Card>

// À éviter : Surconfiguré
<Card
  title="Tasks"
  headerVariant="large"
  bodyPadding="md"
  content={<TaskList tasks={tasks} />}
/>
```

**Gardez des composants ciblés :**

```tsx
// Bon : Ne fait qu'une seule chose
export function TaskItem({ task, onToggle, onDelete }: TaskItemProps) {
  return (
    <li className="flex items-center gap-3 p-3">
      <Checkbox checked={task.done} onChange={() => onToggle(task.id)} />
      <span className={task.done ? 'line-through text-muted' : ''}>{task.title}</span>
      <Button variant="ghost" size="sm" onClick={() => onDelete(task.id)}>
        <TrashIcon />
      </Button>
    </li>
  );
}
```

**Séparez la récupération des données de la présentation :**

```tsx
// Conteneur : gère les données
export function TaskListContainer() {
  const { tasks, isLoading, error, refetch } = useTasks();

  if (isLoading) return <TaskListSkeleton />;
  if (error) return <ErrorState message="Failed to load tasks" retry={refetch} />;
  if (tasks.length === 0) return <EmptyState message="No tasks yet" />;

  return <TaskList tasks={tasks} />;
}

// Présentation : gère le rendu
export function TaskList({ tasks }: { tasks: Task[] }) {
  return (
    <ul role="list" className="divide-y">
      {tasks.map(task => <TaskItem key={task.id} task={task} />)}
    </ul>
  );
}
```

## Gestion de l'état

**Choisissez l'approche la plus simple qui fonctionne :**

```
État local (useState)             → État d'interface spécifique au composant
État remonté (lifted state)       → Partagé entre 2 ou 3 composants frères
Contexte                          → Thème, authentification, langue (beaucoup de lectures, peu d'écritures)
État dans l'URL (searchParams)    → Filtres, pagination, état d'interface partageable
État serveur (React Query, SWR)   → Données distantes avec mise en cache
Store global (Zustand, Redux)     → État client complexe partagé à l'échelle de l'application
```

**Évitez le prop drilling sur plus de 3 niveaux.** Si vous transmettez des props à travers des composants qui ne les utilisent pas, introduisez un contexte ou restructurez l'arborescence des composants.

## Adhésion au design system

### Qualité UI guidée par les références

Lorsque le produit nécessite une direction visuelle distincte, recueillez des éléments probants avant de choisir une mise en page :

1. Recherchez dans un catalogue de références fiable ou utilisez les références fournies par l'équipe produit.
2. Étudiez deux ou trois écrans pertinents. Consignez les décisions concernant la hiérarchie, la densité, la navigation, les contrôles, le comportement réactif et les états d'interaction.
3. Transformez ces décisions en un bref contrat de design avant l'implémentation. Définissez le rôle de l'écran, l'action principale, les états requis, les règles réactives et les modèles à rejeter.
4. Reconstruisez la structure utile avec les propres composants, tokens, contenus et langage visuel du produit. Ne copiez jamais l'image de marque, le texte propriétaire, l'imagerie ou la mise en page exacte d'un autre produit.

Utilisez les références comme des éléments d'appui, non comme des modèles prêts à l'emploi. Si aucune référence n'est disponible, documentez les hypothèses et vérifiez le résultat par rapport au design system existant du produit.

### Évitez l'esthétique IA

Les interfaces générées par IA présentent des motifs reconnaissables. Évitez-les systématiquement :

| Défaut par défaut de l'IA | Pourquoi c'est un problème | Qualité production |
|---|---|---|
| Violet/indigo omniprésent | Les modèles se rabattent par défaut sur des palettes visuellement « sûres », rendant toutes les applications identiques | Utilisez la palette de couleurs réelle du projet |
| Dégradés excessifs | Les dégradés ajoutent du bruit visuel et entrent en conflit avec la plupart des design systems | Dégradés plats ou subtils correspondant au design system |
| Tout arrondir (rounded-2xl) | L'arrondi maximal suggère la « convivialité » mais ignore la hiérarchie des rayons de courbure dans les designs réels | Rayon de bordure (border-radius) cohérent issu du design system |
| Sections hero génériques | Mise en page basée sur des modèles, sans lien avec le contenu réel ou le besoin utilisateur | Mises en page centrées sur le contenu |
| Textes de type Lorem ipsum | Le texte de substitution masque les problèmes de mise en page révélés par le contenu réel (longueur, retour à la ligne, dépassement) | Contenu de substitution réaliste |
| Espacements internes (padding) surdimensionnés partout | Un espacement généreux et uniforme détruit la hiérarchie visuelle et gaspille l'espace à l'écran | Échelle d'espacement cohérente |
| Grilles de cartes standardisées | Les grilles uniformes sont un raccourci de mise en page qui ignore la priorité de l'information et les parcours de lecture | Mises en page orientées vers un objectif précis |
| Design surchargé d'ombres | Les ombres superposées ajoutent une profondeur qui concurrence le contenu et ralentit le rendu sur les appareils peu puissants | Ombres subtiles ou inexistantes, sauf indication contraire du design system |

### Espacement et mise en page

Utilisez une échelle d'espacement cohérente. N'inventez pas de valeurs :

```css
/* Utilisez l'échelle : incréments de 0.25rem (ou selon ce que le projet utilise) */
/* Bon */     padding: 1rem;      /* 16px */
/* Bon */     gap: 0.75rem;       /* 12px */
/* Mauvais */ padding: 13px;      /* Hors échelle */
/* Mauvais */ margin-top: 2.3rem; /* Hors échelle */
```

### Typographie

Respectez la hiérarchie typographique :

```
h1 → Titre de page (un seul par page)
h2 → Titre de section
h3 → Titre de sous-section
body → Texte par défaut
small → Texte secondaire/d'aide
```

Ne sautez pas de niveaux de titre. N'utilisez pas de styles de titre pour du contenu qui n'en est pas un.

### Couleur

- Utilisez des tokens de couleur sémantiques : `text-primary`, `bg-surface`, `border-default` — pas de valeurs hexadécimales brutes
- Assurez un contraste suffisant (4,5:1 pour le texte normal, 3:1 pour le texte de grande taille)
- Ne vous reposez pas uniquement sur la couleur pour transmettre une information (utilisez aussi des icônes, du texte ou des motifs)

## Accessibilité (WCAG 2.1 AA)

Chaque composant doit respecter ces normes :

### Navigation au clavier

```tsx
// Chaque élément interactif doit être accessible au clavier
<button onClick={handleClick}>Click me</button>        // ✓ Focusable par défaut
<div onClick={handleClick}>Click me</div>               // ✗ Non focusable
<div role="button" tabIndex={0} onClick={handleClick}    // ✓ Mais préférez <button>
     onKeyDown={e => {
       if (e.key === 'Enter') handleClick();
       if (e.key === ' ') e.preventDefault();
     }}
     onKeyUp={e => {
       if (e.key === ' ') handleClick();
     }}>
  Click me
</div>
```

### Étiquettes ARIA

```tsx
// Étiquetez les éléments interactifs dépourvus de texte visible
<button aria-label="Close dialog"><XIcon /></button>

// Étiquetez les champs de formulaire
<label htmlFor="email">Email</label>
<input id="email" type="email" />

// Ou utilisez aria-label en l'absence de label visible
<input aria-label="Search tasks" type="search" />
```

### Gestion du focus

```tsx
// Déplacez le focus lorsque le contenu change
function Dialog({ isOpen, onClose }: DialogProps) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (isOpen) closeRef.current?.focus();
  }, [isOpen]);

  // Piégez le focus à l'intérieur de la boîte de dialogue lorsqu'elle est ouverte
  return (
    <dialog open={isOpen}>
      <button ref={closeRef} onClick={onClose}>Close</button>
      {/* contenu du dialogue */}
    </dialog>
  );
}
```

### États vides et d'erreur explicites

```tsx
// N'affichez pas d'écrans vides
function TaskList({ tasks }: { tasks: Task[] }) {
  if (tasks.length === 0) {
    return (
      <div role="status" className="text-center py-12">
        <TasksEmptyIcon className="mx-auto h-12 w-12 text-muted" />
        <h3 className="mt-2 text-sm font-medium">No tasks</h3>
        <p className="mt-1 text-sm text-muted">Get started by creating a new task.</p>
        <Button className="mt-4" onClick={onCreateTask}>Create Task</Button>
      </div>
    );
  }

  return <ul role="list">...</ul>;
}
```

## Design réactif (Responsive Design)

Concevez d'abord pour le mobile, puis étendez :

```tsx
// Tailwind : responsive mobile-first
<div className="
  grid grid-cols-1      /* Mobile : une seule colonne */
  sm:grid-cols-2        /* Petit écran : 2 colonnes */
  lg:grid-cols-3        /* Grand écran : 3 colonnes */
  gap-4
">
```

Testez à ces points de rupture (breakpoints) : 320px, 768px, 1024px, 1440px.

## Chargement et transitions

```tsx
// Chargement par squelette (skeleton, pas de spinners pour le contenu)
function TaskListSkeleton() {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Loading tasks">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="h-12 bg-muted animate-pulse rounded" />
      ))}
    </div>
  );
}

// Mises à jour optimistes pour une meilleure vitesse perçue
function useToggleTask() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: toggleTask,
    onMutate: async (taskId) => {
      await queryClient.cancelQueries({ queryKey: ['tasks'] });
      const previous = queryClient.getQueryData(['tasks']);

      queryClient.setQueryData(['tasks'], (old: Task[]) =>
        old.map(t => t.id === taskId ? { ...t, done: !t.done } : t)
      );

      return { previous };
    },
    onError: (_err, _taskId, context) => {
      queryClient.setQueryData(['tasks'], context?.previous);
    },
  });
}
```

## Voir aussi

Pour les exigences détaillées d'accessibilité et les outils de test, consultez `../../references/accessibility-checklist.md`.

## Justifications courantes à rejeter

| Justification | Réalité |
|---|---|
| « L'accessibilité est un bonus » | C'est une obligation légale dans de nombreuses juridictions et un standard de qualité d'ingénierie. |
| « On le rendra responsive plus tard » | Adapter le responsive après coup est 3 fois plus difficile que de le concevoir dès le départ. |
| « Le design n'est pas définitif, donc je fais l'impasse sur le style » | Utilisez les valeurs par défaut du design system. Une interface sans style donne une impression d'inachevé aux relecteurs. |
| « C'est juste un prototype » | Les prototypes finissent en code de production. Posez les bonnes bases dès le départ. |
| « L'esthétique IA convient pour l'instant » | Elle dénote une faible qualité. Utilisez le véritable design system du projet dès le début. |

## Signaux d'alerte (Red Flags)

- Composants de plus de 200 lignes (découpez-les)
- Styles en ligne (inline styles) ou valeurs de pixels arbitraires
- Absence d'états d'erreur, de chargement ou d'états vides
- Aucun test de navigation au clavier
- La couleur comme unique indicateur d'état (rouge/vert sans texte ni icônes)
- « Look IA » générique (dégradés violets, cartes surdimensionnées, mises en page standardisées)

## Vérification

Après avoir développé l'interface utilisateur :

- [ ] Le composant s'affiche sans erreur dans la console
- [ ] Tous les éléments interactifs sont accessibles au clavier (parcourez la page avec Tab)
- [ ] Le lecteur d'écran parvient à restituer le contenu et la structure de la page
- [ ] Responsive : fonctionne à 320px, 768px, 1024px, 1440px
- [ ] États de chargement, vide, d'erreur, de succès et d'autorisations gérés lorsque pertinent
- [ ] Respecte le design system du projet (espacement, couleurs, typographie)
- [ ] Le résultat final passe une revue de validation des finitions spécifique à l'UI
- [ ] Aucun avertissement d'accessibilité dans les dev tools ou axe-core
