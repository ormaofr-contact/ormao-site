---
name: writing-skills
description: À utiliser lors de la création de nouvelles compétences, de la modification de compétences existantes ou de la vérification du fonctionnement des compétences avant leur déploiement
---

# Rédiger des compétences

## Vue d'ensemble

**Rédiger des compétences EST du Test-Driven Development appliqué à la documentation des processus.**

**Les compétences personnelles se trouvent dans le répertoire de compétences de votre runtime** (`~/.claude/skills/` sur Claude Code) — consultez [codex-tools.md](../using-superpowers/references/codex-tools.md) ou [gemini-tools.md](../using-superpowers/references/gemini-tools.md) pour le chemin sur ces environnements. Codex, Copilot CLI et Gemini CLI reconnaissent également `~/.agents/skills/` comme un alias multi-runtime.

Vous écrivez des cas de test (scénarios sous pression avec des sous-agents), vous les regardez échouer (comportement de référence), vous écrivez la compétence (documentation), vous regardez les tests réussir (les agents s'y conforment) et vous refactorisez (comblez les failles).

**Principe fondamental :** Si vous n'avez pas vu un agent échouer sans la compétence, vous ne savez pas si la compétence enseigne la bonne chose.

**PRÉREQUIS INDISPENSABLE :** Vous DEVEZ comprendre superpowers:test-driven-development avant d'utiliser cette compétence. Cette compétence définit le cycle fondamental RED-GREEN-REFACTOR. La présente compétence adapte le TDD à la documentation.

**Directives officielles :** Pour les bonnes pratiques officielles d'Anthropic concernant la création de compétences, consultez references/anthropic-best-practices.md. Ce document fournit des modèles et des lignes directrices supplémentaires qui complètent l'approche axée sur le TDD de cette compétence.

## Qu'est-ce qu'une compétence ?

Une **compétence** (skill) est un guide de référence pour des techniques, des motifs ou des outils éprouvés. Les compétences aident les futurs agents à trouver et à appliquer des approches efficaces.

**Les compétences sont :** Des techniques réutilisables, des motifs, des outils, des guides de référence

**Les compétences NE sont PAS :** Des récits sur la façon dont vous avez résolu un problème une fois

## Correspondance TDD pour les compétences

| Concept TDD | Création de compétence |
|-------------|------------------------|
| **Cas de test** | Scénario sous pression avec un sous-agent |
| **Code de production** | Document de compétence (SKILL.md) |
| **Le test échoue (RED)** | L'agent enfreint la règle sans la compétence (référence de base) |
| **Le test passe (GREEN)** | L'agent se conforme avec la compétence présente |
| **Refactorisation** | Combler les failles tout en maintenant la conformité |
| **Écrire le test d'abord** | Exécuter le scénario de référence AVANT d'écrire la compétence |
| **Regarder échouer** | Documenter les rationalisations exactes utilisées par l'agent |
| **Code minimal** | Rédiger la compétence en répondant à ces violations spécifiques |
| **Regarder passer** | Vérifier que l'agent se conforme désormais |
| **Cycle de refactorisation** | Trouver de nouvelles rationalisations → combler → re-vérifier |

L'ensemble du processus de création de compétences suit le cycle RED-GREEN-REFACTOR.

## Quand créer une compétence

**Créer lorsque :**
- La technique n'était pas intuitivement évidente pour vous
- Vous vous y référeriez à nouveau à travers plusieurs projets
- Le motif s'applique largement (non spécifique à un projet)
- D'autres personnes en bénéficieraient

**Ne pas créer pour :**
- Des solutions ponctuelles
- Des pratiques standard bien documentées ailleurs
- Des conventions spécifiques à un projet (placez-les dans votre fichier d'instructions)
- Des contraintes mécaniques (si c'est contrôlable par regex/validation, automatisez-le — réservez la documentation aux décisions nécessitant du jugement)

## Types de compétences

### Technique
Méthode concrète avec des étapes à suivre (condition-based-waiting, root-cause-tracing)

### Motif (Pattern)
Façon de réfléchir aux problèmes (flatten-with-flags, test-invariants)

### Référence
Documentation d'API, guides de syntaxe, documentation d'outils (documents bureautiques)

## Structure des répertoires

```
skills/
  skill-name/
    SKILL.md              # Référence principale (obligatoire)
    supporting-file.*     # Seulement si nécessaire
```

**Espace de noms plat** - toutes les compétences dans un seul espace de noms consultable

**Fichiers séparés pour :**
1. **Références volumineuses** (100+ lignes) - documentation d'API, syntaxe complète
2. **Outils réutilisables** - scripts, utilitaires, templates

**Garder en ligne (inline) :**
- Principes et concepts
- Motifs de code (< 50 lignes)
- Tout le reste

## Rédiger SKILL.md

La `description` d'une compétence indique uniquement quand l'utiliser : les conditions de déclenchement et les symptômes, en commençant par « Use when... ». Elle ne résume jamais le flux de travail de la compétence, car un agent qui lit un résumé de workflow le suit au lieu de lire la compétence elle-même.

Lorsque vous écrivez ou modifiez le frontmatter, le nom ou la description d'une compétence, ou lorsque vous devez réduire sa taille, lisez [references/discovery.md](references/discovery.md) : le template SKILL.md, les conseils sur la description et les mots-clés, le nommage, les budgets de tokens et les références croisées vers d'autres compétences.

## Diagrammes de flux

Lorsque vous ajoutez ou modifiez un diagramme de flux dans une compétence, lisez d'abord [references/flowcharts.md](references/flowcharts.md) : quand un diagramme de flux justifie sa présence, les conventions graphviz et comment en faire le rendu.

## Exemples de code

**Un excellent exemple vaut mieux que plusieurs exemples médiocres**

Choisissez le langage le plus pertinent :
- Techniques de test → TypeScript/JavaScript
- Débogage système → Shell/Python
- Traitement de données → Python

**Un bon exemple :**
- Est complet et exécutable
- Est bien commenté pour expliquer le POURQUOI
- Provient d'un scénario réel
- Illustre clairement le motif
- Est prêt à être adapté (pas un template générique)

**À éviter :**
- Implémenter dans 5+ langages
- Créer des templates à trous
- Écrire des exemples artificiels

Vous êtes doué pour le portage de code — un seul excellent exemple suffit.

## Organisation des fichiers

### Compétence autonome
```
defense-in-depth/
  SKILL.md    # Tout est intégré dans le fichier
```
Quand : Tout le contenu tient dans le fichier, aucune référence volumineuse n'est nécessaire

### Compétence avec outil réutilisable
```
condition-based-waiting/
  SKILL.md    # Vue d'ensemble + motifs
  example.ts  # Helpers fonctionnels à adapter
```
Quand : L'outil est du code réutilisable, pas seulement un récit

### Compétence avec référence volumineuse
```
pptx/
  SKILL.md       # Vue d'ensemble + flux de travail
  pptxgenjs.md   # Référence d'API de 600 lignes
  ooxml.md       # Structure XML de 500 lignes
  scripts/       # Outils exécutables
```
Quand : La documentation de référence est trop volumineuse pour être intégrée directement

Invoquez les scripts inclus via leur interpréteur dans le texte (`bash scripts/tool.sh`, `node scripts/tool.js`), jamais par un chemin direct : certains outils d'empaquetage de plugins suppriment les bits d'exécution, et un simple `scripts/tool.sh` échouerait avec `Permission denied`.

## La loi d'airain (identique au TDD)

```
AUCUNE COMPÉTENCE SANS UN TEST QUI ÉCHOUE D'ABORD
```

Cela s'applique aux NOUVELLES compétences ET aux MODIFICATIONS de compétences existantes.

Écrire une compétence avant de tester ? Supprimez-la. Recommencez.
Modifier une compétence sans tester ? Même infraction.

**Aucune exception :**
- Pas pour les « ajouts simples »
- Pas pour « juste ajouter une section »
- Pas pour les « mises à jour de documentation »
- Ne conservez pas les modifications non testées comme « référence »
- N'« adaptez » pas pendant l'exécution des tests
- Supprimer signifie supprimer

**PRÉREQUIS INDISPENSABLE :** La compétence superpowers:test-driven-development explique pourquoi cela est crucial. Les mêmes principes s'appliquent à la documentation.

## Tester tous les types de compétences

Différents types de compétences nécessitent différentes approches de test :

### Compétences imposant une discipline (règles/exigences)

**Exemples :** TDD, verification-before-completion, designing-before-coding

**Tester avec :**
- Des questions académiques : Comprennent-ils les règles ?
- Des scénarios sous pression : Se conforment-ils sous stress ?
- Plusieurs pressions combinées : temps + coûts irrécupérables + épuisement
- Identifier les rationalisations et ajouter des parades explicites

**Critère de succès :** L'agent suit la règle sous une pression maximale

### Compétences techniques (guides pratiques)

**Exemples :** condition-based-waiting, root-cause-tracing, defensive-programming

**Tester avec :**
- Des scénarios d'application : Peuvent-ils appliquer la technique correctement ?
- Des scénarios de variation : Gèrent-ils les cas limites ?
- Des tests d'informations manquantes : Les instructions présentent-elles des lacunes ?

**Critère de succès :** L'agent applique avec succès la technique à un nouveau scénario

### Compétences de motifs (modèles mentaux)

**Exemples :** reducing-complexity, concepts d'information-hiding

**Tester avec :**
- Des scénarios de reconnaissance : Reconnaissent-ils quand le motif s'applique ?
- Des scénarios d'application : Peuvent-ils utiliser le modèle mental ?
- Des contre-exemples : Savent-ils quand NE PAS appliquer ?

**Critère de succès :** L'agent identifie correctement quand et comment appliquer le motif

### Compétences de référence (documentation/API)

**Exemples :** Documentation d'API, références de commandes, guides de bibliothèques

**Tester avec :**
- Des scénarios d'extraction : Peuvent-ils trouver la bonne information ?
- Des scénarios d'application : Peuvent-ils utiliser correctement ce qu'ils ont trouvé ?
- Des tests de lacunes : Les cas d'usage courants sont-ils couverts ?

**Critère de succès :** L'agent trouve et applique correctement l'information de référence

## Rationalisations courantes pour éviter les tests

| Excuse | Réalité |
|--------|---------|
| « La compétence est parfaitement claire » | Clair pour vous ≠ clair pour les autres agents. Testez-la. |
| « C'est juste une référence » | Les références peuvent comporter des lacunes, des sections floues. Testez l'extraction. |
| « Tester est disproportionné » | Les compétences non testées ont des problèmes. Toujours. 15 min de test font gagner des heures. |
| « Je testerai si des problèmes apparaissent » | Problèmes = les agents ne peuvent pas utiliser la compétence. Testez AVANT de déployer. |
| « Trop fastidieux à tester » | Tester est moins fastidieux que de déboguer une mauvaise compétence en production. |
| « J'ai confiance, c'est bon » | L'excès de confiance garantit des problèmes. Testez quand même. |
| « Une revue académique suffit » | Lire ≠ utiliser. Testez des scénarios d'application. |
| « Pas le temps de tester » | Déployer une compétence non testée fait perdre plus de temps à la corriger plus tard. |

**Toutes ces excuses signifient : Testez avant de déployer. Sans exception.**

## Adapter la forme au type d'échec

Avant de rédiger des consignes, classifiez l'échec de référence (baseline). La forme qui blinde un type d'échec peut se retourner de façon mesurable contre un autre.

| Échec de référence | Forme appropriée | Mauvaise forme |
|---|---|---|
| Ignore/enfreint une règle sous pression (sait pertinemment ce qu'il faut faire, mais le fait quand même) | Interdiction + tableau de rationalisations + signaux d'alerte (voir references/bulletproofing.md) | Conseils souples (« préférer... », « envisager... ») |
| Se conforme, mais la sortie a une mauvaise structure (prompt boursouflé, verdict enfoui, spécification répétée) | Recette positive ou contrat : énoncer ce que la sortie EST — ses parties, dans l'ordre | Liste d'interdictions (« ne pas répéter », « ne jamais raconter ») |
| Omet un élément obligatoire dans quelque chose qu'il produit déjà | Structurel : champ ou emplacement OBLIGATOIRE (REQUIRED) dans le template qu'il remplit | Rappels sous forme de texte près du template |
| Le comportement doit dépendre d'une condition | Conditionnel indexé sur un prédicat observable (« si le brief existe, le référencer ») | Règle inconditionnelle + clauses d'exemption |

**Pourquoi les interdictions échouent face aux problèmes de mise en forme :** sous une incitation concurrente (« rendre le prompt autonome »), les agents négocient avec les « ne pas faire X ». Lors de tests comparatifs directs sur les instructions de dispatch de prompt, la variante avec interdiction a produit nettement plus de contenu indésirable que la variante avec recette (distributions complètement disjointes), et s'est avérée pire que le contrôle sans consigne — micro-testez votre propre cas plutôt que de présumer, mais ne recourez jamais à l'interdiction par défaut. Une recette ne laisse rien à négocier : la sortie correspond à la forme spécifiée, ou non.

**Règles quelle que soit la forme choisie :**
- **Pas de clauses de nuance.** « Ne faites pas X sauf si c'est important » rouvre la négociation — l'ajout d'une seule clause de nuance à une recette gagnante l'a fait passer de cohérente à instable dans les mêmes tests de formulation. Exprimez une exception réelle sous forme de conditionnel propre indexé sur un prédicat observable.
- **Les clauses d'exemption ne restreignent pas la portée.** « Cette limite ne s'applique pas aux blocs de code » supprime malgré tout les blocs de code. Si une partie de la sortie doit être exemptée, restructurez pour que la règle ne puisse pas l'atteindre.

## Blindage contre les rationalisations

Lorsque l'échec de référence est un échec de discipline, lisez
[references/bulletproofing.md](references/bulletproofing.md) avant d'écrire
les consignes : combler les failles, la frontière entre l'esprit et la lettre, le
tableau de rationalisations et la liste des signaux d'alerte.

## RED-GREEN-REFACTOR pour les compétences

Suivez le cycle TDD :

### RED : Écrire un test qui échoue (référence de base)

Exécutez un scénario sous pression avec un sous-agent SANS la compétence. Documentez le comportement exact :
- Quels choix ont-ils faits ?
- Quelles rationalisations ont-ils utilisées (au mot près) ?
- Quelles pressions ont déclenché les infractions ?

C'est l'étape « regarder le test échouer » — vous devez voir ce que les agents font naturellement avant d'écrire la compétence.

### GREEN : Écrire la compétence minimale

Rédigez la compétence qui répond à ces rationalisations spécifiques. N'ajoutez pas de contenu superflu pour des cas hypothétiques.

Exécutez les mêmes scénarios AVEC la compétence. L'agent doit désormais se conformer.

### REFACTOR : Combler les failles

L'agent a trouvé une nouvelle rationalisation ? Ajoutez une parade explicite. Re-testez jusqu'à ce que ce soit blindé.

### Micro-tester la formulation avant les scénarios complets

Les scénarios complets sous pression constituent la validation finale, mais ils sont lents et coûteux par itération. Vérifiez d'abord la formulation elle-même à l'aide de micro-tests :

1. **Un échantillon avec contexte neuf par appel** — un appel d'API brut, ou un sous-agent one-shot si vous n'avez pas accès à l'API. System prompt = le contexte réaliste dans lequel vivra la consigne (la compétence complète ou le template de prompt, pas la consigne isolée) ; message utilisateur = une tâche qui incite à l'échec.
2. **Inclure toujours un contrôle sans consigne.** Si le contrôle ne manifeste pas l'échec, il n'y a rien à corriger — arrêtez-vous, ne rédigez pas la consigne.
3. **5+ répétitions par variante.** Les échantillons uniques sont trompeurs.
4. **Lire manuellement chaque correspondance signalée.** Évaluez de manière programmatique si vous le souhaitez, mais les échos de templates et les contre-exemples cités se font passer pour des correspondances ; les comptages automatisés à eux seuls surestiment à la fois l'échec et le succès.
5. **La variance est une métrique.** Quand une consigne porte ses fruits, les répétitions convergent vers la même forme. Cinq interprétations différentes sur cinq répétitions signifient que la formulation n'est pas contraignante — resserrez la structure avant d'ajouter des mots.

Les micro-tests vérifient la formulation ; ils ne remplacent pas les scénarios sous pression pour les compétences de discipline.

**Méthodologie de test :** Consultez [references/testing-skills-with-subagents.md](references/testing-skills-with-subagents.md) pour la méthodologie de test complète :
- Comment rédiger des scénarios sous pression
- Les types de pression (temps, coûts irrécupérables, autorité, épuisement)
- Combler les brèches méthodiquement
- Techniques de méta-test

## Anti-patterns

### ❌ Exemple narratif
« Dans la session 2025-10-03, nous avons constaté qu'un projectDir vide provoquait... »
**Pourquoi c'est mauvais :** Trop spécifique, non réutilisable

### ❌ Dilution multilingue
example-js.js, example-py.py, example-go.go
**Pourquoi c'est mauvais :** Qualité médiocre, fardeau de maintenance

### ❌ Du code dans les diagrammes de flux
```dot
step1 [label="import fs"];
step2 [label="read file"];
```
**Pourquoi c'est mauvais :** Impossible à copier-coller, difficile à lire

### ❌ Libellés génériques
helper1, helper2, step3, pattern4
**Pourquoi c'est mauvais :** Les libellés doivent avoir un sens sémantique

## STOP : Avant de passer à la compétence suivante

**Après avoir rédigé N'IMPORTE QUELLE compétence, vous DEVEZ VOUS ARRÊTER et terminer le processus de déploiement.**

**Ne PAS :**
- Créer plusieurs compétences en lot sans tester chacune d'elles
- Passer à la compétence suivante avant que l'actuelle ne soit vérifiée
- Sauter les tests parce que « le traitement par lot est plus efficace »

**La liste de contrôle de déploiement ci-dessous est OBLIGATOIRE pour CHAQUE compétence.**

Déployer des compétences non testées = déployer du code non testé. C'est une violation des standards de qualité.

## Liste de contrôle de création de compétence (adaptée du TDD)

**IMPORTANT : Créez une tâche à faire pour CHAQUE élément de la liste ci-dessous.**

**Phase RED - Écrire un test qui échoue :**
- [ ] Créer des scénarios sous pression (3+ pressions combinées pour les compétences de discipline)
- [ ] Exécuter les scénarios SANS la compétence - documenter textuellement le comportement de référence
- [ ] Identifier les motifs récurrents dans les rationalisations/échecs

**Phase GREEN - Écrire la compétence minimale :**
- [ ] Le nom utilise uniquement des lettres, des chiffres, des traits d'union (pas de parenthèses/caractères spéciaux)
- [ ] Frontmatter YAML avec les champs requis `name` et `description` (max 1024 caractères ; voir la [spécification](https://agentskills.io/specification))
- [ ] La description commence par « Use when... » et inclut les déclencheurs/symptômes spécifiques
- [ ] Description rédigée à la troisième personne
- [ ] Mots-clés présents dans tout le texte pour la recherche (erreurs, symptômes, outils)
- [ ] Vue d'ensemble claire avec le principe fondamental
- [ ] Répondre aux échecs de référence spécifiques identifiés en phase RED
- [ ] La forme des consignes correspond au type d'échec (voir Adapter la forme au type d'échec)
- [ ] Pour les consignes de cadrage comportemental : formulation micro-testée par rapport à un contrôle sans consigne (5+ répétitions, chaque correspondance signalée lue manuellement) — Sans objet pour les compétences de pure référence
- [ ] Code intégré en ligne OU lien vers un fichier séparé
- [ ] Un seul excellent exemple (pas de version multilingue)
- [ ] Exécuter les scénarios AVEC la compétence - vérifier que les agents s'y conforment désormais

**Phase REFACTOR - Combler les failles :**
- [ ] Identifier les NOUVELLES rationalisations issues des tests
- [ ] Ajouter des contre-mesures explicites (s'il s'agit d'une compétence de discipline)
- [ ] Construire le tableau de rationalisations à partir de toutes les itérations de test
- [ ] Créer la liste des signaux d'alerte (red flags)
- [ ] Re-tester jusqu'à ce que ce soit blindé

**Contrôles de qualité :**
- [ ] Petit diagramme de flux uniquement si la décision n'est pas évidente
- [ ] Tableau de référence rapide
- [ ] Section des erreurs courantes
- [ ] Aucun récit narratif d'expérience
- [ ] Fichiers annexes uniquement pour les outils ou les références volumineuses

**Déploiement :**
- [ ] Commiter la compétence dans git et pousser vers votre fork (si configuré)
- [ ] Envisager de contribuer en amont via une PR (si utile à grande échelle)

## Flux de découverte

Comment les futurs agents trouvent votre compétence :

1. **Rencontre un problème** (« les tests sont instables »)
2. **Recherche dans les compétences** (grep dans les descriptions, parcourt les catégories)
3. **Trouve SKILL** (la description correspond)
4. **Survole la vue d'ensemble** (est-ce pertinent ?)
5. **Lit les motifs** (tableau de référence rapide)
6. **Charge l'exemple** (uniquement lors de l'implémentation)

**Optimisez pour ce flux** - placez les termes recherchables dès le début et fréquemment.
