---
name: documentation-and-adrs
description: Enregistre les décisions et la documentation. À utiliser lorsque vous devez consigner une décision d'architecture (ADR) ou le raisonnement derrière un choix de conception, lors de la modification d'API publiques, du déploiement de fonctionnalités, ou lorsque vous devez enregistrer le contexte dont les futurs ingénieurs et agents auront besoin pour comprendre la base de code.
---

# Documentation et ADR

## Vue d'ensemble

Documentez les décisions, pas seulement le code. La documentation la plus précieuse capture le *pourquoi* — le contexte, les contraintes et les compromis qui ont mené à une décision. Le code montre *ce qui* a été construit ; la documentation explique *pourquoi cela a été conçu ainsi* et *quelles alternatives ont été envisagées*. Ce contexte est essentiel pour les futurs humains et agents qui travailleront sur la base de code.

## Quand l'utiliser

- Prise d'une décision d'architecture importante
- Choix entre plusieurs approches concurrentes
- Ajout ou modification d'une API publique
- Livraison d'une fonctionnalité modifiant le comportement perçu par l'utilisateur
- Intégration de nouveaux membres dans l'équipe (ou d'agents) sur le projet
- Lorsque vous vous surprenez à expliquer la même chose à plusieurs reprises

**Quand NE PAS l'utiliser :** Ne documentez pas le code évident. N'ajoutez pas de commentaires qui répètent simplement ce que le code dit déjà. N'écrivez pas de documentation pour des prototypes jetables.

## Registres de décisions d'architecture (ADR)

Les ADR capturent le raisonnement sous-jacent aux décisions techniques significatives. Il s'agit de la documentation à plus forte valeur que vous puissiez rédiger.

### Quand rédiger un ADR

- Choix d'un framework, d'une bibliothèque ou d'une dépendance majeure
- Conception d'un modèle de données ou d'un schéma de base de données
- Sélection d'une stratégie d'authentification
- Décision concernant une architecture d'API (REST vs GraphQL vs tRPC)
- Choix entre plusieurs outils de build, plateformes d'hébergement ou infrastructures
- Toute décision dont l'annulation ou la modification serait coûteuse

### Respecter d'abord les conventions existantes

Avant de créer un ADR, inspectez le contexte disponible dans le dépôt pour identifier une convention établie — ADR existants, consignes du projet et configuration ou outillage liés aux ADR (par ex. un fichier `.adr-dir`). Une convention établie prévaut sur les règles par défaut ci-dessous. Respectez :

- **Emplacement et format** — par ex. `docs/adr/*.md`, `Documentation/Decisions/*.rst`, une structure MADR ou une configuration `adr-tools`. Utilisez le répertoire existant, l'extension de fichier et le format de balisage (Markdown vs reStructuredText).
- **Numérotation et nommage** — poursuivez la séquence et le schéma de nommage existants (`ADR-004-Title.rst`, `0004-title.md`, …) ; ne repartez pas à 001 et n'introduisez pas un second format.
- **Titres de section** — réutilisez l'ensemble de titres déjà présent dans le projet plutôt que d'imposer ceux de ce modèle.

Si les conventions observées sont contradictoires, signalez le conflit au lieu d'introduire discrètement une nouvelle approche. N'appliquez les valeurs par défaut ci-dessous que si aucune convention ne peut être établie.

### Modèle d'ADR

Stockez les ADR dans `docs/decisions/` avec une numérotation séquentielle (sauf si le projet utilise déjà un autre emplacement — voir ci-dessus) :

```markdown
# ADR-001: Use PostgreSQL for primary database

## Status
Proposed | Accepted | Superseded by ADR-XXX | Deprecated

## Date
2025-01-15

## Context
We need a primary database for the task management application. Key requirements:
- Relational data model (users, tasks, teams with relationships)
- ACID transactions for task state changes
- Support for full-text search on task content
- Managed hosting available (for small team, limited ops capacity)

## Decision
Use PostgreSQL with Prisma ORM.

## Alternatives Considered

### MongoDB
- Pros: Flexible schema, easy to start with
- Cons: Our data is inherently relational; would need to manage relationships manually
- Rejected: Relational data in a document store leads to complex joins or data duplication

### SQLite
- Pros: Zero configuration, embedded, fast for reads
- Cons: Limited concurrent write support, no managed hosting for production
- Rejected: Not suitable for multi-user web application in production

### MySQL
- Pros: Mature, widely supported
- Cons: PostgreSQL has better JSON support, full-text search, and ecosystem tooling
- Rejected: PostgreSQL is the better fit for our feature requirements

## Consequences
- Prisma provides type-safe database access and migration management
- We can use PostgreSQL's full-text search instead of adding Elasticsearch
- Team needs PostgreSQL knowledge (standard skill, low risk)
- Hosting on managed service (Supabase, Neon, or RDS)
```

### Cycle de vie d'un ADR

```
PROPOSED → ACCEPTED → (SUPERSEDED or DEPRECATED)
```

- **Ne supprimez pas les anciens ADR.** Ils préservent le contexte historique.
- Lorsqu'une décision change, rédigez un nouvel ADR qui référence et remplace l'ancien.

## Documentation inline

### Quand commenter

Commentez le *pourquoi*, pas le *quoi* :

```typescript
// BAD: Restates the code
// Increment counter by 1
counter += 1;

// GOOD: Explains non-obvious intent
// Rate limit uses a sliding window — reset counter at window boundary,
// not on a fixed schedule, to prevent burst attacks at window edges
if (now - windowStart > WINDOW_SIZE_MS) {
  counter = 0;
  windowStart = now;
}
```

### Quand NE PAS commenter

```typescript
// Don't comment self-explanatory code
function calculateTotal(items: CartItem[]): number {
  return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

// Don't leave TODO comments for things you should just do now
// TODO: add error handling  ← Just add it

// Don't leave commented-out code
// const oldImplementation = () => { ... }  ← Delete it, git has history
```

### Documenter les pièges connus

```typescript
/**
 * IMPORTANT: This function must be called before the first render.
 * If called after hydration, it causes a flash of unstyled content
 * because the theme context isn't available during SSR.
 *
 * See ADR-003 for the full design rationale.
 */
export function initializeTheme(theme: Theme): void {
  // ...
}
```

## Documentation d'API

Pour les API publiques (REST, GraphQL, interfaces de bibliothèques) :

### En ligne avec les types (recommandé pour TypeScript)

```typescript
/**
 * Creates a new task.
 *
 * @param input - Task creation data (title required, description optional)
 * @returns The created task with server-generated ID and timestamps
 * @throws {ValidationError} If title is empty or exceeds 200 characters
 * @throws {AuthenticationError} If the user is not authenticated
 *
 * @example
 * const task = await createTask({ title: 'Buy groceries' });
 * console.log(task.id); // "task_abc123"
 */
export async function createTask(input: CreateTaskInput): Promise<Task> {
  // ...
}
```

### OpenAPI / Swagger pour les API REST

```yaml
paths:
  /api/tasks:
    post:
      summary: Create a task
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateTaskInput'
      responses:
        '201':
          description: Task created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Task'
        '422':
          description: Validation error
```

## Structure du README

Chaque projet doit comporter un README contenant :

```markdown
# Project Name

One-paragraph description of what this project does.

## Quick Start
1. Clone the repo
2. Install dependencies: `npm install`
3. Set up environment: `cp .env.example .env`
4. Run the dev server: `npm run dev`

## Commands
| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm test` | Run tests |
| `npm run build` | Production build |
| `npm run lint` | Run linter |

## Architecture
Brief overview of the project structure and key design decisions.
Link to ADRs for details.

## Contributing
How to contribute, coding standards, PR process.
```

## Tenue du journal des modifications (Changelog)

Pour les fonctionnalités déployées :

```markdown
# Changelog

## [1.2.0] - 2025-01-20
### Added
- Task sharing: users can share tasks with team members (#123)
- Email notifications for task assignments (#124)

### Fixed
- Duplicate tasks appearing when rapidly clicking create button (#125)

### Changed
- Task list now loads 50 items per page (was 20) for better UX (#126)
```

## Documentation pour les agents

Prise en compte spécifique du contexte des agents IA :

- **Fichiers CLAUDE.md / règles** — Documentez les conventions du projet afin que les agents les respectent
- **Fichiers de spécification** — Maintenez les specs à jour pour que les agents construisent la bonne fonctionnalité
- **ADR** — Aidez les agents à comprendre pourquoi les décisions passées ont été prises (évite de réexaminer des choix déjà arrêtés)
- **Pièges documentés inline** — Empêchez les agents de tomber dans des pièges connus

## Révision rédactionnelle

Après avoir vérifié le contenu technique, relisez la rédaction pour les personnes qui l'utiliseront. Une formulation plus claire ne doit pas altérer la décision ni ses limites.

1. Identifiez les détails indispensables qui doivent subsister après modification : noms, nombres et unités, commandes, chemins, liens, conditions, compromis et incertitudes. Vérifiez-les par rapport au code et au contexte décisionnel disponible ; signalez tout élément que vous ne pouvez pas étayer.
2. Remplacez les introductions passe-partout, les adjectifs promotionnels et les résumés redondants par les informations concrètes nécessaires au lecteur. Ne remplacez pas une affirmation non étayée par un exemple inventé ou une garantie plus forte. Conservez les répétitions techniques indispensables ainsi que la terminologie établie du projet.
3. Comparez le document révisé avec l'original et ses sources. Rétablissez toute nuance ou mise en garde perdue, vérifiez que les exemples de commandes et de code fonctionnent toujours comme documenté, et explicitez toute question factuelle non résolue au lieu de la dissimuler sous des artifices de style.

## Justifications courantes

| Justification | Réalité |
|---|---|
| « Le code s'auto-documente » | Le code montre ce qu'il fait. Il n'explique pas pourquoi, quelles alternatives ont été écartées, ni quelles contraintes s'appliquent. |
| « Nous rédigerons la doc quand l'API sera stabilisée » | Les API se stabilisent plus vite lorsqu'elles sont documentées. La documentation est le premier test de la conception. |
| « Personne ne lit la documentation » | Les agents la lisent. Les futurs ingénieurs la lisent. Vous-même dans 3 mois la lirez. |
| « Les ADR sont une surcharge inutile » | Un ADR de 10 minutes évite un débat de 2 heures sur la même décision six mois plus tard. |
| « Les commentaires deviennent obsolètes » | Les commentaires sur le *pourquoi* restent stables. Les commentaires sur le *quoi* deviennent obsolètes — c'est pourquoi vous ne devez rédiger que les premiers. |

## Signaux d'alerte

- Décisions d'architecture sans justification écrite
- API publiques dépourvues de documentation ou de types
- README qui n'explique pas comment lancer le projet
- Code commenté au lieu d'être supprimé
- Commentaires TODO présents depuis plusieurs semaines
- Absence d'ADR dans un projet comportant des choix d'architecture majeurs
- Documentation qui paraphrase le code au lieu d'en expliquer l'intention

## Vérification

Après avoir documenté :

- [ ] Des ADR existent pour toutes les décisions d'architecture significatives
- [ ] Le README couvre le démarrage rapide, les commandes et une vue d'ensemble de l'architecture
- [ ] Les fonctions d'API comportent une documentation de leurs paramètres et types de retour
- [ ] Les pièges connus sont documentés inline aux endroits pertinents
- [ ] Aucun code commenté ne subsiste
- [ ] Les fichiers de règles (CLAUDE.md, etc.) sont à jour et exacts
- [ ] Les révisions rédactionnelles préservent les détails des sources, les compromis décisionnels et les nuances sans ajouter de garanties injustifiées
