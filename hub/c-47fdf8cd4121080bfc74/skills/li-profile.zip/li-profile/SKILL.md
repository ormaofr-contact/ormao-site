---
name: li-profile
description: >-
  Évalue un profil LinkedIn sur 100 points selon une grille en 12 critères et
  réécrit les parties qui font perdre des points : titre, infos, expérience,
  sélection, bannière. À utiliser lorsque l'utilisateur dit « optimise mon
  profil », « note mon LinkedIn », « réécris mon titre », « améliore ma section
  infos », ou colle son profil et demande comment il est perçu.
---

# li-profile

Un profil n'est pas un CV. Un CV répond à la question « qu'avez-vous fait ? ». Un profil
répond à « devrais-je contacter cette personne ? », et il y répond en environ
quatre secondes, grâce au titre et aux deux premières lignes de la section Infos.

## Entrée

Demandez à l'utilisateur de coller : le titre, la section Infos, le poste
actuel et les deux dernières expériences professionnelles, ainsi que la présence
ou non d'une bannière et d'une section Sélection. Une capture d'écran du haut du
profil suffit pour la première passe. Ne vous connectez pas à LinkedIn à sa place.

## Évaluation

Lisez `rubric.json` dans ce dossier. Douze critères, 100 points, chacun avec ce
à quoi ressemble la note maximale. Notez chaque élément, affichez le tableau et
donnez le total. Soyez honnête : la plupart des profils se situent entre 30 et 40
points à la première passe, et une note généreuse ne sert à rien.

```
PROFILE SCORE  41/100

  headline            3/12   job title only, no outcome, no audience
  about first 2 lines 2/10   opens with "passionate about"
  about body          4/10   history, not offer
  featured            0/8    empty
  banner              0/6    default blue
  ...
```

## Ensuite, réécrire dans cet ordre

Corrigez dans l'ordre décroissant des points perdus. Ne réécrivez pas tout d'un coup —
l'utilisateur doit réellement coller chacun de ces éléments.

**1. Titre (220 caractères).** La formule qui fonctionne :
`{ce que vous faites pour qui} | {preuve} | {comment démarrer}`. Pas votre intitulé de poste.
Pas « J'aide X à faire Y » dans les trois premiers mots, formule par laquelle un profil
sur deux commence désormais. Proposez trois options.

**2. Infos, les deux premières lignes.** Tout ce qui suit la ligne 2 est masqué derrière
« voir plus » sur mobile, donc ces deux lignes représentent l'intégralité de la section
Infos pour la plupart des lecteurs. Elles doivent indiquer qui vous aidez et ce qui change.
Pas de « passionné », pas de « orienté résultats », pas de bio à la troisième personne,
pas d'accroche commençant par votre propre nom.

**3. Corps de la section Infos.** Rédigé pour un seul lecteur, à la deuxième personne.
Structure : le problème qu'il rencontre, ce que vous faites pour y remédier, une preuve
chiffrée, ce qu'il faut faire ensuite. Moins de 1 400 caractères, même si la limite
est de 2 600.

**4. Sélection.** Trois éléments : le meilleur post, l'élément de preuve, le moyen de
contact. Une section Sélection vide fait perdre huit points alors que c'est le seul
endroit du profil que vous contrôlez totalement.

**5. Expérience.** Chaque poste a droit à une ligne de périmètre et deux à trois puces
qui sont des résultats chiffrés, et non des responsabilités. Résumez tout ce qui a plus
de dix ans en une seule ligne.

**6. Bannière.** Une phrase de positionnement et un moyen de vous joindre. Le dégradé
bleu par défaut est le signal le plus clair sur la page qu'il n'y a personne aux commandes.

## Sortie

Tableau des scores, puis les réécritures sous forme de blocs prêts à être copiés dans
l'ordre des priorités de correction, chacun ayant déjà été passé par `/li-human`.
Réévaluez à la fin et affichez l'écart en toute honnêteté — si la réécriture atteint 88
et non 98, indiquez 88, et précisez ce qu'exigent les points restants (généralement des
recommandations, une vraie bannière et un historique de publication, rien de tout cela
ne pouvant être créé par une réécriture).

Rien n'est enregistré sur LinkedIn par cette compétence. C'est l'utilisateur qui colle
chaque section sur son profil.
