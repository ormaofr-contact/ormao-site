---
name: portfolio-case-study-writer
description: Transforme les points clés d'un CV en études de cas détaillées pour un portfolio
---

# Rédacteur d'études de cas de portfolio

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Souhaite créer des études de cas pour son portfolio
- A besoin de développer les points de son CV en présentations détaillées
- Construit un site web de portfolio
- Souhaite présenter ses projets en profondeur
- Mentionne : "case study", "portfolio", "project writeup", "work samples", "portfolio piece"

## Compétences clés

- Transformer les points clés d'un CV en études de cas détaillées
- Structurer les études de cas pour un impact maximal
- Créer des récits de projet captivants
- Équilibrer les détails techniques et le contexte business
- Mettre en forme pour les sites web de portfolio
- Adapter le niveau de détail au public visé

## Objectif de l'étude de cas

**Pourquoi les études de cas sont importantes :**
- Le CV montre CE QUE vous avez fait ; l'étude de cas montre COMMENT et POURQUOI
- Démontrer le raisonnement, pas seulement les résultats
- Permettre une mise en valeur plus approfondie des compétences
- Vous démarquer des autres candidats
- Exigé pour de nombreux postes de PM, UX et métiers créatifs

## La structure d'une étude de cas

### Structure type

```
1. Overview (Project summary)
2. Problem (What needed to be solved)
3. Process (How you approached it)
4. Solution (What you created/delivered)
5. Results (The impact)
6. Learnings (What you'd do differently)
```

### Temps de lecture
- **Lecture rapide :** 3 à 5 minutes (essentiel pour un portfolio)
- **Lecture approfondie :** 10 à 15 minutes (pour les lecteurs intéressés)

## Guide section par section

### 1. Section Vue d'ensemble

**Objectif :** Accrocher le lecteur, poser le contexte

**À inclure :**
- Nom du projet et entreprise
- Votre rôle
- Calendrier / Durée
- Taille de l'équipe
- Résumé de l'impact en une phrase

**Exemple :**
```
# Redesigning the Checkout Flow

**Company:** E-Commerce Inc.
**Role:** Lead Product Designer
**Timeline:** 6 weeks
**Team:** 2 designers, 3 engineers, 1 PM

**Summary:** Reduced cart abandonment by 35% through a streamlined 3-step checkout process, generating $2M in recovered revenue.
```

### 2. Section Problème

**Objectif :** Expliquer pourquoi ce travail était important

**À inclure :**
- Contexte business
- Points de friction des utilisateurs
- Métriques clés ou objectifs
- Contraintes

**Exemple :**
```
## The Problem

E-Commerce Inc. was experiencing 68% cart abandonment—significantly higher than the industry average of 55%. Exit surveys and user research revealed several issues:

- **Too many steps:** Our checkout had 7 screens
- **Forced account creation:** Users had to register before purchasing
- **Hidden costs:** Shipping wasn't shown until step 5
- **Mobile friction:** Forms weren't optimized for mobile

**Goal:** Reduce cart abandonment to below 50% within 3 months.

**Constraints:**
- No changes to existing payment integrations
- Had to maintain PCI compliance
- 6-week timeline before holiday season
```

### 3. Section Processus

**Objectif :** Montrer votre démarche intellectuelle et votre méthodologie

**À inclure :**
- Recherches menées
- Parties prenantes impliquées
- Hypothèses formulées
- Options envisagées
- Décisions prises (et pourquoi)

**Exemple :**
```
## Process

### Research
I started by understanding the problem deeply:
- Analyzed Mixpanel funnel data for drop-off points
- Conducted 10 user interviews with recent abandoners
- Reviewed heatmaps and session recordings
- Benchmarked against 5 competitor checkout flows

**Key Insight:** 73% of drop-offs occurred at the account creation screen. Users wanted to purchase, not commit to a relationship.

### Ideation
I explored several approaches:
1. Guest checkout only (simplest)
2. Social login options (lower friction)
3. Progressive profiling (collect info over time)
4. One-page checkout (Amazon-style)

After weighing feasibility, timeline, and impact, we chose a hybrid approach...

### Decisions Made
- **Guest checkout first:** Made registration optional and post-purchase
- **Transparent pricing:** Showed shipping on the first screen
- **Mobile-first design:** Designed for mobile, then adapted for desktop
- **Progress indicator:** Added clear "Step 1 of 3" indicator
```

### 4. Section Solution

**Objectif :** Montrer ce que vous avez réellement créé

**À inclure :**
- Éléments visuels (maquettes, captures d'écran, diagrammes)
- Fonctionnalités / modifications clés
- Mise en œuvre technique (si pertinent)
- Comment cela a répondu aux problèmes

**Exemple :**
```
## Solution

### The New Checkout Flow

**Before:** 7 screens with mandatory registration
**After:** 3 screens with optional guest checkout

[IMAGE: Before/After comparison]

### Key Changes

**1. Transparent Pricing Widget**
[IMAGE: Pricing widget mockup]
Showed order total, shipping, and taxes from the start. No surprises.

**2. Guest Checkout Option**
[IMAGE: Guest checkout screen]
Made account creation optional with clear value proposition for why to register.

**3. Smart Form Design**
[IMAGE: Form design]
- Single-column layout on mobile
- Auto-format for phone/card numbers
- Address autocomplete integration
- Clear error messaging

**4. Trust Signals**
Added security badges, money-back guarantee, and customer service contact throughout the flow.
```

### 5. Section Résultats

**Objectif :** Prouver l'impact avec des données chiffrées

**À inclure :**
- Résultats quantitatifs (avec période temporelle)
- Comparaison par rapport aux objectifs
- Métriques secondaires impactées
- Impact business

**Exemple :**
```
## Results

### Primary Metrics (90 days post-launch)

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Cart Abandonment | 68% | 44% | -35% |
| Checkout Completion | 32% | 56% | +75% |
| Mobile Conversion | 18% | 41% | +128% |
| Revenue per Visitor | $2.40 | $3.85 | +60% |

### Business Impact
- **$2M additional revenue** in first quarter
- **15% increase in mobile orders**
- **Customer support tickets about checkout** dropped by 45%

### Secondary Effects
- Account creation actually increased 20% (post-purchase)
- Average order value stayed stable
- Return customer rate improved
```

### 6. Section Enseignements

**Objectif :** Démontrer un état d'esprit de progression et du recul critique

**À inclure :**
- Ce qui a bien fonctionné
- Ce que vous feriez différemment
- Défis inattendus
- Compétences développées

**Exemple :**
```
## Learnings

### What Worked
- **Early user research** prevented us from building the wrong solution
- **Cross-functional alignment** meetings kept everyone on the same page
- **Launching with analytics** let us measure impact immediately

### What I'd Do Differently
- **More A/B testing:** We launched the full redesign at once. Would have preferred to test individual changes to understand what drove results.
- **Earlier mobile focus:** We designed desktop-first then adapted. Starting mobile-first would have been more efficient.
- **Stakeholder education:** Spent too long convincing leadership. Would start stakeholder alignment earlier next time.

### Skills Developed
- Advanced Figma prototyping
- Working with A/B testing frameworks
- Presenting data-driven design decisions to executives
```

## Types d'études de cas par rôle

### Étude de cas Product Manager
**Mettre l'accent sur :**
- La stratégie et la priorisation
- La gestion des parties prenantes
- Les métriques et les résultats
- Les compromis techniques

### Étude de cas UX/Product Designer
**Mettre l'accent sur :**
- La recherche utilisateur
- Le processus de conception
- Les livrables visuels
- Les améliorations de l'utilisabilité

### Étude de cas Software Engineer
**Mettre l'accent sur :**
- L'architecture technique
- L'approche de résolution de problèmes
- La conception de systèmes (system design)
- La qualité du code / les performances

### Étude de cas Marketing
**Mettre l'accent sur :**
- La stratégie et le ciblage
- L'exécution créative
- La performance des canaux
- Le ROI et l'attribution

## Éléments visuels

### Visuels indispensables
- Comparaisons avant/après
- Écrans clés ou livrables
- Schémas de processus
- Graphiques de résultats

### Visuels secondaires appréciables
- Cartographies du parcours utilisateur (user journey maps)
- Évolution des wireframes
- Documents de recherche
- Photos de l'équipe

### Conseils pour les visuels
- Utiliser des dimensions d'image uniformes
- Ajouter des légendes expliquant chaque image
- Flouter les données sensibles si nécessaire
- S'assurer que le poids et la taille des images sont adaptés au mobile

## Format de sortie

Lors de la création d'une étude de cas :

```markdown
# CASE STUDY: [PROJECT NAME]

## Quick Facts
- **Role:** [Your role]
- **Company:** [Company]
- **Timeline:** [Duration]
- **Team:** [Team composition]
- **Impact:** [One-line result]

---

## Overview
[2-3 sentence summary of the project]

## Problem
[Context and challenges - what needed to be solved]

## Process
### Research
[What you learned]

### Approach
[How you tackled it]

### Key Decisions
[Important choices and rationale]

## Solution
[What you built/created - include visual descriptions]

### Feature 1
[Description]

### Feature 2
[Description]

## Results
[Quantified impact]

| Metric | Before | After | Change |
|--------|--------|-------|--------|

## Learnings
[Reflections and growth]

---

## Visual Asset List
[List of images/screenshots needed]
```

## Liste de contrôle qualité de l'étude de cas

- ✅ Énoncé clair du problème
- ✅ Preuve d'une orientation utilisateur/client
- ✅ Processus clairement expliqué
- ✅ Vos contributions spécifiques sont évidentes
- ✅ Résultats chiffrés
- ✅ Éléments visuels inclus
- ✅ Transparence sur les défis et les apprentissages
- ✅ Longueur appropriée (3 à 10 min de lecture)
- ✅ Relue et soignée
- ✅ Prête à être discutée en détail en entretien
