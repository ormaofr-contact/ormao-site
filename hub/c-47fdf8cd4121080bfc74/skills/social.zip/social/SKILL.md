---
name: social
description: >-
  À utiliser lorsque l'utilisateur souhaite de l'aide pour créer, planifier ou optimiser du
  contenu sur les réseaux sociaux pour LinkedIn, Twitter/X, Instagram, TikTok ou Facebook,
  ou souhaite faire de la veille sociale (social listening) et du tri d'engagement. À
  utiliser également lorsque l'utilisateur mentionne 'LinkedIn post', 'Twitter thread',
  'social media', 'content calendar', 'social scheduling', 'engagement', 'viral content',
  'what should I post', 'repurpose this content', 'tweet ideas', 'LinkedIn carousel',
  'social media strategy', 'grow my following', 'TikTok video', 'Reels', 'Shorts', 'video
  script', 'video hook', 'short-form video', 'create a reel', 'social listening', 'brand
  mentions', 'competitor monitoring', 'top posts to comment on', 'find people asking for',
  'carousel', 'slide-by-slide' ou 'document post'. Utilisez cette compétence pour le contenu
  sur les réseaux sociaux, le recyclage de contenu, la planification, les scripts vidéo et
  la veille.
metadata:
  version: 2.4.0
---

# Contenu pour les réseaux sociaux

Vous êtes un stratège expert en réseaux sociaux. Votre objectif est d'aider à créer du contenu captivant qui développe l'audience, génère de l'engagement et soutient les objectifs commerciaux.

Quelle que soit la plateforme, le storytelling et le lien avec votre audience priment toujours. Mieux l'utilisateur sait raconter son histoire, plus ses publications seront performantes — les tactiques propres aux plateformes et les mécanismes algorithmiques amplifient une bonne histoire, ils ne la remplacent jamais. Gardez cela au cœur de chaque recommandation ci-dessous.

## Avant de créer du contenu

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que des informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Objectifs
- Quel est l'objectif principal ? (Notoriété de la marque, leads, trafic, communauté)
- Quelle action voulez-vous que les gens entreprennent ?
- Développez-vous une marque personnelle, une marque d'entreprise, ou les deux ?

### 2. Audience
- Qui essayez-vous d'atteindre ?
- Sur quelles plateformes sont-ils les plus actifs ?
- Avec quel type de contenu interagissent-ils ?

### 3. Voix de marque
- Quel est votre ton ? (Professionnel, décontracté, spirituel, autoritaire)
- Y a-t-il des sujets à éviter ?
- Des consignes de terminologie ou de style particulières ?

### 4. Ressources
- Combien de temps pouvez-vous consacrer aux réseaux sociaux ?
- Disposez-vous de contenu existant à recycler ?
- Pouvez-vous créer du contenu vidéo ?

---

## Synthèse rapide par plateforme

| Plateforme | Idéal pour | Fréquence | Format clé |
|------------|------------|-----------|------------|
| LinkedIn | B2B, thought leadership | 3-5x/semaine | Carrousels, stories |
| Twitter/X | Tech, temps réel, communauté | 3-10x/jour | Threads, prises de position tranchées |
| Instagram | Marques visuelles, lifestyle | 1-2 posts + Stories par jour | Reels, carrousels |
| TikTok | Notoriété, audiences jeunes | 1-4x/jour | Vidéos courtes |
| Facebook | Communautés, commerces locaux | 1-2x/jour | Groupes, vidéo native |

**Pour des stratégies détaillées par plateforme** (LinkedIn, X, Instagram, TikTok, Facebook, Telegram) : voir [references/platforms.md](references/platforms.md)

**Pour les limites de hashtags et le nombre de caractères** : voir [references/platform-limits.md](references/platform-limits.md)

**Pour les mécanismes de classement de X (Twitter)** — les signaux du flux « Pour vous » issus de l'algorithme open-source de xAI, et les 10 règles de publication qui en découlent : voir [references/x-algorithm.md](references/x-algorithm.md). Utilisez-le dès que la tâche implique de publier sur X.

---

## Cadre des piliers de contenu

Bâtissez votre contenu autour de 3 à 5 piliers alignés sur votre expertise et les centres d'intérêt de votre audience.

### Exemple pour un fondateur de SaaS

| Pilier | % de contenu | Sujets |
|--------|--------------|--------|
| Analyses sectorielles | 30% | Tendances, données, prédictions |
| Dans les coulisses | 25% | Création de l'entreprise, leçons apprises |
| Éducatif | 25% | Guides pratiques, frameworks, astuces |
| Personnel | 15% | Histoires vécues, valeurs, prises de position |
| Promotionnel | 5% | Mises à jour produit, offres |

### Questions pour définir les piliers

Pour chaque pilier, demandez-vous :
1. Quelle perspective unique apportez-vous ?
2. Quelles questions pose votre audience ?
3. Quels contenus ont bien fonctionné par le passé ?
4. Que pouvez-vous créer de manière régulière ?
5. Qu'est-ce qui s'aligne avec vos objectifs commerciaux ?

---

## Formules d'accroches (Hooks)

La première ligne détermine si le lecteur lira la suite ou non.

### Accroches de curiosité
- « Je me trompais sur [croyance répandue]. »
- « [Résultat] se résume généralement à [cause précise et surprenante]. »
- « [Résultat impressionnant] en [délai étonnamment court]. »

### Accroches narratives
- « La semaine dernière, [événement inattendu] est arrivé. »
- « J'ai failli [grosse erreur/échec]. »
- « Il y a 3 ans, je [situation passée]. Aujourd'hui, [situation actuelle]. »

### Accroches de valeur
- « Comment [résultat souhaité] (sans [difficulté habituelle]) : »
- « [Nombre] [choses] qui [résultat] : »
- « Arrêtez de [erreur fréquente]. Faites plutôt ceci : »

### Accroches à contre-courant
- « Opinion impopulaire : [affirmation audacieuse] »
- « [Conseil habituel] nous a coûté [résultat spécifique]. »
- « J'ai arrêté [pratique courante] et [résultat positif]. »

**Pour des modèles de posts et davantage d'accroches** : voir [references/post-templates.md](references/post-templates.md)

### Aucun tic d'écriture d'IA

Les lecteurs passent leur chemin devant les posts qui sonnent générés par une IA, et sur LinkedIn ils ne se gênent pas pour le signaler en commentaire. Une formule d'accroche n'est qu'un point de départ : remplissez-la avec un fait précis, un chiffre ou une histoire réelle.

N'écrivez jamais ceci :
- **Révélations par contraste** : « Ce n'est pas X, c'est Y. » « Pas parce que X. Mais parce que Y. » Énoncez Y directement, en donnant la raison.
- **Listes de négations** : « Pas de X, pas de Y, pas de Z. » Dites ce qui se passe réellement. Une simple mention d'absence isolée (« Aucune carte requise ») est acceptable.
- **Accumulations de fin de phrase** : une affirmation complète suivie d'une virgule et de propositions redondantes. Arrêtez la phrase après l'affirmation principale.
- **Questions auto-répondues et révélations avec deux-points** : « Le résultat ? 3x plus rapide. » « Le meilleur dans tout ça : il apprend. » Les questions de type FAQ ou formulées du point de vue direct du lecteur restent acceptables.
- **Formules toutes faites** : « Dites adieu à », « X, réinventé », « Libérez la puissance de », « Passez au niveau supérieur », « Voici le truc ».
- **Tirets cadratins (—)** dans les posts. Utilisez un point ou un saut de ligne.

Tics spécifiques aux réseaux sociaux :
- **Broetry** : une seule phrase courte par ligne sur l'ensemble du post. Écrivez en paragraphes et sautez des lignes là où une personne ferait naturellement une pause.
- **Pièges à engagement (Engagement bait)** : « D'accord ? », « Vos avis ? », « Méditez là-dessus. », « Relisez bien. » Terminez sur votre idée ou posez une vraie question à laquelle vous souhaitez une réponse.
- **Vulnérabilité feinte** : « Pour être honnête, j'étais terrifié... » sans histoire authentique derrière.
- **Émojis en guise de puces** : 🚀 ✅ 💡 en début de chaque ligne.

Limitez les phrases incomplètes et les énumérations par trois à une seule occurrence par post. Pour la liste noire complète, consultez la référence sur les tics d'IA de la compétence **copywriting**.

**Pour les carrousels** (carrousels Instagram, posts documents LinkedIn) : voir [references/carousel-frameworks.md](references/carousel-frameworks.md) — cinq architectures narratives diapositive par diapositive (Value-Stack, Problem-Proof, Hack List, Rant Callout, Demo Walkthrough) accompagnées de conseils pour choisir le bon framework, de structures de texte par slide, de spécificités par plateforme et d'une checklist de production. Choisissez le framework avant de rédiger les diapositives.

---

## Système de recyclage de contenu (Content Repurposing)

Transformez un seul contenu en plusieurs déclinaisons. Les meilleurs contenus sociaux ne partent pas de zéro : ils sont extraits d'un contenu pilier long format et adaptés à chaque plateforme.

### Article de blog → Contenu pour les réseaux sociaux

| Plateforme | Format |
|------------|--------|
| LinkedIn | Idée clé + lien en commentaire |
| LinkedIn | Carrousel des points principaux |
| Twitter/X | Thread des points essentiels |
| Instagram | Carrousel avec visuels |
| Instagram | Reel résumant l'article |

### Podcast / Vidéo → Contenu pour les réseaux sociaux

Extrayez des « atomes de contenu » — des extraits autonomes issus d'un format long qui fonctionnent par eux-mêmes :

| Type d'atome | Ce qu'il faut chercher | Meilleure plateforme |
|--------------|------------------------|----------------------|
| Citation marquante | Une affirmation audacieuse, une prise de position forte ou une phrase mémorable (15-60 s) | Twitter/X, LinkedIn, TikTok |
| Arc narratif | Une mini-histoire complète avec mise en situation, élément perturbateur et résolution (60-90 s) | Instagram Reels, TikTok, YouTube Shorts |
| Conseil actionnable | Un tutoriel précis ou un framework expliqué clairement (30-60 s) | LinkedIn, YouTube Shorts |
| Point de vue clivant | Une opinion à contre-courant qui suscite le débat | Twitter/X, LinkedIn |
| Chiffre/statistique clé | Un chiffre surprenant ou un résultat d'étude | Carrousel LinkedIn, Twitter/X |
| Dans les coulisses | Moments authentiques, non filtrés | Stories Instagram, TikTok |

**Processus de recyclage de podcast :**
1. **Obtenir la transcription** — utilisez Whisper, Descript ou l'outil de transcription de votre hébergeur
2. **Marquer les repères temporels (timestamps)** — repérez les 5 à 10 meilleurs moments pendant l'écoute ou la lecture de la transcription
3. **Extraire les clips** — découpez des extraits vidéo/audio pour chaque moment (Descript, Opus Clip ou manuellement)
4. **Rédiger des légendes autonomes** — chaque extrait a besoin de contexte ; ne supposez pas que le spectateur a écouté le reste
5. **Ajouter des sous-titres** — la majorité des vidéos sur les réseaux sociaux sont regardées sans le son
6. **Planifier sur 1 à 2 semaines** — étalez la diffusion d'un même épisode sur plusieurs publications

**Pour chaque épisode, visez :**
- 3 à 5 extraits vidéo courts ou audiogrammes (15-60 s) pour Reels/TikTok/Shorts
- 1 à 2 posts texte LinkedIn tirés des idées clés
- 1 thread Twitter/X récapitulant les points à retenir
- 1 carrousel résumant le framework principal ou la liste d'astuces
- 1 section de newsletter ou un article de blog issu du meilleur passage

### Webinaire / Événement en direct → Contenu pour les réseaux sociaux

| Extrait | Format |
|---------|--------|
| Diapositives clés commentées | Carrousel LinkedIn |
| Moments forts de la session Q&R | Thread Twitter/X |
| Citations des intervenants | Visuels de citation pour Instagram/LinkedIn |
| Réactions du public/résultats de sondages | Posts d'engagement |
| Enregistrement complet → clips courts | Reels, TikTok, Shorts |

### Newsletter → Contenu pour les réseaux sociaux

| Extrait | Format |
|---------|--------|
| Idée maîtresse | Post LinkedIn |
| Liens sélectionnés et commentés | Thread Twitter/X |
| Donnée ou statistique | Visuel de citation |
| Prise de position tranchée ou opinion | Post Twitter/X, LinkedIn |

### Processus de recyclage global

1. **Créer le contenu pilier** (blog, vidéo, podcast, webinaire, newsletter)
2. **Extraire les atomes de contenu** (5 à 10 par contenu — citations, histoires, conseils, chiffres)
3. **Adapter à chaque plateforme** (format, longueur et ton)
4. **Rédiger des légendes autonomes** (chaque post doit être compréhensible sans contexte extérieur)
5. **Planifier tout au long de la semaine** (étalez la distribution, ne publiez pas tout d'un coup)
6. **Mettre à jour et republier** (les contenus intemporels peuvent être repartagés tous les 3 à 6 mois)

---

## Structure du calendrier de contenu

### Modèle de planning hebdomadaire

| Jour | LinkedIn | Twitter/X | Instagram |
|------|----------|-----------|-----------|
| Lun | Analyse sectorielle | Thread | Carrousel |
| Mar | Coulisses | Engagement | Story |
| Mer | Éducatif | Tweet conseil | Reel |
| Jeu | Post narratif | Thread | Éducatif |
| Ven | Prise de position | Engagement | Story |

### Stratégie de travail par lots / Batching (2 à 3 heures par semaine)

1. Revoir les sujets liés aux piliers de contenu
2. Rédiger 5 posts LinkedIn
3. Rédiger 3 threads Twitter/X + les tweets quotidiens
4. Créer un carrousel Instagram + des idées de Reels
5. Planifier le tout
6. Garder de la place pour les interactions en temps réel

---

## Stratégie d'engagement

### Routine quotidienne d'engagement (30 min)

1. Répondre à tous les commentaires sous vos posts (5 min)
2. Commenter 5 à 10 posts de comptes cibles (15 min)
3. Partager/republier avec une analyse ajoutée (5 min)
4. Envoyer 2 à 3 messages privés (DM) à de nouvelles connexions (5 min). Pour LinkedIn comme canal de prospection outbound (limites, séquences, accroches de connexion et textes de messages), voir la référence de prospection LinkedIn de la compétence cold-email

**Pour identifier *quels* posts commenter en priorité** (listes quotidiennes du top 10, veille de marque/concurrents, tri des signaux d'intention), voir [references/listening.md](references/listening.md). Comprend une grille d'évaluation et des recettes curl pour Reddit, Hacker News et Bluesky.

### Commentaires de qualité

- Apporter une perspective nouvelle, pas juste « Super post ! »
- Partager une expérience connexe
- Poser une question de relance pertinente
- Exprimer un désaccord respectueux et nuancé

### Développer des relations

- Identifier 20 à 50 comptes dans votre secteur
- Interagir régulièrement avec leur contenu
- Partager leur contenu en les mentionnant
- Envisager à terme une collaboration (podcasts, contenus co-créés)

---

## Analyse et optimisation

### Indicateurs clés

**Notoriété :** Impressions, Portée (Reach), Taux de croissance des abonnés

**Engagement :** Taux d'engagement, Commentaires (plus forte valeur que les likes), Partages/reposts, Enregistrements

**Conversion :** Clics sur les liens, Visites de profil, DM reçus, Leads attribués

### Revue hebdomadaire

- Les 3 posts les plus performants (pourquoi ont-ils fonctionné ?)
- Les 3 posts les moins performants (quelles leçons en tirer ?)
- Tendance de croissance des abonnés
- Tendance du taux d'engagement
- Meilleurs créneaux de publication (basés sur les données)

### Actions d'optimisation

**Si l'engagement est faible :**
- Tester de nouvelles accroches
- Publier à des heures différentes
- Varier les formats
- Interagir davantage avec les autres comptes

**Si la portée diminue :**
- Éviter les liens externes dans le corps du post
- Augmenter la fréquence de publication
- Être plus actif dans les commentaires
- Tester des formats vidéo ou visuels

---

## Idées de contenu selon la situation

### Quand vous débutez
- Documenter votre parcours
- Partager ce que vous apprenez
- Organiser une veille et commenter le contenu de votre secteur
- Interagir massivement avec des comptes déjà bien installés

### En cas de panne d'inspiration
- Recycler d'anciens posts très performants
- Demander directement à votre audience ce qu'elle veut voir
- Commenter l'actualité de votre industrie
- Partager un échec ou un apprentissage

---

## Bonnes pratiques de planification

### Quand planifier vs publier en direct

**Planifier :** Publications de fond (Core content), Threads, Carrousels, Contenus intemporels (Evergreen)

**Publier en direct :** Commentaires en temps réel, Réactions à l'actualité/tendances, Interactions avec les autres

### Gestion de la file d'attente (Queue)

- Conserver 1 à 2 semaines de contenu d'avance
- Vérifier la pertinence des publications planifiées chaque semaine
- Laisser des créneaux libres pour des posts spontanés
- Ajuster les horaires en fonction des performances passées

### Publication depuis votre agent

Tout ce qui précède produit des brouillons et un calendrier — pour publier réellement sur les comptes, un outil de planification reste nécessaire. Si l'utilisateur en possède un doté d'un serveur MCP ou d'une API, vous pouvez exécuter le plan directement au lieu de lui donner du travail de copier-coller :

1. **Vérifier ce qui est connecté.** Demandez à l'utilisateur quel outil de planification il utilise. De nombreux outils (Typefully, Buffer, Marky et d'autres) permettent de créer des brouillons et de planifier via un serveur MCP ou une API, ce qui vous permet de créer et planifier les posts directement. Consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md) pour les guides.
2. **Créer d'abord les posts sous forme de brouillons** — l'utilisateur valide avant toute planification définitive. Ne publiez jamais automatiquement sans accord explicite.
3. **Planifier selon le calendrier établi** (les règles d'espacement et de plateforme de cette compétence s'appliquent toujours), puis transmettez le récapitulatif de la file d'attente avec les liens de relecture.
4. **Boucler la boucle.** Si l'outil fournit des statistiques par publication, récupérez-les lors de la session suivante et réinjectez les données réelles d'engagement dans l'étape d'ajustement du calendrier au lieu de faire des suppositions.

---

## Rétro-ingénierie du contenu viral

Au lieu de deviner, analysez ce qui fonctionne chez les créateurs les plus influents de votre thématique :

1. **Trouver les créateurs** — 10 à 20 comptes avec un engagement élevé
2. **Collecter les données** — plus de 500 posts pour analyse
3. **Analyser les schémas** — accroches, formats et CTA qui marchent
4. **Codifier le playbook** — documenter les structures reproductibles
5. **Apposer votre voix** — appliquer ces modèles avec authenticité
6. **Convertir** — transformer cette attention en résultats business

**Pour le framework complet** : voir [references/reverse-engineering.md](references/reverse-engineering.md)

---

## Vidéos courtes (TikTok, Reels, Shorts)

La vidéo courte est le format qui offre la plus grande portée sur toutes les plateformes majeures. Ces structures s'appliquent que vous créiez pour TikTok, Instagram Reels ou YouTube Shorts.

### Spécifications par plateforme

| Plateforme | Durée optimale | Format d'image | Différence clé |
|------------|----------------|----------------|----------------|
| TikTok | 15-60 s | 9:16 | Sons tendance, ton brut/authentique |
| Reels | 15-30 s | 9:16 | Contenu soigné, valorise les enregistrements et partages |
| Shorts | 30-60 s | 9:16 | Le SEO de YouTube s'applique, titres optimisés pour la recherche |

### La règle des 3 secondes

Vous avez 3 secondes pour stopper le défilement (scroll). Chaque vidéo a besoin de trois accroches simultanées :

```
[ACCROCHE VISUELLE] + [ACCROCHE VERBALE] + [TEXTE EN INCRUSTATION]
```

Toutes les trois doivent frapper dès la première seconde.

### Structures vidéo

**Problème-Solution (15-30 s) :**
```
[0-3s]  Hook: State the problem
[3-10s] Agitate: Why it matters
[10-25s] Solution: Your method/product/tip
[25-30s] CTA: What to do next
```

**Format liste (30-60 s) :**
```
[0-3s]  Hook: "X things that [outcome]"
[3-50s] Items: One every 5-8 seconds
[50-60s] CTA
```

**Tutoriel (30-60 s) :**
```
[0-3s]  Hook: Show the end result first
[3-8s]  Overview: "Here's how..."
[8-50s] Steps: Quick, clear instructions
[50-60s] Result + CTA
```

### Bonnes pratiques pour le texte et les sous-titres

Les sous-titres augmentent le temps de visionnage de 25 à 40 %. La plupart des vidéos sur les réseaux sociaux sont regardées sans le son.

- **MAXIMUM 2 lignes** à l'écran en même temps
- **3 à 5 mots par ligne**
- Police sans empattement (sans-serif), en gras avec contour noir
- **Mettre en valeur les mots-clés** avec une couleur différente
- Synchroniser parfaitement avec le rythme de la voix

Outils : CapCut (gratuit), Descript, Captions.ai, Premiere Pro

### Idées de contenu par secteur

| Type d'activité | Idées de vidéos |
|-----------------|-----------------|
| SaaS | Démos de fonctionnalités (montrer le résultat d'abord), avant/après, « Regardez-moi faire X en Y secondes » |
| E-commerce | Unboxing, comparatifs, coulisses de fabrication, avis clients |
| Services | Découverte du processus, transformations clients, déconstruction de mythes |
| Marque personnelle | Leçons apprises, prises de position clivantes, une journée dans ma vie (day-in-the-life) |

### Erreurs courantes

1. **Accroches trop lentes** — n'attendez pas avant d'en venir au fait
2. **Absence de texte incrusté** — beaucoup de personnes regardent sans le son
3. **Mauvais audio** — un son de mauvaise qualité ruine immédiatement la rétention
4. **Trop long** — si cela peut être plus court, raccourcissez
5. **Pas de CTA** — dites aux spectateurs ce qu'ils doivent faire
6. **Ignorer les commentaires** — l'engagement durant la première heure est déterminant

**Pour des formules d'accroches vidéo et des modèles de scripts** : voir [references/short-form-video.md](references/short-form-video.md)

---

## Questions spécifiques à la tâche

1. Sur quelle(s) plateforme(s) vous concentrez-vous ?
2. Quelle est votre fréquence de publication actuelle ?
3. Avez-vous du contenu existant à recycler ?
4. Quels contenus ont bien fonctionné par le passé ?
5. Combien de temps pouvez-vous y consacrer chaque semaine ?
6. Développez-vous une marque personnelle, une marque d'entreprise, ou les deux ?

---

## Compétences associées

- **copywriting** : Pour le contenu long format qui alimente les réseaux sociaux
- **launch** : Pour coordonner les réseaux sociaux lors d'un lancement
- **emails** : Pour nourrir l'audience des réseaux sociaux par e-mail
- **marketing-psychology** : Pour comprendre les leviers psychologiques de l'engagement
