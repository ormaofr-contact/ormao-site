---
name: li-comment
description: >-
  Rédiger des commentaires sur les publications LinkedIn d'autres personnes qui
  donnent l'impression d'être écrits par un humain avec une opinion, pas un robot.
  À utiliser lorsque l'utilisateur colle un post et souhaite un commentaire, dit
  « commente ceci », « interagis avec ceci », « qu'est-ce que je réponds ici »,
  ou veut un lot de commentaires pour sa session d'engagement.
---

# li-comment

Commenter est l'action qui a le plus fort effet de levier sur LinkedIn, et la
plus facile à rater. Un commentaire sur un post à 400 réactions est vu par plus
de monde que la plupart de vos propres publications. Un commentaire générique
n'est vu par personne et vous coûte de la crédibilité auprès de l'auteur.

## Entrée

L'utilisateur colle le texte du post (ainsi que le nom et le rôle de l'auteur
s'il les a). S'il colle une capture d'écran, lisez-la. S'il vous donne une URL
que vous ne pouvez pas ouvrir, demandez-lui de coller le texte — ne devinez pas
ce que disait le post, et n'utilisez pas l'automatisation de navigateur pour
scraper le fil.

## Les neuf types de commentaires

Choisissez en fonction de ce qu'est réellement le post. Ne choisissez jamais le
type 1 par défaut.

| # | type | quand | forme |
| --- | --- | --- | --- |
| 1 | **Ajouter une donnée** | le post affirme quelque chose que vous pouvez étayer par un chiffre | « On a observé la même chose : 40 % de nos… » |
| 2 | **Ajouter le cas manquant** | le post a raison mais est incomplet | « C'est vrai jusqu'à ce que {condition}. Ensuite… » |
| 3 | **Désaccord respectueux** | vous pensez sincèrement que c'est faux | nommer d'abord le point d'accord, puis la divergence |
| 4 | **Prolonger une phrase** | une phrase du post est particulièrement bonne | la citer, puis rebondir dessus |
| 5 | **Poser la vraie question** | le post a éludé la partie difficile | une question, précise, sans formule du genre « curieux d'entendre » |
| 6 | **Le retour d'expérience** | vous avez fait ce qu'ils décrivent | ce qui s'est passé, en deux phrases |
| 7 | **La correction** | il y a une erreur factuelle | avoir raison, être bref, être bienveillant, être sûr de soi |
| 8 | **Le recadrage** | le post a les bons faits mais le mauvais cadre | « Une autre façon de voir les choses : » |
| 9 | **La phrase choc** | le post n'a besoin de rien, vous voulez juste une présence | moins de 12 mots, doit être drôle ou percutant de vérité |

## Règles

- **2 à 4 phrases.** Plus long ressemble à un détournement du post. Plus court
  ressemble à du remplissage.
- **Ne jamais commencer par « Super post »**, « J'adore », « Tellement vrai »,
  « Tout à fait d'accord », « Ça résonne tellement », ou par le prénom de
  l'auteur suivi d'un point d'exclamation. Ces six approches sont invisibles.
- **Pas d'émoji en accroche.** Pas de 🔥 ou 👏 en premier caractère.
- **Ne jamais reformuler le post.** L'auteur sait ce qu'il a écrit et tous les
  lecteurs aussi.
- **Une seule idée.** Un commentaire avec deux points ressemble à une tentative
  de faire un article de blog.
- **Dire quelque chose de précis.** Si le commentaire pouvait convenir sous
  n'importe quel post sur le même sujet, ce n'est pas un commentaire, c'est du
  bruit.
- **Le désaccord est autorisé et efficace**, mais l'accord doit venir en premier
  et être sincère.

## Sortie

Fournissez **deux options de types différents**, étiquetées, plus une phrase
expliquant la raison de celle que vous publieriez. Passez les deux par
`/li-human` d'abord — un commentaire contenant un tiret cadratin paraît plus
évidemment rédigé par une machine qu'un post complet, car les commentaires sont
courts et les gens les lisent attentivement.

```
OPTIONS DE COMMENTAIRE (sur le post de @author à propos du recrutement)

[6 · Retour d'expérience]
On a testé la version sans CV pour 3 recrutements l'année dernière. Deux ont
été les meilleures recrues qu'on ait faites. Le troisième a été une
catastrophe, et la différence tenait au fait d'avoir déjà exercé le poste en
pratique ou non, pas à la prestation en entretien.

[3 · Désaccord respectueux]
D'accord sur le problème de signal. Mais la solution qui a fonctionné pour
nous n'était pas de supprimer le CV, c'était de donner à chaque candidat le
même exercice rémunéré de 90 minutes. Même résultat, beaucoup moins de débats
en interne.

Publiez le premier. Ce sont vos propres données et cela concède un échec, ce
qui est précisément ce à quoi les gens répondent.
```

## Mode par lot (batch)

Si l'utilisateur souhaite faire une session d'engagement, demandez-lui les 5 à
10 posts sous forme de texte collé en un seul message, renvoyez un commentaire
chacun dans un seul bloc, et tenez à jour une note de ceux qu'il a déjà
commentés cette semaine dans `~/.claude/linkedin/log.md`. Commenter les trois
mêmes personnes tous les jours est visible et cela donne exactement
l'impression que ça donne.

## Jamais

Ne publiez pas automatiquement. N'utilisez pas d'outil de navigation pour
publier des commentaires au nom de l'utilisateur. La publication automatisée et
le scraping enfreignent tous deux les Conditions d'utilisation de LinkedIn et
mettent le compte en danger. Cette compétence écrit le commentaire.
L'utilisateur le publie.
