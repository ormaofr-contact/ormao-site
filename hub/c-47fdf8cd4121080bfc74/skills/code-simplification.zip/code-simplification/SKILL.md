---
name: code-simplification
description: Simplifie le code pour plus de clarté. À utiliser lors du refactoring de code pour en améliorer la lisibilité sans modifier son comportement. À utiliser lorsque le code fonctionne mais est plus difficile à lire, à maintenir ou à étendre qu'il ne le devrait. À utiliser lors de la revue de code ayant accumulé une complexité inutile.
---

# Simplification de code

> Inspiré par le [Claude Code Simplifier plugin](https://github.com/anthropics/claude-plugins-official/blob/main/plugins/code-simplifier/agents/code-simplifier.md). Adapté ici sous la forme d'une compétence agnostique vis-à-vis du modèle et guidée par les processus, pour tout agent de programmation IA.

## Vue d'ensemble

Simplifiez le code en réduisant la complexité tout en préservant exactement son comportement. L'objectif n'est pas d'avoir moins de lignes — c'est d'obtenir un code plus facile à lire, à comprendre, à modifier et à déboguer. Chaque simplification doit passer un test simple : « Un nouveau membre de l'équipe comprendrait-il cela plus rapidement que la version originale ? »

## Quand l'utiliser

- Après qu'une fonctionnalité est opérationnelle et que les tests passent, mais que l'implémentation semble plus lourde qu'elle ne devrait l'être
- Pendant une revue de code lorsque des problèmes de lisibilité ou de complexité sont signalés
- Lorsque vous rencontrez une logique profondément imbriquée, des fonctions trop longues ou des noms peu clairs
- Lors du refactoring de code écrit dans l'urgence
- Lors de la consolidation d'une logique connexe dispersée dans plusieurs fichiers
- Après la fusion de modifications ayant introduit de la duplication ou des incohérences

**Quand NE PAS l'utiliser :**

- Le code est déjà propre et lisible — ne simplifiez pas pour le simple plaisir de le faire
- Vous ne comprenez pas encore ce que fait le code — comprenez avant de simplifier
- Le code est critique en termes de performances et la version « plus simple » serait sensiblement plus lente
- Vous êtes sur le point de réécrire entièrement le module — simplifier du code jetable est une perte de temps

## Les cinq principes

### 1. Conserver exactement le comportement

Ne modifiez pas ce que fait le code — uniquement la manière dont il l'exprime. Toutes les entrées, sorties, effets de bord, comportements d'erreur et cas limites doivent rester identiques. Si vous n'êtes pas certain qu'une simplification préserve le comportement, ne la faites pas.

```
À DEMANDER AVANT CHAQUE MODIFICATION :
→ Cela produit-il la même sortie pour chaque entrée ?
→ Cela conserve-t-il le même comportement en cas d'erreur ?
→ Cela préserve-t-il les mêmes effets de bord et le même ordre d'exécution ?
→ Tous les tests existants passent-ils toujours sans modification ?
```

### 2. Respecter les conventions du projet

Simplifier signifie rendre le code plus cohérent avec la base de code, et non imposer des préférences externes. Avant de simplifier :

```
1. Lire CLAUDE.md / les conventions du projet
2. Étudier la manière dont le code voisin gère des structures similaires
3. Respecter le style du projet pour :
   - L'ordre des imports et le système de modules
   - Le style de déclaration des fonctions
   - Les conventions de nommage
   - Les modèles de gestion des erreurs
   - La profondeur d'annotation des types
```

Une simplification qui rompt la cohérence du projet n'est pas une simplification — c'est du bruit inutile.

### 3. Préférer la clarté à l'ingéniosité

Un code explicite est préférable à un code compact lorsque la version compacte nécessite un temps d'arrêt mental pour être analysée.

```typescript
// UNCLEAR: Dense ternary chain
const label = isNew ? 'New' : isUpdated ? 'Updated' : isArchived ? 'Archived' : 'Active';

// CLEAR: Readable mapping
function getStatusLabel(item: Item): string {
  if (item.isNew) return 'New';
  if (item.isUpdated) return 'Updated';
  if (item.isArchived) return 'Archived';
  return 'Active';
}
```

```typescript
// UNCLEAR: Chained reduces with inline logic
const result = items.reduce((acc, item) => ({
  ...acc,
  [item.id]: { ...acc[item.id], count: (acc[item.id]?.count ?? 0) + 1 }
}), {});

// CLEAR: Named intermediate step
const countById = new Map<string, number>();
for (const item of items) {
  countById.set(item.id, (countById.get(item.id) ?? 0) + 1);
}
```

### 4. Maintenir l'équilibre

La simplification a un mode d'échec : la sur-simplification. Attention à ces pièges :

- **Inliner de manière trop agressive** — supprimer une fonction utilitaire qui donnait un nom à un concept rend le site d'appel plus difficile à lire
- **Combiner des logiques sans rapport** — fusionner deux fonctions simples en une seule fonction complexe n'est pas plus simple
- **Supprimer des abstractions « inutiles »** — certaines abstractions existent pour l'extensibilité ou la testabilité, non par complexité
- **Optimiser le nombre de lignes** — avoir moins de lignes n'est pas l'objectif ; une compréhension plus facile l'est

### 5. Se limiter à ce qui a changé

Par défaut, limitez-vous à simplifier le code récemment modifié. Évitez les refactorings opportunistes de code non lié, sauf si l'on vous demande explicitement d'élargir le périmètre. Une simplification sans périmètre défini crée du bruit dans les diffs et risque d'engendrer des régressions involontaires.

## Le processus de simplification

### Étape 1 : Comprendre avant de toucher (la barrière de Chesterton)

Avant de modifier ou de supprimer quoi que ce soit, comprenez pourquoi cela existe. C'est le principe de la barrière de Chesterton : si vous voyez une barrière en travers d'une route et ne comprenez pas pourquoi elle est là, ne la détruisez pas. Comprenez d'abord la raison, puis décidez si cette raison s'applique toujours.

```
AVANT DE SIMPLIFIER, RÉPONDEZ À CES QUESTIONS :
- Quelle est la responsabilité de ce code ?
- Qu'est-ce qui l'appelle ? Qu'appelle-t-il ?
- Quels sont les cas limites et les chemins d'erreur ?
- Existe-t-il des tests qui définissent le comportement attendu ?
- Pourquoi a-t-il pu être écrit de cette façon ? (Performances ? Contrainte de plateforme ? Raison historique ?)
- Vérifiez git blame : quel était le contexte d'origine de ce code ?
```

Si vous ne pouvez pas répondre à ces questions, vous n'êtes pas prêt à simplifier. Explorez davantage le contexte d'abord.

### Étape 2 : Identifier les opportunités de simplification

Recherchez ces modèles — chacun constitue un signal concret, et non une vague intuition :

**Complexité structurelle :**

| Motif | Signal | Simplification |
|-------|--------|----------------|
| Imbrication profonde (3+ niveaux) | Flux de contrôle difficile à suivre | Extraire les conditions dans des clauses de garde (guard clauses) ou des fonctions d'assistance |
| Fonctions longues (50+ lignes) | Responsabilités multiples | Découper en fonctions ciblées avec des noms descriptifs |
| Opérateurs ternaires imbriqués | Nécessite une charge mentale pour être analysé | Remplacer par des chaînes if/else, un switch ou des objets de correspondance |
| Paramètres booléens (flags) | `doThing(true, false, true)` | Remplacer par des objets d'options ou des fonctions distinctes |
| Conditions répétées | Même vérification `if` à plusieurs endroits | Extraire dans une fonction de prédicat bien nommée |

**Nommage et lisibilité :**

| Motif | Signal | Simplification |
|-------|--------|----------------|
| Noms génériques | `data`, `result`, `temp`, `val`, `item` | Renommer pour décrire le contenu : `userProfile`, `validationErrors` |
| Noms abrégés | `usr`, `cfg`, `btn`, `evt` | Utiliser des mots complets sauf si l'abréviation est universelle (`id`, `url`, `api`) |
| Noms trompeurs | Fonction nommée `get` qui modifie également l'état | Renommer pour refléter le comportement réel |
| Commentaires expliquant le « quoi » | `// increment counter` au-dessus de `count++` | Supprimer le commentaire — le code est suffisamment clair |
| Commentaires expliquant le « pourquoi » | `// Retry because the API is flaky under load` | Les conserver — ils expriment une intention que le code ne peut pas exprimer |

**Redondance :**

| Motif | Signal | Simplification |
|-------|--------|----------------|
| Logique dupliquée | Les 5+ mêmes lignes à plusieurs endroits | Extraire dans une fonction partagée |
| Code mort | Branches inaccessibles, variables inutilisées, blocs commentés | Supprimer (après avoir confirmé qu'il est réellement mort) |
| Abstractions inutiles | Wrapper qui n'apporte aucune valeur | Inliner le wrapper, appeler directement la fonction sous-jacente |
| Modèles surconçus (over-engineered) | Fabrique de fabrique, stratégie avec une seule stratégie | Remplacer par l'approche directe et simple |
| Assertions de type redondantes | Cast vers un type déjà inféré | Supprimer l'assertion |

### Étape 3 : Appliquer les modifications progressivement

Effectuez une simplification à la fois. Lancez les tests après chaque modification. **Soumettez les modifications de refactoring séparément des ajouts de fonctionnalités ou des corrections de bugs.** Une PR qui refactorise et ajoute une fonctionnalité correspond à deux PR — séparez-les.

```
POUR CHAQUE SIMPLIFICATION :
1. Effectuer la modification
2. Exécuter la suite de tests
3. Si les tests passent → commiter (ou passer à la simplification suivante)
4. Si les tests échouent → annuler et reconsidérer
```

Évitez de regrouper plusieurs simplifications en une seule modification non testée. Si quelque chose casse, vous devez savoir quelle simplification en est la cause.

**La règle des 500 :** Si un refactoring doit toucher plus de 500 lignes, investissez dans l'automatisation (codemods, scripts sed, transformations AST) plutôt que d'effectuer les modifications à la main. Les éditions manuelles à cette échelle sont sources d'erreurs et épuisantes à relire.

### Étape 4 : Vérifier le résultat

Après toutes les simplifications, prenez du recul et évaluez l'ensemble :

```
COMPARER AVANT ET APRÈS :
- La version simplifiée est-elle véritablement plus facile à comprendre ?
- Avez-vous introduit de nouveaux motifs incohérents avec la base de code ?
- Le diff est-il propre et facile à relire ?
- Un coéquipier approuverait-il ce changement ?
```

Si la version « simplifiée » est plus difficile à comprendre ou à relire, revenez en arrière. Toutes les tentatives de simplification ne réussissent pas.

## Conseils spécifiques aux langages

### TypeScript / JavaScript

```typescript
// SIMPLIFY: Unnecessary async wrapper
// Before
async function getUser(id: string): Promise<User> {
  return await userService.findById(id);
}
// After
function getUser(id: string): Promise<User> {
  return userService.findById(id);
}

// SIMPLIFY: Verbose conditional assignment
// Before
let displayName: string;
if (user.nickname) {
  displayName = user.nickname;
} else {
  displayName = user.fullName;
}
// After
const displayName = user.nickname || user.fullName;

// SIMPLIFY: Manual array building
// Before
const activeUsers: User[] = [];
for (const user of users) {
  if (user.isActive) {
    activeUsers.push(user);
  }
}
// After
const activeUsers = users.filter((user) => user.isActive);

// SIMPLIFY: Redundant boolean return
// Before
function isValid(input: string): boolean {
  if (input.length > 0 && input.length < 100) {
    return true;
  }
  return false;
}
// After
function isValid(input: string): boolean {
  return input.length > 0 && input.length < 100;
}
```

### Python

```python
# SIMPLIFY: Verbose dictionary building
# Before
result = {}
for item in items:
    result[item.id] = item.name
# After
result = {item.id: item.name for item in items}

# SIMPLIFY: Nested conditionals with early return
# Before
def process(data):
    if data is not None:
        if data.is_valid():
            if data.has_permission():
                return do_work(data)
            else:
                raise PermissionError("No permission")
        else:
            raise ValueError("Invalid data")
    else:
        raise TypeError("Data is None")
# After
def process(data):
    if data is None:
        raise TypeError("Data is None")
    if not data.is_valid():
        raise ValueError("Invalid data")
    if not data.has_permission():
        raise PermissionError("No permission")
    return do_work(data)
```

### React / JSX

```tsx
// SIMPLIFY: Verbose conditional rendering
// Before
function UserBadge({ user }: Props) {
  if (user.isAdmin) {
    return <Badge variant="admin">Admin</Badge>;
  } else {
    return <Badge variant="default">User</Badge>;
  }
}
// After
function UserBadge({ user }: Props) {
  const variant = user.isAdmin ? 'admin' : 'default';
  const label = user.isAdmin ? 'Admin' : 'User';
  return <Badge variant={variant}>{label}</Badge>;
}

// SIMPLIFY: Prop drilling through intermediate components
// Before — consider whether context or composition solves this better.
// This is a judgment call — flag it, don't auto-refactor.
```

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « Ça fonctionne, pas besoin d'y toucher » | Un code fonctionnel mais difficile à lire sera difficile à corriger lorsqu'il cassera. Simplifier maintenant fait gagner du temps sur chaque modification future. |
| « Moins de lignes, c'est toujours plus simple » | Un ternaire imbriqué d'une seule ligne n'est pas plus simple qu'un if/else de 5 lignes. La simplicité concerne la vitesse de compréhension, pas le nombre de lignes. |
| « Je vais juste simplifier rapidement ce code non lié au passage » | Une simplification hors périmètre crée des diffs bruités et risque d'introduire des régressions dans du code que vous n'aviez pas l'intention de modifier. Restez concentré. |
| « Les types le rendent auto-documenté » | Les types documentent la structure, pas l'intention. Une fonction bien nommée explique le *pourquoi* bien mieux qu'une signature de type n'explique le *quoi*. |
| « Cette abstraction pourrait être utile plus tard » | Ne conservez pas d'abstractions spéculatives. Si elle n'est pas utilisée maintenant, c'est de la complexité sans valeur. Supprimez-la et réintroduisez-la au besoin. |
| « L'auteur d'origine devait avoir une raison » | Peut-être. Vérifiez avec git blame — appliquez la barrière de Chesterton. Mais la complexité accumulée n'a souvent aucune raison ; c'est juste le résidu d'itérations successives dans l'urgence. |
| « Je vais refactoriser tout en ajoutant cette fonctionnalité » | Séparez le refactoring du développement de fonctionnalités. Les modifications mélangées sont plus difficiles à relire, à annuler et à comprendre dans l'historique. |

## Signaux d'alerte

- Simplification qui nécessite de modifier les tests pour qu'ils passent (vous avez probablement altéré le comportement)
- Code « simplifié » plus long et plus difficile à suivre que l'original
- Renommage d'éléments selon vos préférences personnelles plutôt que selon les conventions du projet
- Suppression de la gestion des erreurs sous prétexte que « cela rend le code plus propre »
- Simplification d'un code que vous ne comprenez pas entièrement
- Regroupement de nombreuses simplifications dans un seul commit volumineux et difficile à relire
- Refactoring de code hors du périmètre de la tâche en cours sans qu'on vous l'ait demandé

## Vérification

Après avoir terminé une passe de simplification :

- [ ] Tous les tests existants passent sans modification
- [ ] Le build réussit sans nouveaux avertissements
- [ ] Le linter/formateur passe (aucune régression de style)
- [ ] Chaque simplification constitue une modification incrémentale et facile à relire
- [ ] Le diff est propre — aucune modification sans rapport n'y est mélangée
- [ ] Le code simplifié respecte les conventions du projet (vérifié par rapport à CLAUDE.md ou équivalent)
- [ ] Aucune gestion d'erreurs n'a été supprimée ou affaiblie
- [ ] Aucun code mort n'a été laissé (imports inutilisés, branches inaccessibles)
- [ ] Un coéquipier ou un agent de revue approuverait la modification comme une nette amélioration
