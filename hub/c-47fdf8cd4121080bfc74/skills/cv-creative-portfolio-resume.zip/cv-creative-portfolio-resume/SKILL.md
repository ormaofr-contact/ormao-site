---
name: creative-portfolio-resume
description: Équilibrer design visuel et compatibilité ATS pour les métiers créatifs
---

# CV portfolio créatif

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Travaille dans un domaine créatif (design, marketing, rédaction)
- Doit trouver le juste équilibre entre design visuel et compatibilité ATS
- Souhaite mettre en valeur ses compétences créatives à travers la mise en page de son CV
- Conçoit un CV portfolio pour des postes créatifs
- Mentionne : « CV créatif », « CV de designer », « CV visuel », « CV portfolio », « secteur créatif »

## Capacités principales

- Équilibrer attrait visuel et compatibilité ATS
- Concevoir des CV pour des rôles créatifs
- Intégrer des éléments de portfolio dans le contenu du CV
- Conseiller sur le moment opportun pour utiliser un format créatif plutôt qu'un format traditionnel
- Guider la hiérarchie visuelle et les choix de design
- Relier efficacement le CV au portfolio

## Le dilemme du CV créatif

**Le problème :**
- Les professionnels créatifs veulent démontrer leurs compétences en design à travers leur CV
- Mais la plupart des candidatures passent par des systèmes ATS
- Les CV au design trop complexe échouent souvent à l'analyse syntaxique (parsing) des ATS

**La solution :**
L'approche à deux versions :
1. **Version compatible ATS** pour les candidatures en ligne
2. **Version travaillée / graphique** pour le portfolio, le networking et les envois directs

## Quand utiliser chaque version

### Utiliser la version compatible ATS pour :
- Les candidatures via des portails en ligne
- Les soumissions sur les jobboards
- Les cas où le CV sera analysé par un logiciel
- Les situations où vous n'êtes pas certain du processus de traitement

### Utiliser la version graphique pour :
- Les événements de networking
- Les e-mails directs aux responsables du recrutement
- Le site web portfolio
- Les entretiens en personne
- Les agences créatives qui attendent des CV visuels
- Les cas où il est explicitement indiqué qu'aucun ATS n'est utilisé

## CV créatif compatible ATS

Même la version ATS peut exprimer de la créativité grâce à :

### Des éléments visuels subtils
- Utilisation stratégique des espaces blancs
- Hiérarchie typographique soignée
- Organisation réfléchie du contenu
- Qualité rédactionnelle (copywriting percutant)
- Présentation soignée et professionnelle

### Touches créatives sans risque
- ✅ Police professionnelle personnalisée (parmi celles compatibles ATS)
- ✅ Utilisation stratégique du gras et de l'italique
- ✅ Séparateurs de section épurés (lignes simples)
- ✅ Espacements réguliers et intentionnels
- ✅ Touche de couleur sur le nom ou les en-têtes (avec parcimonie)
- ✅ Liens hypertextes vers le portfolio

### Éléments à toujours éviter
- ❌ Colonnes multiples
- ❌ Zones de texte
- ❌ Images ou icônes
- ❌ Tableaux pour la mise en page
- ❌ Polices de caractères exotiques
- ❌ Graphiques ou barres de compétences

## CV portfolio graphique

### Principes de design

**1. Montrer plutôt que raconter (« Show, Don't Just Tell »)**
- Votre CV EST un échantillon de votre travail de design
- Le choix de la typographie est crucial
- La mise en page démontre votre démarche de conception (design thinking)
- Les détails témoignent de votre souci du travail bien fait

**2. La clarté avant l'originalité**
- L'information doit rester facile à trouver
- Donnez la priorité absolue à la lisibilité
- Réservez les expérimentations graphiques aux pièces de votre portfolio

**3. Cohérence de marque**
- Alignez le CV avec votre site web portfolio
- Palette de couleurs cohérente
- Identité visuelle unifiée

### Éléments visuels à prendre en compte

**Typographie :**
- Police de titre (de caractère, expressive)
- Police de corps de texte (lisible, professionnelle)
- Hiérarchie de taille (nom > sections > corps)
- Hauteur de ligne (interlignage) et espacement des lettres (crénage)

**Couleur :**
- Couleur de marque pour les accents
- Contraste élevé pour une lisibilité optimale
- Palette restreinte (2 à 3 couleurs maximum)
- Pensez aux couleurs qui s'impriment bien

**Mise en page :**
- Envisagez une présentation sur deux colonnes (uniquement pour la version graphique)
- Espaces blancs stratégiques
- Hiérarchie visuelle évidente
- Marges et gouttières régulières

**Accents visuels :**
- Icônes (si utilisées, de manière cohérente)
- Séparateurs et filets
- Éléments d'arrière-plan subtils
- Votre logo ou monogramme personnel

## Conseils spécifiques par domaine créatif

### Graphistes / Designers graphiques

**Ce qu'il faut démontrer :**
- Maîtrise de la typographie
- Mise en page et composition
- Hiérarchie visuelle
- Souci du détail

**Approche du CV :**
- Votre CV EST une pièce de votre portfolio
- Design épuré et sophistiqué
- Démontrez votre palette de compétences par des choix subtils
- Renvoyez vers le portfolio pour montrer la diversité de vos créations

### Designers UX/Produit

**Ce qu'il faut démontrer :**
- Compétences en architecture de l'information
- Réflexion centrée sur l'utilisateur
- Hiérarchie visuelle claire
- Approche méthodique et systématique

**Approche du CV :**
- Structure facile à scanner et organisée
- Hiérarchie du contenu limpide
- Organisation pensée pour l'utilisateur (le recruteur)
- Liens vers des études de cas

### Marketing / Marque

**Ce qu'il faut démontrer :**
- Vision de marque (brand thinking)
- Capacité de storytelling
- Communication stratégique
- Attention portée à la cible

**Approche du CV :**
- Identité visuelle fidèle à votre positionnement de marque
- Déroulé narratif captivant
- Choix de contenu stratégiques
- Preuves concrètes à l'appui de vos affirmations

### Rédacteurs / Concepteurs-rédacteurs / Métiers du contenu

**Ce qu'il faut démontrer :**
- Qualité d'écriture
- Rigueur et précision éditoriale
- Clarté du propos
- Style et tonalité

**Approche du CV :**
- Rédaction irréprochable
- Puces d'action percutantes
- Zéro faute
- Personnalité transmise à travers le style d'écriture

### Photographes / Vidéastes

**Ce qu'il faut démontrer :**
- Sens visuel
- Qualité de production
- Compétence technique
- Sensibilité esthétique

**Approche du CV :**
- Design épuré, non surchargé
- Lien bien mis en évidence vers le portfolio
- La qualité avant la quantité
- Laisser le portfolio parler de lui-même

## Intégration du portfolio

### Directement sur le CV

**Lien vers le portfolio :**
```
Portfolio: yourname.com
```

**Lien vers un projet spécifique :**
```
• Redesigned checkout flow, increasing conversion by 40%
  Case Study: yourname.com/checkout
```

### Page CV sur le site du portfolio

**Options :**
1. Téléchargement d'un PDF (version graphique)
2. Page CV au format HTML
3. Expérience de CV interactive
4. Toutes les options ci-dessus combinées

**Bonnes pratiques :**
- Proposez un téléchargement PDF pour le côté pratique
- Veillez à ce que la version web soit responsive
- Maintenez cette page à jour par rapport au CV principal

## Conseils d'exécution graphique

### Checklist typographie
- [ ] Le nom est l'élément le plus visible
- [ ] Hiérarchie claire (3 à 4 niveaux maximum)
- [ ] Texte courant à 10-12 pt minimum
- [ ] L'interlignage laisse respirer le texte
- [ ] Pas plus de 2 familles de polices
- [ ] Les polices se complètent harmonieusement

### Checklist mise en page
- [ ] Sections et enchaînements évidents
- [ ] Marges régulières sur l'ensemble du document
- [ ] Espace blanc suffisant
- [ ] Éléments alignés sur une grille
- [ ] Équilibre visuel atteint
- [ ] Scannable en 6 secondes

### Checklist couleur
- [ ] Palette limitée (2 à 3 couleurs)
- [ ] Contraste élevé pour le texte
- [ ] Choix de couleurs accessibles
- [ ] Bon rendu à l'impression en noir et blanc
- [ ] Cohérence avec la marque personnelle
- [ ] Allure professionnelle

## Outils pour les CV graphiques

**Logiciels de design :**
- Adobe InDesign (le meilleur pour la mise en page)
- Figma (idéal pour les profils orientés web)
- Adobe Illustrator (basé sur le vectoriel)
- Sketch (alternative sur Mac)

**Options plus simples :**
- Canva (modèles disponibles)
- Google Docs (limité mais compatible ATS)
- Microsoft Word (étonnamment performant)

**À éviter :**
- PowerPoint/Keynote (non conçus pour cela)
- Générateurs de CV en ligne génériques
- Modèles trop lourds qui masquent le contenu

## Format de restitution

Lors de la création d'un CV créatif :

```markdown
# STRATÉGIE DE CV CRÉATIF

## Type de poste : [Design/Marketing/Créatif]
## Secteur : [Agence/En interne/Freelance]

## Stratégie de versions

### Version 1 : Compatible ATS
**À utiliser pour :** Candidatures en ligne, sites d'emploi
**Format :** .docx et .pdf
**Niveau de design :** Épuré et professionnel, ornements minimes

### Version 2 : Graphique
**À utiliser pour :** Portfolio, networking, prise de contact directe
**Format :** .pdf (qualité impression)
**Niveau de design :** Traitement créatif complet

## Spécifications de design

### Typographie
- Titres : [Nom de la police, graisse, taille]
- Corps de texte : [Nom de la police, graisse, taille]
- Accent : [Nom de la police, cas d'usage]

### Couleurs
- Primaire : [Code hex] - [Cas d'usage]
- Secondaire : [Code hex] - [Cas d'usage]  
- Texte : [Code hex]

### Mise en page
- Format : [Une colonne / Deux colonnes]
- Marges : [Spécifications]
- Grille : [Le cas échéant]

## Intégration du portfolio
- Lien principal vers le portfolio : [URL]
- Études de cas à mettre en avant : [Liste]
- Page CV sur le portfolio : [O/N]

## Adaptations du contenu pour le domaine créatif
- [Recommandation de contenu spécifique]
- [Recommandation de contenu spécifique]
```

## Checklist du CV créatif

- ✅ Disposer à la fois d'une version ATS et d'une version graphique
- ✅ Le design met en avant des compétences pertinentes
- ✅ Le contenu reste lisible et facile à scanner
- ✅ Le lien vers le portfolio est clairement visible
- ✅ L'identité visuelle est cohérente
- ✅ La typographie est professionnelle
- ✅ Les couleurs sont accessibles et s'impriment bien
- ✅ Le fichier est optimisé pour le partage (taille raisonnable)
- ✅ La qualité du contenu est à la hauteur de la qualité du design
- ✅ Le CV constitue une véritable pièce de portfolio en soi
