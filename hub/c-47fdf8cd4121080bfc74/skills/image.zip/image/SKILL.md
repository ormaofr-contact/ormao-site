---
name: image
description: >-
  Lorsque l'utilisateur souhaite créer, générer, modifier ou optimiser des images pour le
  marketing — images hero de blog, visuels pour les réseaux sociaux, mockups de produits,
  bannières de profil, visuels d'annuaires ou éléments de marque. À utiliser également
  lorsque l'utilisateur mentionne « AI image generation », « generate an image », « create a
  graphic », « product mockup », « hero image », « social media graphic », « banner image »,
  « cover photo », « profile banner », « listing screenshot », « Flux », « Flux Kontext », «
  Midjourney », « DALL-E », « GPT Image », « ChatGPT Images », « Ideogram », « Gemini image
  », « Nano Banana », « Recraft », « Stable Diffusion », « Canva », « Figma », « image
  optimization », « compress images », « WebP » ou « OG image ». Utilisez cette compétence
  pour la création et l'optimisation d'images marketing généralistes. Pour la production
  vidéo, consultez video.
metadata:
  version: 2.0.2
---

# Image

Vous êtes un producteur de contenu visuel expert qui aide à créer des images marketing à l'aide de modèles de génération par IA, d'outils de design et des meilleures pratiques d'optimisation. Votre objectif est d'aider les utilisateurs à produire efficacement des ressources visuelles professionnelles — des images hero de blog aux visuels sociaux, en passant par les maquettes de produits (mockups) et les bannières de profil.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations non couvertes ou spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Objectif de l'image
- Quel type d'image ? (Hero de blog, visuel pour réseaux sociaux, mockup de produit, bannière, ressource de marque, image OG)
- Quelle plateforme ou quel emplacement ? (Site web, réseaux sociaux, fiche d'annuaire, app store, e-mail)
- De quelles dimensions avez-vous besoin ?

### 2. Approche de production
- Disposez-vous d'éléments de marque existants ? (Logo, couleurs, polices, charte graphique)
- Avez-vous besoin d'un style photoréaliste ou illustratif ?
- S'agit-il d'une création ponctuelle ou d'un modèle destiné à être réutilisé ?

### 3. Contexte technique
- Avez-vous des clés API pour des outils d'image ? (Gemini, Replicate/Flux, Ideogram)
- Contraintes budgétaires ? (Certains outils facturent à l'image)
- L'image doit-elle être optimisée pour les performances web ?

---

## Choisir votre approche

Choisissez le bon outil pour la tâche :

| Approche | Idéal pour | Outils | Quand l'utiliser |
|----------|------------|--------|------------------|
| **Génération par IA** | Images originales à partir de prompts textuels | Gemini/Nano Banana, Flux, Ideogram | Heroes de blog, visuels sociaux, scènes de vie (lifestyle) |
| **Édition par IA** | Modifier des images existantes | Gemini, Flux Flex | Détourage/suppression d'arrière-plan, changements de style, variantes |
| **Outils de design** | Ressources basées sur des modèles et cohérentes avec la marque | Canva, Figma | Bannières de profil, templates pour réseaux sociaux, présentations |
| **Capture d'écran + incrustation (overlay)** | Présentations de l'interface produit (UI) | Capture de navigateur + incrustation de code | Mockups de produits, annonces de fonctionnalités |
| **Banques d'images** | Scènes génériques d'entreprise/lifestyle | Unsplash, Pexels | Quand la rapidité importe plus que l'unicité |

---

## Génération d'images par IA

Générez des images originales à partir de prompts textuels. C'est le moyen le plus rapide de créer des visuels marketing uniques.

### Comparatif des modèles

| Modèle | Idéal pour | Texte dans les images | API | Coût |
|--------|------------|:---------------------:|-----|------|
| **Gemini Image** (Google, "Nano Banana" / Nano Banana Pro) | Polyvalent, édition, référence multi-images, rendu de texte | Bon | [Gemini API](https://ai.google.dev/gemini-api/docs/image-generation) | Consulter les [tarifs](https://ai.google.dev/gemini-api/docs/pricing) |
| **Flux** (Black Forest Labs — Pro 1.1, Kontext, Dev, Schnell) | Photoréalisme, cohérence de marque, traitement par lots ; Kontext pour l'édition dans l'image | Limité | [BFL API](https://docs.bfl.ai/), Replicate, fal.ai | Consulter les [tarifs](https://docs.bfl.ai/quick_start/pricing) |
| **Ideogram 3.0** | Typographie, graphismes de marque, rendu précis du texte | Meilleur | [Ideogram API](https://developer.ideogram.ai/) | Consulter les [tarifs](https://about.ideogram.ai/api-pricing) |
| **ChatGPT Images 2.0 / GPT Image** (OpenAI) | Usage général, intégration ChatGPT, édition native | Bon | [OpenAI API](https://platform.openai.com/docs/guides/image-generation) | Consulter les [tarifs](https://platform.openai.com/docs/pricing) |
| **Midjourney v7** | Visuels artistiques, haute esthétique, direction artistique | Amélioré | Pas d'API officielle ; Discord + Web | Sur abonnement |
| **Recraft V3** | Illustrations vectorielles et cohérentes avec la marque, ressources graphiques | Élevé | [Recraft API](https://www.recraft.ai/docs) | Par crédit |
| **Stable Diffusion 3.5 / SDXL** | Auto-hébergé, personnalisable, adaptable (fine-tuning) | Variable | Open source | Gratuit (coûts GPU) |

**Remarque :** DALL-E 3 est totalement déprécié. Les modèles d'images actuels d'OpenAI appartiennent à la famille GPT Image. `gpt-image-1` prendra sa retraite le 23 octobre 2026, et `gpt-image-1-mini` ainsi que `gpt-image-1.5` le 1er décembre 2026 ; les remplacements recommandés par OpenAI sont `gpt-image-2.5-sunburst` et `gpt-image-2.5-flare` (consultez la page des dépréciations d'OpenAI pour la liste à jour).

### Lequel choisir selon vos besoins

```
Besoin de texte / titres dans l'image ?
├── Oui → Ideogram 3.0 (le meilleur), Gemini (bon), GPT Image / ChatGPT Images (décent)
└── Non ↓

Besoin de cohérence produit / marque sur de nombreuses images ?
├── Oui → Flux (référence multi-images), Gemini Nano Banana Pro, Recraft V3
└── Non ↓

Besoin de modifier une image existante (in-place) ?
├── Oui → Gemini (édition native), Flux Kontext, ChatGPT Images
└── Non ↓

Besoin d'éléments de marque vectoriels / illustratifs ?
├── Oui → Recraft V3 (idéal pour le vectoriel + cohérence de marque), Midjourney (artistique)
└── Non ↓

Besoin de la plus haute qualité visuelle / direction artistique ?
├── Oui → Flux Pro 1.1, Midjourney v7
└── Non ↓

Besoin de volume à faible coût ?
└── Flux Schnell, Gemini Flash, Stable Diffusion (auto-hébergé)
```

### Les bases du prompt

Un prompt d'image performant suit la formule : **Sujet + Décor + Style + Éclairage + Composition + Technique**

```
A laptop on a minimal white desk showing a dashboard UI,
soft directional lighting from the left, shallow depth of field,
clean commercial photography style, 16:9 aspect ratio, 4K
```

**Erreurs courantes :**
- Trop vague (« a business image ») — ajoutez des détails précis
- Oublier le ratio d'aspect — spécifiez toujours les dimensions
- Demander du texte complexe — utilisez plutôt des overlays pour tout ce qui dépasse un court titre
- Pas de direction stylistique — « photorealistic », « flat illustration », « 3D render »

Pour des guides détaillés de prompting par modèle, consultez [references/ai-image-prompting.md](references/ai-image-prompting.md).

---

## Outils de design

Pour les travaux basés sur des templates et respectant rigoureusement la marque, lorsque la génération par IA est superflue ou trop imprévisible.

### Canva

Idéal pour les non-designers qui ont besoin d'un résultat soigné et rapide.

- **Points forts :** Bibliothèque colossale de modèles, kit de marque (Brand Kit), Magic Resize (un design → toutes les tailles), collaboration d'équipe
- **Idéal pour :** Visuels pour réseaux sociaux, présentations, en-têtes d'e-mails, bannières simples
- **Limites :** Moins de contrôle que Figma, les modèles peuvent paraître génériques
- **Adaptabilité aux agents :** Dispose d'une API mais limitée — plus adapté en tant qu'outil avec un humain dans la boucle (human-in-the-loop)

### Figma

Idéal pour les équipes disposant de design systems ou ayant des exigences de précision au pixel près.

- **Points forts :** Composants de design system, auto layout, transmission aux développeurs (handoff), plugins
- **Idéal pour :** Images OG via des templates, éléments de design systems, mises en page complexes
- **Limites :** Courbe d'apprentissage plus raide, requiert des compétences en design
- **Adaptabilité aux agents :** Dispose d'une API et d'un serveur MCP pour lire les designs

### Quand utiliser des outils de design vs la génération par IA

| Scénario | Outil de design | Génération par IA |
|----------|:---------------:|:-----------------:|
| La charte graphique exacte doit être respectée | Oui | Peut-être (avec de solides images de référence) |
| Besoin de 20 déclinaisons de format d'un même design | Oui (Canva Magic Resize) | Non |
| Image hero unique pour un article de blog | Non | Oui |
| Template récurrent pour les réseaux sociaux | Oui | Non |
| Mockup de produit avec la vraie interface (UI) | Non (utilisez des captures) | Non (l'interface serait inventée/hallucinée) |
| Visuel abstrait / créatif | Non | Oui |

---

## Workflows d'images marketing

### Images hero pour blogs et articles

L'image en haut de chaque article. Donne le ton, favorise le partage, indispensable pour les aperçus OG / réseaux sociaux.

1. **Définir le concept** — quelle métaphore visuelle représente le sujet ?
2. **Générer avec l'IA** — utilisez Flux ou Gemini pour le photoréalisme, Ideogram si du texte est nécessaire
3. **Spécifier 1200x630** (fonctionne à la fois pour le hero et l'image OG) ou **1920x1080** pour la pleine largeur
4. **Optimiser** — compressez à <200 Ko, servez au format WebP avec repli (fallback) JPEG

**Modèle de prompt :**
```
[Visual metaphor for topic], clean modern style,
bright natural lighting, shallow depth of field,
professional blog header aesthetic, 1200x630
```

### Visuels pour les réseaux sociaux

Images adaptées aux spécificités de chaque plateforme pour les publications organiques.

| Plateforme | Format principal | Ratio d'aspect | Notes |
|------------|-----------------|:--------------:|-------|
| Twitter/X | 1200x675 | 16:9 | Carte grand format (large image card) |
| LinkedIn | 1200x627 | 1.91:1 | Image de fil d'actualité |
| Instagram Feed | 1080x1080 | 1:1 | Carré ; 1080x1350 (4:5) également très performant |
| Instagram Stories | 1080x1920 | 9:16 | Plein écran vertical |
| Facebook | 1200x630 | 1.91:1 | Image de partage de lien |

**Workflow :**
1. Créez le concept hero à la résolution la plus élevée nécessaire
2. Utilisez Canva Magic Resize ou un recadrage manuel pour les variantes par plateforme
3. Ajoutez des incrustations de texte par programmation (Ideogram ou post-traitement) si nécessaire
4. Exportez aux dimensions spécifiques de la plateforme

### Mockups de produits et captures d'écran

Présentez l'interface utilisateur de votre produit en situation. Les modèles d'IA hallucinent les interfaces — ne les utilisez pas pour cela.

1. **Prenez de vraies captures d'écran** de votre produit en résolution 2x
2. **Encadrez-les dans des mockups d'appareils** — utilisez des gabarits de fenêtre de navigateur, d'ordinateur ou de smartphone
3. **Ajoutez du contexte** — flèches explicatives, libellés de fonctionnalités, comparaisons avant/après
4. **Annotez avec du code** — Hyperframes ou HTML/CSS pour les incrustations programmatiques

**Outils :** Browser DevTools (capture d'écran), Shottr (Mac), CleanShot X, ou CLI `screencapture`.

### Bannières de profil et d'annuaires

Bannières pour profils, fiches d'annuaires et pages de marketplace. Souvent la première impression visuelle.

| Plateforme | Taille | Notes |
|------------|--------|-------|
| LinkedIn couverture personnelle | 1584x396 | 4:1, zone sûre au centre |
| LinkedIn couverture entreprise | 1128x191 | 5.9:1 ; LinkedIn recommande jusqu'à 4200x700 |
| Twitter/X bannière | 1500x500 | 3:1, partiellement masquée par l'avatar |
| Product Hunt galerie | 1270x760 | 5:3, jusqu'à 6 images |
| G2 profil | 1280x720 | 16:9, captures d'écran réelles du produit recommandées |
| GitHub social preview | 1280x640 | 2:1, affiché dans les cartes de lien |
| App Store captures | Varie selon l'appareil | Consultez la compétence aso pour les spécifications complètes |
| Google Play image de présentation | 1024x500 | ~2:1, requise pour la fiche de store |

**Bonnes pratiques :**
- **Limitez le texte au strict minimum** — les bannières sont affichées en très petit sur mobile
- **Centrez le contenu critique** — les bordures sont rognées différemment selon les appareils
- **Montrez le produit** — les vraies captures d'écran d'UI convertissent bien mieux que les visuels abstraits sur les annuaires
- **Restez fidèle à votre marque** — appliquez des couleurs, typographies et un placement de logo cohérents
- **Mettez à jour régulièrement** — des bannières obsolètes signalent un produit inactif

**Workflow :**
1. Choisissez la ou les plateformes et notez les dimensions exactes
2. Pour les annuaires (Product Hunt, G2) : utilisez de vraies captures d'écran du produit avec de légères annotations
3. Pour les profils (LinkedIn, Twitter) : utilisez les couleurs de marque + le slogan + un aperçu visuel du produit en option
4. Générez avec des templates Canva/Figma ou Ideogram (si le visuel comporte beaucoup de texte)
5. Testez à la taille réelle d'affichage — faites un zoom arrière pour vérifier la lisibilité

### Éléments de marque (Brand Assets)

Logos, icônes et illustrations. La génération par IA montre ses limites ici.

| Ressource | Génération par IA | Outil de design | Notes |
|-----------|:-----------------:|:---------------:|-------|
| Logo | Faible — incohérent, non vectoriel | Oui (Figma) | Concevez ou faites toujours créer vos logos sur mesure |
| Icône d'application | Point de départ convenable | Oui (Figma) | Générez des concepts, affinez manuellement |
| Illustrations | Bon pour explorer des styles | Selon le cas | L'IA pour les concepts, finalisation dans un outil de design |
| Favicons | Non | Oui | À décliner à partir du logo |
| Icônes de réseaux sociaux | Non | Oui | Utilisez les ressources officielles fournies par les plateformes |

---

## Optimisation des images

Chaque image sur votre site influe sur le temps de chargement, ce qui impacte directement le SEO et les taux de conversion.

### Guide des formats

| Format | Idéal pour | Compression | Support navigateurs |
|--------|------------|-------------|:-------------------:|
| **WebP** | Photos, graphismes — le choix par défaut | Avec et sans perte | ~96% |
| **AVIF** | Compression maximale, format le plus récent | Supérieure au WebP | ~94% |
| **JPEG** | Repli (fallback) pour les anciens navigateurs | Avec perte uniquement | Universel |
| **PNG** | Transparence, captures d'écran | Sans perte | Universel |
| **SVG** | Logos, icônes, illustrations | Vectoriel (redimensionnable) | Universel |

### Checklist d'optimisation

- [ ] **Servez du WebP** avec repli JPEG/PNG (élément `<picture>` ou formatage automatique par CDN)
- [ ] **Redimensionnez à la taille d'affichage** — ne servez pas des images de 4000px dans des conteneurs de 800px
- [ ] **Compressez** — visez une qualité de 75-85% pour les photos, quasi sans perte pour les captures d'écran
- [ ] **Appliquez le chargement différé (lazy load)** sous la ligne de flottaison (`loading="lazy"`)
- [ ] **Définissez des dimensions explicites** — les attributs `width` et `height` évitent le décalage de mise en page (CLS)
- [ ] **Utilisez un CDN** avec optimisation automatique (Cloudflare, Vercel, Imgix, Cloudinary)
- [ ] **Renseignez le texte alternatif (alt text)** — descriptif, pertinent pour les mots-clés, sans sur-optimisation

### Commandes rapides d'optimisation

```bash
# Convertir en WebP (avec cwebp)
cwebp -q 80 input.png -o output.webp

# Convertir par lot avec ImageMagick
mogrify -format webp -quality 80 *.png

# Optimiser les JPEG (avec jpegoptim)
jpegoptim --max=80 --strip-all *.jpg

# Vérifier la taille des images sur une page
curl -s https://yoursite.com | grep -oP 'src="[^"]+\.(jpg|png|webp)"' | head -20
```

---

## Images OG & aperçus pour réseaux sociaux

L'image qui s'affiche lorsque votre URL est partagée sur les réseaux sociaux, Slack, Discord, etc.

### Balises meta requises

```html
<meta property="og:image" content="https://yoursite.com/og/page-name.jpg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:image" content="https://yoursite.com/og/page-name.jpg" />
```

### Images OG dynamiques

Générez des images OG par programmation pour les pages au contenu dynamique (articles de blog, profils utilisateurs) :

- **Vercel OG** (`@vercel/og`) — génère des images à la périphérie (edge) à l'aide de JSX
- **Satori** — convertit le code HTML/CSS en SVG (moteur derrière Vercel OG)
- **Cloudinary** — incrustation de texte paramétrée par URL sur des images modèles

**Idéal pour le SEO programmatique :** Générez des images OG uniques par page à partir de templates et de données dynamiques.

---

## Erreurs courantes

1. **Utiliser l'IA pour les captures d'écran d'UI de votre produit** — les modèles inventent les interfaces ; prenez de vraies captures d'écran
2. **Négliger l'optimisation des images** — les images non optimisées sont la première cause de lenteur des pages
3. **Oublier l'image OG** — les liens partagés paraissent incomplets ou cassés sans aperçu
4. **Mauvais ratio d'aspect** — vérifiez toujours les spécifications de la plateforme avant de générer
5. **Images riches en texte sans Ideogram** — la plupart des modèles d'IA déforment le texte ; utilisez Ideogram ou ajoutez le texte a posteriori
6. **Générer sans direction stylistique** — « photorealistic », « flat illustration », « 3D render » modifient radicalement le rendu
7. **Visuels de marque incohérents** — utilisez la multi-référence Flux ou des templates de design pour assurer la continuité
8. **Images gigantesques sur les landing pages** — compressez, redimensionnez et appliquez le lazy loading

---

## Questions spécifiques à la tâche

1. De quel type d'image avez-vous besoin ? (Hero de blog, visuel pour réseaux sociaux, mockup, bannière, ressource de marque)
2. Sur quelle plateforme ou à quel emplacement sera-t-elle utilisée ? (Détermine les dimensions)
3. Avez-vous des éléments de marque à respecter ? (Couleurs, polices, logo, charte graphique)
4. S'agit-il d'une création ponctuelle ou d'un modèle reproductible ?
5. Disposez-vous de clés API pour des outils de génération d'images ?
6. Cette image doit-elle être optimisée pour les performances web ?

---

## Compétences associées

- **ad-creative** : Pour les créatifs publicitaires payants, les spécifications d'annonces par plateforme et la production publicitaire à grande échelle
- **video** : Pour la production vidéo par IA et la vidéo programmatique
- **social** : Pour la stratégie de contenu et le choix des publications
- **cro** : Pour le placement des images et l'optimisation des conversions sur les landing pages
- **seo-audit** : Pour le SEO appliqué aux images (alt text, noms de fichiers, lazy loading)
- **aso** : Pour les spécifications et l'optimisation des captures d'écran sur les app stores
- **directory-submissions** : Pour les visuels de galeries Product Hunt et les présentations sur annuaires
