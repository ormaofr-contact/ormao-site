---
name: executing-plans
description: À utiliser lors de l'exécution d'un plan d'implémentation dans la session actuelle en tant qu'implémenteur vous-même — votre partenaire humain a choisi l'exécution en ligne, ou aucun outil de sous-agent n'est disponible
---

# Exécution des plans

Exécutez le plan vous-même, tâche par tâche, dans cette session : aucun
sous-agent implémenteur par tâche, aucun réviseur par tâche. Une seule
revue avec un contexte neuf de l'ensemble de la branche à la fin.

**Pourquoi en ligne :** Le développement piloté par sous-agents paie le
prix d'un implémenteur neuf et d'un réviseur neuf pour chaque tâche,
chacun relisant la base de code depuis zéro. L'exécution en ligne paie pour
un seul contexte (le vôtre) plus un réviseur à la fin. Ce à quoi elle
renonce, c'est à un contexte neuf par tâche et à une deuxième paire d'yeux
par tâche. Cette compétence conserve ce que ces deux éléments apportaient,
par d'autres moyens : le brief est la spécification, le registre (ledger)
est votre mémoire, le TDD est le point de contrôle à chaque tâche, et le
réviseur final est la deuxième paire d'yeux.

**Principe fondamental :** La réflexion a déjà été menée dans le plan.
Exécutez-le exactement, prouvez chaque étape à l'aide d'un test que vous
avez vu échouer puis réussir, et laissez une trace qui survit à vos
propres oublis.

**Narration :** entre les appels d'outils, commentez tout au plus sur une
ligne courte — le registre et les résultats des outils portent la trace.

**Exécution continue :** Ne faites pas de pause pour solliciter votre
partenaire humain entre les tâches. Il a choisi l'exécution en ligne pour
consommer moins, pas pour répondre à « dois-je continuer ? » après chaque
tâche. Exécutez toutes les tâches du plan sans vous arrêter.

**Des arbitrages (rulings), pas de blocages.** Conflits, ambiguïtés, défauts
du plan — tranchez-les. La spécification est l'autorité qui fait foi, le
plan est son argumentation, et votre jugement tranche ce à quoi ni l'un ni
l'autre ne répond. Consignez chaque décision dans le registre sous la forme
`Ruling: <what you decided> — <why> — <what it costs if wrong>`, et
continuez. Dévier du plan sans arbitrage consigné dans le registre est une
décision prise en secret.

Quatre choses vous arrêtent, et uniquement celles-ci : une opération
irréversible ou destructive ; une action sensible en matière de sécurité ;
un effet de bord en dehors de ce worktree pour lequel les usages exigent de
demander d'abord (un merge, un push vers une branche partagée, une
publication) ; et un plan tellement corrompu que toute voie à suivre
relève de la conjecture. Pour ceux-là, arrêtez-vous et demandez.

## Quand l'utiliser

- Vous disposez d'un plan issu de superpowers:writing-plans et votre
  partenaire humain a choisi l'exécution en ligne lors du passage de relais.
- Votre environnement ne dispose d'aucun outil de sous-agent (voir les
  références par plateforme dans `../using-superpowers/references/`). Ne
  fabriquez jamais de faux dispatch ; exécutez le plan ici.
- Les tâches sont en grande partie indépendantes — la même condition
  préalable que pour superpowers:subagent-driven-development.

Un plan entièrement spécifié fait de l'exécution en ligne une simple
transcription accompagnée de tests : cela fonctionne très bien sur un
modèle de session intermédiaire, et le seul endroit où le modèle le plus
performant justifie son coût est la revue finale, que cette compétence
délègue séparément. Signalez-le à votre partenaire humain lorsqu'il
choisit le mode en ligne.

Préférez superpowers:subagent-driven-development lorsque votre partenaire
humain souhaite un point de contrôle avec revue à chaque tâche, ou lorsque
le plan est suffisamment long pour que ses dernières tâches s'exécutent
sur un contexte compacté. L'exécution en ligne sur un long plan fonctionne
toujours — le registre est ce qui permet de s'en remettre —, mais les
dernières tâches bénéficient de moins de ressources attentionnelles.

## Le processus

```dot
digraph process {
    rankdir=TB;

    subgraph cluster_per_task {
        label="Per Task";
        "task-start: brief + BASE; read the brief" [shape=box];
        "Work the steps in order: TDD, run every verification, read every output" [shape=box];
        "Step output matches plan's Expected?" [shape=diamond];
        "Plan wrong? Rule and ledger. Code wrong? systematic-debugging" [shape=box];
        "Commit as the plan's commit steps say" [shape=box];
        "Completion contract met?" [shape=diamond];
        "task-done: run tests, ledger the result; mark todo complete" [shape=box];
    }

    "Setup: worktree, workspace + ledger, read plan + spec, pre-flight scan" [shape=box];
    "More tasks remain?" [shape=diamond];
    "Final whole-branch review (fresh reviewer if you have one)" [shape=box];
    "Re-grade, then: Critical/Important → ONE fix pass, each fix RED→GREEN + green suite; Minor → ledger" [shape=box];
    "Final review clean: delete this plan's workspace" [shape=box];
    "Use superpowers:finishing-a-development-branch" [shape=box style=filled fillcolor=lightgreen];

    "Setup: worktree, workspace + ledger, read plan + spec, pre-flight scan" -> "task-start: brief + BASE; read the brief";
    "task-start: brief + BASE; read the brief" -> "Work the steps in order: TDD, run every verification, read every output";
    "Work the steps in order: TDD, run every verification, read every output" -> "Step output matches plan's Expected?";
    "Step output matches plan's Expected?" -> "Plan wrong? Rule and ledger. Code wrong? systematic-debugging" [label="no"];
    "Plan wrong? Rule and ledger. Code wrong? systematic-debugging" -> "Work the steps in order: TDD, run every verification, read every output";
    "Step output matches plan's Expected?" -> "Commit as the plan's commit steps say" [label="yes, last step"];
    "Commit as the plan's commit steps say" -> "Completion contract met?";
    "Completion contract met?" -> "Work the steps in order: TDD, run every verification, read every output" [label="no - finish the task"];
    "Completion contract met?" -> "task-done: run tests, ledger the result; mark todo complete" [label="yes"];
    "task-done: run tests, ledger the result; mark todo complete" -> "More tasks remain?";
    "More tasks remain?" -> "task-start: brief + BASE; read the brief" [label="yes"];
    "More tasks remain?" -> "Final whole-branch review (fresh reviewer if you have one)" [label="no"];
    "Final whole-branch review (fresh reviewer if you have one)" -> "Re-grade, then: Critical/Important → ONE fix pass, each fix RED→GREEN + green suite; Minor → ledger";
    "Re-grade, then: Critical/Important → ONE fix pass, each fix RED→GREEN + green suite; Minor → ledger" -> "Final review clean: delete this plan's workspace";
    "Final review clean: delete this plan's workspace" -> "Use superpowers:finishing-a-development-branch";
}
```

## Configuration

Assurez-vous que le travail se déroule dans un espace de travail isolé :
utilisez superpowers:using-git-worktrees pour en créer un ou vérifier
celui qui existe déjà. Ne commencez jamais l'implémentation sur une
branche main/master sans l'accord explicite de votre partenaire humain.

La mémoire de la conversation ne survit pas à la compaction de contexte.
Un exécuteur en ligne qui perd le fil réimplémente des tâches dont les
commits existent déjà — le même échec qu'un contrôleur qui les réassigne,
payé avec votre propre contexte. Suivez la progression dans un fichier de
registre (ledger), pas seulement dans les todos. Les todos de
l'environnement sont une vue en direct ; le registre est la trace
officielle.

L'espace de travail et le registre sont partagés avec
superpowers:subagent-driven-development — même répertoire, même format —
afin qu'un plan puisse changer d'exécuteur en cours de route et que le
nouvel exécuteur reprenne à partir du même registre.

- Chaque plan possède un espace de travail : au lancement de la compétence,
  exécutez `../subagent-driven-development/scripts/sdd-workspace PLAN_FILE`
  — cela affiche le répertoire ignoré par git du plan
  (`<repo-root>/.superpowers/sdd/<plan-basename>/`), qui abrite chaque
  artefact pour CE plan : registre, briefs, paquets de revue. Le répertoire
  d'un autre plan n'est jamais le vôtre à lire ou à écrire.
- Vérifiez la présence du registre de ce plan à l'emplacement
  `<workspace>/progress.md`. Si sa première ligne mentionne votre fichier
  de plan, les tâches comportant une ligne `Task <N>: complete` sont
  TERMINÉES — ne les refaites pas ; reprenez à la première tâche qui n'en a
  pas. Leurs commits existent dans git même lorsque votre contexte ne se
  souvient plus de les avoir créés : après une compaction, faites confiance
  au registre et à `git log` plutôt qu'à vos propres souvenirs. Un registre
  dont la première ligne mentionne un fichier de plan différent représente
  la progression d'un autre plan : laissez-le et commencez le vôtre, à neuf.
- Créez le registre avec son identité sur la première ligne :
  `# SDD ledger — plan: <plan file path>`.
- `git clean -fdx` détruira l'espace de travail (c'est un espace temporaire
  ignoré par git) ; si cela se produit, récupérez la situation à partir de
  `git log`.

Lisez le plan une fois, notez son contexte et ses Global Constraints, et
créez une todo par tâche. Si le plan mentionne une Spec, lisez-la
également : la spécification est l'autorité sur laquelle s'appuie le plan,
et les conflits internes au plan se résolvent par rapport à elle. Un plan
sans spécification accessible reçoit une note dans le registre l'indiquant
— les arbitrages faits sans celle-ci sont provisoires.

**SOUS-COMPÉTENCE REQUISE :** chargez superpowers:test-driven-development
dès maintenant, avant la tâche 1. Elle régit chaque étape de chaque tâche
ci-dessous ; un plan dont les étapes indiquent déjà « écrivez d'abord le
test qui échoue » ne vous dispense pas de la lire.

Avant la tâche 1, inspectez le plan pour détecter d'éventuels conflits
entre les tâches. Les blocs Interfaces du plan vous indiquent où regarder :
pour chaque tâche qui consomme ce qu'une tâche antérieure produit, insérez
une ligne dans le registre — les deux tâches, ce que l'une produit par
rapport à ce que l'autre consomme, et ce que vous avez trouvé. Les tâches
qui ne partagent rien n'ont pas de ligne ; un plan dont les tâches ne
partagent rien reçoit la ligne unique `Pre-flight: no shared interfaces`.
Tranchez chaque conflit qu'une ligne met en évidence en prenant la
spécification comme autorité souveraine, consignez l'arbitrage à côté de sa
ligne, et commencez la tâche 1. Le texte propre à chaque tâche est vérifié
lorsque vous lisez son brief, pas ici.

## La boucle de tâche

Tout ce que vous affichez, et chaque résultat d'outil, reste présent dans
votre contexte pour le reste de la session. Redirigez les sorties de tests
volumineuses vers un fichier dans l'espace de travail et lisez-en la fin
(`tail`) ; lisez un brief, pas l'intégralité du plan.

### 1. Prendre la tâche

- Exécutez le script `scripts/task-start PLAN_FILE N` de cette compétence.
  Il affiche le chemin du brief et BASE (le commit à partir duquel la plage
  de la tâche est découpée) en un seul appel. Lisez le brief pour chaque
  tâche, y compris celles dont vous vous souvenez depuis la configuration :
  ce dont vous vous souvenez n'est qu'un résumé, le brief contient les
  valeurs, signatures et cas de test exacts.
- Marquez la todo de la tâche comme in_progress.

Chaque appel d'outil est un tour qui relit l'intégralité de votre contexte.
Le suivi s'intègre au travail — un ajout au registre se fait dans le même
appel que le commit, jamais dans un appel dédié.

### 2. Dérouler les étapes

Les étapes du plan sont déjà ordonnées selon RED-GREEN ; suivez-les dans
cet ordre conformément à superpowers:test-driven-development, chargé lors
de la configuration. Le code d'une étape de test est écrit en premier et
exécuté en premier. Le voir échouer est une étape, pas une formalité — un
test qui réussit avant que l'implémentation n'existe est une anomalie
concernant le test.

Chaque étape exécutant une commande comporte une ligne `Expected:`. Lancez
la commande, lisez sa sortie et comparez. Trois issues possibles :

- **Correspondance.** Étape suivante.
- **Le code est erroné.** Utilisez superpowers:systematic-debugging.
  Trouvez la cause ; ne corrigez jamais le symptôme pour forcer la sortie de
  l'étape à correspondre.
- **Le plan est erroné** — une étape contredit la spécification, une
  interface d'une tâche antérieure ne correspond pas à ce que cette tâche
  consomme, une commande ne peut pas fonctionner. Tranchez en choisissant
  le plus petit changement qui satisfait la spécification, consignez-le
  dans le registre sous la forme `Task <N>: Ruling: <finding> — <what you
  decided and why>`, et continuez. L'arbitrage est consigné, pas mémorisé :
  les tâches ultérieures qui touchent à la même interface le liront dans
  le registre.

Commitez comme l'indiquent les étapes de commit du plan. Une tâche qui
s'étend sur plusieurs commits ne pose pas de problème ; BASE est ce à
partir de quoi la plage de revue est découpée, jamais `HEAD~1`.

### 3. Le contrat d'achèvement

Avant d'inscrire la ligne d'une tâche dans le registre, toutes les
affirmations suivantes doivent être vraies, preuves à l'appui dans cette
session — et non déduites du fait que le diff semble correct :

- Chaque test mentionné dans le brief existe et a été exécuté lors de cette
  tâche, et vous en avez lu la sortie.
- La dernière exécution des tests pour la tâche a réussi — `task-done`
  correspond à cette exécution, et il inscrit la commande ainsi que le
  résultat dans la ligne du registre.
- Chaque ligne `Expected:` du brief a été comparée à la sortie réelle.
- Chaque divergence par rapport au brief fait l'objet d'une ligne
  `Ruling:` dans le registre.

**SOUS-COMPÉTENCE REQUISE :** superpowers:verification-before-completion
régit cette affirmation. Si un seul élément manque, la tâche n'est pas
terminée : terminez-la.

### 4. Terminer la tâche

Exécutez le script `scripts/task-done PLAN_FILE N BASE -- <test command>` de
cette compétence avec la commande de test indiquée dans le brief pour
l'ensemble de la tâche. Il exécute les tests, conserve la sortie complète
dans l'espace de travail, en affiche la fin, et — seulement s'ils
réussissent — ajoute la ligne d'achèvement au registre :

`Task <N>: complete (commits <base7>..<head7>, tests: <command> → <result>)`

Une exécution en échec n'enregistre rien ; la tâche n'est pas terminée.
Lorsqu'elle s'enregistre, marquez la todo comme terminée et prenez la
tâche suivante.

## Revue finale

Exécutez `../subagent-driven-development/scripts/review-package PLAN_FILE MERGE_BASE HEAD`
(MERGE_BASE = le commit d'où la branche est issue, par ex.
`git merge-base main HEAD`) et effectuez la revue à partir du fichier
affiché.

**Avec un outil de sous-agent :** déléguez au réviseur sur le modèle
disponible le plus performant — la revue de l'ensemble de la branche est une
tâche de jugement — en utilisant le fichier
[code-reviewer.md](../requesting-code-review/code-reviewer.md) de
superpowers:requesting-code-review, avec le chemin du paquet, les chemins
du plan et de la spécification, la section Review Focus du plan
textuellement si elle existe (les classes d'entrées et les modes de
défaillance que les tests du plan n'exercent pas — le réviseur examine
chacun délibérément), ainsi qu'un pointeur vers les lignes `Ruling:` du
registre pour qu'il puisse peser les décisions que vous avez prises.
Spécifiez le modèle explicitement ; un modèle omis hérite de celui de la
session, qui n'est peut-être pas le plus performant. C'est le seul contexte
neuf que l'ensemble du processus s'offre. Ne l'ignorez pas, et ne le
remplacez pas par votre propre lecture du diff.

**Sans outil de sous-agent :** lisez code-reviewer.md et réalisez vous-même
cette revue sur le paquet, lors d'une passe distincte après la ligne de
registre de la dernière tâche. Écrivez `Final review: self-review (no
subagent tool)` dans le registre, et indiquez-le dans votre message
final : une auto-revue par l'auteur a moins de valeur qu'un réviseur neuf,
et votre partenaire humain décide si cela suffit avant le merge.

Triez les remarques avant d'agir sur l'une d'elles. Les niveaux de
sévérité attribués par le réviseur sont consultatifs ; le contrôle vous
appartient. Sa liste « Declined to judge » vous revient également :
chaque ligne s'y trouvant est un arbitrage que vous effectuez et
consignez, exactement comme un conflit de plan — `Final: Ruling: <behavior
the reviewer set aside> — <what a reasonable person using this software
gets, and why that stands or why it is now a finding> — <cost if wrong>`.
Réévaluez d'abord selon l'effet : la spécification est un document
d'intention, et la sévérité d'une remarque dépend de ce qu'une personne
raisonnable utilisant ce logiciel subira si c'est déployé, non de savoir si
la spécification mentionne l'entrée qui la déclenche — un réviseur qui a
classé une remarque comme Minor parce que la spécification était muette a
évalué la spécification, pas l'effet. Ensuite :

- **Critical et Important** entrent dans la passe de correction.
- **Minor** va dans le registre sous la forme `Final: minor (deferred):
  <one-liner>` et dans votre message final sous la section « Minors
  reportés ». Les Minors n'entrent jamais dans la passe de correction et ne
  deviennent jamais des arbitrages — un arbitrage est une décision
  concernant un conflit, pas une note indiquant que vous avez décliné une
  suggestion de fignolage.

Corrigez vous-même les remarques Critical et Important — vous êtes
l'implémenteur ici — en UNE SEULE passe. Chaque correction est vérifiée
par TDD, pas par un second réviseur : écrivez le test qui reproduit la
remarque, regardez-le échouer, faites-le réussir, puis lancez la suite
complète. Enregistrez chacune dans le registre sous la forme `Final: fixed
<finding> — <test name> RED→GREEN, suite <N>/<N>`. Une correction sans
test ayant d'abord échoué n'est pas vérifiée ; une suite qui n'est pas au
vert après la passe signifie que la passe n'est pas terminée. Ne déléguez
pas une nouvelle revue : cela relirait un diff dont les tests de couverture
répondent déjà par « traité » et dont l'exécution de la suite répond déjà
par « n'a rien cassé ».

Une remarque que vous décidez de ne pas corriger constitue un arbitrage —
`Final: Ruling: <finding> — <why the code stands> — <cost if wrong>` — et
est transmise à votre partenaire humain dans la liste des arbitrages. Il n'y
a pas de seconde passe de correction.

## Finalisation

Avant de supprimer quoi que ce soit, rassemblez chaque ligne du registre
contenant `Ruling:` dans votre message final sous la section « Arbitrages
que j'ai rendus », dans l'ordre où vous les avez faits, chacun accompagné
de son coût en cas d'erreur, et chaque ligne `minor (deferred)` sous
« Minors reportés ». Les deux listes sont exhaustives. Votre message final
est le seul endroit où les décisions prises au nom de votre partenaire
humain — et les remarques sur lesquelles vous avez choisi de ne pas agir —
lui parviennent.

Lorsque la revue finale est sans encombre et que ses corrections sont
commitées, supprimez le répertoire de travail de ce plan — l'historique git
sert désormais de trace officielle. Les répertoires frères appartiennent à
d'autres plans ; ne les touchez pas.

Utilisez superpowers:finishing-a-development-branch.

## Rationalisations courantes

| Excuse | Réalité |
|--------|---------|
| « Je me souviens de ce que dit la tâche N » | Vous vous souvenez d'un résumé. Le brief contient les valeurs exactes. Lisez-le. |
| « Le code du plan est correct, pas besoin de regarder le test échouer » | Un test que vous n'avez jamais vu échouer ne prouve rien. C'est une étape. Exécutez-le. |
| « Je lancerai la suite complète à la fin plutôt qu'à chaque étape » | Les exécutions par étape sont la façon dont vous apprenez quelle étape a tout cassé. L'exécution de fin de tâche est le contrat, pas un substitut. |
| « Le plan est erroné ici, je vais simplement faire ce qu'il faut » | Faites ce qu'il faut et consignez l'arbitrage dans le registre. Une déviation non consignée est une décision prise en secret. |
| « J'écrirai les lignes du registre après quelques tâches » | La compaction de contexte n'attend pas un moment opportun. Une ligne par tâche, dans le même message que le commit. |
| « Je vais vérifier avec lui avant la tâche suivante » | Il a choisi l'exécution en ligne pour consommer moins. Les demandes de confirmation consomment son temps. Seuls les quatre cas d'arrêt vous arrêtent. |
| « J'ai lu mon propre diff attentivement ; le réviseur final est redondant » | Même auteur, mêmes angles morts. Le réviseur est le seul contexte neuf que ce processus s'offre. |
| « Les tests devraient passer, le changement était trivial » | « Devraient » n'est pas une preuve. Le contrat exige la commande et sa sortie. |
| « Les sous-agents sont lents et coûteux, je vais aussi sauter la revue finale » | Le mode en ligne a déjà éliminé les réviseurs par tâche. Une revue de l'ensemble de la branche est le minimum requis, pas le plafond. |
| « Le réviseur a dit Minor, donc c'est Minor » | L'étiquette a évalué le silence de la spécification. Évaluez ce que l'utilisateur obtient. Réévaluez, puis filtrez. |
| « La correction est évidente, pas besoin d'un test qui échoue d'abord » | Le test qui échoue est la seule preuve que la remarque était réelle et qu'elle est désormais résolue. Sans lui, vous n'avez qu'un diff et un espoir. |
| « Je vais corriger les remarques mineures aussi tant que j'y suis » | Chaque remarque mineure que vous corrigez représente un test, un correctif et une exécution de suite que votre partenaire n'a pas demandés. Consignez-les dans le registre ; votre partenaire décidera. |
