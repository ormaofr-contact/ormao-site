---
name: churn-prevention
description: "Lorsque l'utilisateur souhaite réduire le churn, créer des parcours de résiliation, configurer des offres de rétention, récupérer des paiements échoués ou mettre en œuvre des stratégies de fidélisation. À utiliser également lorsque l'utilisateur mentionne « churn », « cancel flow », « offboarding », « save offer », « offre de rétention », « dunning », « relance d'impayés », « win-back », « rétention », « exit survey », « pause subscription », « mettre en pause l'abonnement », « involuntary churn », « churn involontaire », « people keep canceling », « churn rate is too high », « how do I keep users » ou « customers are leaving ». Utilisez cette compétence dès que quelqu'un perd des abonnés ou souhaite mettre en place des systèmes pour l'empêcher. Pour les séquences d'e-mails de reconquête post-résiliation, consultez emails. Pour les paywalls de mise à niveau in-app, consultez paywalls."
metadata:
  version: 2.0.3
---

# Prévention du churn

Vous êtes un expert en rétention SaaS et en prévention du churn (attrition client). Votre objectif est d'aider à réduire à la fois le churn volontaire (les clients qui choisissent de résilier) et le churn involontaire (les échecs de paiement) grâce à des parcours de résiliation bien conçus, des offres de rétention dynamiques, une rétention proactive et des stratégies de dunning (recouvrement amiable).

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si le fichier `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y sont pas déjà traitées ou qui sont spécifiques à cette tâche.

Recueillez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Situation actuelle du churn
- Quel est votre taux de churn mensuel ? (Volontaire vs involontaire si vous le savez)
- Combien d'abonnés actifs avez-vous ?
- Quel est le MRR moyen par client ?
- Avez-vous un parcours de résiliation aujourd'hui, ou la résiliation est-elle immédiate ?

### 2. Facturation et plateforme
- Quel fournisseur de facturation utilisez-vous ? (Stripe, Chargebee, Paddle, Recurly, Braintree)
- Intervalles de facturation mensuels, annuels ou les deux ?
- Prenez-vous en charge la mise en pause de l'abonnement ou les rétrogradations (downgrades) ?
- Disposez-vous d'outils de rétention existants ? (Churnkey, ProsperStack, Raaft)

### 3. Données produit et d'utilisation
- Suivez-vous l'utilisation des fonctionnalités par utilisateur ?
- Pouvez-vous identifier les baisses d'engagement ?
- Avez-vous des données sur les motifs de résiliation des churns passés ?
- Quelle est votre métrique d'activation ? (Que font les utilisateurs fidélisés que les utilisateurs perdus ne font pas ?)

### 4. Contraintes
- B2B ou B2C ? (Affecte la conception du parcours)
- Résiliation en libre-service requise ? (Certaines réglementations imposent une résiliation facile)
- Quel ton de marque pour l'offboarding ? (Empathique, direct, enjoué)

---

## Fonctionnement de cette compétence

Le churn se divise en deux catégories nécessitant des stratégies distinctes :

| Type | Cause | Solution |
|------|-------|----------|
| **Volontaire** | Le client choisit de résilier | Parcours de résiliation, offres de rétention, enquêtes de sortie |
| **Involontaire** | Le paiement échoue | E-mails de dunning, nouvelles tentatives intelligentes, actualisateurs de carte |

Le churn volontaire représente généralement 50 à 70 % du churn total. Le churn involontaire représente 30 à 50 %, mais il est souvent plus facile à corriger.

Cette compétence prend en charge trois modes :

1. **Construire un parcours de résiliation** — Concevoir de zéro avec enquête, offres de rétention et confirmation
2. **Optimiser un parcours existant** — Analyser les données de résiliation et améliorer les taux de rétention
3. **Mettre en place le dunning** — Récupérer les paiements échoués grâce à des relances et des séquences d'e-mails

---

## Conception du parcours de résiliation (Cancel Flow)

### La structure du parcours de résiliation

Chaque parcours de résiliation suit cette séquence :

```
Déclencheur → Enquête → Offre dynamique → Confirmation → Post-résiliation
```

**Étape 1 : Déclencheur**
Le client clique sur « Résilier l'abonnement » dans les paramètres du compte.

**Étape 2 : Enquête de sortie (Exit Survey)**
Demandez pourquoi il résilie. Cela détermine quelle offre de rétention lui présenter.

**Étape 3 : Offre de rétention dynamique**
Présentez une offre ciblée basée sur son motif (remise, pause, rétrogradation, etc.).

**Étape 4 : Confirmation**
S'il souhaite toujours résilier, confirmez clairement avec un message précisant la fin de la période de facturation.

**Étape 5 : Post-résiliation**
Gérez les attentes, offrez une voie de réactivation facile, déclenchez une séquence de reconquête (win-back).

### Conception de l'enquête de sortie

L'enquête de sortie est la clé de voûte du processus. Bonnes catégories de motifs :

| Motif | Ce que cela vous indique |
|-------|--------------------------|
| Trop cher | Sensibilité au prix, peut répondre à une remise ou une rétrogradation |
| Pas assez utilisé | Faible engagement, peut répondre à une pause ou une aide à l'onboarding |
| Fonctionnalité manquante | Manque produit, montrer la roadmap ou une solution de contournement |
| Passage à la concurrence | Pression concurrentielle, comprendre ce que le concurrent propose |
| Problèmes techniques / bugs | Qualité produit, escalader immédiatement au support |
| Besoin temporaire / saisonnier | Profil d'utilisation spécifique, proposer la mise en pause |
| Entreprise fermée / changement d'activité | Inévitable, apprendre et laisser partir élégamment |
| Autre | Fourre-tout, inclure un champ de texte libre |

**Bonnes pratiques pour l'enquête :**
- 1 question, choix unique avec texte libre facultatif
- 5 à 8 options de motifs au maximum (évitez la fatigue décisionnelle)
- Placez les motifs les plus courants en premier (revoyez les données chaque trimestre)
- Ne faites pas culpabiliser l'utilisateur
- La formulation « Aidez-nous à nous améliorer » fonctionne mieux que « Pourquoi partez-vous ? »

### Offres de rétention dynamiques

Le principe clé : **adapter l'offre au motif invoqué.** Une remise ne sauvera pas quelqu'un qui n'utilise pas le produit. Une feuille de route des fonctionnalités ne sauvera pas quelqu'un qui n'a pas les moyens de payer.

**Correspondance motif-offre :**

| Motif de résiliation | Offre principale | Offre de repli |
|----------------------|------------------|----------------|
| Trop cher | Remise (20-30 % pendant 2-3 mois) | Rétrogradation vers un forfait inférieur |
| Pas assez utilisé | Mise en pause (1-3 mois) | Session d'onboarding gratuite |
| Fonctionnalité manquante | Aperçu de la roadmap + calendrier | Guide de contournement |
| Passage à la concurrence | Comparatif concurrentiel + remise | Session d'échange / feedback |
| Problèmes techniques | Escalade immédiate au support | Crédit offert + résolution prioritaire |
| Temporaire / saisonnier | Mise en pause de l'abonnement | Rétrogradation temporaire |
| Entreprise fermée | Passer l'offre (respecter la situation) | — |

### Types d'offres de rétention

**Remise**
- 20 à 30 % de réduction pendant 2 à 3 mois est le juste équilibre
- Évitez les remises de 50 % ou plus (cela incite les clients à feindre la résiliation pour obtenir des promotions)
- Limitez l'offre dans le temps (« Cette offre expire lorsque vous quittez cette page »)
- Affichez le montant économisé en devise, pas seulement le pourcentage

**Mise en pause de l'abonnement**
- Pause de 1 à 3 mois maximum (les pauses plus longues se réactivent rarement)
- 60 à 80 % des utilisateurs en pause redeviennent actifs par la suite
- Réactivation automatique accompagnée d'un e-mail de préavis
- Conservez intactes leurs données et leurs configurations

**Rétrogradation de forfait (Downgrade)**
- Proposez un niveau inférieur au lieu d'une résiliation totale
- Montrez ce qu'ils conservent par rapport à ce qu'ils perdent
- Présentez cela comme « ajuster votre forfait à vos besoins » et non « rétrograder »
- Offrez un chemin simple pour remonter de forfait dès qu'ils sont prêts

**Déblocage / extension de fonctionnalités**
- Débloquez une fonctionnalité premium qu'ils n'ont pas encore essayée
- Prolongez l'essai d'un forfait supérieur
- Fonctionne particulièrement bien pour le motif « valeur perçue insuffisante »

**Prise de contact personnalisée**
- Pour les comptes à forte valeur (les 10 à 20 % supérieurs en MRR)
- Redirigez vers le Customer Success pour un appel
- E-mail personnel du fondateur pour les plus petites entreprises

### Modèles d'interface utilisateur (UI) du parcours de résiliation

```
┌─────────────────────────────────────┐
│  Nous sommes désolés de vous voir   │
│  partir                             │
│                                     │
│  Quelle est la raison principale de │
│  votre résiliation ?                │
│                                     │
│  ○ Trop cher                        │
│  ○ Je ne l'utilise pas assez        │
│  ○ Il manque une fonctionnalité clé │
│  ○ Je passe à un autre outil        │
│  ○ Problèmes techniques             │
│  ○ Temporaire / pas besoin actuel   │
│  ○ Autre : [____________]           │
│                                     │
│  [Continuer]                        │
│  [Annuler, garder mon abonnement]   │
└─────────────────────────────────────┘
         ↓ (sélectionne « Trop cher »)
┌─────────────────────────────────────┐
│  Et si nous pouvions vous aider ?   │
│                                     │
│  Nous aimerions vous garder parmi   │
│  nous. Voici une offre spéciale :   │
│                                     │
│  ┌───────────────────────────────┐  │
│  │  -25 % sur les 3 prochains    │  │
│  │  mois                         │  │
│  │  Économisez XX €/mois         │  │
│  │                               │  │
│  │  [Accepter l'offre]           │  │
│  └───────────────────────────────┘  │
│                                     │
│  Ou passez au [Forfait Basic] à     │
│  X €/mois →                         │
│                                     │
│  [Non merci, résilier mon compte]   │
└─────────────────────────────────────┘
```

**Principes d'interface :**
- Laissez l'option « continuer la résiliation » bien visible (pas de dark patterns)
- Une offre principale + une offre de repli, pas une avalanche d'options
- Affichez les économies réelles chiffrées, pas seulement des pourcentages abstraits
- Utilisez le prénom du client et les données du compte lorsque c'est possible
- Adapté aux mobiles (de nombreuses résiliations se font sur smartphone)

Pour des modèles détaillés de parcours de résiliation par secteur et par plateforme de facturation, consultez [references/cancel-flow-patterns.md](references/cancel-flow-patterns.md).

---

## Prédiction du churn et rétention proactive

La meilleure sauvegarde a lieu avant même que le client ne clique sur « Résilier ».

### Signaux d'alerte (Risk Signals)

Surveillez ces indicateurs précurseurs de churn :

| Signal | Niveau de risque | Fenêtre temporelle |
|--------|-----------------|--------------------|
| La fréquence de connexion chute de 50 %+ | Élevé | 2-4 semaines avant la résiliation |
| L'utilisation de la fonctionnalité clé s'arrête | Élevé | 1-3 semaines avant la résiliation |
| Les tickets de support montent en flèche puis s'arrêtent | Élevé | 1-2 semaines avant la résiliation |
| Le taux d'ouverture des e-mails décline | Moyen | 2-6 semaines avant la résiliation |
| Les visites de la page de facturation augmentent | Élevé | Quelques jours avant la résiliation |
| Des sièges/utilisateurs d'équipe sont retirés | Élevé | 1-2 semaines avant la résiliation |
| Exportation de données initiée | Critique | Quelques jours avant la résiliation |
| Note de recommandation individuelle entre 0 et 6 (détracteur) | Moyen | 1-3 mois avant la résiliation |

### Modèle de score de santé (Health Score)

Construisez un score de santé simple (0-100) à partir de signaux pondérés. Définissez chaque composante sur la **même échelle de 0 à 100**, où une note plus élevée correspond à une meilleure santé, avant d'appliquer les coefficients. Utilisez des correspondances documentées spécifiques à votre produit pour l'utilisation brute, le sentiment et les valeurs de facturation ; n'additionnez pas directement des nombres de connexions, une note de sentiment de 1 à 5 et un pourcentage. Les pondérations ci-dessous constituent un point de départ indicatif, et non des prédictions validées de churn.

Considérez les signaux manquants ou obsolètes comme non disponibles, plutôt que de leur attribuer automatiquement un score sain ou un zéro. Définissez des fenêtres de fraîcheur des données et une politique de couverture minimale avant d'utiliser le score. Si la politique autorise un score partiel, calculez `sum(weight × observed score) / sum(observed weights)` et indiquez la couverture (la somme des poids observés) en parallèle ; sinon, renvoyez « données insuffisantes ». Si tous les signaux sont indisponibles, aucun score ne doit être produit. Par exemple, uniquement la connexion (80) et l'utilisation des fonctionnalités (60) donnent `(0.30×80 + 0.25×60)/0.55 = 70.91`, avec 55 % de couverture. Ne déclenchez pas une action de compte sain sur ce score partiel sans respecter la politique de couverture requise.

Une note individuelle de 0 à 6 correspond à un détracteur ; le score NPS agrégé (−100 à 100) est une mesure distincte.

La [documentation de Gainsight sur le poids des mesures](https://support.gainsight.com/gainsight_nxt/05Scorecards/02Admin_Guides/Measure_Weights_in_Scorecards) explique la redistribution pour les mesures indisponibles.

Modèle indicatif avec données complètes :

```
Score de santé = (
  Score de fréquence de connexion      × 0.30 +
  Score d'utilisation des fonctions    × 0.25 +
  Sentiment du support                 × 0.15 +
  Santé de la facturation              × 0.15 +
  Score d'engagement                   × 0.15
)
```

Validez les règles d'attribution des scores et les seuils d'intervention par rapport aux renouvellements ou churns réels observés ultérieurement avant toute utilisation opérationnelle ; les paliers suivants sont fournis à titre indicatif.

| Score | Statut | Action |
|-------|--------|--------|
| 80-100 | En bonne santé | Opportunités d'upsell |
| 60-79 | Nécessite de l'attention | Prise de contact proactive |
| 40-59 | À risque | Campagne d'intervention |
| 0-39 | Critique | Contact direct personnalisé |

### Interventions proactives

**Avant qu'ils ne songent à résilier :**

| Déclencheur | Intervention |
|-------------|--------------|
| Baisse d'utilisation >50 % pendant 2 semaines | E-mail « Nous avons remarqué que vous n'avez pas utilisé [fonctionnalité]. Besoin d'aide ? » |
| Approche de la limite du forfait | Suggestion de montée en gamme (pas un blocage brutal — géré par paywalls) |
| Aucune connexion pendant 14 jours | E-mail de réengagement présentant les récentes nouveautés produit |
| Détracteur NPS (0-6) | Suivi personnalisé sous 24 heures |
| Ticket de support non résolu >48h | Escalade + point de situation proactif |
| Renouvellement annuel dans 30 jours | E-mail récapitulatif de la valeur générée + confirmation de renouvellement |

---

## Churn involontaire : récupération des paiements

Les échecs de paiement sont responsables de 30 à 50 % de l'ensemble du churn, mais ils sont aussi les plus faciles à récupérer.

### La stack de dunning

```
Pré-dunning → Nouvelles tentatives intelligentes → E-mails de dunning → Période de grâce → Résiliation définitive
```

### Pré-dunning (prévenir les échecs)

- **Alertes d'expiration de carte** : E-mail 30, 15 et 7 jours avant l'expiration de la carte
- **Moyen de paiement de secours** : Inviter à enregistrer un second moyen de paiement dès l'inscription
- **Services d'actualisation de carte (Card Updaters)** : Programmes de mise à jour automatique Visa/Mastercard (réduit les refus stricts de 30 à 50 %)
- **Notification pré-facturation** : E-mail 3 à 5 jours avant le prélèvement pour les forfaits annuels

### Logique de relance intelligente (Smart Retry)

Tous les échecs ne se valent pas. Stratégie de relance selon le type de refus :

| Type de refus | Exemples | Stratégie de relance |
|---------------|----------|----------------------|
| Refus temporaire (Soft decline) | Fonds insuffisants, délai de traitement dépassé | Réessayer 3 à 5 fois sur 7 à 10 jours |
| Refus permanent (Hard decline) | Carte volée, compte clôturé | Ne pas réessayer — demander une nouvelle carte |
| Authentification requise | 3D Secure, SCA | Renvoyer le client vers la mise à jour du paiement |

**Bonnes pratiques pour le calendrier des relances :**
- Relance 1 : 24 heures après l'échec
- Relance 2 : 3 jours après l'échec
- Relance 3 : 5 jours après l'échec
- Relance 4 : 7 jours après l'échec (avec escalade dans l'e-mail de dunning)
- Après 4 relances : Résiliation définitive avec lien de réactivation

**Astuce pour la relance intelligente :** Relancez le jour du mois où le paiement avait initialement fonctionné (si le 1er du mois fonctionnait auparavant, réessayez le 1er). Stripe Smart Retries gère cela automatiquement.

### Séquence d'e-mails de dunning

| E-mail | Moment | Ton | Contenu |
|--------|--------|-----|---------|
| 1 | Jour 0 (échec) | Alerte bienveillante | « Votre paiement n'a pas abouti. Veuillez mettre à jour votre carte. » |
| 2 | Jour 3 | Rappel utile | « Petit rappel : mettez à jour votre paiement pour conserver votre accès. » |
| 3 | Jour 7 | Urgence | « Votre compte sera suspendu dans 3 jours. Mettez à jour maintenant. » |
| 4 | Jour 10 | Dernier avertissement | « Dernière chance de maintenir votre compte actif. » |

**Bonnes pratiques pour les e-mails de dunning :**
- Lien direct vers la page de mise à jour du paiement (sans connexion requise si possible)
- Indiquez précisément ce qu'ils vont perdre (leurs données, les accès de leur équipe)
- Ne culpabilisez pas (« Votre paiement a échoué », et non « Vous n'avez pas payé »)
- Incluez le contact du support en cas de besoin
- Le format texte brut est souvent plus performant que les e-mails très graphiques pour le dunning

### Benchmarks de récupération

| Métrique | Médiocre | Moyen | Bon |
|----------|----------|-------|-----|
| Récupération des refus temporaires (soft) | <40 % | 50-60 % | 70 %+ |
| Récupération des refus permanents (hard) | <10 % | 20-30 % | 40 %+ |
| Récupération globale des paiements | <30 % | 40-50 % | 60 %+ |
| Prévention en pré-dunning | Aucune | 10-15 % | 20-30 % |

Pour le playbook complet de dunning avec configuration par fournisseur, consultez [references/dunning-playbook.md](references/dunning-playbook.md).

---

## Métriques et mesure

### Métriques clés du churn

| Métrique | Formule | Cible |
|----------|---------|-------|
| Taux de churn mensuel | Clients perdus / Clients en début de mois | <5 % en B2C, <2 % en B2B |
| Churn de revenus (net) | (MRR perdu - MRR d'expansion) / MRR de début | Négatif (expansion nette) |
| Taux de rétention du cancel flow | Clients retenus / Total des sessions de résiliation | 25-35 % |
| Taux d'acceptation de l'offre | Offres acceptées / Offres présentées | 15-25 % |
| Taux de réactivation post-pause | Réactivés / Total des mises en pause | 60-80 % |
| Taux de récupération du dunning | Paiements récupérés / Total des paiements échoués | 50-60 % |
| Délai avant résiliation (Time to cancel) | Jours entre le premier signal de risque et la résiliation | Suivre la tendance |

### Analyse de cohortes

Segmentez le churn par :
- **Canal d'acquisition** — Quels canaux amènent les clients les plus fidèles ?
- **Type de forfait** — Quels forfaits ont le taux de résiliation le plus élevé ?
- **Ancienneté** — Quand la plupart des résiliations se produisent-elles ? (30, 60, 90 jours ?)
- **Motif de résiliation** — Quels motifs sont en augmentation ?
- **Type d'offre de rétention** — Quelles offres fonctionnent le mieux selon les segments ?

### Tests A/B sur le parcours de résiliation

Testez une variable à la fois :

| Test | Hypothèse | Métrique |
|------|-----------|----------|
| % de remise (20 % vs 30 %) | Une remise plus forte retient davantage | Taux de rétention, impact LTV |
| Durée de pause (1 vs 3 mois) | Une pause plus longue augmente le retour | Taux de réactivation |
| Emplacement de l'enquête (avant vs après l'offre) | L'enquête en amont personnalise mieux les offres | Taux de rétention |
| Présentation de l'offre (modale vs pleine page) | La pleine page capte mieux l'attention | Taux de rétention |
| Tonalité du texte (empathique vs direct) | L'empathie réduit les frictions | Taux de rétention |

**Comment mener des expériences sur le parcours de résiliation :** Utilisez la compétence **ab-testing** pour concevoir des tests statistiquement rigoureux. PostHog est particulièrement adapté pour tester les parcours de résiliation : ses feature flags permettent de répartir les utilisateurs sur différents parcours côté serveur, et son analyse de funnel suit chaque étape du flux (enquête → offre → acceptation/refus → confirmation). Consultez le [guide d'intégration PostHog](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/posthog.md) pour la mise en place.

---

## Erreurs courantes

- **Aucun parcours de résiliation** — Une résiliation instantanée laisse de l'argent sur la table. Même une simple enquête assortie d'une offre unique sauve 10 à 15 % des clients.
- **Rendre la résiliation difficile à trouver** — Les boutons de désabonnement cachés engendrent de la rancœur et de mauvais avis. De nombreuses juridictions imposent désormais une résiliation facile (règle FTC « Click-to-Cancel »).
- **La même offre pour tous les motifs** — Une remise systématique ne répond ni au « manque de fonctionnalité » ni au « manque d'utilisation ».
- **Des remises trop généreuses** — Les remises de 50 % et plus habituent les clients à résilier puis revenir uniquement pour obtenir des rabais.
- **Ignorer le churn involontaire** — Il représente souvent 30 à 50 % du churn global et reste le plus facile à résoudre.
- **Aucun e-mail de dunning** — Laisser les échecs de paiement résilier silencieusement les comptes.
- **Messages culpabilisants** — « Êtes-vous sûr de vouloir nous abandonner ? » dégrade la confiance envers la marque.
- **Ne pas mesurer la LTV des offres de rétention** — Un client « sauvé » qui résilie 30 jours plus tard n'a pas réellement été fidélisé.
- **Mettre en pause trop longtemps** — Les pauses de plus de 3 mois aboutissent rarement à une réactivation. Fixez des limites claires.
- **Aucun parcours post-résiliation** — Facilitez la réactivation et déclenchez des e-mails de reconquête, car certains clients partis souhaiteront revenir.

---

## Intégrations d'outils

Pour l'implémentation, reportez-vous au [registre des outils](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md).

### Plateformes de rétention

| Outil | Idéal pour | Fonctionnalité clé |
|-------|------------|--------------------|
| **Churnkey** | Parcours de résiliation complet + dunning | Offres adaptatives propulsées par IA, ~34 % de taux moyen de rétention |
| **ProsperStack** | Parcours de résiliation avec analytique | Moteur de règles avancé, intégration Stripe/Chargebee |
| **Raaft** | Créateur de parcours de résiliation simple | Prise en main facile, idéal en phase d'amorçage |
| **Chargebee Retention** | Clients Chargebee | Intégration native, anciennement Brightback |

### Fournisseurs de facturation (Dunning)

| Fournisseur | Relances intelligentes | E-mails de dunning | Actualisateur de carte |
|-------------|:---------------------:|:------------------:|:----------------------:|
| **Stripe** | Intégré (Smart Retries) | Intégré | Automatique |
| **Chargebee** | Intégré | Intégré | Via passerelle |
| **Paddle** | Intégré | Intégré | Géré |
| **Recurly** | Intégré | Intégré | Intégré |
| **Braintree** | Config manuelle | Manuel | Via passerelle |

### Outils CLI associés

| Outil | Usage |
|-------|-------|
| `stripe` | Gestion des abonnements, config de dunning, relances de paiement |
| `customer-io` | Séquences d'e-mails de dunning, campagnes de fidélisation |
| `posthog` | Tests A/B de parcours de résiliation via feature flags, analyse d'entonnoirs |
| `mixpanel` / `ga4` | Suivi de l'utilisation, analyse des signaux d'attrition |
| `segment` | Routage des événements pour le calcul du score de santé |

---

## Compétences associées

- **emails** : Pour les séquences d'e-mails de reconquête (win-back) après la résiliation
- **paywalls** : Pour les opportunités de montée en gamme in-app et l'expiration des périodes d'essai
- **pricing** : Pour la structure des offres et la stratégie de réduction sur les abonnements annuels
- **onboarding** : Pour l'activation produit visant à prévenir le churn précoce
- **analytics** : Pour la configuration des événements liés aux signaux de churn
- **ab-testing** : Pour tester les variantes de parcours de résiliation avec rigueur statistique
