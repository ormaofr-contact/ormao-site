---
name: slack-gif-creator
description: Connaissances et utilitaires pour créer des GIF animés optimisés pour Slack. Fournit des contraintes, des outils de validation et des concepts d'animation. À utiliser lorsque les utilisateurs demandent des GIF animés pour Slack, comme « fais-moi un GIF de X qui fait Y pour Slack ».
license: Complete terms in LICENSE.txt
---

# Slack GIF Creator

Une boîte à outils fournissant des utilitaires et des connaissances pour créer des GIF animés optimisés pour Slack.

## Exigences de Slack

**Dimensions :**
- GIF d'emojis : 128x128 (recommandé)
- GIF de messages : 480x480

**Paramètres :**
- FPS : 10-30 (plus la valeur est basse, plus le fichier est léger)
- Couleurs : 48-128 (moins de couleurs = fichier plus léger)
- Durée : rester sous la barre des 3 secondes pour les GIF d'emojis

## Flux de travail principal

```python
from core.gif_builder import GIFBuilder
from PIL import Image, ImageDraw

# 1. Create builder
builder = GIFBuilder(width=128, height=128, fps=10)

# 2. Generate frames
for i in range(12):
    frame = Image.new('RGB', (128, 128), (240, 248, 255))
    draw = ImageDraw.Draw(frame)

    # Draw your animation using PIL primitives
    # (circles, polygons, lines, etc.)

    builder.add_frame(frame)

# 3. Save with optimization
builder.save('output.gif', num_colors=48, optimize_for_emoji=True)
```

## Dessiner des graphismes

### Travailler avec des images téléversées par l'utilisateur
Si un utilisateur téléverse une image, déterminez s'il souhaite :
- **L'utiliser directement** (par ex., « anime ceci », « découpe ceci en images »)
- **L'utiliser comme inspiration** (par ex., « fais quelque chose comme ça »)

Chargez et manipulez les images à l'aide de PIL :
```python
from PIL import Image

uploaded = Image.open('file.png')
# Use directly, or just as reference for colors/style
```

### Dessiner à partir de zéro
Lorsque vous dessinez des graphismes à partir de zéro, utilisez les primitives de dessin de PIL ImageDraw :

```python
from PIL import ImageDraw

draw = ImageDraw.Draw(frame)

# Circles/ovals
draw.ellipse([x1, y1, x2, y2], fill=(r, g, b), outline=(r, g, b), width=3)

# Stars, triangles, any polygon
points = [(x1, y1), (x2, y2), (x3, y3), ...]
draw.polygon(points, fill=(r, g, b), outline=(r, g, b), width=3)

# Lines
draw.line([(x1, y1), (x2, y2)], fill=(r, g, b), width=5)

# Rectangles
draw.rectangle([x1, y1, x2, y2], fill=(r, g, b), outline=(r, g, b), width=3)
```

**Ne pas utiliser :** Les polices d'emojis (peu fiables d'une plateforme à l'autre) ni supposer que des graphismes prépackagés existent dans cette compétence.

### Soigner le rendu des graphismes

Les graphismes doivent avoir un rendu soigné et créatif, et non rudimentaire. Voici comment procéder :

**Utilisez des lignes plus épaisses** - Définissez toujours `width=2` ou plus pour les contours et les lignes. Les lignes fines (width=1) donnent un aspect haché et amateur.

**Ajoutez de la profondeur visuelle** :
- Utilisez des dégradés pour les arrière-plans (`create_gradient_background`)
- Superposez plusieurs formes pour apporter de la complexité (par ex., une étoile avec une étoile plus petite à l'intérieur)

**Rendez les formes plus intéressantes** :
- Ne vous contentez pas de dessiner un cercle simple — ajoutez des reflets, des anneaux ou des motifs
- Les étoiles peuvent avoir une lueur (dessinez des versions plus grandes et semi-transparentes à l'arrière-plan)
- Combinez plusieurs formes (étoiles + étincelles, cercles + anneaux)

**Faites attention aux couleurs** :
- Utilisez des couleurs vives et complémentaires
- Ajoutez du contraste (contours sombres sur formes claires, contours clairs sur formes sombres)
- Pensez à la composition globale

**Pour les formes complexes** (cœurs, flocons de neige, etc.) :
- Utilisez des combinaisons de polygones et d'ellipses
- Calculez soigneusement les points pour assurer la symétrie
- Ajoutez des détails (un cœur peut comporter une courbe de surbrillance, les flocons de neige ont des branches complexes)

Soyez créatif et minutieux ! Un bon GIF Slack doit avoir l'air soigné, et non ressembler à un simple graphique de remplacement.

## Utilitaires disponibles

### GIFBuilder (`core.gif_builder`)
Assemble les images et optimise pour Slack :
```python
builder = GIFBuilder(width=128, height=128, fps=10)
builder.add_frame(frame)  # Add PIL Image
builder.add_frames(frames)  # Add list of frames
builder.save('out.gif', num_colors=48, optimize_for_emoji=True, remove_duplicates=True)
```

### Validateurs (`core.validators`)
Vérifient si le GIF respecte les exigences de Slack :
```python
from core.validators import validate_gif, is_slack_ready

# Detailed validation
passes, info = validate_gif('my.gif', is_emoji=True, verbose=True)

# Quick check
if is_slack_ready('my.gif'):
    print("Ready!")
```

### Fonctions d'adoucissement / Easing (`core.easing`)
Mouvement fluide au lieu d'un mouvement linéaire :
```python
from core.easing import interpolate

# Progress from 0.0 to 1.0
t = i / (num_frames - 1)

# Apply easing
y = interpolate(start=0, end=400, t=t, easing='ease_out')

# Available: linear, ease_in, ease_out, ease_in_out,
#           bounce_out, elastic_out, back_out
```

### Aides pour les images (`core.frame_composer`)
Fonctions pratiques pour les besoins courants :
```python
from core.frame_composer import (
    create_blank_frame,         # Solid color background
    create_gradient_background,  # Vertical gradient
    draw_circle,                # Helper for circles
    draw_text,                  # Simple text rendering
    draw_star                   # 5-pointed star
)
```

## Concepts d'animation

### Tremblement / Vibration (Shake/Vibrate)
Décaler la position de l'objet avec une oscillation :
- Utilisez `math.sin()` ou `math.cos()` avec l'index de l'image
- Ajoutez de légères variations aléatoires pour un rendu naturel
- Appliquez sur la position x et/ou y

### Pulsation / Battement de cœur (Pulse/Heartbeat)
Mettre à l'échelle la taille de l'objet de manière rythmée :
- Utilisez `math.sin(t * frequency * 2 * math.pi)` pour une pulsation fluide
- Pour un battement de cœur : deux pulsations rapides puis une pause (ajustez l'onde sinusoïdale)
- Ajustez l'échelle entre 0,8 et 1,2 de la taille de base

### Rebond (Bounce)
L'objet tombe et rebondit :
- Utilisez `interpolate()` avec `easing='bounce_out'` pour l'atterrissage
- Utilisez `easing='ease_in'` pour la chute (accélération)
- Appliquez la gravité en augmentant la vitesse y à chaque image

### Rotation (Spin/Rotate)
Faire pivoter l'objet autour de son centre :
- PIL : `image.rotate(angle, resample=Image.BICUBIC)`
- Pour une oscillation : utilisez une onde sinusoïdale pour l'angle au lieu d'une valeur linéaire

### Fondu en entrée / sortie (Fade In/Out)
Apparition ou disparition progressive :
- Créez une image RGBA, ajustez le canal alpha
- Ou utilisez `Image.blend(image1, image2, alpha)`
- Fondu en entrée : alpha de 0 à 1
- Fondu en sortie : alpha de 1 à 0

### Glissement (Slide)
Déplacer l'objet depuis l'extérieur de l'écran vers sa position :
- Position de départ : en dehors des limites du cadre
- Position finale : emplacement cible
- Utilisez `interpolate()` avec `easing='ease_out'` pour un arrêt progressif
- Pour un effet de dépassement (overshoot) : utilisez `easing='back_out'`

### Zoom
Mettre à l'échelle et positionner pour un effet de zoom :
- Zoom avant : passer de l'échelle 0,1 à 2,0, recadrer au centre
- Zoom arrière : passer de l'échelle 2,0 à 1,0
- Possibilité d'ajouter un flou de mouvement pour accentuer l'effet (filtre PIL)

### Explosion / Éclatement de particules (Explode/Particle Burst)
Créer des particules rayonnant vers l'extérieur :
- Générez des particules avec des angles et des vitesses aléatoires
- Mettez à jour chaque particule : `x += vx`, `y += vy`
- Ajoutez la gravité : `vy += gravity_constant`
- Faites disparaître les particules progressivement au fil du temps (réduction de l'alpha)

## Stratégies d'optimisation

Uniquement lorsqu'il vous est demandé de réduire la taille du fichier, appliquez quelques-unes des méthodes suivantes :

1. **Moins d'images** - FPS plus bas (10 au lieu de 20) ou durée plus courte
2. **Moins de couleurs** - `num_colors=48` au lieu de 128
3. **Dimensions plus petites** - 128x128 au lieu de 480x480
4. **Supprimer les doublons** - `remove_duplicates=True` dans save()
5. **Mode emoji** - `optimize_for_emoji=True` optimise automatiquement

```python
# Maximum optimization for emoji
builder.save(
    'emoji.gif',
    num_colors=48,
    optimize_for_emoji=True,
    remove_duplicates=True
)
```

## Philosophie

Cette compétence fournit :
- **Des connaissances** : les exigences de Slack et les concepts d'animation
- **Des utilitaires** : GIFBuilder, validateurs, fonctions d'adoucissement
- **De la flexibilité** : créez la logique d'animation à l'aide des primitives PIL

Elle ne fournit PAS :
- Des modèles d'animation rigides ou des fonctions toutes faites
- Le rendu de polices d'emojis (non fiable d'une plateforme à l'autre)
- Une bibliothèque de graphismes prépackagés intégrée dans la compétence

**Remarque sur les téléversements d'utilisateurs** : Cette compétence n'inclut pas de graphismes préconçus, mais si un utilisateur téléverse une image, utilisez PIL pour la charger et la manipuler — déduisez à partir de sa demande s'il souhaite qu'elle soit utilisée directement ou simplement comme source d'inspiration.

Soyez créatif ! Combinez les concepts (rebond + rotation, pulsation + glissement, etc.) et exploitez tout le potentiel de PIL.

## Dépendances

```bash
pip install pillow imageio numpy
