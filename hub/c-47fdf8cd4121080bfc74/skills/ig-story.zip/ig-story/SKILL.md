---
name: ig-story
description: >-
  Rédigez les stories Instagram du jour : la séquence plan par plan, quels
  stickers utiliser et où, ainsi que celui qui incite à passer en MP. À utiliser
  lorsque l'utilisateur dit « stories », « que poster en story », « séquence de story »,
  « idée de sondage », « je n'ai rien à poster en story » ou souhaite vendre quelque chose
  sans créer de post dédié.
---

# ig-story

Les stories ne sont pas un feed miniature. Le feed permet aux inconnus de vous
découvrir. Les stories permettent aux personnes qui vous suivent déjà de décider
si vous valez la peine qu'on vous achète quelque chose, et elles constituent le
seul espace sur Instagram où un simple clic se transforme en conversation d'un
seul coup.

Personne en dehors de vos abonnés ne les voit, la mission est donc totalement
différente : de la profondeur, pas de la portée.

## La structure quotidienne

Trois à sept plans par jour. Au-delà d'environ sept, le taux de passage au plan
suivant explose et les derniers plans ne sont vus par personne — ce qui est
exactement l'endroit où les gens placent leur appel à l'action.

```
1       THE OPEN     something happening today, with a face or a hand in it.
2-3     THE MIDDLE   the actual content: the process, the result, the mistake.
4       THE ASK      one sticker. Poll, question box, quiz or link.
5       THE CLOSE    the answer, the outcome, or tomorrow's setup.
```

Placez la demande au plan 4, pas au plan 7. Le taux de complétion chute à
chaque clic et l'appel à l'action doit être vu par les personnes qui sont encore
là.

## Les stickers, et leur véritable utilité

| sticker | rôle | quand l'utiliser |
| --- | --- | --- |
| **Sondage** | l'interaction la plus facile à obtenir | vous cherchez un volume de réponses, pas de l'information |
| **Boîte à questions** | récolter les mots exacts employés par votre audience | vous avez besoin d'idées de contenu ou d'objections, au mot près |
| **Quiz** | enseigner en leur laissant la possibilité de se tromper | il y a une idée reçue courante dans votre thématique |
| **Curseur emoji** | sonder l'ambiance | rien d'important. Amusant, faible valeur |
| **Lien** | le seul espace cliquable en dehors de la bio | il y a une vraie destination vers laquelle rediriger |
| **Compte à rebours** | une échéance à laquelle s'abonner | un lancement, un live, une date limite |
| **À votre tour** | toucher occasionnellement au-delà de vos abonnés | la consigne est accessible à n'importe qui dans la thématique |

La boîte à questions est l'élément le plus sous-estimé de cette liste. Chaque
réponse est une légende, une accroche de Reel ou une amorce de MP rédigée avec
les propres mots de votre audience. Utilisez-les dans `/ig-reel` comme formule
#16.

## Règles

- **Un visage ou une main dès le premier plan.** Le texte sur fond coloré est
  passé d'un clic, et le premier plan détermine si la suite sera regardée.
- **Une seule idée par plan.** Personne ne lit un paragraphe entier dans une
  story.
- **Gardez le texte au centre.** Sur un format 1080x1920, rien au-dessus de
  y=250 ni en dessous de y=1600. La barre de profil se trouve en haut et la barre
  de réponse en bas.
- **Adressez-vous à une seule personne.** Utilisez le « tu » ou un « vous »
  singulier. Les stories sont ce qui se rapproche le plus d'un MP sans en être
  un.
- **Ne republiez pas votre propre post du feed en story sans commentaire.**
  C'est le type de plan le plus ignoré sur la plateforme. Si vous renvoyez vers
  un post, racontez ce qui s'est passé dans les commentaires et pourquoi cela
  vaut le coup d'aller le voir.
- **Vendez en story, pas dans vos posts.** Trois plans de contexte, un plan
  d'offre, un plan de preuve. Cette séquence convertit mieux qu'un post du feed
  sur le même sujet et ne vous coûte aucune portée.

## Le tunnel de MP, fait avec honnêteté

La séquence qui fonctionne : une story qui pose un problème, une boîte à
questions ou un sondage qui permet aux gens de dire « c'est moi », puis une
réponse à chaque personne qui a répondu. La conversation démarre parce qu'ils
ont fait le premier pas.

Les réponses automatiques par mot-clé en MP sont une fonctionnalité officielle
et prise en charge pour les comptes professionnels, via les outils intégrés
d'Instagram et les partenaires certifiés. Envoyer des MP en masse à des
personnes qui n'ont pas interagi ne l'est pas, et c'est ce qui fait restreindre
les comptes. La règle est simple : **ils agissent en premier, vous répondez
ensuite.**

## Format de sortie

Les plans dans l'ordre, avec pour chacun ce qui apparaît à l'écran, ce qui est
dit, et quel sticker utiliser, ainsi que la démarche à suivre avec les
réponses :

```
STORIES  ·  Tuesday  ·  5 frames

1  [selfie, walking]      "Third refund request this year. Same reason."
2  [screen recording]     the clause, highlighted
3  [talking]              "Approval is a feeling. Delivery is a date."
4  [poll]                 "Have you been burned by a late approval?"  Yes / Not yet
5  [text on photo]        "Reply and I will send you the clause."

After: everyone who votes Yes gets a reply. That is the whole funnel.
```

Rien n'est publié automatiquement. C'est l'utilisateur qui publie.
