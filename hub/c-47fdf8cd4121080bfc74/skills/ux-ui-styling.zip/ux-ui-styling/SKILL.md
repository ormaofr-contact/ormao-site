---
name: ui-styling
description: Créez des interfaces utilisateur esthétiques et accessibles avec les composants shadcn/ui (basés sur Radix UI + Tailwind), le style utility-first de Tailwind CSS et des conceptions visuelles sur canvas. À utiliser lors de la création d'interfaces utilisateur, de l'implémentation de systèmes de conception (design systems), de la création de mises en page responsives, de l'ajout de composants accessibles (dialogues, menus déroulants, formulaires, tableaux), de la personnalisation de thèmes et de couleurs, de l'implémentation du mode sombre, de la génération de designs visuels et d'affiches, ou de l'établissement de modèles de style cohérents à travers les applications.
argument-hint: "[component or layout]"
license: MIT
metadata:
  author: claudekit
  version: "1.0.0"
---

# Compétence UI Styling

Compétence complète pour créer de superbes interfaces utilisateur accessibles combinant les composants shadcn/ui, le style utilitaire Tailwind CSS et des systèmes de conception visuelle basés sur canvas.

## Référence

- shadcn/ui : https://ui.shadcn.com/llms.txt
- Tailwind CSS : https://tailwindcss.com/docs

## Quand utiliser cette compétence

À utiliser pour :
- Créer une interface utilisateur avec des frameworks basés sur React (Next.js, Vite, Remix, Astro)
- Implémenter des composants accessibles (boîtes de dialogue, formulaires, tableaux, navigation)
- Styliser avec une approche CSS utility-first
- Créer des mises en page responsives et mobile-first
- Implémenter le mode sombre et la personnalisation des thèmes
- Construire des systèmes de conception avec des design tokens cohérents
- Générer des visuels, des affiches ou des éléments graphiques de marque
- Prototyper rapidement avec un retour visuel immédiat
- Ajouter des modèles d'interface complexes (tableaux de données, graphiques, palettes de commandes)

## Stack principale

### Couche de composants : shadcn/ui
- Composants accessibles prédéfinis via les primitives Radix UI
- Modèle de distribution par copier-coller (les composants vivent dans votre base de code)
- Approche TypeScript-first avec sécurité de typage complète
- Primitives composables pour des interfaces complexes
- Installation et gestion via CLI

### Couche de style : Tailwind CSS
- Framework CSS utility-first
- Traitement au moment du build sans aucun surcoût à l'exécution
- Conception responsive mobile-first
- Design tokens cohérents (couleurs, espacements, typographie)
- Élimination automatique du code mort (purge)

### Couche de design visuel : Canvas
- Compositions visuelles de qualité muséale
- Approche de conception guidée par une philosophie
- Communication visuelle sophistiquée
- Texte minimal, impact visuel maximal
- Motifs systématiques et esthétique soignée

## Chemins des scripts

Les chemins des scripts dans cette compétence et ses dossiers `references/` sont relatifs au répertoire contenant ce SKILL.md, et non au projet : `scripts/<file>` correspond au propre dossier `scripts/` de cette compétence, et `../<skill>/scripts/<file>` correspond à une sous-compétence sœur installée à ses côtés. Construisez le chemin complet à partir de ce répertoire (Claude Code l'indique comme répertoire de base de la compétence lors de son chargement) et conservez le répertoire de travail à la racine du projet — les scripts lisent et écrivent les fichiers du projet tels que `docs/brand-guidelines.md`, `assets/design-tokens.json` ou `src/` par rapport à celle-ci.

## Démarrage rapide

### Configuration composants + styles

**Installer shadcn/ui avec Tailwind :**
```bash
npx shadcn@latest init
```

La CLI demande le framework, TypeScript, les chemins et les préférences de thème. Cela configure à la fois shadcn/ui et Tailwind CSS.

**Ajouter des composants :**
```bash
npx shadcn@latest add button card dialog form
```

**Utiliser les composants avec le style utilitaire :**
```tsx
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export function Dashboard() {
  return (
    <div className="container mx-auto p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Analytics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">View your metrics</p>
          <Button variant="default" className="w-full">
            View Details
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
```

### Alternative : Configuration Tailwind seule

**Projets Vite :**
```bash
npm install -D tailwindcss @tailwindcss/vite
```

```javascript
// vite.config.ts
import tailwindcss from '@tailwindcss/vite'
export default { plugins: [tailwindcss()] }
```

```css
/* src/index.css */
@import "tailwindcss";
```

## Guide de la bibliothèque de composants

**Catalogue exhaustif de composants avec modèles d'utilisation, installation et exemples de composition.**

Consulter : `references/shadcn-components.md`

Couvre :
- Composants de formulaire et de saisie (Button, Input, Select, Checkbox, Date Picker, validation de Formulaire)
- Mise en page et navigation (Card, Tabs, Accordion, Navigation Menu)
- Superpositions et dialogues (Dialog, Drawer, Popover, Toast, Command)
- Retours et statut (Alert, Progress, Skeleton)
- Composants d'affichage (Table, Data Table, Avatar, Badge)

## Thème et personnalisation

**Configuration des thèmes, variables CSS, implémentation du mode sombre et personnalisation des composants.**

Consulter : `references/shadcn-theming.md`

Couvre :
- Configuration du mode sombre avec next-themes
- Système de variables CSS
- Personnalisation des couleurs et palettes
- Personnalisation des variantes de composants
- Implémentation du sélecteur de thème (theme toggle)

## Modèles d'accessibilité

**Modèles ARIA, navigation au clavier, support des lecteurs d'écran et utilisation accessible des composants.**

Consulter : `references/shadcn-accessibility.md`

Couvre :
- Fonctionnalités d'accessibilité de Radix UI
- Modèles de navigation au clavier
- Gestion du focus
- Annonces pour lecteurs d'écran
- Accessibilité de la validation des formulaires

## Utilitaires Tailwind

**Classes utilitaires fondamentales pour la mise en page, l'espacement, la typographie, les couleurs, les bordures et les ombres.**

Consulter : `references/tailwind-utilities.md`

Couvre :
- Utilitaires de mise en page (Flexbox, Grid, positionnement)
- Système d'espacement (padding, margin, gap)
- Typographie (tailles de police, graisses, alignement, hauteur de ligne)
- Couleurs et arrière-plans
- Bordures et ombres
- Valeurs arbitraires pour un style personnalisé

## Design responsive

**Points de rupture (breakpoints) mobile-first, utilitaires responsives et mises en page adaptatives.**

Consulter : `references/tailwind-responsive.md`

Couvre :
- Approche mobile-first
- Système de breakpoints (sm, md, lg, xl, 2xl)
- Modèles d'utilitaires responsives
- Container queries
- Requêtes max-width
- Breakpoints personnalisés

## Personnalisation de Tailwind

**Structure du fichier de configuration, utilitaires personnalisés, plugins et extensions de thème.**

Consulter : `references/tailwind-customization.md`

Couvre :
- Directive @theme pour les tokens personnalisés
- Couleurs et polices personnalisées
- Extensions d'espacement et de breakpoints
- Création d'utilitaires personnalisés
- Variantes personnalisées
- Organisation en couches (@layer base, components, utilities)
- Directive @apply pour l'extraction de composants

## Système de conception visuelle

**Philosophie de conception sur canvas, principes de communication visuelle et compositions sophistiquées.**

Consulter : `references/canvas-design-system.md`

Couvre :
- Approche philosophique de la conception
- Communication visuelle prioritaire sur le texte
- Motifs systématiques et composition
- Couleur, forme et design spatial
- Intégration textuelle minimale
- Exécution de qualité muséale
- Systèmes de conception multi-pages

## Scripts utilitaires

**Automatisation Python pour l'installation de composants et la génération de configuration.**

### shadcn_add.py
Ajouter des composants shadcn/ui avec gestion des dépendances :
```bash
python scripts/shadcn_add.py button card dialog
```

### tailwind_config_gen.py
Générer tailwind.config.js avec un thème personnalisé :
```bash
python scripts/tailwind_config_gen.py --colors brand:blue --fonts display:Inter
```

Le générateur refuse de créer ou remplacer une configuration si un fichier frère `tailwind.config.js`, `.cjs`, `.mjs`, ou `.ts` existe déjà. Examinez d'abord la configuration signalée, puis passez `--force` uniquement lorsque la concurrence de sortie est intentionnelle :
```bash
python scripts/tailwind_config_gen.py --colors brand:blue --force
```

## Bonnes pratiques

1. **Composition de composants** : Construire des interfaces complexes à partir de primitives simples et composables
2. **Style Utility-First** : Utiliser directement les classes Tailwind ; extraire des composants uniquement en cas de réelle répétition
3. **Responsive Mobile-First** : Commencer par les styles mobiles, superposer les variantes responsives
4. **Accessibilité dès la conception** : Exploiter les primitives Radix UI, ajouter des états de focus, utiliser du HTML sémantique
5. **Design Tokens** : Utiliser une échelle d'espacement cohérente, des palettes de couleurs et un système typographique harmonisés
6. **Cohérence du mode sombre** : Appliquer les variantes sombres à tous les éléments thématisés
7. **Performance** : Tirer parti de la purge CSS automatique, éviter les noms de classes dynamiques
8. **TypeScript** : Utiliser une sécurité de typage complète pour une meilleure expérience de développement (DX)
9. **Hiérarchie visuelle** : Laisser la composition guider l'attention, utiliser l'espacement et la couleur avec intention
10. **Savoir-faire d'expert** : Chaque détail compte - traitez l'interface utilisateur comme un art

## Navigation dans les références

**Bibliothèque de composants**
- `references/shadcn-components.md` - Catalogue complet des composants
- `references/shadcn-theming.md` - Thèmes et personnalisation
- `references/shadcn-accessibility.md` - Modèles d'accessibilité

**Système de style**
- `references/tailwind-utilities.md` - Classes utilitaires fondamentales
- `references/tailwind-responsive.md` - Design responsive
- `references/tailwind-customization.md` - Configuration et extensions

**Design visuel**
- `references/canvas-design-system.md` - Philosophie de conception et workflows canvas

**Automatisation**
- `scripts/shadcn_add.py` - Installation de composants
- `scripts/tailwind_config_gen.py` - Génération de configuration

## Modèles courants

**Formulaire avec validation :**
```tsx
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
})

export function LoginForm() {
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "" }
  })

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(console.log)} className="space-y-6">
        <FormField control={form.control} name="email" render={({ field }) => (
          <FormItem>
            <FormLabel>Email</FormLabel>
            <FormControl>
              <Input type="email" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <Button type="submit" className="w-full">Sign In</Button>
      </form>
    </Form>
  )
}
```

**Mise en page responsive avec mode sombre :**
```tsx
<div className="min-h-screen bg-white dark:bg-gray-900">
  <div className="container mx-auto px-4 py-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
            Content
          </h3>
        </CardContent>
      </Card>
    </div>
  </div>
</div>
```

## Ressources

- Documentation shadcn/ui : https://ui.shadcn.com
- Documentation Tailwind CSS : https://tailwindcss.com
- Radix UI : https://radix-ui.com
- Tailwind UI : https://tailwindui.com
- Headless UI : https://headlessui.com
- v0 (Générateur d'UI par IA) : https://v0.dev
