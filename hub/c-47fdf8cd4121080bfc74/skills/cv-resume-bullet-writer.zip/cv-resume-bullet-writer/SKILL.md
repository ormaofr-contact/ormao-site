---
name: resume-bullet-writer
description: Transformez les puces de CV faibles en réalisations percutantes enrichies de métriques et d'impact
---

# Rédacteur de puces de CV

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Rédiger ou améliorer les puces de son CV
- Transformer des descriptions faibles en réalisations percutantes
- Ajouter des métriques et des résultats quantifiables
- Rendre son expérience plus convaincante
- Mentionne : « améliorer mes puces », « renforcer mon CV », « quantifier mes réalisations », « orienté résultats »

À utiliser également lorsque vous constatez des puces faibles nécessitant une amélioration (formulations passives, absence de chiffres, descriptions vagues).

## Capacités clés

- Transformer les puces faibles en formulations axées sur les réalisations
- Appliquer la méthode STAR et la formule X-Y-Z
- Ajouter des métriques et des résultats quantifiables
- Utiliser des verbes d'action percutants
- Adapter les puces à des rôles ou secteurs spécifiques
- S'assurer que chaque puce démontre un impact, et pas seulement des tâches

## Le problème des puces de CV

La plupart des CV contiennent des puces faibles qui énumèrent des tâches quotidiennes plutôt que des réalisations :

❌ **Puces faibles (ce qu'il NE faut PAS faire) :**
- « Responsable de la gestion d'une équipe »
- « A aidé au service client »
- « A travaillé sur l'amélioration des processus »
- « A assisté sur des projets »

Ces formulations sont passives, vagues et ne montrent ni impact ni résultat.

✅ **Puces fortes (ce qu'il FAUT faire) :**
- « Dirigé une équipe interfonctionnelle de 12 personnes pour livrer un produit de 2 M$, augmentant le chiffre d'affaires de 35 % »
- « Résolu plus de 50 problèmes clients par jour, faisant passer le score de satisfaction de 3,2 à 4,8/5 »
- « Rationalisé le processus d'approbation, réduisant le temps de cycle de 40 % (de 10 à 6 jours) »
- « Géré un portefeuille de 8 projets simultanés avec un taux de livraison dans les délais de 100 % »

Ces formulations sont actives, précises et quantifient l'impact.

## Cadres méthodologiques fondamentaux

### 1. La formule X-Y-Z (méthode Google)

**Structure :** « Accompli [X], mesuré par [Y], en faisant [Z] »

- X = Ce que vous avez accompli
- Y = Comment vous l'avez mesuré
- Z = Quelles actions vous avez menées

**Exemples :**

```
❌ BEFORE: "Managed social media accounts"

✅ AFTER: "Grew Instagram following by 250% (5K to 17.5K) by implementing daily content calendar and influencer partnerships"

X = Grew Instagram following by 250%
Y = 5K to 17.5K followers
Z = Daily content calendar + influencer partnerships
```

```
❌ BEFORE: "Improved customer service"

✅ AFTER: "Increased customer satisfaction scores by 40% (3.2 to 4.5/5) by redesigning support ticketing system and training 15 agents"

X = Increased customer satisfaction by 40%
Y = 3.2 to 4.5 out of 5
Z = Redesigned ticketing system + trained agents
```

### 2. La méthode STAR

**Structure :**
- **S**ituation : Quel était le contexte ?
- **T**âche (Task) : Quel était l'objectif à atteindre ?
- **A**ction : Qu'avez-VOUS fait précisément ?
- **R**ésultat (Result) : Quel a été le résultat mesurable ?

**Exemple :**

Récit STAR complet :
« Prise en main d'une équipe commerciale sous-performante (S) avec un taux d'atteinte des quotas de 65 %. Chargé d'améliorer la performance au cours du premier trimestre (T). Mise en place d'un nouveau programme de formation et refonte de la grille de commissions (A). Atteinte d'un taux de réalisation des quotas de 92 % dès le deuxième trimestre, générant 1,8 M$ de chiffre d'affaires supplémentaire (R). »

Pour une puce de CV (STAR condensé) :
« Redynamisé une équipe commerciale sous-performante grâce à un programme de formation et à la refonte des commissions, augmentant l'atteinte des objectifs de 65 % à 92 % et générant 1,8 M$ de revenus supplémentaires »

### 3. La méthode CAR (alternative à STAR)

**Structure :**
- **C**hallenge (Défi) : Quel était le problème ?
- **A**ction : Qu'avez-vous fait pour le résoudre ?
- **R**ésultat (Result) : Que s'est-il passé ?

**Exemple :**

« Réduit le taux d'attrition client (C) en déployant un programme d'accompagnement proactif (A), retenant 85 % des comptes à risque représentant 500 k$ d'ARR (R) »

## Verbes d'action par catégorie

### Leadership et gestion
- Dirigé, Piloté, Géré, Supervisé, Coordonné
- Mené, Orchestré, Chapeauté, Porté, Mentoré

### Réussite et accomplissement
- Atteint, Livré, Dépassé, Surpassé, Décroché
- Sécurisé, Remporté, Obtenu, Capté, Conclu

### Croissance et amélioration
- Développé, Augmenté, Boosté, Étendu, Mis à l'échelle
- Élevé, Amplifié, Maximisé, Accéléré, Doublé

### Création et innovation
- Créé, Développé, Conçu, Bâti, Lancé
- Initié, Établi, Fondé, Introduit, Conçu à l'origine

### Optimisation et efficacité
- Rationalisé, Optimisé, Perfectionné, Amélioré, Revitalisé
- Transformé, Restructuré, Modernisé, Automatisé, Simplifié

### Analyse et stratégie
- Analysé, Évalué, Diagnostiqué, Identifié, Estimé
- Étudié, Examiné, Audité, Modélisé, Anticipé

### Collaboration et communication
- Collaboré, Fédéré, Facilité, Coordonné, Travaillé en partenariat
- Présenté, Communiqué, Négocié, Influencé, Convaincu

### Résolution de problèmes
- Résolu, Dépanné, Rectifié, Débogué, Traité
- Éliminé, Réduit, Atténué, Prévenu, Corrigé

## Stratégies de quantification

Chaque puce doit comporter au moins UN chiffre. Voici comment identifier des métriques :

### Types de métriques à inclure

**1. Argent**
- Chiffre d'affaires généré : « 2 M$ de nouveaux revenus »
- Économies réalisées : « Réduit les coûts de 50 k$ par an »
- Budget géré : « Géré un budget de projet de 5 M$ »
- Taille des contrats : « Conclu 3 contrats grands comptes d'une valeur de 500 k$ »

**2. Pourcentages**
- Croissance : « Augmenté le taux de conversion de 45 % »
- Amélioration : « Réduit le taux d'erreur de 60 % »
- Efficacité : « Diminué le temps de traitement de 30 % »
- Qualité : « Amélioré la précision de 85 % à 98 % »

**3. Temps**
- Vitesse : « Réduit le temps de chargement de 8 s à 2 s »
- Fréquence : « Fourni des rapports hebdomadaires à plus de 50 parties prenantes »
- Durée : « Finalisé un projet de 6 mois en 4 mois »
- Temps gagné : « Automatisé un processus, faisant gagner 10 heures/semaine à l'équipe »

**4. Échelle / Volume**
- Personnes : « Encadré une équipe de 15 personnes », « Formé plus de 50 employés »
- Projets : « Géré 8 initiatives simultanées »
- Clients : « Accompagné plus de 500 clients grands comptes »
- Utilisateurs : « Développé un produit utilisé par plus de 100 000 utilisateurs actifs quotidiens »

**5. Comparaison / Avant-Après**
- « Augmenté de X à Y »
- « Réduit de X à Y »
- « Passé de X à Y »

### Quand vous ne disposez pas de chiffres exacts

Utilisez des stratégies d'estimation :

**Approximer avec ~**
« Amélioré les performances de ~40 % »

**Utiliser des fourchettes**
« Encadré une équipe de 8 à 12 personnes »
« Généré 50 k$ à 75 k$ de chiffre d'affaires mensuel »

**Utiliser des estimations prudentes**
Si vous estimez le gain à 60 %, indiquez 50 %
Si vous avez fait gagner 100 heures, indiquez 75 heures

**Quantifier les moyens mis en œuvre si les résultats sont inconnus**
Impossible de mesurer les revenus ? Quantifiez les activités :
- « Réalisé plus de 30 entretiens clients »
- « Analysé plus de 500 points de données »
- « Conçu plus de 20 campagnes marketing »

**Identifier des métriques associées**
Impossible de mesurer la conversion ? Mesurez le trafic, l'engagement ou d'autres métriques du tunnel de conversion

## Exemples de puces par secteur d'activité

### Ingénierie logicielle

❌ FAIBLE :
- A écrit du code pour de nouvelles fonctionnalités
- A corrigé des bugs en production
- A travaillé avec l'équipe produit

✅ FORTE :
- Conçu l'architecture d'un microservice d'authentification traitant plus de 500 k utilisateurs actifs par jour, réduisant la latence de connexion de 60 % (de 5 s à 2 s)
- Résolu plus de 50 bugs critiques en production sur 6 mois, faisant passer la disponibilité du système de 97,2 % à 99,8 %
- Collaboré avec l'équipe produit pour livrer 12 fonctionnalités en avance sur le planning, générant une hausse de 25 % de l'engagement utilisateur

### Gestion de produit (Product Management)

❌ FAIBLE :
- A géré la feuille de route du produit
- A collaboré avec les parties prenantes
- A lancé de nouvelles fonctionnalités

✅ FORTE :
- Défini et exécuté la feuille de route d'un produit générant 10 M$ d'ARR, en priorisant plus de 50 demandes de fonctionnalités issues de 200+ clients
- Animé des réunions hebdomadaires avec les équipes d'ingénierie, de design et de direction pour aligner les priorités stratégiques
- Lancé 8 fonctionnalités majeures en 12 mois, stimulant la rétention client de 40 % et générant 2 M$ de revenus additionnels

### Vente / Commercial

❌ FAIBLE :
- A rencontré des clients
- A conclu des ventes
- A dépassé ses quotas

✅ FORTE :
- Généré 3,2 M$ de nouveaux revenus en concluant 15 contrats grands comptes, atteignant 142 % de l'objectif annuel
- Piloté le cycle de vente de plus de 50 prospects en parallèle, maintenant un taux de closing de 35 % (moyenne de l'entreprise : 22 %)
- Dépassé le quota trimestriel pendant 8 trimestres consécutifs, se classant 2e sur 45 commerciaux au niveau national

### Marketing

❌ FAIBLE :
- A créé des campagnes marketing
- A géré les réseaux sociaux
- A analysé les performances des campagnes

✅ FORTE :
- Déployé 12 campagnes multicanales générant 500 k$ de revenus attribués et plus de 2 500 prospects qualifiés
- Développé l'audience LinkedIn de 400 % (de 3 k à 15 k abonnés) grâce à une stratégie de contenu expert, générant plus de 200 demandes de démo entrantes
- Analysé la performance des campagnes sur 8 canaux via Google Analytics, identifiant les 3 canaux les plus performants à l'origine de 75 % des conversions

### Succès client (Customer Success)

❌ FAIBLE :
- A aidé les clients avec leurs problèmes
- A géré des comptes clients
- A animé des sessions d'intégration

✅ FORTE :
- Maintenu un taux de rétention client de 95 % sur un portefeuille de 50 comptes grands comptes représentant 4 M$ d'ARR
- Résolu plus de 40 tickets clients par semaine avec un temps de réponse moyen de 2 heures, atteignant un score CSAT de 4,9/5
- Dispensé plus de 25 sessions d'onboarding pour de nouveaux clients, atteignant un taux d'adoption produit de 90 % dans les 30 premiers jours

### Analyse de données

❌ FAIBLE :
- A analysé des données
- A créé des rapports
- A formulé des recommandations

✅ FORTE :
- Analysé plus de 500 000 transactions pour identifier une opportunité commerciale de 2 M$, présenté les conclusions au comité de direction menant au lancement d'une nouvelle gamme
- Conçu un tableau de bord automatisé sous Tableau réduisant le temps de reporting manuel de 15 heures/semaine pour une équipe de 8 personnes
- Développé un modèle prédictif d'attrition client d'une précision de 85 %, permettant des campagnes de rétention ciblées ayant préservé 500 k$ d'ARR

### Opérations / Gestion de projet

❌ FAIBLE :
- A géré des projets
- A coordonné les équipes
- A suivi l'avancement

✅ FORTE :
- Piloté 8 projets interfonctionnels en simultané avec un taux de livraison dans les délais de 100 % et aucun dépassement de budget sur un portefeuille de 5 M$
- Coordonné les efforts des équipes d'ingénierie, de design et de marketing (30+ personnes) pour lancer un produit en avance sur le calendrier
- Mis en œuvre un système de suivi de projet réduisant la durée des réunions d'avancement de 50 % et améliorant la visibilité pour plus de 15 parties prenantes

## Erreurs courantes dans la rédaction de puces

### Erreur 1 : Langage passif
❌ « Était responsable de... »
❌ « A aidé à... »
❌ « A assisté sur... »
❌ « A participé à... »

✅ Utilisez des verbes d'action : Dirigé, Créé, Livré, Atteint

### Erreur 2 : Absence de métriques
❌ « Amélioré les performances du site web »
✅ « Amélioré le temps de chargement du site web de 60 % (de 8 s à 3,2 s) »

❌ « Encadré une grande équipe »
✅ « Dirigé une équipe interfonctionnelle de 25 personnes réparties sur 4 départements »

### Erreur 3 : Tâches quotidiennes au lieu de réalisations
❌ « Responsable du support client »
✅ « Résolu plus de 50 tickets par jour avec un taux de satisfaction client de 98 % »

❌ « Géré les comptes de réseaux sociaux »
✅ « Fait croître l'audience sur les réseaux sociaux de 300 % (de 10 k à 40 k) en 8 mois »

### Erreur 4 : Trop vague
❌ « A travaillé avec les parties prenantes »
✅ « Animé des réunions hebdomadaires avec plus de 15 parties prenantes issues des équipes d'ingénierie, produit et direction »

❌ « Amélioré les processus »
✅ « Rationalisé le flux d'approbation, réduisant le temps de cycle de 10 à 4 jours (gain de 60 %) »

### Erreur 5 : Trop long
❌ « Était responsable de la gestion et de la supervision de tous les aspects du service de succès client, notamment l'intégration, la formation, le support et la rétention pour un portefeuille de clients grands comptes... »

✅ « Piloté le succès client pour 50 comptes grands comptes (3 M$ d'ARR), atteignant un taux de rétention de 95 % »

**Règle : Limitez les puces à 1 ou 2 lignes maximum**

## Processus de rédaction des puces

### Étape 1 : Partir de la puce faible
```
Original: "Managed social media"
```

### Étape 2 : Poser des questions de clarification
- Quelles plateformes ?
- Combien d'abonnés ?
- Quelle croissance avez-vous obtenue ?
- Quelles actions spécifiques avez-vous menées ?
- Quel impact cela a-t-il eu sur l'entreprise ?

### Étape 3 : Rassembler les informations
- Plateformes : Instagram, LinkedIn
- Début : 5 k abonnés
- Fin : 18 k abonnés  
- Actions : Calendrier de contenu quotidien, partenariats influenceurs
- Impact : 200 prospects générés

### Étape 4 : Appliquer la formule
En appliquant X-Y-Z :
« Fait croître l'audience Instagram et LinkedIn de 260 % (de 5 k à 18 k) en mettant en place un calendrier éditorial quotidien et 15 partenariats influenceurs, générant plus de 200 prospects qualifiés »

### Étape 5 : Optimiser la longueur
Si la formulation est trop longue, privilégiez les métriques les plus percutantes :
« Fait croître l'audience sur les réseaux sociaux de 260 % (de 5 k à 18 k abonnés) via une stratégie de contenu et des partenariats influenceurs, générant 200+ prospects »

## Liste de contrôle de la force d'une puce

Chaque puce doit comporter :
- ✅ Un verbe d'action fort (éviter « responsable de », « a aidé »)
- ✅ Au moins un chiffre ou une métrique
- ✅ Un résultat ou un impact précis
- ✅ Des éléments de contexte sur l'envergure (taille de l'équipe, budget, utilisateurs, etc.)
- ✅ 1 à 2 lignes maximum
- ✅ Une tournure mettant en valeur un accomplissement et non une simple tâche
- ✅ Une pertinence directe avec le poste ciblé

## Format de sortie

Lors de la réécriture des puces, structurez la réponse ainsi :

```markdown
## BULLET IMPROVEMENTS

### Original Bullet #1:
"Managed customer accounts"

### Issues:
- Passive language ("managed")
- No metrics
- Vague (what does "managed" mean?)
- No results shown

### Improved Version:
"Grew portfolio of 40 enterprise accounts from $2M to $3.5M ARR (75% growth) through quarterly business reviews and proactive upselling strategy"

### What Changed:
- Added scale (40 accounts)
- Added growth metric (75%, $2M to $3.5M)
- Specified actions (QBRs, upselling)
- Shows business impact (revenue growth)

---

### Original Bullet #2:
[Continue for each bullet...]
```

## Situations particulières

### Pour les profils débutants / jeunes diplômés
Mettre l'accent sur :
- Les projets universitaires ayant eu un impact réel
- Les réalisations lors de stages
- Les projets de cours pertinents
- Les expériences de bénévolat avec des résultats quantifiables
- Les responsabilités associatives appuyées par des chiffres

Exemple :
« Dirigé l'association de marketing de l'université (50 membres), organisé 8 événements rassemblant plus de 300 étudiants et sécurisé 10 k$ de sponsors d'entreprises »

### Pour les personnes en reconversion professionnelle
Mettre l'accent sur :
- Les compétences transférables
- La reformulation des expériences passées au regard du nouveau secteur
- La mise en avant des projets pertinents ou side projects
- La capacité d'apprentissage et d'adaptation

Exemple :
« Géré des équipes interfonctionnelles de 15 personnes (commerce de détail traditionnel) » → peut devenir :
« Piloté des équipes transversales de 15 personnes réparties sur les opérations, le merchandising et l'expérience client, coordonnant les flux de travail et atteignant un taux de finalisation des projets de 100 % »

### Pour les périodes sans emploi
Mettre l'accent sur :
- Les missions en freelance ou de conseil
- Les réalisations dans le bénévolat
- Les projets personnels
- Les formations et le développement professionnel

N'attirez pas l'attention sur les périodes d'inactivité ; comblez l'espace avec des réalisations concrètes et pertinentes.

## Liste de contrôle pour la mise en œuvre

Pour chaque puce du CV :
1. ✅ Identifier le verbe faible → Le remplacer par un verbe d'action percutant
2. ✅ Vérifier la présence de chiffres → Ajouter au moins une métrique
3. ✅ Confirmer la présence d'un résultat → Ajouter l'impact ou le bénéfice généré
4. ✅ Vérifier la précision → Supprimer tout terme vague
5. ✅ Contrôler la longueur → S'en tenir à 1 ou 2 lignes
6. ✅ Relire à voix haute → S'assurer de la fluidité et du naturel
7. ✅ Vérifier la pertinence → S'assurer de l'alignement avec le poste visé
