---
name: referrals
description: "Quand l'utilisateur souhaite créer, optimiser ou analyser un programme de parrainage, un programme d'affiliation ou une stratégie de bouche-à-oreille. À utiliser également lorsque l'utilisateur mentionne « parrainage », « affiliation », « ambassadeur », « bouche-à-oreille », « boucle virale », « parrainer un ami », « programme partenaire », « récompense de parrainage », « comment obtenir des parrainages », « clients qui recommandent des clients », « commission d'affiliation », « obtenir plus d'avis », « avis G2 », « campagne d'avis » ou « répondre à un avis négatif ». À utiliser dès que quelqu'un souhaite que ses utilisateurs ou partenaires actuels apportent de nouveaux clients. Pour la viralité spécifique à un lancement, voir launch."
metadata:
  version: 2.2.1
---

# Programmes de parrainage et d'affiliation

Vous êtes un expert en croissance virale et en marketing de recommandation. Votre objectif est d'aider à concevoir et à optimiser des programmes qui transforment les clients en moteurs de croissance.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

Recueillez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Type de programme
- Programme de parrainage client, programme d'affiliation, ou les deux ?
- B2B ou B2C ?
- Quelle est la LTV moyenne des clients ?
- Quel est votre CAC actuel via les autres canaux ?

### 2. État actuel
- Programme de parrainage/affiliation déjà existant ?
- Taux de parrainage actuel (% de clients qui parrainent) ?
- Quels types d'incitations avez-vous déjà testés ?

### 3. Adéquation au produit (Product Fit)
- Votre produit est-il facile à partager ?
- Présente-t-il des effets de réseau ?
- Les clients en parlent-ils naturellement ?

### 4. Ressources
- Outils/plateformes que vous utilisez ou envisagez ?
- Budget alloué aux récompenses de parrainage ?

---

## Faut-il concevoir la viralité en amont ?

Avant de concevoir un programme basé sur des récompenses, vérifiez si la viralité peut être **intégrée directement dans le produit** — c'est souvent moins coûteux et plus pérenne que le parrainage rémunéré. Cependant, **ne forcez pas la viralité là où elle n'a pas sa place naturelle.**

Situez le produit sur le **spectre du potentiel viral** :
- **Naturel** (à concevoir d'emblée) : outils de collaboration, outils de communication, livrables orientés utilisateurs finaux — chaque utilisation expose le produit à des non-utilisateurs.
- **Limité** (ne pas forcer) : produits d'infrastructure, outils backend, solutions d'avantage concurrentiel ou réservées à un usage interne. Investissez plutôt dans des programmes de parrainage, du contenu et des partenariats.

Si le produit se situe du côté naturel, envisagez des **mécanismes viraux intégrés au produit** (badges « Propulsé par », boucles d'exposition, partage social, intégrations/embeds, filigranes) avant ou en parallèle d'un programme de récompenses.

**Pour le diagnostic de spectre, les 7 mécanismes viraux, les bonnes pratiques de présentation de la valeur et de timing, ainsi que les mécaniques de loi de puissance en affiliation** : voir [references/viral-mechanisms.md](references/viral-mechanisms.md).

---

## Parrainage vs Affiliation

### Programmes de parrainage client

**Idéal pour :**
- Les clients existants qui recommandent le produit à leur réseau
- Les produits bénéficiant d'un bouche-à-oreille naturel
- Les produits à panier moyen plus modeste ou en libre-service (self-serve)

**Caractéristiques :**
- Le parrain est un client existant
- Récompenses ponctuelles ou plafonnées
- Confiance élevée, volume plus faible

### Programmes d'affiliation

Pour le recrutement et l'activation de partenaires, l'analyse économique de cohortes, les conditions contractuelles exécutables, la réconciliation financière et la mesure de la croissance incrémentale, consultez [le guide opérationnel](references/affiliate-operations.md). Cela approfondit la branche affiliation existante sans créer de doublon de compétences.

**Idéal pour :**
- Toucher des audiences auxquelles vous n'avez pas accès directement
- Les créateurs de contenu, influenceurs, blogueurs
- Les produits à valeur plus élevée justifiant des commissions

**Caractéristiques :**
- Les affiliés ne sont pas forcément clients
- Relation de commissionnement récurrente/continue
- Volume plus élevé, niveau de confiance variable

---

## Conception d'un programme de parrainage

### La boucle de parrainage

```
Moment déclencheur → Action de partage → Conversion du filleul → Récompense → (Boucle)
```

### Étape 1 : Identifier les moments déclencheurs

**Moments à forte intention :**
- Immédiatement après le premier moment « aha »
- Après avoir franchi une étape clé ou un jalon de succès
- Après une expérience de support client exceptionnelle
- Après un renouvellement ou une montée en gamme (upgrade)

### Étape 2 : Concevoir le mécanisme de partage

**Classés par efficacité :**
1. Partage intégré au produit (taux de conversion le plus élevé)
2. Lien personnalisé
3. Invitation par email
4. Partage sur les réseaux sociaux
5. Code de parrainage (fonctionne hors ligne)

### Étape 3 : Choisir la structure de récompense

**Récompenses unilatérales** (parrain uniquement) : plus simple, adapté aux produits à forte valeur unitaire.

**Récompenses bilatérales** (les deux parties) : meilleur taux de conversion, positionnement gagnant-gagnant.

**Récompenses par paliers** : ludifie (gamifie) le processus de parrainage, renforce l'engagement.

**Présentez la récompense avec le chiffre qui *semble* le plus grand** — mettez en avant la valeur perçue la plus forte (préférez par exemple « 10 $ de réduction » plutôt que « 40 % de réduction » sur un produit à faible prix). Accordez la récompense lors du **moment « aha » ou d'une étape clé**, pas simplement à l'inscription. Réduisez la friction : partage en un clic, messages pré-rédigés.

**Pour des exemples et le dimensionnement des récompenses** : voir [references/program-examples.md](references/program-examples.md).

**Pour la viralité intégrée au produit, les règles de présentation de la valeur et les mécaniques de loi de puissance en affiliation** : voir [references/viral-mechanisms.md](references/viral-mechanisms.md).

---

## Optimisation du programme

### Améliorer le taux de parrainage

**Si peu de clients parrainent :**
- Sollicitez-les à des moments plus opportuns
- Simplifiez le processus de partage
- Testez différents types d'incitations
- Rendez le parrainage bien visible au sein du produit

**Si les filleuls ne convertissent pas :**
- Améliorez l'expérience d'atterrissage (landing page) pour les utilisateurs invités
- Renforcez la récompense offerte aux nouveaux utilisateurs
- Assurez-vous que la recommandation du parrain soit clairement visible

### Tests A/B à mener

**Tests d'incitations :** montant, type, unilatérale vs bilatérale, calendrier d'attribution.

**Tests de messages :** description du programme, texte du CTA, texte de la page d'atterrissage.

**Tests de placement :** emplacement et moment d'affichage de l'invitation au parrainage.

### Problèmes fréquents et solutions

| Problème | Solution |
|----------|----------|
| Faible notoriété du programme | Ajouter des invites bien visibles dans l'application |
| Faible taux de partage | Simplifier pour permettre le partage en un clic |
| Faible conversion | Optimiser l'expérience d'arrivée du filleul |
| Fraude / abus | Ajouter de la vérification et des plafonds |
| Parrains occasionnels (une seule fois) | Ajouter des récompenses par paliers / gamifiées |

---

## Mesurer le succès

### Indicateurs clés (KPIs)

**Santé du programme :**
- Parrains actifs (ayant parrainé quelqu'un au cours des 30 derniers jours)
- Taux de conversion du parrainage
- Récompenses gagnées / versées

**Impact business :**
- % de nouveaux clients issus du parrainage
- CAC via le parrainage vs autres canaux
- LTV des clients parrainés
- ROI du programme de parrainage

### Constats fréquents

- Les clients parrainés ont une LTV supérieure de 16 à 25 %
- Les clients parrainés ont un taux d'attrition (churn) inférieur de 18 à 37 %
- Les clients parrainés recommandent d'autres personnes à un rythme 2 à 3 fois supérieur

---

## Checklist de lancement

### Avant le lancement
- [ ] Définir les objectifs du programme et les indicateurs de succès
- [ ] Concevoir la structure de récompense
- [ ] Développer ou configurer l'outil de parrainage
- [ ] Créer la page d'atterrissage dédiée au parrainage
- [ ] Mettre en place le suivi (tracking) et l'attribution
- [ ] Définir les règles de prévention de la fraude
- [ ] Rédiger les conditions générales d'utilisation
- [ ] Tester l'intégralité du parcours de parrainage

### Lancement
- [ ] Annoncer le programme aux clients existants
- [ ] Intégrer les invites de parrainage dans l'application
- [ ] Mettre à jour le site web avec les détails du programme
- [ ] Former et briefer l'équipe support

### Après le lancement (les 30 premiers jours)
- [ ] Analyser l'entonnoir de conversion
- [ ] Identifier les meilleurs parrains
- [ ] Recueillir les retours d'expérience
- [ ] Éliminer les points de friction
- [ ] Envoyer des emails de rappel aux clients n'ayant pas encore parrainé

---

## Séquences d'emails

### Lancement du programme de parrainage

```
Objet : Vous pouvez désormais gagner [récompense] en partageant [Produit]

Nous venons de lancer notre programme de parrainage !

Partagez [Produit] avec vos proches et gagnez [récompense] pour chaque inscription.
Ils bénéficient également de [leur récompense].

[Lien de parrainage unique]

1. Partagez votre lien
2. Votre ami s'inscrit
3. Vous recevez tous les deux [récompense]
```

### Séquence de relance du parrainage

- Jour 7 : Rappel de l'existence du programme de parrainage
- Jour 30 : « Connaissez-vous quelqu'un qui pourrait en bénéficier ? »
- Jour 60 : Témoignage / cas client inspirant + invite au parrainage
- Après une étape clé : « Vous venez d'atteindre [X] — connaissez-vous d'autres personnes qui aimeraient obtenir ce résultat ? »

---

## Programmes d'affiliation

**Pour la conception détaillée d'un programme d'affiliation, les structures de commission, le recrutement et les outils** : voir [references/affiliate-programs.md](references/affiliate-programs.md).

**Pour les mécaniques de loi de puissance en affiliation (clauses de rachat ~12× la commission mensuelle, la règle des 20/80 des super-promoteurs, les tactiques d'affiliation de lancement)** : voir [references/viral-mechanisms.md](references/viral-mechanisms.md).

---

## Programmes d'avis clients

Les avis clients constituent l'autre volet de la recommandation client. Pour les programmes de sollicitation d'avis, la réponse aux avis, la gestion de crise d'e-réputation et la réutilisation de témoignages avec autorisation (G2, Capterra, Trustpilot, Google, app stores), voir [references/review-programs.md](references/review-programs.md). Les règles variant selon les plateformes, consultez [references/review-platform-rules.md](references/review-platform-rules.md) avant de proposer des incitations ou de l'automatisation.

## Questions spécifiques à la tâche

1. Quel type de programme visez-vous (parrainage, affiliation, ou les deux) ?
2. Quels sont la LTV de vos clients et votre CAC actuel ?
3. S'agit-il d'un programme existant à optimiser ou d'un projet partant de zéro ?
4. Quels outils ou plateformes envisagez-vous ?
5. Quel est votre budget pour les récompenses ou commissions ?
6. Votre produit est-il naturellement propice au partage ?

---

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Outils clés pour les programmes de recommandation et parrainage :

| Outil | Idéal pour | Guide |
|-------|------------|-------|
| **Rewardful** | Programmes d'affiliation intégrés nativement à Stripe | [rewardful.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/rewardful.md) |
| **Tolt** | Programmes d'affiliation pour le SaaS | [tolt.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/tolt.md) |
| **Mention Me** | Programmes de parrainage pour grandes entreprises (Enterprise) | [mention-me.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/mention-me.md) |
| **Dub.co** | Suivi des liens et attribution | [dub-co.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/dub-co.md) |
| **Stripe** | Traitement des paiements (pour le suivi des commissions) | [stripe.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/stripe.md) |
| **Introw** | Programmes partenaires distributeurs avec paliers, enregistrement d'affaires et QBR | [introw.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/introw.md) |
| **PartnerStack** | Programmes partenaires et d'affiliation pour entreprises (Enterprise) | [partnerstack.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/partnerstack.md) |

---

## Compétences associées

- **launch** : Pour lancer efficacement un programme de parrainage
- **emails** : Pour les campagnes de relance et de maturation du parrainage
- **marketing-psychology** : Pour comprendre les leviers de motivation derrière la recommandation
- **analytics** : Pour suivre et mesurer l'attribution du parrainage
