---
name: design-system
description: Architecture de tokens, spécifications de composants et génération de diapositives. Tokens à trois niveaux (primitif→sémantique→composant), variables CSS, échelles d'espacement/typographie, spécifications de composants, création stratégique de présentations. À utiliser pour les design tokens, le design systématique et les présentations conformes à la marque.
argument-hint: "[component or token]"
license: MIT
metadata:
  author: claudekit
  version: "1.0.0"
---

# Design System

Architecture de tokens, spécifications de composants, design systématique, génération de diapositives.

## Quand l'utiliser

- Création de design tokens
- Définition des états de composants
- Systèmes de variables CSS
- Échelles d'espacement/typographie
- Passage du design au code (design-to-code handoff)
- Configuration de thème Tailwind
- **Génération de diapositives / présentations**

## Architecture des tokens

Charger : `references/token-architecture.md`

### Structure à trois niveaux

```
Primitif (valeurs brutes)
       ↓
Sémantique (alias d'usage)
       ↓
Composant (spécifique au composant)
```

**Exemple :**
```css
/* Primitive */
--color-blue-600: #2563EB;

/* Semantic */
--color-primary: var(--color-blue-600);

/* Component */
--button-bg: var(--color-primary);
```

## Chemins des scripts

Les chemins de scripts dans cette compétence et ses `references/` sont relatifs au répertoire contenant ce SKILL.md, et non au projet : `scripts/<file>` désigne le propre dossier `scripts/` de cette compétence, et `../<skill>/scripts/<file>` désigne une sous-compétence sœur installée à ses côtés. Construisez le chemin complet à partir de ce répertoire (Claude Code l'indique comme répertoire de base de la compétence lors de son chargement) et conservez le répertoire de travail à la racine du projet — les scripts lisent et écrivent les fichiers du projet tels que `docs/brand-guidelines.md`, `assets/design-tokens.json` ou `src/` de manière relative à celle-ci.

## Démarrage rapide

**Générer les tokens :**
```bash
node scripts/generate-tokens.cjs --config tokens.json -o tokens.css
```

**Valider l'utilisation :**
```bash
node scripts/validate-tokens.cjs --dir src/
```

## Références

| Sujet | Fichier |
|-------|---------|
| Architecture des tokens | `references/token-architecture.md` |
| Tokens primitifs | `references/primitive-tokens.md` |
| Tokens sémantiques | `references/semantic-tokens.md` |
| Tokens de composants | `references/component-tokens.md` |
| Spécifications des composants | `references/component-specs.md` |
| États & Variantes | `references/states-and-variants.md` |
| Intégration Tailwind | `references/tailwind-integration.md` |

## Modèle de spécification de composant

| Propriété | Par défaut | Survol (Hover) | Actif | Désactivé |
|-----------|------------|----------------|-------|-----------|
| Background | primary | primary-dark | primary-darker | muted |
| Text | white | white | white | muted-fg |
| Border | none | none | none | muted-border |
| Shadow | sm | md | none | none |

## Scripts

| Script | Objectif |
|--------|----------|
| `generate-tokens.cjs` | Générer le CSS à partir de la configuration JSON des tokens |
| `validate-tokens.cjs` | Vérifier la présence de valeurs codées en dur dans le code |
| `search-slides.py` | Recherche BM25 + recommandations contextuelles |
| `slide-token-validator.py` | Valider la conformité des diapositives HTML aux tokens |
| `fetch-background.py` | Récupérer des images depuis Pexels/Unsplash |

## Modèles

| Modèle | Objectif |
|--------|----------|
| `design-tokens-starter.json` | JSON de départ avec structure à trois niveaux |

## Intégration

**Avec brand :** Extraire les primitives des couleurs/de la typographie de la marque
**Avec ui-styling :** Tokens de composants → configuration Tailwind

**Dépendances de la compétence :** brand, ui-styling
**Agents principaux :** ui-ux-designer, frontend-developer

## Système de diapositives

Présentations conformes à la marque utilisant les design tokens + Chart.js + système de décision contextuelle.

### Source de vérité

| Fichier | Objectif |
|---------|----------|
| `docs/brand-guidelines.md` | Identité de marque, tonalité, couleurs |
| `assets/design-tokens.json` | Définitions des tokens (primitif→sémantique→composant) |
| `assets/design-tokens.css` | Variables CSS (à importer dans les diapositives) |
| `assets/css/slide-animations.css` | Bibliothèque d'animations CSS |

### Recherche de diapositives (BM25)

```bash
# Basic search (auto-detect domain)
python scripts/search-slides.py "investor pitch"

# Domain-specific search
python scripts/search-slides.py "problem agitation" -d copy
python scripts/search-slides.py "revenue growth" -d chart

# Contextual search (Premium System)
python scripts/search-slides.py "problem slide" --context --position 2 --total 9
python scripts/search-slides.py "cta" --context --position 9 --prev-emotion frustration
```

### Fichiers CSV du système de décision

| Fichier | Objectif |
|---------|----------|
| `data/slide-strategies.csv` | 15 structures de présentation + arcs émotionnels + rythmes sparkline |
| `data/slide-layouts.csv` | 25 mises en page + variantes de composants + animations |
| `data/slide-layout-logic.csv` | Objectif → Mise en page + indicateur break_pattern |
| `data/slide-typography.csv` | Type de contenu → Échelle typographique |
| `data/slide-color-logic.csv` | Émotion → Traitement des couleurs |
| `data/slide-backgrounds.csv` | Type de diapositive → Catégorie d'image (Pexels/Unsplash) |
| `data/slide-copy.csv` | 25 formules de copywriting (PAS, AIDA, FAB) |
| `data/slide-charts.csv` | 25 types de graphiques avec configuration Chart.js |

### Flux de décision contextuel

```
1. Analyser l'objectif/contexte
        ↓
2. Rechercher dans slide-strategies.csv → Obtenir la stratégie + les temps forts émotionnels
        ↓
3. Pour chaque diapositive :
   a. Interroger slide-layout-logic.csv → mise en page + break_pattern
   b. Interroger slide-typography.csv → échelle typographique
   c. Interroger slide-color-logic.csv → traitement des couleurs
   d. Interroger slide-backgrounds.csv → image si nécessaire
   e. Appliquer la classe d'animation depuis slide-animations.css
        ↓
4. Générer le HTML avec les design tokens
        ↓
5. Valider avec slide-token-validator.py
```

### Rupture de schéma (Sparkline de Duarte)

Les présentations premium alternent les émotions pour maintenir l'engagement :
```
"Ce qui est" (frustration) ↔ "Ce qui pourrait être" (espoir)
```

Le système calcule les ruptures de schéma aux positions 1/3 et 2/3.

### Exigences pour les diapositives

**TOUTES les diapositives DOIVENT :**
1. Importer `assets/design-tokens.css` - unique source de vérité
2. Utiliser des variables CSS : `var(--color-primary)`, `var(--slide-bg)`, etc.
3. Utiliser Chart.js pour les graphiques (PAS de barres en CSS uniquement)
4. Inclure une navigation (flèches du clavier, clic, barre de progression)
5. Aligner le contenu au centre
6. Se concentrer sur la persuasion / la conversion

### Intégration de Chart.js

```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<canvas id="revenueChart"></canvas>
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: ['Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            data: [5, 12, 28, 45],
            borderColor: '#FF6B6B',  // Use brand coral
            backgroundColor: 'rgba(255, 107, 107, 0.1)',
            fill: true,
            tension: 0.4
        }]
    }
});
</script>
```

### Conformité des tokens

```css
/* CORRECT - uses token */
background: var(--slide-bg);
color: var(--color-primary);
font-family: var(--typography-font-heading);

/* WRONG - hardcoded */
background: #0D0D0D;
color: #FF6B6B;
font-family: 'Space Grotesk';
```

### Implémentation de référence

Exemple fonctionnel incluant toutes les fonctionnalités :
```
assets/designs/slides/claudekit-pitch-251223.html
```

### Commande

```bash
/slides:create "10-slide investor pitch for ClaudeKit Marketing"
```

## Bonnes pratiques

1. Ne jamais utiliser de code hexadécimal brut dans les composants - toujours référencer des tokens
2. La couche sémantique permet le basculement de thème (clair/sombre)
3. Les tokens de composants permettent la personnalisation par composant
4. Utiliser le format HSL pour le contrôle de l'opacité
5. Documenter la finalité de chaque token
6. **Les diapositives doivent impérativement importer design-tokens.css et utiliser exclusivement var()**
