---
name: apple-design
description: L'approche d'Apple en matière de conception d'interfaces et de mouvement physique fluide, adaptée pour le web. À utiliser lors de la création ou de la révision d'interfaces pilotées par des gestes, d'animations avec ressorts (springs), d'interactions de glissement/balayage/feuilles (sheets), de transitions avec inertie et interruptibles, de matériaux translucides et de profondeur, de typographie (taille optique, approche/tracking, interlignage/leading), de réduction de mouvement, ou des fondements du design (retour d'information, cohérence spatiale, retenue) propres aux interfaces de style Apple.
---

# Design Apple

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, réponds uniquement :

> Je suis prêt à vous aider à concevoir des interfaces fluides dans le style Apple pour le web ; mes connaissances sont issues des conférences de design de la WWDC d'Apple, adaptées pour le web.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Comment Apple conçoit des interfaces qui cessent de ressembler à un ordinateur pour devenir une extension naturelle de vous-même. Ces connaissances sont issues des conférences de design de la WWDC d'Apple — principalement *Designing Fluid Interfaces* (WWDC 2018) — condensées et adaptées pour la plateforme web (CSS, Pointer Events, `requestAnimationFrame`, bibliothèques de ressorts comme Motion/Framer Motion).

Le fil conducteur : **une interface semble vivante lorsque le mouvement part de la valeur actuelle à l'écran, hérite de la vélocité de l'utilisateur, projette l'inertie vers l'avant, et peut être saisie et inversée à tout instant.** Les ressorts (*springs*) sont l'outil qui rend tout cela naturel, car ils sont intrinsèquement interruptibles et conscients de la vitesse.

## L'idée fondamentale

> « Lorsque nous alignons l'interface sur notre façon de penser et de bouger, la magie opère : elle cesse de ressembler à un ordinateur pour devenir une extension fluide et transparente de nous-mêmes. »

Une interface est fluide lorsqu'elle se comporte comme le monde physique : les éléments répondent instantanément, bougent de manière continue, conservent leur inertie, résistent aux limites et peuvent être redirigés en plein mouvement. Tout ce qui suit vise à se rapprocher de cet idéal.

Apple conçoit le design comme une réponse à quatre besoins humains : **la sécurité/prévisibilité, la compréhension, l'accomplissement et la joie.** Chaque règle présentée ici répond à l'un d'eux.

## 1. Réactivité — éliminer la latence

Dès que le décalage apparaît, le sentiment de manipulation directe s'effondre. La réactivité est le socle sur lequel repose tout le reste.

- **Répondre dès l'appui (pointer-down), pas au relâchement.** Mettre un bouton en surbrillance dès l'instant où il est pressé. Attendre le `click`/touch-up pour afficher un retour donne une impression d'inertie.
- **Faire la chasse à chaque latence.** Auditer les debounces, les délais artificiels, les attentes de transition et le délai de frappe d'environ 300 ms. Tout ce qui n'est pas essentiel sur le chemin d'entrée constitue une régression.
- **Le retour doit être continu *pendant* l'interaction, pas seulement à la fin.** Pour un glissement (drag), un curseur (slider) ou un tiroir (drawer), mettez à jour l'UI à 1:1 avec le pointeur tout au long du geste — n'animez jamais uniquement lorsque le geste s'achève.

```css
/* Le retour se fait à l'appui, et il est instantané */
.button:active {
  transform: scale(0.97);
  transition: transform 100ms ease-out;
}
```

## 2. Manipulation directe — suivi 1:1

> « Le toucher et le contenu doivent bouger ensemble. »

Lorsque l'utilisateur fait glisser un élément, celui-ci doit rester collé au doigt — et respecter le décalage par rapport à *l'endroit où il a été saisi*. Réaligner brutalement l'élément sur son centre au moment de la saisie brise immédiatement l'illusion.

- Utiliser les Pointer Events avec `setPointerCapture` pour que le suivi continue même si le pointeur sort des limites de l'élément.
- Conserver un court **historique de vitesse/position** (les derniers événements `pointermove`), pas seulement le point actuel — vous aurez besoin de la vitesse au moment du relâchement.

```js
el.addEventListener('pointerdown', (e) => {
  el.setPointerCapture(e.pointerId);
  const grabOffset = e.clientY - el.getBoundingClientRect().top; // respecter l'endroit où il a été saisi
  // ...suivre l'historique de position + horodatage pour calculer la vitesse
});
```

## 3. Interruptibilité — le principe le plus important

> « La pensée et le geste se produisent en parallèle. »

Chaque animation doit pouvoir être interrompue et redirigée à tout moment. L'utilisateur doit pouvoir attraper un élément en plein vol et inverser sa trajectoire sans attendre la fin de l'animation. Une fenêtre modale en train de se fermer que l'utilisateur rattrape doit suivre le doigt — et non terminer sa fermeture pour ensuite se rouvrir.

- **Ne jamais bloquer les interactions pendant une transition.**
- **Toujours animer à partir de la valeur de *présentation* (actuelle), jamais de la valeur cible.** En cas d'interruption, lisez la transformation en temps réel de l'élément à l'écran et démarrez la nouvelle animation à partir de là. Démarrer depuis la valeur logique/cible provoque un saut visible.
- **Éviter les transitions CSS et `@keyframes` pour tout ce qui est piloté par des gestes** — ils ne peuvent pas être saisis et inversés de manière fluide en cours de route. Les ressorts s'animent par défaut à partir de la valeur actuelle, ce qui correspond exactement aux besoins de l'interruption.
- **Lorsqu'un geste s'inverse, fusionner la vélocité — pas de coupure nette.** Remplacer une animation par une autre lors d'une inversion crée une discontinuité de vitesse, un « mur de briques ». Les bibliothèques de ressorts qui conservent la vitesse lors d'un changement de cible l'évitent. (C'est ce que font nativement les *animations additives* d'iOS ; sur le web, choisissez une bibliothèque de ressorts qui redéfinit la cible à partir de la vitesse actuelle).
- **Décomposer le mouvement 2D en ressorts X et Y indépendants.** Un seul ressort appliqué à une distance 2D se désynchronise lorsque X et Y ont des vitesses différentes.

## 4. Comportement plutôt qu'animation — utiliser des ressorts

> « Pensez à l'animation comme à une conversation entre vous et l'objet, et non comme à quelque chose de prescrit par l'interface. »

Une animation préenregistrée à durée fixe ne peut pas réagir à une nouvelle action. Un ressort le peut — une nouvelle entrée modifie simplement la cible, et le mouvement reste continu. Privilégiez les ressorts pour tout ce que l'utilisateur peut toucher.

Apple a délibérément remplacé le triplet de la physique classique (masse/rigidité/amortissement) par deux paramètres plus intuitifs pour les designers. Réfléchissez avec ceux-ci :

- **Damping ratio (taux d'amortissement)** — contrôle le dépassement (*overshoot*). `1.0` = amortissement critique, aucun rebond, stabilisation fluide. `< 1.0` = dépassement et oscillations. Plus la valeur est basse, plus le rebond est prononcé.
- **Response (temps de réponse)** — la rapidité avec laquelle la valeur atteint la cible, en secondes. Plus la valeur est basse, plus l'animation est vive. **Ce n'est pas une « durée »** — un ressort n'a pas de durée fixe ; son temps de stabilisation découle de ses paramètres.

**Valeurs par défaut :**
- Commencer la plupart des éléments d'UI avec un **damping de `1.0`** (amortissement critique) — élégant et sans distraction.
- N'ajouter du rebond (**damping ~`0.8`**) **que lorsque le geste lui-même portait de l'inertie** (une pichenette/flick, un lancer, le relâchement d'un glissement). Un rebond sur un menu qui vient d'apparaître en fondu semble artificiel ; un rebond sur une carte que l'on vient de projeter d'un coup sec semble naturel.

**Valeurs concrètes utilisées par Apple :**

| Interaction | Damping | Response |
| --- | --- | --- |
| Déplacement / repositionnement (ex. PiP) | `1.0` | `0.4` |
| Rotation | `0.8` | `0.4` |
| Tiroir / feuille (sheet) | `0.8` | `0.3` |

**Équivalence web (Motion / Framer Motion) :** l'API de ressort `bounce` + `duration` correspond étroitement au couple damping + response d'Apple. Une convention sûre consiste à utiliser des ressorts avec `damping: 1.0` partout par défaut ; réservez le rebond aux interactions physiques pilotées par l'inertie.

```js
import { animate } from 'motion';

// Valeur par défaut avec amortissement critique (sans dépassement)
animate(el, { y: 0 }, { type: 'spring', bounce: 0, duration: 0.4 });

// Interaction avec inertie — un léger rebond, uniquement parce qu'une pichenette l'a précédée
animate(el, { y: target }, { type: 'spring', bounce: 0.2, duration: 0.4 });
```

## 5. Transfert de vélocité — la jonction entre glissement et animation

Lorsqu'un geste prend fin, l'animation doit **se poursuivre à la vitesse exacte du doigt**, de sorte qu'il n'y ait aucune rupture visible entre le glissement et l'animation. C'est le détail qui sépare le plus une interface « fluide » d'une interface simplement « correcte ».

Transmettez la vitesse de relâchement du pointeur comme vitesse initiale du ressort. Certaines API de ressorts attendent une vitesse **relative** — normalisez-la par la distance restante jusqu'à la cible :

```
relativeVelocity = gestureVelocity / (targetValue − currentValue)
```

Exemple : élément à `y=50`, cible à `y=150` (100 px restants), doigt se déplaçant à 50 px/s → vitesse initiale du ressort = `50 / 100 = 0.5`. Framer Motion / Motion prennent directement la vitesse absolue en px/s (option `velocity`), vous leur transmettez donc généralement la valeur brute.

## 6. Projection d'inertie — animer vers l'endroit où le geste *va*

> « Partir d'une petite action pour produire un grand résultat. »

Ne vous alignez pas sur la limite la plus proche du *point de relâchement*. Utilisez la vitesse pour **projeter la position de repos** — exactement comme la décélération du défilement — puis alignez-vous sur la cible la plus proche de ce point projeté. C'est ce qui donne l'impression qu'un geste rapide projette réellement l'élément.

La fonction exacte de projection d'Apple (issue du code d'exemple de *Designing Fluid Interfaces*) :

```js
// decelerationRate ≈ 0.998 pour une sensation de défilement standard ; 0.99 pour plus de nervosité
function project(initialVelocity /* px/s */, decelerationRate = 0.998) {
  return (initialVelocity / 1000) * decelerationRate / (1 - decelerationRate);
}

const projectedEndpoint = currentPosition + project(releaseVelocity);
const target = nearestSnapPoint(projectedEndpoint);   // choisir la cible à partir de la projection
animateSpringTo(target, { velocity: releaseVelocity }); // puis transmettre la vitesse (§5)
```

Remarque : la formule des manuels de physique `v²/(2·decel)` n'est *pas* ce qu'Apple utilise — utilisez la formule de décroissance exponentielle ci-dessus. C'est le comportement standard dans les bons bottom-sheets et carrousels (Vaul, Embla).

## 7. Cohérence spatiale — trajectoires symétriques, origines ancrées

> « Si quelque chose disparaît dans une direction, nous nous attendons à ce qu'il réapparaisse d'où il est venu. »

- **Entrer et sortir par la même trajectoire.** Un panneau qui glisse depuis la droite doit disparaître vers la droite. Une entrée par la droite suivie d'une sortie par le bas semble déconnectée et déroutante.
- **Ancrer les interactions à leur source.** Un menu, un popover ou une feuille (sheet) doit provenir de l'élément qui l'a déclenché — définissez `transform-origin` sur le déclencheur, afin que la relation spatiale entre le bouton et le contenu soit évidente. (C'est le même principe de conscience de l'origine que pour les popovers qui s'agrandissent depuis leur déclencheur, et non depuis leur centre).
- **Miroiter les courbes d'atténuation (easing) sur les transitions réversibles** afin que la trajectoire aller corresponde à la trajectoire retour (utilisez des points de contrôle cubic-bézier inversés pour les deux directions).

## 8. Suggérer dans la direction du geste

L'être humain anticipe un état final à partir d'une trajectoire. Le mouvement intermédiaire doit signaler la destination — les modules du Centre de contrôle « grandissent vers le haut et vers l'extérieur en direction de votre doigt ». Faites en sorte que les images intermédiaires suggèrent le résultat, plutôt que d'effectuer une simple interpolation aveugle.

## 9. Effet élastique (rubber-banding) — des limites douces

Arrivé à un bord, résistez progressivement plutôt que de vous arrêter net. Un arrêt brutal est interprété comme un blocage (« gelé ») ; une résistance continue indique que le système est « réactif, mais qu'il n'y a rien de plus ici ». Appliquez un amortissement qui augmente à mesure que l'utilisateur tire au-delà de la limite.

```js
// Plus on dépasse la limite, moins l'élément suit — les vrais objets ralentissent avant de s'arrêter
function rubberband(overshoot, dimension, constant = 0.55) {
  return (overshoot * dimension * constant) / (dimension + constant * Math.abs(overshoot));
}
```

## 10. Détails de conception des gestes (la checklist de la sensation)

- **Tap (toucher) :** surbrillance dès le touch-*down* (instantané), validation au touch-*up*. Ajoutez environ 10 px d'hystérésis/marge de frappe (hit padding) autour de la cible, et permettez l'annulation en glissant le doigt vers l'extérieur puis retour.
- **Glissement / balayage (drag/swipe) :** exigez un petit seuil de déplacement (hystérésis, ~10 px) avant de confirmer une direction, puis suivez à 1:1.
- **Détecter tous les gestes plausibles en parallèle dès le premier mouvement**, puis annuler avec certitude les gestes écartés une fois l'intention clarifiée. Évitez les détecteurs qui ne rapportent qu'un état *final* (événements de type `swipeleft`) — ils éliminent le suivi continu indispensable au retour visuel.
- **Minimiser les délais de désambiguïsation.** La détection du double tap retarde inévitablement les taps simples ; n'assumez ce coût que là où le double tap est réellement nécessaire.

## 11. Fluidité au niveau de l'image (frame-level)

La fluidité concerne *le contenu de chaque image*, pas seulement la fréquence d'affichage.

- Maintenez le changement de position entre chaque image sous le seuil de perception pour éviter l'effet stroboscopique.
- Pour les mouvements très rapides, un léger **flou de mouvement / étirement (motion blur / stretch)** traduit la vitesse et s'interprète mieux qu'une traînée nette et brutale.
- `requestAnimationFrame` est l'horloge synchronisée avec l'écran sur le web (Apple utilise `CADisplayLink`). N'animez que des propriétés adaptées au compositeur — `transform` et `opacity` — et signalez les mouvements imminents avec `will-change`.

## 12. Matériaux et profondeur — la translucidité traduit la hiérarchie

Apple utilise des matériaux translucides comme une couche fonctionnelle flottante qui apporte de la structure sans accaparer l'attention. Sur le web, reproduisez cet effet avec `backdrop-filter`.

- **Concevoir la navigation, les barres d'outils et les feuilles sous forme de calques translucides** (`backdrop-filter: blur()` + arrière-plan semi-transparent) sous lesquels le contenu défile — et non comme des barres opaques occupant une bande fixe.
- **Le poids du matériau code la hiérarchie :** des matériaux plus sombres/lourds séparent les zones structurelles (barres latérales) ; des matériaux plus clairs attirent l'attention sur les éléments interactifs (boutons). **Ne superposez jamais une surface translucide claire sur une autre** — la lisibilité s'effondre.
- **Les surfaces plus grandes doivent paraître plus épaisses :** un flou plus prononcé et une ombre plus profonde que pour les petits éléments. Envisagez des ombres contextuelles — plus denses sur un contenu textuel chargé pour la séparation, plus douces sur des arrière-plans unis.
- **Assombrir pour focaliser, séparer pour maintenir le flux.** Une tâche modale associe la surface à un voile d'assombrissement (*scrim*) et repousse l'arrière-plan en retrait/vers le bas. Un panneau parallèle et non bloquant utilise la translucidité et le décalage *sans* voile afin de ne pas interrompre le flux. Pour les feuilles empilées, assombrissez et repoussez progressivement chaque couche parente.
- **La vibrance préserve la lisibilité du texte sur des arrière-plans changeants.** Sur les surfaces floutées/translucides, n'utilisez pas de texte gris plat — utilisez un contraste plus élevé, une graisse légèrement plus forte et une légère augmentation de l'espacement des lettres. Placez la couleur sur une couche solide, pas sur le premier plan translucide.
- **Effets de bordure au défilement, pas de séparateurs rigides.** Au lieu d'une bordure de 1 px sous un en-tête fixe, appliquez un léger flou/masque en dégradé là où le contenu rencontre l'interface flottante — uniquement là où l'UI flottante chevauche réellement le contenu.
- **Matérialiser, ne pas se contenter d'un fondu.** Pour les surfaces vitrées/floutées, animez conjointement le rayon de flou et l'échelle lors de l'entrée/sortie, afin que la surface donne l'impression d'un matériau réel qui arrive plutôt que d'un simple fondu d'opacité.

```css
.toolbar {
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(20px) saturate(180%);
  border-top: 1px solid rgba(255, 255, 255, 0.4); /* bord supérieur brillant = la lumière accroche le matériau */
}
```

## 13. Retour multimodal — mouvement + son + retour haptique

Trois règles pour combiner les sens (issues de *Designing Audio-Haptic Experiences*) :

1. **Causalité** — l'origine du retour doit être évidente. Déclenchez-le sur l'événement causal réel (le basculement d'un interrupteur, l'élément qui s'enclenche à sa place) et adaptez son caractère à la dimension physique de l'action.
2. **Harmonie** — le visuel, le son et le retour haptique doivent se déclencher sur la **même image**. La moindre latence entre eux détruit l'illusion. Ne laissez pas une transition CSS décaler l'audio ou le retour haptique (Vibration API).
3. **Utilité** — n'ajoutez du retour que là où il a une vraie valeur ajoutée. Réservez l'haptique et le son aux moments significatifs (succès, erreur, validation, enclenchement). L'excès de retours habitue les utilisateurs à tous les ignorer.

## 14. Réduction des mouvements et accessibilité

La réduction des mouvements ne signifie pas l'*absence* de retour — elle implique un équivalent plus doux, sans perturbation vestibulaire. Répondez à trois signaux indépendants et intégrez-les dans vos composants :

- **`prefers-reduced-motion: reduce`** — remplacer les glissements/ressorts/parallaxes par de courts **fondus enchaînés d'opacité ou des transitions statiques**. Supprimez l'élasticité et le dépassement (*overshoot*). Conservez les changements d'opacité/couleur qui facilitent la compréhension.
- **`prefers-reduced-transparency: reduce`** — rendre les surfaces translucides plus dépolies ou opaques : augmentez l'opacité de l'arrière-plan, supprimez le flou.
- **`prefers-contrast: more`** — des arrière-plans quasi opaques avec une bordure nette et contrastée.

De plus : évitez les arrière-plans en mouvement occupant tout le viewport, les oscillations lentes en boucle (proches de 0,2 Hz / un cycle toutes les 5 s), et les variations brusques de luminosité (adoucir les changements de thème sombre↔clair). Rendez les grands objets en mouvement semi-transparents pendant leur déplacement, et faites disparaître en fondu les grandes surfaces lors d'un repositionnement important avant de les réafficher une fois stabilisées.

```css
@media (prefers-reduced-motion: reduce) {
  .sheet { transition: opacity 200ms ease; transform: none !important; }
}
@media (prefers-reduced-transparency: reduce) {
  .toolbar { background: white; backdrop-filter: none; }
}
```

## 15. Typographie — taille optique, approche (tracking), interlignage (leading)

Apple conçoit ses polices de caractères pour qu'elles adaptent leur forme à leur taille ; la même rigueur s'applique sur le web. (Issu de *The Details of UI Typography*, WWDC 2020.)

- **L'approche / tracking (letter-spacing) dépend de la taille — jamais une valeur unique pour toutes les tailles.** Les grands textes d'affichage nécessitent un tracking *négatif* (les lettres semblent trop espacées à mesure qu'elles grandissent) ; les petits textes demandent un tracking légèrement *positif* pour la lisibilité. Un `letter-spacing` fixe sera toujours inadapté à un niveau ou un autre. Resserrez les titres, laissez le corps de texte proche de `0`.
- **L'interlignage / leading (line-height) évolue de manière inverse à la taille.** Rapproché sur les grands titres, plus aéré sur le corps de texte. Augmentez-le pour les écritures avec de grandes hampes ascendantes/descendantes ; resserrez-le pour les interfaces denses et riches en informations.
- **Construire la hiérarchie à partir de l'ensemble graisse + taille + interlignage**, et non de la taille seule. Mettez l'accent avec la graisse — elle apporte de la présence sans consommer plus d'espace.
- **Respecter les préférences de taille de texte de l'utilisateur** (Dynamic Type). Adaptez la mise en page *avec* le texte — espacements en `rem`/`em`, pas en px fixes — afin qu'une police plus grande ne brise pas la mise en page.
- **Utiliser par défaut la police système de la plateforme** avant d'adopter une police personnalisée ; elle intègre déjà le calibrage de taille optique, les tables de tracking et les ajustements de lisibilité. Ne la remplacez qu'avec une raison valable.

```css
:root { font: 100%/1.5 system-ui, sans-serif; } /* corps de texte : police système, interlignage confortable */

.display {
  font-size: clamp(2rem, 5vw, 4rem);
  line-height: 1.05;        /* interlignage resserré pour les grands textes */
  letter-spacing: -0.02em;  /* tracking négatif à mesure que la taille augmente */
  font-optical-sizing: auto;
}
```

## 16. Fondements du design — les huit principes

Le mouvement et le savoir-faire décrits ci-dessus servent les huit principes de design d'Apple (*Principles of Great Design*, WWDC 2026). Utilisez-les comme grille de réflexion :

1. **Finalité (Purpose).** Concevoir avec intention ; décider de ce qu'il ne faut *pas* construire. Chaque fonctionnalité réclame du temps, de l'attention et de la confiance à l'utilisateur — ne dépensez ce capital que là où le retour en vaut la peine.
2. **Autonomie (Agency).** Laisser le contrôle aux utilisateurs : proposer des choix, ne jamais imposer un chemin unique. Accompagnez cela d'un droit à l'erreur — un retour en arrière (undo) facile pour les maladresses, une boîte de confirmation uniquement pour les actions véritablement destructrices et irréversibles (à utiliser avec parcimonie ; l'excès habitue à cliquer sans lire).
3. **Responsabilité (Responsibility).** Agir dans l'intérêt de l'utilisateur. Confidentialité : demander au bon moment, uniquement ce qui est nécessaire, en toute transparence. Sécurité : anticiper les mauvais usages et les préjudices — en particulier avec l'IA (une application de recettes attentive aux allergies ne doit jamais suggérer un ingrédient nocif). Ajoutez des prévisualisations, des confirmations, des avertissements ; supprimez une fonctionnalité dont le risque l'emporte sur la valeur.
4. **Familiarité (Familiarity).** S'appuyer sur ce que les gens savent déjà. Utilisez des métaphores ni trop littérales ni trop abstraites (une corbeille signifie supprimer), et respectez leur physique. Soyez cohérent : les éléments d'apparence identique doivent se comporter de la même façon et se trouver au même endroit (fermer est toujours en haut à gauche sur macOS) afin que l'on puisse anticiper la suite. Ne rompez avec un modèle familier que si vous pouvez prouver qu'il est meilleur — puis testez-le, ne vous fiez pas à des suppositions.
5. **Flexibilité (Flexibility).** Concevoir pour différents contextes, appareils et l'ensemble des capacités humaines. Adaptez-vous à la plateforme (iPhone = toucher rapide ; ordinateur = flux de travail approfondis avec un contrôle précis du pointeur) et à la situation. Concevez de manière inclusive (âge, langue, niveau d'expertise, accessibilité). Lorsqu'aucune disposition unique ne convient à tout le monde, permettez la personnalisation — réorganiser les commandes, masquer ce qui n'est pas utilisé.
6. **Simplicité — pas minimalisme (Simplicity).** Éliminer le superflu pour faire briller l'essentiel ; tout enfouir au même endroit donne un aspect minimaliste mais n'est pas simple. Soyez concis (langage simple, pas de jargon, moins d'étapes) et clair (utilisez la hiérarchie — ordre, espacement, contraste — pour que le plus important soit le plus évident). Chaque élément doit mériter sa place ; parfois, *ajouter* du contexte simplifie (une barre de lecture vidéo indiquant le temps restant). Présentez d'abord le chemin habituel, les options avancées un niveau plus bas.
7. **Savoir-faire (Craft).** Un souci du détail sans compromis forge la confiance. Une belle typographie, des couleurs qui s'adaptent au mode clair/sombre, une iconographie limpide et des animations réactives offrant un retour immédiat et naturel. Rien n'est laissé au hasard — chaque espacement, synchronisation et alignement est un choix délibéré et justifiable. Un défilement saccadé, des icônes mal alignées et des mises en page qui se brisent lors de la rotation traduisent un manque de soin. Le savoir-faire exige itération et longévité — continuez à faire évoluer le design à mesure que les fonctionnalités et le matériel changent.
8. **Enchantement (Delight).** Le résultat de la réussite des sept autres principes, et non des confettis plaqués par-dessus. Déterminez l'émotion que vous souhaitez susciter (sérénité, confiance, enthousiasme) et renforcez-la dans chaque décision.

Règles tactiques au service de ces principes :

- **Les retours se déclinent en quatre types :** état, complétion, avertissement, erreur. Confirmez les actions importantes, affichez l'état d'avancement, prévenez avant les problèmes, validez en ligne (pas à la soumission).
- **Orientation (Wayfinding).** Chaque écran doit répondre à ces questions : Où suis-je ? Où puis-je aller ? Qu'y a-t-il là-bas ? Comment en sortir ? Ne piégez jamais l'utilisateur.
- **Regroupement et correspondance (Grouping & mapping).** La proximité implique une relation ; placez une commande près de ce qu'elle modifie et disposez les commandes de manière à refléter ce qu'elles changent. Si vous avez besoin d'une étiquette pour expliquer une commande, c'est que la correspondance est faible.
- **Des libellés directs et précis valent mieux que des termes génériques et prudents.** Nommez les éléments de navigation d'après leur contenu (« Progrès », « Bibliothèque »), et non avec des termes parapluies vagues (« Accueil »). La précision crée la prévisibilité.

## 17. Processus

- **Prototyper de manière interactive — un prototype interactif vaut « un million de designs statiques ».** C'est en construisant l'interface et en jouant avec qu'on la découvre ; un prototype fonctionnel établit aussi une exigence concrète qui évite une implémentation finale médiocre.
- **Concevoir l'interaction et le visuel ensemble.** « On ne devrait pas pouvoir distinguer où s'arrête l'un et où commence l'autre. » Le mouvement n'est pas une couche rajoutée après les pixels.
- **Tester avec de vraies personnes en contexte réel**, et examiner le mouvement d'un œil neuf — visionnez-le au ralenti / image par image pour repérer ce qui reste invisible à vitesse normale.

## Référence rapide

| Besoin | Technique | Valeur concrète |
| --- | --- | --- |
| Ressort d'UI par défaut | Amortissement critique, aucun rebond | `damping 1.0`, `response 0.3–0.4` |
| Ressort d'inertie / pichenette | Sous-amorti, léger rebond | `damping ~0.8`, `response 0.3–0.4` |
| Geste → vitesse du ressort | Transmettre la vitesse de relâchement | `gestureVelocity / (target − current)` si normalisée |
| Point d'atterrissage d'une pichenette | Projeter l'inertie | `current + (v/1000)·d/(1−d)`, `d ≈ 0.998` |
| Interrompre proprement | Partir de la valeur de présentation (en direct) | lire la transformation à l'écran |
| Éviter le « mur de briques » à l'inversion | Conserver la vitesse lors du changement de cible | ressort qui fusionne la vitesse |
| Transition réversible | Miroiter la courbe d'atténuation (easing) | cubic-bézier inverse |
| Décider inversion vs validation | Utiliser le **signe** de la vitesse, pas la position | au relâchement |
| Glissement 1:1 | Pointer Events + capture | respecter le décalage de saisie |
| Retour visuel | Dès le pointer-down, continu | jamais seulement à la fin |
| Limite | Effet élastique (rubber-band), pas d'arrêt brutal | résistance progressive |
| Habillage (chrome) translucide | Couche avec `backdrop-filter` | le contenu défile en dessous |
| Approche typographique (tracking) | Dépend de la taille, jamais fixe | resserrer pour les grands textes (`-0.02em`), corps proche de `0` |
| Réduction des mouvements | Fondu enchaîné, pas de glissement/ressort | `@media (prefers-reduced-motion)` |
