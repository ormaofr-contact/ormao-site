---
name: li-carousel
description: >-
  Créer une publication de document LinkedIn (carrousel) : le texte diapositive
  par diapositive, la couverture qui incite au swipe, et le PDF à publier. À
  utiliser lorsque l'utilisateur mentionne « carrousel », « document post »,
  « slides pour LinkedIn », « transforme ceci en carrousel », ou dispose d'une
  idée sous forme de liste qui n'aurait aucun impact sous forme de post texte.
---

# li-carousel

Les publications de type document sont le format générant le temps de consultation le plus élevé sur LinkedIn, car chaque swipe est comptabilisé, contrairement à un simple défilement. Ce format valorise une idée découpée en étapes. Il pénalise en revanche un post texte simplement découpé en morceaux.

## Quand l'utiliser à la place d'un post texte

Utilisez un carrousel lorsque l'idée présente une **séquence** : des étapes, un compte à rebours, une progression avant/après, un framework composé de plusieurs parties. Utilisez un post texte lorsque l'idée repose sur une seule affirmation. Découper une seule affirmation sur huit diapositives est l'erreur la plus fréquente qui fait échouer un carrousel ; si c'est ce que propose l'utilisateur, dites-le-lui et orientez-le vers `/li-post`.

## Structure

8 à 12 diapositives. En dessous de 8, c'est un post texte. Au-delà de 12, le taux de complétion s'effondre.

```
1        COVER      the hook, 6 words or fewer, plus one line of promise
2        THE STAKE  why this matters, in one sentence
3-N      ONE IDEA PER SLIDE. A headline of 3-7 words, and at most 25 words
                    under it. If a slide needs a paragraph, it is two slides.
N+1      RECAP      the whole thing as a list, so the screenshot is useful
LAST     CTA        one action. Follow, comment a keyword, or the link. One.
```

## Règles de rédaction des diapositives

- **La diapositive 1 représente 80 % du résultat.** Six mots. En grand. Le reste de la présentation ne pourra pas sauver une couverture que personne ne swipe.
- **Numérotez chaque diapositive** (3/10). La complétion augmente quand les lecteurs voient la fin approcher.
- **Aucune diapositive ne doit être un paragraphe.** Si vous ne pouvez pas le formuler en 25 mots, divisez-la.
- **La diapositive récapitulative est celle que les gens capturent en photo.** Rendez-la autonome.
- **L'identifiant de l'utilisateur sur chaque diapositive**, en petit, dans le coin inférieur. Les captures d'écran voyagent sans vous.

## Création du PDF

LinkedIn exige un PDF au format 1080x1350 (4:5) pour occuper un maximum d'espace dans le fil, de moins de 100 Mo et de moins de 300 pages. Concevez-le en HTML et imprimez-le en PDF :

```bash
# one page per slide, 1080x1350, no margins
# then: Chrome headless --print-to-pdf, or any HTML-to-PDF you already use
```

Rédigez le HTML avec une `<section>` par diapositive, `width:1080px; height:1350px; page-break-after:always`, une seule couleur d'accentuation et une typographie d'au moins 28px — les utilisateurs lisent ces contenus sur mobile à la taille d'une miniature. Si l'utilisateur dispose d'une compétence de marque ou d'un design system dans ce projet, utilisez-le et n'inventez pas de palette.

## Format de sortie

Le texte diapositive par diapositive d'abord, sous forme de liste numérotée que l'utilisateur peut lire en dix secondes. Ensuite, le **texte d'accompagnement du post** — un carrousel nécessite toujours 2 à 3 lignes au-dessus, qui constituent la véritable accroche dans le fil d'actualité. Passez les deux au crible de `/li-human`. Ne générez le PDF que si l'utilisateur valide le texte.

Rien n'est téléversé sur LinkedIn. L'utilisateur publie lui-même le PDF.
