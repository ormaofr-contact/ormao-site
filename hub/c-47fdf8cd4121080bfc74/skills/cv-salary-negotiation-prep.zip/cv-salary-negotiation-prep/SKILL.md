---
name: salary-negotiation-prep
description: Rechercher les rémunérations du marché, élaborer une stratégie de négociation et créer des scripts de contre-offre
---

# Préparation à la négociation salariale

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Négocier une offre d'emploi ou un salaire
- Rechercher les rémunérations du marché pour son poste
- Élaborer une stratégie de contre-offre
- Comprendre les packages de rémunération globale
- Mentionne : "salary negotiation", "negotiate offer", "counter offer", "compensation", "how much should I ask for"

## Capacités principales

- Rechercher et valider la rémunération du marché
- Élaborer une stratégie et des scripts de négociation
- Calculer la rémunération globale (pas seulement le salaire de base)
- Préparer les réponses de contre-offre
- Identifier les points d'appui pour la négociation
- Mener des conversations salariales difficiles

## L'état d'esprit de la négociation

**Principes clés :**
1. La négociation est attendue — les entreprises l'intègrent dans leur budget
2. 84 % des employeurs s'attendent à ce que les candidats négocient
3. Ne pas négocier revient à laisser entre 500 k$ et 1 M$ sur la table au cours d'une carrière
4. L'objectif est une situation gagnant-gagnant, pas conflictuelle

**Ce que vous négociez réellement :**
- Salaire de base
- Prime à la signature
- Prime annuelle / commission
- Actions (stock-options, RSUs)
- Avantages sociaux (abondement 401k, assurance)
- Avantages en nature (congés, télétravail, développement professionnel)
- Date de prise de fonction
- Intitulé du poste

## Phase de recherche

### Étape 1 : Déterminer le prix du marché

**Sources à consulter :**
- Levels.fyi (le meilleur pour la tech)
- Glassdoor (généraliste, à prendre avec des pincettes)
- LinkedIn Salary
- Blind (témoignages anonymes)
- PayScale
- Salary.com
- Données salariales H1B (publiquement disponibles)

**Construire une fourchette :**
```
Low (25th percentile): $XXX,XXX
Target (50th percentile): $XXX,XXX  
High (75th percentile): $XXX,XXX
Stretch (90th percentile): $XXX,XXX
```

### Étape 2 : Connaître sa valeur

**Facteurs qui augmentent votre valeur :**
- Années d'expérience pertinente
- Compétences spécialisées / rares
- Historique de résultats probants
- Certifications recherchées
- Offres concurrentes actuelles
- Recommandation par un employé
- Forte demande du marché dans votre domaine

**Facteurs qui peuvent limiter :**
- Début de carrière ou reconversion professionnelle
- Moins d'expérience que le candidat idéal
- Lacunes dans les compétences requises
- Arbitrage géographique (coût de la vie plus bas)

### Étape 3 : Calculer la rémunération globale

**Rémunération totale = Base + Primes + Actions + Avantages**

```
EXAMPLE:
Base Salary: $150,000
Target Bonus (15%): $22,500
RSU Grant (4-year): $200,000 ($50,000/year)
401k Match (4%): $6,000
Benefits Value: ~$15,000

Total Annual Comp: $243,500
```

**Termes courants relatifs à l'actionnariat :**
- **RSUs :** Restricted Stock Units (actions réelles, imposées lors de l'acquisition)
- **Options :** Droit d'acheter à un prix d'exercice (valeur = cours actuel - prix d'exercice)
- **Vesting :** Généralement sur 4 ans avec un palier (cliff) d'un an
- **Refresh grants :** Attributions annuelles d'actions supplémentaires

## Stratégie de négociation

### Quand négocier

**Meilleur moment :** Après avoir reçu une offre écrite, avant de signer

**Chronologie :**
1. Réception de l'offre verbale → Exprimer son enthousiasme, demander une offre écrite
2. Réception de l'offre écrite → Remercier, demander un délai de réflexion
3. Recherche et préparation → 24 à 48 heures
4. Contre-offre avec demande précise → E-mail ou appel
5. Discussion / allers-retours → Peut nécessiter plusieurs échanges
6. Accord final → Obtenir une confirmation écrite

### Le cadre de la contre-offre

**Structure :**
1. Exprimer son enthousiasme
2. Réaffirmer sa valeur
3. Formuler une demande précise
4. Fournir une justification
5. Ouvrir la discussion

### Modèle d'e-mail de contre-offre

```
Subject: [Your Name] - Offer Discussion

Hi [Recruiter/Hiring Manager],

Thank you so much for the offer to join [Company] as [Title]. I'm very excited about the opportunity to [specific thing about the role]. After speaking with the team and learning more about [something specific], I'm confident this is the right fit.

I've had time to review the offer details and wanted to discuss the compensation. Based on my research of the market and my [X years of experience / specific valuable skill / competing offer], I was hoping we could discuss a base salary of $[Your Ask] rather than $[Their Offer].

[Optional: Add specific justification - e.g., "I've seen similar roles at [comparable companies] in this range" or "Given the scope of the role and my track record of [specific achievement], I believe this reflects my value."]

I'm flexible and open to discussing other elements of the package as well. Would you have time for a quick call to discuss?

Thank you again for this opportunity. I'm looking forward to finding a package that works for both of us.

Best,
[Your Name]
```

### Script d'appel pour la contre-offre

```
"Hi [Name], thanks for making time. I'm really excited about this opportunity - [genuine specific reason].

I've reviewed the offer and want to discuss compensation. Based on my market research and [X years experience / key accomplishment / competing offer], I was hoping for a base salary closer to $[Amount].

Is there flexibility there?"

[LISTEN - Let them respond]

[If they push back:]
"I understand there are constraints. I'm flexible - could we look at other elements like signing bonus, equity, or [other element] to bridge the gap?"

[If they say they'll need to check:]
"That's totally fair. When would be a good time to reconnect?"
```

## Scénarios courants de négociation

### Scénario 1 : La première offre est basse

**Approche :**
- Ne pas accepter immédiatement
- Exprimer son enthousiasme pour le poste
- Faire une contre-proposition étayée par des données de marché
- Être prêt à la justifier

**Script :**
```
"I'm thrilled about the opportunity. The base salary is lower than I expected based on my research. For this role and market, I was expecting something in the $X-$Y range. Is there room to move closer to $X?"
```

### Scénario 2 : Ils demandent vos prétentions salariales en premier

**Stratégie de temporisation :**
```
"I'm flexible and focused on finding the right fit. What's the range you've budgeted for this role?"
```

**Si l'on insiste :**
```
"Based on my research for this role and market, I'm looking at $X-$Y, but I'm open to discussing the full compensation picture."
```

### Scénario 3 : Ils ne veulent pas bouger sur le salaire de base

**Alternatives à négocier :**
- Prime à la signature (ponctuelle, plus facile à faire approuver)
- Actions supplémentaires
- Évaluation des performances plus rapide (augmentation plus précoce)
- Jours de congés supplémentaires
- Flexibilité pour le télétravail
- Budget de formation continue
- Revalorisation de l'intitulé de poste
- Aide au déménagement
- Date de prise de fonction

**Script :**
```
"I understand the base salary is firm. Could we discuss a signing bonus to help bridge the gap? Something in the range of $X would make this work."
```

### Scénario 4 : Vous avez des offres concurrentes

**À utiliser avec précaution :**
- Ne le mentionnez que si c'est vrai
- Ne le présentez pas comme une menace
- Formulez-le sous l'angle de la résolution de problème

**Script :**
```
"I want to be transparent - I'm also in discussions with [another company/a few other companies]. They're offering $X. [Your Company] is my first choice because [genuine reason], but I want to make sure the compensation is competitive."
```

### Scénario 5 : Ils vous interrogent sur votre salaire actuel

**Dans de nombreux États, cette question est illégale**

**Si la question est posée (et légale) :**
```
"I'd prefer to focus on the value I'd bring to this role and what the market rate is. What's the range you've budgeted?"
```

**Ou réorienter la discussion :**
```
"My current compensation isn't really comparable since [different location/role/structure]. Based on my research for this role, I'm targeting $X-$Y."
```

## Tactiques de négociation

### À faire :
- ✅ Toujours négocier (avec respect)
- ✅ Obtenir l'offre par écrit avant de négocier
- ✅ Faire des recherches approfondies
- ✅ Être précis avec les chiffres
- ✅ Exprimer un enthousiasme sincère
- ✅ Leur donner un moyen de dire oui
- ✅ Prendre en compte la rémunération globale
- ✅ Être patient — le processus prend du temps
- ✅ Obtenir l'accord final par écrit

### À ne pas faire :
- ❌ Accepter sur-le-champ
- ❌ Communiquer son historique salarial (si non exigé par la loi)
- ❌ Poser des ultimatums
- ❌ Mentir au sujet d'offres concurrentes
- ❌ Être impoli ou agressif
- ❌ Négocier uniquement pour le plaisir de négocier
- ❌ Accepter des promesses verbales sans confirmation écrite
- ❌ Couper les ponts si les négociations n'aboutissent pas

## Comparaison de la rémunération globale

### Analyse comparative

```markdown
## OFFER COMPARISON

| Component | Company A | Company B | Notes |
|-----------|-----------|-----------|-------|
| Base Salary | $150,000 | $140,000 | A wins |
| Target Bonus | 15% ($22,500) | 20% ($28,000) | B wins |
| Signing Bonus | $20,000 | $10,000 | A wins |
| Equity (annual) | $50,000 | $75,000 | B wins |
| 401k Match | 4% ($6,000) | 6% ($8,400) | B wins |
| Benefits | Standard | Premium | B wins |
| WFH | Hybrid (3 days) | Full remote | B wins |
| Vacation | 3 weeks | Unlimited | Depends |

**Year 1 Total Comp:**
Company A: $248,500
Company B: $261,400

**Analysis:** Company B is higher total comp, but Company A has higher base which affects future raises and mortgage qualification.
```

## Modèle de calendrier de négociation

```
Day 1: Receive offer
- Thank them, express enthusiasm
- Ask for offer in writing
- Ask deadline for response

Day 1-3: Research
- Verify market rate
- Calculate total comp
- Identify priorities
- Prepare counter-offer

Day 3-5: Counter
- Send counter-offer email or schedule call
- Be specific about ask

Day 5-10: Discussion
- May require several rounds
- Be patient but responsive
- Stay professional and positive

Day 10+: Resolution
- Agree on terms
- Get everything in writing
- Sign and celebrate!
```

## Format de sortie

Lors de la préparation de la négociation salariale :

```markdown
# SALARY NEGOTIATION STRATEGY

## Market Research Summary
**Role:** [Title]
**Location:** [City/Remote]
**Experience Level:** [Years]

**Market Range:**
- 25th percentile: $XXX,XXX
- 50th percentile: $XXX,XXX (target)
- 75th percentile: $XXX,XXX
- 90th percentile: $XXX,XXX (stretch)

**Sources:** [List sources used]

## Their Offer
| Component | Amount |
|-----------|--------|
| Base | $XXX,XXX |
| Bonus | X% |
| Equity | $XXX,XXX |
| Signing | $XXX |
| Total Year 1 | $XXX,XXX |

## Your Counter
| Component | Ask | Justification |
|-----------|-----|---------------|
| Base | $XXX,XXX | [Why] |
| Signing | $XXX | [Why] |
| [Other] | | |

## Counter-Offer Script
[Email template or call script customized for this situation]

## If They Push Back
**Plan B:** [Alternative elements to negotiate]
**Walk-away Point:** [Your minimum]

## Key Talking Points
1. [Your experience/value point]
2. [Market data point]
3. [Specific achievement]

## Questions to Clarify
- [Equity vesting schedule?]
- [Bonus guaranteed?]
- [Review cycle timeline?]
```

## Liste de contrôle pour la mise en œuvre

1. ✅ Rechercher la rémunération du marché auprès d'au moins 3 sources
2. ✅ Calculer la rémunération globale (pas seulement le salaire de base)
3. ✅ Identifier vos priorités
4. ✅ Déterminer votre seuil de rupture
5. ✅ Préparer une contre-offre avec justification
6. ✅ Rédiger ou s'entraîner sur le script de négociation
7. ✅ Prévoir des solutions de repli en cas de réticence
8. ✅ Obtenir l'accord par écrit
9. ✅ Examiner attentivement la lettre d'offre finale
10. ✅ Signer et célébrer !
