---
name: li-repurpose
description: >-
  Transformer un contenu long (vidéo YouTube, podcast, newsletter, article de blog,
  transcription ou appel client) en une semaine de posts LinkedIn. À utiliser lorsque
  l'utilisateur dit « recycle ceci », « transforme ceci en posts », « j'ai une vidéo / newsletter /
  transcription » ou colle un contenu long et souhaite le publier sur LinkedIn.
---

# li-repurpose

Un bon contenu long contient quatre à six posts. La plupart des gens n'en extraient qu'un seul et jettent le reste.

## Entrée

Une transcription, un article, une newsletter, un script, un compte-rendu d'appel. Si l'utilisateur fournit une URL YouTube et qu'un outil de transcription est disponible dans la session, utilisez-le ; sinon, demandez-lui de coller le texte. Lisez l'intégralité du contenu avant d'en extraire quoi que ce soit.

## Extraire, ne pas résumer

Le résumé d'une vidéo n'est pas un post. Personne ne veut d'un résumé. Parcourez le contenu et extrayez les éléments qui fonctionnent de manière autonome :

| élément | ce que c'est |
| --- | --- |
| **Affirmations** | chaque phrase susceptible de lancer un débat |
| **Chiffres** | chaque montant, coût, durée, pourcentage |
| **Histoires** | chaque moment mettant en scène une personne, un contexte et un coût |
| **Mécanismes** | chaque explication du type « voici comment cela fonctionne... » |
| **Erreurs** | chaque aveu d'un échec ou d'un problème |
| **Citations** | chaque phrase déjà percutante et citable telle quelle |

Listez ce que vous avez trouvé, avec le décompte, avant de rédiger quoi que ce soit. Si le contenu produit moins de quatre éléments, il est creux, et les quatre posts qu'on tenterait d'en tirer le seront aussi. Dites-le clairement.

## Construire ensuite la semaine

Chaque extrait devient un post, et chaque post doit tenir debout tout seul : le lecteur n'a pas vu la vidéo et ne la verra jamais. N'écrivez jamais « comme je le disais dans ma dernière vidéo ». Le post se suffit à lui-même.

Attribuez à chacun une formule d'accroche issue de `li-post/hooks.json`, et variez-les : cinq posts issus d'une même source avec la même structure d'accroche donnent l'impression d'une usine à contenu.

Ordonnez-les au fil de la semaine de sorte que l'affirmation la plus forte vienne en premier, l'histoire en milieu de semaine, et le post axé sur le mécanisme en dernier, au moment où les personnes ayant aimé les précédents sont à l'affût.

## Sortie

```
SOURCE: "Why we killed discovery calls" (18 min, 3,400 words)

FOUND  4 claims, 6 numbers, 2 stories, 3 mechanisms, 1 mistake, 5 quotable lines

WEEK
TUE  #1  Contrarian    Discovery calls are a tax you pay for a bad website
WED  #17 Time Anchor   We got 6 hours a week back by deleting one calendar link
THU  #9  Cold Open     "Can we just hop on a quick call?"
FRI  #21 Direct Value  The 4-question form that replaced the call. Steal it.

Say "write Tuesday" and I will draft it.
```

Rédigez ensuite à la demande, un post à la fois, chacun en passant par `/li-post` et `/li-human`. Ne livrez pas quatre posts finalisés d'un coup : ils sonneraient tous de la même façon, et l'utilisateur n'en modifiera aucun.
