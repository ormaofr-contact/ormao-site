---
name: attribution
description: >-
  À utiliser lorsque l'utilisateur souhaite déterminer quelles actions marketing génèrent
  réellement des conversions et du chiffre d'affaires, choisir ou interpréter un modèle
  d'attribution, ou réconcilier des chiffres contradictoires entre différents outils. À
  utiliser également lorsque l'utilisateur mentionne "attribution", "modèle d'attribution",
  "premier point de contact vs dernier point de contact", "multi-touch", "quel canal génère
  du CA", "quel est mon vrai CAC", "mes tableaux de bord se contredisent", "Google/Meta dit
  X mais GA dit Y", "media mix model", "MMM", "incrémentalité", "geo lift", "test
  d'exclusion / holdout", "comment nous avez-vous connus", "attribution autodéclarée", "dark
  social", ou souhaite instrumenter l'attribution lui-même — "rattacher mes réservations à
  leur source", "attribution SavvyCal/Calendly", "combler le fossé de l'identify", "suivre
  les conversions sur un domaine tiers", "attribution first-party / auto-hébergée".
metadata:
  version: 1.1.6
---

# Attribution

Vous aidez les utilisateurs à répondre à la question la plus difficile du marketing : **lesquelles de mes actions ont réellement généré cette conversion et ce chiffre d'affaires ?** L'attribution est le domaine où les marketeurs perdent le plus d'argent — sur des canaux qui paraissent performants dans un tableau de bord et désastreux dans un autre, sur le "direct" et la "recherche de marque" qui masquent la véritable source, et sur des modèles qui codent silencieusement une opinion comme s'il s'agissait d'un fait.

Cette compétence repose sur deux piliers. Identifiez celui dont l'utilisateur a besoin avant de vous lancer :

- **(A) Interprétation** — choisir un modèle d'attribution, sélectionner une approche de mesure et *réconcilier les chiffres contradictoires* rapportés par vos outils. Cela s'applique à tout le monde, même sans compétences techniques.
- **(B) Maîtriser son attribution (first-party)** — instrumenter et réconcilier l'attribution *vous-même* lorsque vous contrôlez le site ou l'application. Il s'agit du volet technique/développement. Utilisez-le lorsque l'utilisateur dit "je veux suivre cela moi-même" ou qu'il fait face à une conversion hébergée sur un domaine qui ne lui appartient pas.

La plupart des demandes commencent par le volet (A). Ne passez au volet (B) que s'ils contrôlent la surface concernée et souhaitent développer la solution.

Contexte produit : vérifiez la présence de `.agents/product-marketing.md` et lisez-le s'il existe — le type d'activité, le cycle de vente et la conversion principale guident la quasi-totalité des recommandations ici.

## Périmètre — ce que cette compétence ne gère PAS

Définissez ces limites d'emblée pour ne pas refaire le travail des compétences voisines :

- **Suivi général des événements, plans de taggage, configuration des UTM, GA4/GTM** → **analytics**. L'attribution *présuppose que le suivi existe déjà*. La frontière : analytics = "quels événements et comment les déclencher" ; attribution = "comment les points de contact s'associent aux conversions et se répercutent sur le chiffre d'affaires".
- **Pixels des plateformes publicitaires, CAPI, suivi des conversions côté serveur** → **conversion-tracking**. L'attribution exploite les chiffres rapportés par les plateformes et corrige leurs biais ; elle ne configure pas les pixels.
- **Étapes du pipeline, cycle de vie des leads, tableaux de bord de CA dans le CRM** → **revops**. L'attribution alimente les données du pipeline ; elle ne définit pas les étapes.
- **Visibilité dans / mesure de la recherche IA** → **ai-seo**. L'attribution se contente de qualifier le trafic IA d'angle mort.

---

## Pilier A — Interprétation

### 1. Ce que l'attribution peut et ne peut pas vous dire

Cadrez les attentes avant d'analyser le moindre chiffre :

- **L'attribution est directionnelle, pas une vérité absolue.** C'est un modèle de causalité construit à partir de données incomplètes (les cookies expirent, les sessions se fragmentent, les points de contact hors ligne disparaissent, les internautes se renseignent sur un appareil et achètent sur un autre). Considérez-la comme une indication forte, jamais comme un verdict irrévocable.
- **Chaque modèle est une opinion.** Le modèle "premier point de contact" (first-touch) attribue tout le mérite à la première publicité ; le "dernier point de contact" (last-touch) l'attribue au clic final. Les deux sont faux dans des directions opposées. Choisir un modèle, c'est choisir l'histoire que l'on veut croire — dites-le explicitement.
- **L'écart d'attribution est normal : séparez les résultats réels du crédit attribué.** La somme des conversions rapportées par chaque canal dépasse presque toujours les conversions réelles, car chaque plateforme revendique la même vente selon sa propre fenêtre d'attribution et ses règles d'affichage (view-through). Comptez les conversions réelles une seule fois, dédupliquées par rapport à une source unique de vérité, et expliquez le crédit de chaque plateforme séparément. Les deux ne concorderont pas, et une répartition modélisée ne remplacera jamais le grand livre des conversions.

Lorsqu'un utilisateur exige un chiffre unique et exact, reformulez : "Nous pouvons vous fournir un chiffre *défendable, cohérent* et une visibilité sur les canaux en progression. Une vérité objective unique n'existe pas — voici pourquoi, et voici ce sur quoi nous nous basons malgré tout pour prendre des décisions."

### 2. Les modèles d'attribution

L'ensemble classique basé sur des règles, complété par l'attribution basée sur les données (data-driven) — et les biais de chacun. Le modèle **dernier clic non direct** (last non-direct) est une variante du dernier contact (pour éviter le fourre-tout du direct), pas une école de pensée distincte.

| Modèle | Règle d'attribution | Idéal pour | Son biais / angle mort |
|---|---|---|---|
| **Premier point de contact (First-touch)** | 100 % au premier contact connu | Valorisation du haut de tunnel / demand-gen ; cycles courts | Ignore tout ce qui a conclu la vente ; surévalue les canaux de notoriété |
| **Dernier point de contact (Last-touch)** | 100 % au dernier contact avant conversion | Réponse directe, e-commerce rapide | Surévalue le bas de tunnel + la recherche de marque/le direct ; ignore ce qui a créé la demande |
| **Dernier clic non direct (Last non-direct)** | 100 % au dernier contact en ignorant le "direct" | Solution simple contre la pollution du trafic direct | Reste un modèle à point de contact unique ; déplace simplement l'angle mort |
| **Linéaire** | Crédit égal à chaque contact | Parcours longs et multi-touch où chaque étape compte | Traite une visite anodine au même niveau qu'une démo ; flatte les canaux à haute fréquence |
| **Dépréciation dans le temps (Time-decay)** | Davantage de crédit aux contacts proches de la conversion | Cycles plus longs où la récence compte | Sous-évalue le haut de tunnel ; reste une hypothèse arbitraire, pas une mesure |
| **Basé sur la position (En U)** | 40 % premier, 40 % dernier, 20 % au milieu | B2B avec des moments clairs de "création" et de "conclusion" | La répartition 40/40/20 est arbitraire ; les contacts intermédiaires sont lésés |
| **Basé sur les données (Algorithmique / Shapley)** | Crédit calculé selon la contribution marginale modélisée | Comptes à fort volume disposant de suffisamment de conversions | Une boîte noire ; nécessite du volume ; aveugle aux contacts hors ligne/invisibles non injectés |

**Note sur la disponibilité dans les plateformes :** Google Ads et GA4 ont supprimé le premier clic, le linéaire, la dépréciation dans le temps et le modèle basé sur la position de leurs rapports sélectionnables (en 2023). Ces interfaces proposent **l'attribution basée sur les données** et le **dernier clic** (ainsi que la variante dernier clic sur les canaux payants de GA4). Enseignez l'ensemble du tableau en tant que *concepts* et modèles calculables sur votre propre historique d'événements / CRM / data warehouse — pas comme des options déroulantes de Google.

**Règles empiriques :**
- Ne présentez jamais un modèle unique de manière isolée pour un cycle de vente long. Affichez **le premier et le dernier contact côte à côte** — la vérité se trouve entre les deux, et l'écart entre eux *constitue* l'information clé.
- L'attribution basée sur les données (DDA) nécessite du volume. Google Ads restreignait historiquement la DDA à ~3 000 interactions publicitaires et ~300 conversions sur 30 jours ; les seuils stricts ont disparu et la DDA est devenue le choix par défaut, mais Google recommande toujours environ **200 conversions et ~2 000 interactions publicitaires** sur 30 jours pour garantir la qualité. En deçà, la DDA se replie souvent vers des hypothèses proches du dernier clic — du bruit statistique déguisé en science. Sur Google/GA4 avec peu de données : privilégiez le dernier clic (ou acceptez que DDA ≈ dernier clic). Ailleurs (first-party / CRM / data warehouse) : calculez un modèle basé sur la position ou comparez premier et dernier contact côte à côte.
- Le choix du modèle importe bien moins que la **cohérence** dans le temps et le croisement avec une vérification externe indépendante du modèle (Pilier A §4, déclaratif).

Pour les calculs mathématiques, des exemples détaillés d'un parcours évalué selon six modèles basés sur des règles et une explication claire de Shapley, consultez `references/attribution-models.md`.

### 3. Les trois paradigmes de mesure

Les modèles répartissent le crédit *au sein* de vos données suivies. Les paradigmes représentent la méthode pour déterminer la *causalité* — de plus en plus rigoureux, de plus en plus coûteux :

| Paradigme | En quoi cela consiste | Questions résolues | Prérequis | Points de vigilance |
|---|---|---|---|---|
| **MTA** (Attribution multi-touch) | Associer les points de contact au niveau utilisateur, appliquer un modèle | "Quels points de contact apparaissent dans les parcours convertis ?" | Suivi propre et multi-appareils au niveau utilisateur | La disparition des cookies et la confidentialité dégradent les données utilisateurs ; les parcours de clics surévaluent structurellement la recherche/le direct et sous-évaluent les canaux à base d'impressions |
| **MMM** (Modélisation du mix marketing/médias) | Régression descendante (top-down) des dépenses par rapport aux résultats dans le temps | "Quelle est la contribution globale de chaque canal, y compris hors ligne et notoriété ?" | 2 à 3 ans de données hebdomadaires, variations de dépenses | Corrélationnel ; lent à réagir ; nécessite de vraies variations de budget pour apprendre |
| **Incrémentalité** (holdout géographique, PSA, ghost ads, tests on/off) | Expérience contrôlée : groupe exposé vs groupe témoin | "Ce canal a-t-il *provoqué* un gain (lift) que je n'aurais pas obtenu autrement ?" | Capacité à priver une partie de l'audience ; volume suffisant pour la significativité | La référence absolue, mais on ne peut tester que peu d'éléments à la fois |

**Comment choisir :** petit budget / cycle court → de bons UTM + dernier clic non direct + une enquête autodéclarée surpassent un modèle sophistiqué. Budget moyen, plusieurs canaux → MTA au quotidien + tests d'incrémentalité périodiques sur vos plus gros postes de dépenses. Gros budget, dépenses hors ligne + notoriété de marque → MMM pour le portefeuille global + incrémentalité pour valider les coefficients du MMM. L'incrémentalité sert d'arbitre dès que deux canaux revendiquent les mêmes conversions.

Un tableau de décision par budget × cycle de vente × nombre de canaux, ainsi que la méthode pour *interpréter* un test de holdout géographique ou PSA (sans jargon statistique excessif), se trouvent dans `references/measurement-paradigms.md`.

### 4. L'attribution autodéclarée

Le signal le plus sous-exploité, et souvent le plus honnête pour les cycles longs et le dark social. Une question post-conversion "Comment nous avez-vous connus ?" capte ce que le tracking ne peut structurellement pas voir : podcasts, bouche-à-oreille, communautés Slack, tweet d'un fondateur, recommandation d'un ami.

- **Quand elle surpasse le tracking :** cycles de réflexion longs, fort bouche-à-oreille, croissance par la marque ou la communauté, ou fort trafic sur le dark social (voir §5). Si une part majeure de vos parcours aboutit en "direct", vous avez un vide que seule l'attribution autodéclarée peut combler.
- **Posez la question au moment précis de la conversion** (inscription, premier achat, demande de démo) — moment de mémorisation maximale, avant que le souvenir ne s'estompe.
- **Formulation :** un champ ouvert ("Comment avez-vous entendu parler de nous pour la première fois ?") capte le dark social ; une liste fermée est plus facile à quantifier mais biaise d'emblée la réponse. La bonne pratique : une liste fermée de vos canaux connus **complétée par un champ texte libre "Autre / Précisez"**.
- **Considérez-la comme un élément de triangulation, pas comme une vérité absolue** — la mémoire est imparfaite et les individus mentionnent le contact le plus *mémorable*, pas nécessairement le premier. **Pondérez à la baisse la part issue du sondage lors de la conversion en crédit** (par exemple, 22 % de mentions pour YouTube prouve la notoriété, mais ne signifie pas que YouTube mérite 22 % des conversions). Croisez avec l'incrémentalité ou les écarts des plateformes avant d'établir une règle de répartition.
- Côté technique, cela correspond à un champ de formulaire envoyé à votre CRM ou outil d'analyse en tant que propriété utilisateur — voir le Pilier B et `references/first-party-tracking.md`.

### 5. Réconcilier les sources contradictoires

La demande sous-jacente à la majorité des projets d'attribution : **"Google en annonce 50, Meta 40, GA 60, mon CRM 35 — qui a raison ?"** Personne. Voici la méthode.

**Pourquoi chaque source ment systématiquement :**

| Source | Biaisée en faveur de | Parce que |
|---|---|---|
| **Plateformes publicitaires** (Google/Meta/LinkedIn) | Se surévalue *elle-même* | Revendique les conversions post-affichage (view-through) + post-clic dans sa propre fenêtre ; chaque plateforme compte la même vente ; intérêt direct à afficher de bons résultats |
| **GA / analytics web** | Dernier clic non direct | Perd le suivi multi-appareils, perd les utilisateurs bloquant les cookies, classe les inconnus dans le direct |
| **CRM** | Ce que le commercial a saisi / ce que le formulaire a capté | Saisie humaine, écrasement de la source du lead, affaires hors ligne sans trace numérique |
| **Enquête autodéclarée** | Le contact le plus *mémorable* | Biais de mémorisation ; sous-évalue les contacts réels mais banals comme le reciblage (retargeting) |

**Comment trianguler :**
1. **Choisissez une source de vérité unique pour le volume de conversions** — généralement votre CRM ou votre base backend (le système où l'argent est réel). Tout le reste sert à expliquer *d'où elles proviennent*, pas à redéfinir *combien il y en a*.
2. **N'additionnez jamais les chiffres d'une plateforme à l'autre.** Si Google et Meta revendiquent tous deux une conversion, vous avez une seule conversion avec deux prétendants, pas deux conversions. Dédupliquez par rapport au total de votre source de vérité.
3. **Recherchez la concordance des tendances, pas une égalité parfaite.** Si toutes les sources indiquent que la recherche payante progresse et que l'organique baisse ce trimestre, cette tendance est fiable même si aucun chiffre ne coïncide au centime près.
4. **Utilisez l'autodéclaration comme arbitre** lorsque les plateformes se disputent les mêmes conversions, et **l'incrémentalité** lorsque les enjeux financiers justifient un test. Ne **transformez pas** un écart plateforme vs GA en règle de coefficient multiplicateur (Meta annonce 2× GA ≠ "multiplier Meta par deux") — examinez les fenêtres et le post-affichage, puis fondez tout ajustement sur l'incrémentalité.
5. **Anticipez et budgétez l'écart.** Présentez vos résultats ainsi : "Les plateformes revendiquent N ; nous en vérifions M ; l'écart correspond aux doubles revendications + affichage (view-through) + non suivi — voici notre meilleure estimation de répartition."
6. **Opérationnalisez la triangulation sous forme de règles dès que possible** — dès que vous disposez d'un groupe témoin (holdout) ou d'une fourchette fiable issue des enquêtes pour un canal, appliquez un **ajustement documenté au niveau du canal** dans vos rapports (déplacez le crédit du Direct/marque vers le canal sous-évalué pendant la période du test) plutôt que de traiter les données MTA brutes comme une vérité absolue. Détails dans `references/measurement-paradigms.md`.

Le résultat final est une attribution honnête assortie de niveaux de confiance, et non une réconciliation artificielle à la décimale près.

### 6. Les angles morts

Les zones où les conversions se cachent, pénalisant injustement des canaux pourtant performants :

- **Direct** — le grand fourre-tout. Favoris et URL tapées à la main, certes, mais aussi suppressions de referrers, passages d'application à navigateur web, dark social et tout point de contact perdu par votre tracking. Une part importante de direct peut englober de véritables visites directes, des utilisateurs récurrents et des pertes de mesure. Analysez sa composition avant d'en conclure à un simple bug de suivi.
- **Recherche de marque** — les personnes qui vous ont découvert ailleurs et ont cherché votre nom sur Google. Le dernier contact attribue le mérite au search de marque payant ou organique ; le véritable moteur est l'élément déclencheur qui les a poussés à chercher. Segmentez la marque du hors-marque, sinon vous couperez les budgets du haut de tunnel.
- **Dark social** — les partages sans referrer : messages privés, Slack/Discord, podcasts, newsletters, captures d'écran. Structurellement invisible pour le tracking ; l'attribution autodéclarée est le seul moyen de le révéler (§4).
- **Trafic IA** — les assistants et moteurs de recherche IA influencent de plus en plus les acheteurs, puis les redirigent via la recherche de marque ou le direct : le point de contact IA reste donc invisible dans les outils d'analyse. Signalez-le et renvoyez les analyses plus poussées vers **ai-seo**.

Lorsque le direct et la recherche de marque dominent, l'explication la plus fréquente est un haut de tunnel performant dont le rôle est occulté par l'attribution. Vérifiez avant de conclure : écartez les clients existants, les referrers perdus et la découverte hors ligne, puis vérifiez l'attribution autodéclarée ou lancez un test d'incrémentalité. C'est l'erreur d'interprétation la plus fréquente en marketing, dans un sens comme dans l'autre : précisez bien ce que démontrent les données réelles.

### 7. Choix selon le type d'activité

Les approches par défaut divergent fortement. Résumé ci-dessous ; playbooks complets dans `references/by-business-type.md`.

- **SaaS B2B (cycle long, ventes accompagnées) :** les parcours s'étalent sur des semaines ou des mois et impliquent plusieurs intervenants ; les modèles à point de contact unique sont donc très trompeurs. Basez-vous sur le **CRM comme source de vérité**, affichez **premier contact + modèle basé sur la position** côte à côte, misez massivement sur le **déclaratif lors de la démo/inscription**, et traitez l'attribution du **pipeline/chiffre d'affaires** (→ revops) comme le véritable baromètre. Les interactions hors ligne (événements, rendez-vous commerciaux) rendent le MTA peu fiable et l'autodéclaration bien plus solide ici.
- **E-commerce / D2C (cycle court, libre-service) :** parcours rapides, volume élevé, dépenses concentrées sur le social ads + search. Prenez pour point de repère le **ROAS des plateformes tout en vous en méfiant** (surestimation due à iOS/CAPI), validez avec un **MMM dès que les dépenses deviennent conséquentes** et des **tests d'incrémentalité/holdouts géographiques** sur vos canaux majeurs, et utilisez une **enquête post-achat** pour capter ce qui échappe aux pixels. Le dernier contact est acceptable pour des produits à achat impulsif ; le duo MMM + incrémentalité est la méthode requise pour allouer les budgets réels.

---

## Pilier B — Maîtriser son attribution (first-party)

À utiliser lorsque l'utilisateur **contrôle le site ou l'application** et souhaite instrumenter l'attribution lui-même — particulièrement pour une conversion qui a lieu sur un **domaine externe** (une prise de rendez-vous SavvyCal/Calendly/Cal.com, une page Stripe Checkout). Ce pilier est issu de déploiements réels en production ; le guide complet avec les snippets de code est disponible dans `references/first-party-tracking.md`. L'essentiel :

### Le graphe d'identité

L'attribution first-party repose sur un principe unique : **relier la navigation anonyme à la conversion finale.**

1. Un visiteur arrive de manière anonyme ; votre outil d'analyse lui attribue un **`distinct_id` anonyme** et associe les **propriétés de premier contact** (`$initial_referrer`, `$initial_utm_*`) à ses événements.
2. Au moment de la conversion (inscription, réservation, achat), vous appelez la fonction **`identify()`** avec un identifiant pérenne (adresse e-mail ou UUID utilisateur). Cela **fusionne** l'historique anonyme avec le profil identifié — le premier point de contact est désormais conservé jusqu'à la conversion.
3. Chaque événement de conversion peut désormais être segmenté par canal de premier contact. C'est tout l'enjeu.

### Combler le fossé de l'`identify()`

L'erreur la plus répandue en tracking first-party : **aucun appel à `identify()` n'est jamais déclenché**, de sorte que les conversions ne sont jamais rattachées à l'historique de navigation et que chaque client semble sortir de nulle part. (Formulation inspirée de l'approche de Tessa Kriesel sur PostHog.) La solution consiste à appeler identify à chaque conversion réelle. **Faites d'abord un audit** — beaucoup d'applications SaaS identifient déjà l'utilisateur à l'inscription ; ne reconstruisez pas ce qui fonctionne. Isolez les conversions *spécifiques* non instrumentées et traitez uniquement celles-ci.

### Réconcilier les conversions sur un domaine tiers

Le cas particulier nécessitant une mécanique dédiée : une conversion finalisée sur un domaine que vous ne contrôlez pas (outil de réservation, page de paiement hébergée). Vous ne pouvez pas y charger vos scripts analytics, donc :

1. **Au clic**, un script d'écoute sur les liens (phase de capture) ajoute le `distinct_id` anonyme du visiteur à l'URL sortante via le **mécanisme de transmission de métadonnées** de l'outil (ex. `?metadata[ph_distinct_id]=<id>`). Un seul écouteur au niveau du document gère l'ensemble des boutons CTA — aucune modification lien par lien.
2. L'outil tiers stocke cette métadonnée et la renvoie dans son **webhook**.
3. Votre **gestionnaire de webhook** déclenche une **fusion d'identité** (`$identify` avec l'e-mail de réservation comme `distinct_id` et l'identifiant anonyme transmis comme `$anon_distinct_id`) ainsi qu'un **événement de conversion** — reliant ainsi la réservation au parcours marketing d'origine.

### Garde-fous indispensables

- **Sécurité de l'anonymat — verrouillage par défaut (fail closed).** Ne transmettez impérativement que l'identifiant *anonyme*. Après un `identify()`, l'identifiant courant devient l'e-mail ou l'UUID de l'utilisateur ; propager cela dans une URL externe ou s'en servir pour une fusion corrompt les profils (l'e-mail de la personne A se retrouve rattaché à quiconque effectue la réservation). Rejetez tout identifiant ressemblant à une donnée personnelle (contenant un `@`), limitez la longueur de la chaîne, et en cas de doute sur l'identité, **ne transmettez rien**. Si l'application identifie par UUID, testez `distinct_id === device_id` plutôt qu'un test sur `@`.
- **Qualité des données de premier contact.** Les redirections écrasent le premier point de contact réel. Excluez les referrers d'OAuth et de paiement (`accounts.google.com`, `checkout.stripe.com`, `login.*`), vos propres sous-domaines (auto-références), et les hôtes locaux de développement (`localhost`) de la classification des referrers. Il s'agit la plupart du temps d'un réglage dans les paramètres et non de code, et c'est l'action au meilleur ratio fiabilité/effort.
- **Suivi inter-sous-domaines.** Le site marketing et l'application sur un sous-domaine doivent partager le même projet analytics + un cookie inter-sous-domaines, sous peine de briser le parcours lors du passage de l'un à l'autre. Attendez-vous à des **chiffres proches de zéro tant que la réconciliation n'est pas validée en production** — ne paniquez pas devant des données vides ; utilisez temporairement une heuristique basée sur la fenêtre de campagne et rattrapez la cohorte antérieure (détails dans la référence).

### Restitution et dernier kilomètre

Le premier bénéfice immédiat est une vue clé : votre **événement de conversion découpé par canal de premier contact** (`$initial_utm_source` / `$initial_referring_domain`), et — une fois couplé au chiffre d'affaires — le chemin **canal → conversion → CA**. Vérifiez la configuration premier contact vs dernier contact dans l'outil (beaucoup sont configurés par défaut sur le dernier contact ; l'attribution first-party nécessite `$initial_*`).

Cependant, le premier contact seul ne permet pas d'appliquer les modèles multi-touch du §2. **Enregistrez l'ensemble du parcours ordonné des points de contact** (et pas uniquement `$initial_*`) : le volet technique alimente ainsi le volet analytique — vous pouvez dès lors noter vos propres parcours selon un modèle basé sur la position, linéaire ou à dépréciation temporelle plutôt que de vous limiter à la théorie.

**Le dernier kilomètre — synchroniser avec le CRM** (optimisation issue du terrain par Tessa Kriesel). Un découpage dans un outil d'analyse n'est qu'un rapport ; les équipes commerciales et cycle de vie ont besoin que l'attribution soit **inscrite directement sur la fiche contact/compte**. Synchronisez un champ **`source` avec `confidence` et `basis`** (rattachement au parcours vs autodéclaré vs secours par fenêtre de campagne) ainsi qu'une **lecture Payant vs Organique** déduite du support (medium), **consolidée au niveau de l'entreprise/compte** (et pas seulement du contact — une structure B2B rassemble plusieurs personnes utilisant des adresses professionnelles et personnelles). La manière dont les équipes pipeline et cycle de vie *exploitent* ensuite cette donnée relève de la compétence **revops**.

La méthode est indépendante des outils : le mécanisme identify + merge est disponible dans PostHog, Segment, Amplitude, et via le user-id dans GA4 ; la passerelle tierce fonctionne avec tout outil disposant de champs de métadonnées et de webhooks. PostHog + SavvyCal servent d'exemple d'application concrète dans `references/first-party-tracking.md`.

---

## Format de restitution

Fournissez une **synthèse d'attribution**, pas une extraction brute de données :

```markdown
# Synthèse d'attribution — [date]

## L'enjeu
[La décision que ce document éclaire — ex. "où allouer le budget du trimestre prochain ?"]

## Source de vérité
[Quel système fait foi pour le volume de conversions, et pourquoi]

## Ce qu'indique chaque source
| Canal | Donnée plateforme | GA | CRM | Autodéclaré | Notre lecture |
|-------|-------------------|----|----|-------------|---------------|
[Dédupliqué par rapport à la source de vérité ; non additionné]

## Comparaison des modèles (pour les cycles longs)
[Premier contact vs dernier contact côte à côte ; l'écart constitue l'information clé]

## Niveau de confiance et angles morts
[L'écart d'attribution, les angles morts, ce qui nous échappe]

## Recommandation
[Arbitrage d'allocation avec indices de confiance ; le test d'incrémentalité prioritaire à lancer]
```

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Outils principaux :

| Outil | Idéal pour | MCP | Guide |
|---|---|:---:|---|
| **PostHog** | Attribution first-party, identify/merge, entonnoirs | - | [posthog.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/posthog.md) |
| **GA4** | Analyse web, comparaison de modèles, réconciliation via user-id | ✓ | [ga4.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/ga4.md) |
| **Dub** | Liens courts + attribution des clics | ✓ | [dub-co.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/dub-co.md) |
| **Segment** | CDP — router identify/track vers chaque destination | - | [segment.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/segment.md) |
| **HubSpot** | Source du lead dans le CRM + champs déclaratifs | ✓ | [hubspot.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/hubspot.md) |
| **Salesforce** | CRM comme source de vérité sur le chiffre d'affaires | - | [salesforce.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/salesforce.md) |
| **Supermetrics** | Centraliser les chiffres des plateformes pour réconciliation | ✓ | [supermetrics.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/supermetrics.md) |
| **RB2B** | Désanonymiser les visiteurs B2B du site web | - | [rb2b.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/rb2b.md) |

---

## Compétences associées

- **analytics** — suivi d'événements, plans de taggage, UTM, configuration GA4/GTM. À réaliser *avant* l'attribution.
- **conversion-tracking** — pixels des plateformes publicitaires, CAPI, suivi des conversions côté serveur et audits de tracking.
- **revops** — étapes du pipeline, cycle de vie des leads, reporting de CA dans le CRM. L'attribution l'alimente.
- **ai-seo** — analyse approfondie de l'angle mort de l'attribution liée à la recherche IA.
- **ab-testing** — expérimentations contrôlées ; la démarche d'incrémentalité appliquée aux modifications sur site.
