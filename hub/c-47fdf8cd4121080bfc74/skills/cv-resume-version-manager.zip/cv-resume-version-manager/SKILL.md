---
name: resume-version-manager
description: Suivre les différentes versions de CV, maintenir un CV maître et gérer les versions adaptées
---

# Gestionnaire de versions de CV

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A plusieurs versions de CV à gérer
- Doit suivre des CV adaptés à des offres spécifiques
- Souhaite maintenir un CV maître
- Postule à de nombreux postes différents
- Mentionne : « versions de CV », « CV maître », « différentes versions », « suivre les CV », « quel CV »

## Capacités principales

- Créer et maintenir un document de CV maître
- Suivre les versions adaptées du CV
- Organiser les versions de CV par poste/secteur
- Maintenir une source unique et fiable de vérité
- Rationaliser les mises à jour de CV
- Éviter la confusion entre les versions

## La problématique de la gestion des versions

**Points de friction courants :**
- « Quelle version ai-je envoyée à l'entreprise X ? »
- « Où se trouve mon CV le plus récent ? »
- « J'ai 15 fichiers de CV et je ne sais pas lequel est le meilleur »
- « J'ai oublié de mettre à jour mon CV après ce projet »
- « Je continue d'adapter mon CV à partir de versions de base différentes »

**La solution :**
Une approche méthodique comprenant :
1. Un CV maître (source de vérité)
2. Des versions adaptées bien organisées
3. Des conventions de nommage claires
4. Un flux de travail de mise à jour

## Le concept de CV maître

### Qu'est-ce qu'un CV maître ?

Un document exhaustif contenant :
- TOUTES vos expériences (pas seulement les plus récentes)
- TOUTES les puces descriptives que vous avez rédigées
- Chaque réalisation, projet, compétence
- Tous les détails (même s'ils ne tiennent pas sur une seule page)

**Objectif :** Servir de source de référence dans laquelle piocher lors de la personnalisation

### Structure du CV maître

```markdown
# MASTER RESUME - [YOUR NAME]
Last Updated: [Date]

## CONTACT INFORMATION
[Full contact details]

## PROFESSIONAL SUMMARY VERSIONS
[Summary for Role Type A]
[Summary for Role Type B]
[Summary for Role Type C]

## ALL SKILLS
### Technical Skills
[Complete list by category]

### Soft Skills
[Complete list]

### Industry Knowledge
[All domains]

## PROFESSIONAL EXPERIENCE

### Company Name | Title | Dates

**All Bullets (choose best for each application):**
• Bullet 1 (leadership focused)
• Bullet 2 (technical focused)
• Bullet 3 (results focused)
• Bullet 4 (collaboration focused)
• Bullet 5 (additional achievement)
• Bullet 6 (additional achievement)

**Keywords this experience covers:**
[List of keywords this job demonstrates]

### Previous Company | Title | Dates
[Same format...]

## EDUCATION
[Complete education history]

## CERTIFICATIONS
[All certifications ever earned]

## PROJECTS
[All notable projects]

## VOLUNTEER / ADDITIONAL
[All other relevant experience]
```

## Système d'organisation des fichiers

### Structure des dossiers

```
Resume/
├── Master/
│   └── LastName_Master_Resume.docx
├── Tailored/
│   ├── ProductManagement/
│   │   ├── LastName_PM_Google_Jan2024.pdf
│   │   └── LastName_PM_Meta_Jan2024.pdf
│   ├── Engineering/
│   │   ├── LastName_SWE_Startup_Feb2024.pdf
│   │   └── LastName_SWE_Enterprise_Feb2024.pdf
│   └── General/
│       └── LastName_General_Resume.pdf
├── CoverLetters/
│   ├── Google_PM_CoverLetter.docx
│   └── Meta_PM_CoverLetter.docx
└── Applications/
    └── ApplicationTracker.xlsx
```

### Convention de nommage des fichiers

**Modèle :**
`[LastName]_[Role/Type]_[Company]_[Date].pdf`

**Exemples :**
- `Smith_ProductManager_Google_Jan2024.pdf`
- `Smith_SWE_Stripe_Feb2024.pdf`
- `Smith_DataScience_General_2024.pdf`
- `Smith_Master_Resume_v3.docx`

## Catégories de versions

### Par poste ciblé

**Product Management :**
- Met l'accent sur : La stratégie, la roadmap, les métriques, les parties prenantes
- Compétences mises en avant : Outils produit, analytique, recherche utilisateur

**Software Engineering :**
- Met l'accent sur : Les projets techniques, les systèmes, le code
- Compétences mises en avant : Langages, frameworks, outils

**Data Science :**
- Met l'accent sur : L'analyse, le ML, les méthodes statistiques
- Compétences mises en avant : Python, SQL, bibliothèques ML

### Par secteur d'activité

**Tech / Startup :**
- Met l'accent sur : L'innovation, la croissance, la débrouillardise
- Ton : Moderne, direct, axé sur les réalisations

**Grandes entreprises / Corporate :**
- Met l'accent sur : Le passage à l'échelle, les processus, la collaboration
- Ton : Professionnel, structuré, exhaustif

**Finance :**
- Met l'accent sur : L'analyse, la conformité, la rigueur
- Ton : Conservateur, précis, axé sur les certifications

### Par niveau de séniorité

**Contributeur individuel :**
- Accent sur l'exécution et les compétences techniques
- Descriptions détaillées des projets
- Accomplissements techniques

**Manager :**
- Leadership et développement d'équipe
- Collaboration transverse
- Métriques d'impact business

**Cadre dirigeant (Executive) :**
- Leadership stratégique
- Responsabilité de compte de résultat (P&L)
- Transformation organisationnelle

## Suivi des candidatures

### Feuille de calcul simple de suivi

```
| Company | Role | Version Used | Date Applied | Status | Notes |
|---------|------|--------------|--------------|--------|-------|
| Google | PM | PM_Google_Jan | 1/15/24 | Interview | 2nd round 2/1 |
| Meta | PM | PM_Meta_Jan | 1/18/24 | Applied | Referral from John |
| Startup | PM | PM_General | 1/20/24 | Rejected | Too senior |
```

### Informations à suivre

- Nom de l'entreprise
- Intitulé du poste
- Version de CV utilisée
- Version de lettre de motivation utilisée
- Date de candidature
- Canal de candidature (portail, recommandation, direct)
- Statut actuel
- Dates de relance
- Notes et contacts

## Flux de travail de mise à jour

### Quand mettre à jour le CV maître

**Mise à jour immédiate pour :**
- Nouveau poste ou promotion
- Projet majeur achevé
- Nouvelles compétences ou certifications
- Réalisations significatives
- Prix ou distinctions

**Revue trimestrielle :**
- Ajouter les réalisations récentes
- Mettre à jour les métriques avec de nouvelles données
- Actualiser la section des compétences
- Supprimer les informations obsolètes

### Flux de travail : du CV maître au CV adapté

```
1. Start with Master Resume
   ↓
2. Copy to new file (don't edit master)
   ↓
3. Analyze job description
   ↓
4. Select relevant bullets from master
   ↓
5. Choose appropriate summary version
   ↓
6. Reorder skills for relevance
   ↓
7. Add job-specific keywords
   ↓
8. Trim to appropriate length
   ↓
9. Save with proper naming convention
   ↓
10. Update application tracker
```

## Scénarios courants

### Scénario 1 : Postuler à des postes similaires

**Stratégie :**
- Créer une version bien adaptée au type de poste
- Apporter des ajustements mineurs pour chaque entreprise
- Noter quelle variante légère a été envoyée à quel endroit

### Scénario 2 : Postuler à différents types de postes

**Stratégie :**
- Créer des versions de base distinctes pour chaque type de poste
- Maintenir une organisation claire des dossiers
- Chaque version puise dans le même CV maître

### Scénario 3 : Volume élevé de candidatures rapides

**Stratégie :**
- Créer 2 à 3 versions solides par catégorie
- Utiliser des versions « générales » pour les candidatures rapides
- Réserver l'adaptation approfondie pour les opportunités prioritaires

### Scénario 4 : Reconversion professionnelle

**Stratégie :**
- Créer une version axée sur la transition
- Mettre en valeur les compétences transférables
- Conserver la version du secteur d'origine comme solution de repli

## Bonnes pratiques de gestion des versions

### À FAIRE :
- ✅ Toujours partir du CV maître comme source
- ✅ Utiliser des conventions de nommage cohérentes
- ✅ Suivre quelle version a été envoyée à quelle entreprise
- ✅ Garder le CV maître à jour
- ✅ Dater vos fichiers
- ✅ Sauvegarder sur un stockage cloud

### À NE PAS FAIRE :
- ❌ Modifier directement le CV maître pour postuler
- ❌ Utiliser des noms vagues comme « resume_final_v2 »
- ❌ Oublier quelle version a été envoyée
- ❌ Laisser le CV maître devenir obsolète
- ❌ Avoir plusieurs fichiers « maître »
- ❌ Supprimer les anciennes versions (les archiver plutôt)

## Format de sortie

Lors de la gestion des versions de CV :

```markdown
# RESUME VERSION MANAGEMENT

## Master Resume Status
**Last Updated:** [Date]
**Location:** [File path]
**Total Experience Entries:** [X]
**Total Bullet Points Available:** [X]

## Active Versions

### Role Type: Product Management
**Base Version:** PM_General_2024.docx
**Tailored Versions:**
| Company | File Name | Date Created | Status |
|---------|-----------|--------------|--------|
| Google | PM_Google_Jan24 | 1/15/24 | Submitted |
| Meta | PM_Meta_Jan24 | 1/18/24 | Submitted |

### Role Type: Engineering
[Same structure]

## Update Queue
- [ ] Add Q4 project results to master
- [ ] Update skills with new certification
- [ ] Archive versions older than 6 months

## Recommended Actions
1. [Action 1]
2. [Action 2]
```

## Liste de contrôle de gestion des versions

- ✅ Le CV maître existe et est à jour
- ✅ La structure des dossiers est organisée
- ✅ La convention de nommage est cohérente
- ✅ Le tableau de suivi des candidatures est maintenu à jour
- ✅ La version envoyée à chaque entreprise est identifiée
- ✅ Toutes les versions s'appuient sur le même CV maître
- ✅ Un système de sauvegarde est en place
- ✅ Les anciennes versions sont archivées (non supprimées)
- ✅ Le flux de mise à jour est formalisé
- ✅ Des révisions régulières du CV maître sont planifiées
