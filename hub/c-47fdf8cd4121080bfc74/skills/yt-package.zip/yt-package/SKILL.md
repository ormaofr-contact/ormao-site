---
name: yt-package
description: >-
  Rédige et analyse le titre et la miniature d'une vidéo YouTube comme un ensemble indissociable,
  en vérifiant la troncature, la répétition et le manque de clarté avant publication. À utiliser pour
  « idées de titre », « comment devrais-je appeler ça », « texte de miniature », « mon CTR est
  mauvais », packaging, ou toute demande visant à renommer ou repacker une vidéo existante.
---

# yt-package

Le titre et la miniature forment UNE seule et même unité. Les concevoir séparément est la raison pour laquelle la plupart des packagings échouent : la miniature répète le titre, et la moitié de la surface de clic dit deux fois la même chose.

```bash
python3 title.py --title "..." --thumb "AI RAN IT"
python3 title.py titles.txt            # one per line, ranked
```

## Avant d'écrire

1. Lis `~/.claude/youtube/voice.md` s'il existe. C'est le profil vocal de l'utilisateur : sa façon de s'exprimer face caméra, les mots qu'il n'utilise jamais, à qui il s'adresse, ce qu'il refuse d'affirmer. S'il n'existe pas, demande **trois de ses propres vidéos**, lis-les ou transcris-les, déduis-en le ton et rédige le fichier. Un script qui n'adopte pas le bon ton est pire que pas de script du tout, car l'utilisateur devra le lire à voix haute.
2. N'invente jamais un chiffre, un résultat ou une source. Si un chiffre pouvait renforcer l'accroche et que tu n'en as pas, demande-le ou écris la ligne sans lui.

## Règles appliquées par l'outil, et pourquoi

- **60 caractères** correspond à la limite de troncature sur la recherche desktop, **40** sur le flux d'accueil mobile. Les deux sont signalés car ils échouent différemment : une coupe sur desktop perd la fin, une coupe sur mobile peut faire perdre le sujet.
- **La miniature ne doit pas répéter le titre.** Des mots différents, la même promesse.
- **Trois mots maximum sur la miniature.** À la taille d'affichage d'un flux, un quatrième mot n'est qu'un pâté illisible.
- **Un chiffre, un nom ou une date** surpasse n'importe quel adjectif disponible.
- **Deux mots en majuscules est le plafond maximal** avant qu'un titre ne ressemble à du spam.

## En écrire dix, en garder deux

Génère dix titres, passe-les tous dans `title.py`, montre à l'utilisateur les trois meilleurs avec leurs scores et le problème spécifique identifié pour chacun. Pour le gagnant, rédige le brief de miniature : l'expression, le cadrage, les trois mots, et ce que l'arrière-plan doit faire pour maintenir un bon contraste à la taille du flux.

## Le sas de validation

Rien n'est publié automatiquement ici. Cette compétence rédige et c'est toi qui publies. Chaque résultat se termine par un bloc que l'utilisateur peut copier, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
