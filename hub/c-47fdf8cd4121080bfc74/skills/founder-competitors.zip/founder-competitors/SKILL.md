---
name: founder-competitors
description: >-
  Cartographie chaque concurrent et l'opportunité non exploitée qu'ils laissent.
  Trouve les concurrents directs, indirects et les substituts qu'un acheteur
  utiliserait à la place, à partir de sources publiques uniquement, et consigne ce
  que chacun vend, à quel prix, comment ils se positionnent et ce dont leurs
  clients se plaignent dans les avis publics, chaque fait étant accompagné d'un
  lien. Se termine par une carte de positionnement et l'espace stratégique que la
  nouvelle entreprise peut occuper. À utiliser lorsque l'utilisateur dit « qui sont
  mes concurrents », « ce marché est-il saturé », « qu'est-ce qui existe
  d'autre », « analyse concurrentielle », « trouver l'opportunité » ou « à qui
  suis-je confronté ».
argument-hint: "[ville ou marché]"
---

# founder-competitors

Chaque acheteur résout déjà ce problème d'une manière ou d'une autre. Cette
compétence découvre comment, ce qu'ils paient et ce qu'ils détestent là-dedans,
afin que la nouvelle entreprise démarre avec une opportunité identifiée plutôt
qu'une simple supposition.

## Les règles

- **Sources publiques uniquement, chaque fait sourcé avec un lien.** Sites web,
  pages de tarifs, menus, fiches App Store et Google Maps, sites d'avis, Reddit,
  actualités. Si une source est inaccessible, indiquez-le. N'inventez jamais un
  concurrent, un prix, une note ou un avis.
- **Lire, ne pas scraper.** Lisez les pages comme le ferait un humain. Respectez
  les conditions d'utilisation de chaque site.
- **Les citations sont textuelles**, courtes, avec le lien. Elles relèvent de la
  recherche, jamais du témoignage promotionnel.

## Étape 1 : qui est présent

À partir de `founder/idea.md` (rédigez-le d'abord s'il est manquant ; voir
l'étape 0 de `/founder-board`) :

| type | ce que cela signifie | exemple pour un café matcha |
| --- | --- | --- |
| Direct | vend la même chose au même acheteur | d'autres bars à matcha accessibles à pied |
| Indirect | un produit différent pour le même besoin | les cafés situés dans la même rue |
| Substitut | comment les acheteurs s'en sortent sans entreprise | poudre de matcha à la maison, boissons en canette |

Visez 5 à 10 concurrents directs et indirects, plus les principaux substituts.
Pour un commerce local, recherchez sur la carte la zone exacte ; pour une
activité en ligne, cherchez comme le ferait un acheteur (« meilleur <produit>
pour <public> », « alternative à <produit> »).

## Étape 2 : les faits

Une ligne par concurrent dans `founder/competitors.csv` :

`name,type,url,location_or_channel,price_of_comparable_item,what_it_sells,positioning_line,rating,review_count,source_date`

`positioning_line` correspond à leur propre titre ou slogan, copié tel quel. Le
prix concerne l'article le plus proche de ce que vend la nouvelle entreprise, en
précisant ce qu'il comprend.

## Étape 3 : ce que disent leurs clients

Pour les 3 à 5 principaux, lisez leurs avis (d'abord les avis 1 à 3 étoiles, puis
les 4 étoiles du type « j'adore, mais... »). Notez les plaintes récurrentes sous
forme de thèmes accompagnés du nombre d'occurrences et d'une ou deux citations
avec lien pour chacun. Qualifiez un thème de fragile s'il compte moins de trois
avis.

## Étape 4 : la carte et l'opportunité

Rédigez `founder/competitors.md` :

1. Le tableau (issu du CSV), trié selon le degré de concurrence directe de
   chacun.
2. La fourchette de prix : le plus bas, la médiane, le plus élevé pour l'article
   comparable.
3. Une carte de positionnement au format texte : deux axes pertinents pour cet
   acheteur (prix et praticité, qualité et rapidité...), indiquant où se situe
   chaque concurrent.
4. Les plaintes, classées, avec des liens.
5. **L'opportunité** : ce que personne ne fait bien et que cette entreprise
   pourrait accomplir, étayé par des preuves. S'il n'y a aucune opportunité,
   dites-le clairement ; c'est le résultat le plus utile que cette compétence
   puisse fournir.
6. La menace : qui pourrait copier la nouvelle entreprise le plus rapidement,
   et comment.

## Sortie

`founder/competitors.csv`, `founder/competitors.md`. Ensuite :
`/founder-consumer` utilise les plaintes pour formuler de véritables objections ;
`/founder-pricing` s'appuie sur la fourchette de prix.
