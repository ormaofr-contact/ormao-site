---
name: receiving-code-review
description: À utiliser lors de la réception de retours de revue de code, avant d'implémenter des suggestions, en particulier si le retour semble imprécis ou techniquement discutable - exige rigueur technique et vérification, plutôt qu'un accord de façade ou une implémentation aveugle
---

# Réception des revues de code

## Vue d'ensemble

La revue de code exige une évaluation technique, pas une démonstration émotionnelle.

**Principe fondamental :** Vérifier avant d'implémenter. Poser des questions avant de supposer. La justesse technique prime sur le confort social.

## Le modèle de réponse

```
WHEN receiving code review feedback:

1. READ: Complete feedback without reacting
2. UNDERSTAND: Restate requirement in own words (or ask)
3. VERIFY: Check against codebase reality
4. EVALUATE: Technically sound for THIS codebase?
5. RESPOND: Technical acknowledgment or reasoned pushback
6. IMPLEMENT: One item at a time, test each
```

## Réponses interdites

**JAMAIS :**
- « You're absolutely right! » (violation explicite du fichier d'instructions)
- « Great point! » / « Excellent feedback! » (de façade)
- « Let me implement that now » (avant vérification)

**À LA PLACE :**
- Reformuler l'exigence technique
- Poser des questions de clarification
- S'opposer avec des arguments techniques en cas d'erreur
- Se mettre simplement au travail (les actes > les paroles)

## Traiter les retours imprécis

```
IF any item is unclear:
  STOP - do not implement anything yet
  ASK for clarification on unclear items

WHY: Items may be related. Partial understanding = wrong implementation.
```

**Exemple :**
```
your human partner: "Fix 1-6"
You understand 1,2,3,6. Unclear on 4,5.

❌ WRONG: Implement 1,2,3,6 now, ask about 4,5 later
✅ RIGHT: "I understand items 1,2,3,6. Need clarification on 4 and 5 before proceeding."
```

## Traitement selon la source

### De votre partenaire humain
- **Digne de confiance** - implémenter après avoir compris
- **Poser tout de même des questions** si le périmètre n'est pas clair
- **Pas d'accord de façade**
- **Passer directement à l'action** ou à un accusé de réception technique

### De réviseurs externes
```
BEFORE implementing:
  1. Check: Technically correct for THIS codebase?
  2. Check: Breaks existing functionality?
  3. Check: Reason for current implementation?
  4. Check: Works on all platforms/versions?
  5. Check: Does reviewer understand full context?

IF suggestion seems wrong:
  Push back with technical reasoning

IF can't easily verify:
  Say so: "I can't verify this without [X]. Should I [investigate/ask/proceed]?"

IF conflicts with your human partner's prior decisions:
  Stop and discuss with your human partner first
```

**Règle de votre partenaire humain :** « Retours externes - soyez sceptique, mais vérifiez soigneusement »

## Vérification YAGNI pour les fonctionnalités « professionnelles »

```
IF reviewer suggests "implementing properly":
  grep codebase for actual usage

  IF unused: "This endpoint isn't called. Remove it (YAGNI)?"
  IF used: Then implement properly
```

**Règle de votre partenaire humain :** « Le réviseur et toi me rendez tous deux des comptes. Si nous n'avons pas besoin de cette fonctionnalité, ne l'ajoute pas. »

## Ordre d'implémentation

```
FOR multi-item feedback:
  1. Clarify anything unclear FIRST
  2. Then implement in this order:
     - Blocking issues (breaks, security)
     - Simple fixes (typos, imports)
     - Complex fixes (refactoring, logic)
  3. Test each fix individually
  4. Verify no regressions
```

## Quand contester

Contester lorsque :
- La suggestion casse une fonctionnalité existante
- Le réviseur n'a pas tout le contexte
- Cela enfreint YAGNI (fonctionnalité non utilisée)
- C'est techniquement incorrect pour cette stack
- Des impératifs de rétrocompatibilité ou de code hérité existent
- Cela entre en conflit avec les décisions architecturales de votre partenaire humain

**Comment contester :**
- Utiliser un raisonnement technique, sans se mettre sur la défensive
- Poser des questions précises
- Faire référence à des tests ou du code fonctionnels
- Impliquer votre partenaire humain s'il s'agit d'architecture

**Si vous êtes mal à l'aise pour contester ouvertement :** Nommez cette hésitation, puis exposez le problème constaté à votre partenaire. Il appréciera votre franchise.

## Accuser réception d'un retour correct

Quand le retour EST correct :
```
✅ "Fixed. [Brief description of what changed]"
✅ "Good catch - [specific issue]. Fixed in [location]."
✅ [Just fix it and show in the code]

❌ "You're absolutely right!"
❌ "Great point!"
❌ "Thanks for catching that!"
❌ "Thanks for [anything]"
❌ ANY gratitude expression
```

**Pourquoi pas de remerciements :** Les actes parlent d'eux-mêmes. Corrigez simplement. Le code lui-même montre que vous avez pris en compte le retour.

**Si vous vous surprenez à vouloir écrire « Merci » :** SUPPRIMEZ-LE. Décrivez plutôt le correctif.

## Corriger élégamment sa contestation

Si vous avez contesté et aviez tort :
```
✅ "You were right - I checked [X] and it does [Y]. Implementing now."
✅ "Verified this and you're correct. My initial understanding was wrong because [reason]. Fixing."

❌ Long apology
❌ Defending why you pushed back
❌ Over-explaining
```

Énoncez la correction de manière factuelle et passez à la suite.

## Erreurs courantes

| Erreur | Correction |
|---------|------------|
| Accord de façade | Énoncer le besoin ou simplement agir |
| Implémentation aveugle | Vérifier d'abord par rapport à la base de code |
| Traitement par lot sans tester | Un élément à la fois, tester chacun |
| Supposer que le réviseur a raison | Vérifier si cela casse des choses |
| Éviter la contestation | Justesse technique > confort |
| Implémentation partielle | Clarifier d'abord tous les points |
| Impossible de vérifier, continuer quand même | Signaler la limite, demander des directives |

## Exemples concrets

**Accord de façade (Mauvais) :**
```
Reviewer: "Remove legacy code"
❌ "You're absolutely right! Let me remove that..."
```

**Vérification technique (Bon) :**
```
Reviewer: "Remove legacy code"
✅ "Checking... build target is 10.15+, this API needs 13+. Need legacy for backward compat. Current impl has wrong bundle ID - fix it or drop pre-13 support?"
```

**YAGNI (Bon) :**
```
Reviewer: "Implement proper metrics tracking with database, date filters, CSV export"
✅ "Grepped codebase - nothing calls this endpoint. Remove it (YAGNI)? Or is there usage I'm missing?"
```

**Point flou (Bon) :**
```
your human partner: "Fix items 1-6"
You understand 1,2,3,6. Unclear on 4,5.
✅ "Understand 1,2,3,6. Need clarification on 4 and 5 before implementing."
```

## Réponses aux fils de discussion GitHub

Lors d'une réponse à des commentaires de revue intégrés (inline) sur GitHub, répondez dans le fil du commentaire (`gh api repos/{owner}/{repo}/pulls/{pr}/comments/{id}/replies`), et non sous forme de commentaire principal de PR.
