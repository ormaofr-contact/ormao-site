---
name: founder-marketing
description: >-
  Votre directeur marketing. Transforme le panel d'acheteurs et la cartographie des concurrents en positionnement, identifie les canaux que le client cible utilise réellement, élabore une campagne de lancement sur 30 jours avec publications et publicités datées, les dix premières accroches, une répartition du budget et les indicateurs à surveiller. Chaque message répond à une objection soulevée par des acheteurs réels ou simulés. À utiliser lorsque l'utilisateur dit « comment commercialiser cela », « plan marketing », « campagne de lancement », « comment trouver des clients », « où faire de la publicité », « rédige mes publicités » ou « positionnement ».
argument-hint: "[budget]"
---

# founder-marketing

Une entreprise dont personne n'entend parler n'existe pas. Cette compétence planifie la façon dont les premiers clients en entendent parler, en s'appuyant sur ce que le reste du pack a déjà appris au lieu d'utiliser un guide générique.

## Étape 1 : lire les éléments probants

- `founder/panel/results.md` : qui achète, qui n'achète pas et pourquoi. Les segments affichant le taux d'achat le plus élevé constituent la première audience. Les principales objections sont ce à quoi le marketing doit répondre.
- `founder/competitors.md` : comment les concurrents se positionnent (pour ne pas leur ressembler) et l'opportunité à saisir.
- `founder/offer.md` et `founder/pricing.md` : ce qui est vendu, à quel prix.
- `founder/numbers.json` : ce que vaut un client, ce qui plafonne ce que vous pouvez dépenser pour en acquérir un.

Si aucun de ces éléments n'existe, indiquez ce qui manque et proposez d'exécuter d'abord `/founder-consumer --quick`. N'inventez pas d'audience.

## Étape 2 : positionnement

Une ligne, puis les raisons :

```
For <the segment that buys most>, who <their problem in their words>,
<business> is the <category> that <the gap>, unlike <the nearest alternative>.
```

Proposez trois versions, recommandez-en une et précisez quelles données du panel la soutiennent.

## Étape 3 : canaux

Dressez la liste des endroits où la première audience accorde réellement son attention, en fonction du type d'entreprise et du lieu : passage piéton et signalétique en vitrine, Google Maps, Instagram et TikTok, créateurs locaux, groupes de quartier, partenariats avec des commerces voisins, e-mail, recherche payante, social ads payants. Pour chacun : pourquoi il convient à cet acheteur, le coût approximatif, et comment vous saurez si cela a fonctionné. Choisissez-en deux ou trois pour commencer ; précisez ce que vous ne faites pas et pourquoi.

## Étape 4 : la campagne de 30 jours

`founder/marketing.md` reçoit un calendrier daté allant de lancement -14 jours à lancement +16 jours : ce qui est publié chaque jour, sur quel canal, avec le message. Incluez :

- **Dix accroches**, chacune répondant à une objection du panel ou exploitant une motivation d'achat, rédigées pour le format adapté (une phrase d'accroche de 3 secondes pour la vidéo, un titre pour une publicité, une affiche en vitrine).
- L'offre de la semaine de lancement issue de `founder/pricing.md` et sa date de fin.
- Ce qu'il faut publier lorsqu'il n'y a rien de nouveau à dire (les coulisses, la fabrication).

## Étape 5 : budget et chiffres

- La répartition du budget entre les canaux choisis.
- Le montant maximal que vous pouvez dépenser pour acquérir un client : à partir de la marge contributive unitaire du DAF et du nombre d'achats par acheteur issus du panel, détaillez le calcul.
- Les trois indicateurs à surveiller chaque semaine et le seuil qui signifie « changez quelque chose ».

## Règles

- Pas de faux avis, de faux abonnés, de faux témoignages, d'avant/après ou de mentions « vu dans les médias ».
- Les citations du panel relèvent de la recherche ; ne les utilisez jamais comme citations de clients dans des publicités.
- Déclarez les partenariats rémunérés. Respectez les règles publicitaires relatives aux allégations sur le marché de l'utilisateur (en particulier les allégations sur la santé et les revenus). Ne constitue pas un conseil juridique.

## Sortie

`founder/marketing.md`. Étape suivante : `/founder-brand`, puis `/founder-launch`.
