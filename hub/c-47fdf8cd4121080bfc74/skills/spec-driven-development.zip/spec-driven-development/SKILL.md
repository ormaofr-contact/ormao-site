---
name: spec-driven-development
description: Crée des spécifications avant de coder. À utiliser lors du démarrage d'un nouveau projet, d'une nouvelle fonctionnalité ou d'un changement important lorsqu'aucune spécification n'existe encore. À utiliser lors de la rédaction d'un PRD ou d'un document d'exigences avec objectifs et périmètre, ou lorsque les exigences sont floues, ambiguës ou n'existent que sous forme d'idée vague. À utiliser lorsqu'une seule exigence couvre plusieurs fonctionnalités testables indépendamment et doit être décomposée en une cartographie des capacités de modules avant la spécification.
---

# Développement piloté par les spécifications (Spec-Driven Development)

## Vue d'ensemble

Rédigez une spécification structurée avant d'écrire la moindre ligne de code. La spécification est la source unique de vérité partagée entre vous et l'ingénieur humain — elle définit ce que nous construisons, pourquoi, et comment nous saurons que c'est terminé. Coder sans spécification relève de la conjecture.

## Quand l'utiliser

- Démarrage d'un nouveau projet ou d'une nouvelle fonctionnalité
- Les exigences sont ambiguës ou incomplètes
- Le changement touche plusieurs fichiers ou modules
- Vous êtes sur le point de prendre une décision d'architecture
- La tâche prendrait plus de 30 minutes à implémenter

**Quand NE PAS l'utiliser :** Correctifs d'une seule ligne, corrections de fautes de frappe ou modifications dont les exigences sont non ambiguës et autonomes.

## Le flux de travail avec jalons de validation (Gated Workflow)

Le développement piloté par les spécifications comporte quatre phases, précédées d'une vérification de périmètre (Phase 0) qui ne s'active que lorsqu'une seule demande regroupe plusieurs fonctionnalités testables indépendamment. Ne passez pas à la phase suivante tant que la phase actuelle n'est pas validée.

```
SPÉCIFIER ──→ PLANIFIER ──→ TÂCHES ──→ IMPLÉMENTER
    │             │            │             │
    ▼             ▼            ▼             ▼
  Revue         Revue        Revue         Revue
 humaine       humaine      humaine       humaine
```

### Phase 0 : Vérification du périmètre

La plupart des demandes décrivent une seule capacité. Si c'est le cas ici, ignorez cette phase et passez directement à Spécifier — la Phase 0 existe pour l'exception, pas la règle, et elle n'impose aucune hiérarchie sur les fonctionnalités à capacité unique.

**Détection.** Décomposez avant de spécifier lorsqu'une seule exigence regroupe plusieurs capacités testables indépendamment :

- L'exigence nomme des capacités distinctes avec leurs propres consommateurs ou données (par ex. identité, facturation, notifications, rapports)
- Les critères d'acceptation se regroupent en ensembles qui pourraient être livrés et vérifiés séparément
- Une capacité pourrait être supprimée ou remplacée sans réécrire les exigences des autres

**Proposez une cartographie des capacités avant d'écrire toute spécification.** Concise et facile à relire — un tableau de modules plus un ordre de construction, pas un plan de projet :

```markdown
# Cartographie des capacités : [Nom de l'initiative]

| Module id | Responsabilité | Dépend de |
|---|---|---|
| identity | Comptes, sessions, SSO | — |
| billing | Forfaits, factures, paiements | identity |
| notifications | Diffusion d'e-mails et de webhooks | identity |
| reporting | Tableaux de bord d'utilisation | billing, notifications |

Ordre de construction : identity → billing, notifications → reporting
```

- **Identifiants de modules stables.** En kebab-case, choisis une fois, jamais renommés en cours d'initiative. Les spécifications, les plans et les commandes en aval sélectionnent le travail par ces identifiants au lieu de deviner quelle spécification est active.
- **Sens des dépendances, pas de cycles.** Les flèches pointent dans une seule direction. Si deux modules ont chacun besoin de l'autre, ils ne forment qu'un seul module.
- **Les interfaces se situent à la frontière.** La cartographie enregistre que `billing` dépend de `identity` ; le contrat entre eux relève de la spécification du module fournisseur (voir `api-and-interface-design` pour sa conception).

**La cartographie est soumise à validation comme chaque phase.** L'humain examine les frontières des modules, le sens des dépendances et l'ordre de construction avant qu'aucune spécification de module ne soit rédigée. Se tromper sur la cartographie coûte cher ; relire dix lignes ne coûte rien.

**Puis appliquez la récursion par module.** Exécutez Spécifier → Planifier → Tâches → Implémenter pour chaque module dans l'ordre des dépendances. Chaque module reçoit sa propre spécification, délimitée par l'objectif, les frontières et les critères de réussite de ce module. Enregistrez la cartographie approuvée à la racine du projet et la spécification de chaque module à ses côtés, nommée par identifiant de module (`SPEC-identity.md`, `SPEC-billing.md`) — la cartographie, et non la devinette des noms de fichiers, est l'index de ce qui existe.

### Phase 1 : Spécifier

Commencez par une vision de haut niveau. Posez des questions de clarification à l'humain jusqu'à ce que les exigences soient concrètes.

**Explicitez immédiatement les hypothèses.** Avant d'écrire le moindre contenu de spécification, listez ce que vous supposez :

```
HYPOTHÈSES QUE JE FAIS :
1. Il s'agit d'une application web (pas mobile native)
2. L'authentification utilise des cookies basés sur les sessions (pas de JWT)
3. La base de données est PostgreSQL (d'après le schéma Prisma existant)
4. Nous ciblons uniquement les navigateurs modernes (pas d'IE11)
→ Corrigez-moi maintenant ou je continuerai avec ces hypothèses.
```

Ne comblez pas silencieusement les exigences ambiguës. Le but premier de la spécification est de faire émerger les malentendus *avant* que le code ne soit écrit — les hypothèses implicites sont la forme la plus dangereuse de malentendu.

**Rédigez un document de spécification couvrant ces six domaines clés :**

1. **Objectif** — Que construisons-nous et pourquoi ? Qui est l'utilisateur ? À quoi ressemble la réussite ?

2. **Commandes** — Commandes exécutables complètes avec options, pas seulement des noms d'outils.
   ```
   Build: npm run build
   Test: npm test -- --coverage
   Lint: npm run lint --fix
   Dev: npm run dev
   ```

3. **Structure du projet** — Où réside le code source, où vont les tests, où se trouve la documentation.
   ```
   src/           → Code source de l'application
   src/components → Composants React
   src/lib        → Utilitaires partagés
   tests/         → Tests unitaires et d'intégration
   e2e/           → Tests de bout en bout (end-to-end)
   docs/          → Documentation
   ```

4. **Style de code** — Un extrait de code réel illustrant votre style vaut mieux que trois paragraphes pour le décrire. Incluez les conventions de nommage, les règles de formatage et des exemples de rendu conforme.

5. **Stratégie de test** — Quel framework, où se trouvent les tests, exigences de couverture, quels niveaux de test pour quelles préoccupations.

6. **Frontières (Boundaries)** — Système à trois niveaux :
   - **Toujours faire :** Exécuter les tests avant les commits, respecter les conventions de nommage, valider les entrées
   - **Demander d'abord :** Modifications du schéma de base de données, ajout de dépendances, modification de la configuration CI
   - **Ne jamais faire :** Commiter des secrets, modifier les répertoires de dépendances vendor, supprimer des tests en échec sans approbation

**Modèle de spécification :**

```markdown
# Spécification : [Nom du projet/de la fonctionnalité]

## Objectif
[Ce que nous construisons et pourquoi. User stories ou critères d'acceptation.]

## Stack technique
[Framework, langage, dépendances clés avec versions]

## Commandes
[Build, test, lint, dev — commandes complètes]

## Structure du projet
[Organisation des répertoires avec descriptions]

## Style de code
[Exemple d'extrait + conventions clés]

## Stratégie de test
[Framework, emplacements des tests, exigences de couverture, niveaux de test]

## Frontières
- Toujours : [...]
- Demander d'abord : [...]
- Jamais : [...]

## Critères de réussite
[Comment nous saurons que c'est terminé — conditions spécifiques et testables]

## Questions ouvertes
[Tout point non résolu nécessitant l'intervention de l'humain]
```

**Outils de spécification externes :** Ce flux de travail est agnostique quant au format. Si le projet utilise déjà OpenSpec ou un autre système de spécification, conservez le format d'artefact et les conventions de stockage de ce système au lieu de créer un doublon `SPEC.md`. Cette compétence prend en charge la clarification, le contenu et les jalons d'approbation ; l'outil externe prend en charge la façon dont la spécification approuvée est représentée.

**Recadrez les instructions sous forme de critères de réussite.** Lors de la réception d'exigences vagues, traduisez-les en conditions concrètes :

```
EXIGENCE : "Rendre le tableau de bord plus rapide"

CRITÈRES DE RÉUSSITE RECADRÉS :
- LCP du tableau de bord < 2,5s sur une connexion 4G
- Le chargement initial des données prend < 500ms
- Aucun décalage de mise en page pendant le chargement (CLS < 0,1)
→ Ces objectifs sont-ils les bons ?
```

Cela vous permet d'itérer, de réessayer et de résoudre les problèmes vers un objectif clair plutôt que de deviner ce que signifie "plus rapide".

**Arrêtez-vous après avoir rédigé la spécification (CRITIQUE).** Une fois la spécification enregistrée :

1. Résumez-la et listez les éventuelles questions ouvertes.
2. Demandez à l'humain de l'approuver ou de demander des modifications.
3. **ARRÊTEZ IMMÉDIATEMENT VOTRE TOUR.** Ne commencez PAS la Phase 2, n'invoquez pas `planning-and-task-breakdown`, et n'écrivez pas de code au cours de ce tour. La planification ne commence qu'après que l'humain a approuvé la spécification dans un tour ultérieur.

### Phase 2 : Planifier

Avec la spécification validée, générez un plan d'implémentation technique :

1. Identifiez les composants majeurs et leurs dépendances
2. Déterminez l'ordre d'implémentation (ce qui doit être construit en premier)
3. Notez les risques et les stratégies d'atténuation
4. Identifiez ce qui peut être construit en parallèle par rapport à ce qui doit être séquentiel
5. Définissez des points de contrôle de vérification entre les phases

> Suivez `planning-and-task-breakdown` pour le mappage du graphe de dépendances et les mécanismes de découpage vertical derrière ces étapes ; il s'agit de la source faisant autorité. Les points ci-dessus constituent un résumé léger ; en cas de divergence, `planning-and-task-breakdown` prévaut.
>
> **Convention de sortie :** Enregistrez le plan dans `tasks/plan.md` et consignez la liste des tâches dans la cible définie par `planning-and-task-breakdown` (`tasks/todo.md` par défaut ; les projets peuvent désigner un outil de suivi externe à la place). Créez `tasks/` s'il n'existe pas. Les commandes en aval (`/build`, etc.) s'attendent à ces valeurs par défaut.

Le plan doit être facile à relire : l'humain doit être capable de le lire et de dire "oui, c'est la bonne approche" ou "non, modifie X".

### Phase 3 : Tâches

Décomposez le plan en tâches discrètes et réalisables :

- Chaque tâche doit pouvoir être réalisée au cours d'une seule session de travail ciblée
- Chaque tâche a des critères d'acceptation explicites
- Chaque tâche comprend une étape de vérification (test, build, vérification manuelle)
- Les tâches sont ordonnées par dépendance, et non par importance perçue
- Aucune tâche ne doit nécessiter la modification de plus de ~5 fichiers

> Suivez `planning-and-task-breakdown` pour l'ensemble des mécanismes de dimensionnement des tâches et d'ordonnancement des dépendances ; il s'agit de la source faisant autorité. Le modèle ci-dessous est un format en ligne léger ; en cas de divergence, `planning-and-task-breakdown` prévaut.

**Modèle de tâche :**
```markdown
- [ ] Tâche : [Description]
  - Acceptation : [Ce qui doit être vrai une fois terminé]
  - Vérification : [Comment confirmer — commande de test, build, vérification manuelle]
  - Fichiers : [Quels fichiers seront modifiés]
```

### Phase 4 : Implémenter

Exécutez les tâches une par une en suivant `skills/incremental-implementation/SKILL.md` (`incremental-implementation`) et `skills/test-driven-development/SKILL.md` (`test-driven-development`). Utilisez `skills/context-engineering/SKILL.md` (`context-engineering`) pour charger les sections de spécification et les fichiers sources appropriés à chaque étape au lieu de saturer l'agent avec la spécification dans son ensemble.

## Garder la spécification vivante

La spécification est un document vivant, pas un livrable à usage unique :

- **Mettez à jour lorsque les décisions changent** — Si vous découvrez que le modèle de données doit changer, mettez d'abord à jour la spécification, puis implémentez.
- **Mettez à jour lorsque le périmètre change** — Les fonctionnalités ajoutées ou retirées doivent être reflétées dans la spécification.
- **Commitez la spécification** — La spécification appartient au système de contrôle de version aux côtés du code.
- **Référencez la spécification dans les PR** — Liez chaque PR à la section de spécification qu'elle implémente.

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| "C'est simple, je n'ai pas besoin de spécification" | Les tâches simples n'ont pas besoin de *longues* spécifications, mais elles ont tout de même besoin de critères d'acceptation. Une spécification de deux lignes convient parfaitement. |
| "J'écrirai la spécification après l'avoir codé" | C'est de la documentation, pas de la spécification. La valeur de la spécification réside dans le fait d'imposer la clarté *avant* le code. |
| "La spécification va nous ralentir" | Une spécification de 15 minutes évite des heures de retravail. Un cycle en cascade de 15 minutes vaut mieux que 15 heures de débogage. |
| "Les exigences changeront de toute façon" | C'est pourquoi la spécification est un document vivant. Une spécification dépassée reste meilleure que pas de spécification du tout. |
| "L'utilisateur sait ce qu'il veut" | Même les demandes claires comportent des hypothèses implicites. La spécification fait émerger ces hypothèses. |
| "C'est une seule grande fonctionnalité ; la diviser est inutile" | Si les critères d'acceptation se regroupent en ensembles testables indépendamment, une spécification monolithique oblige chaque tâche en aval à raisonner sur l'ensemble du contrat. Une cartographie des capacités de dix lignes est l'alternative la plus économique. |
| "Je décomposerai pendant la planification" | La planification découpe les tâches au sein d'une spécification. À ce stade, l'artefact surdimensionné existe déjà — les frontières des modules et le sens des dépendances doivent être décidés avant la rédaction de la spécification, pas après. |

## Signaux d'alerte (Red Flags)

- Commencer à écrire du code sans aucune exigence écrite
- Demander "dois-je simplement commencer à développer ?" avant d'avoir clarifié ce que signifie "terminé"
- Implémenter des fonctionnalités non mentionnées dans une spécification ou une liste de tâches
- Prendre des décisions d'architecture sans les documenter
- Ignorer la spécification sous prétexte qu'"il est évident de savoir quoi construire"
- Rédiger la spécification et commencer le plan ou le code au cours du même tour
- Une seule spécification dont les exigences couvrent plusieurs capacités testables indépendamment
- Frontières de modules ou ordre de construction décidés implicitement pendant l'implémentation car aucune cartographie des capacités n'a été approuvée en amont

## Vérification

Avant de passer à l'implémentation, confirmez :

- [ ] La spécification couvre l'ensemble des six domaines clés
- [ ] L'humain a examiné et approuvé la spécification
- [ ] Le tour s'est achevé après l'enregistrement de la spécification ; l'approbation a été donnée dans un tour ultérieur
- [ ] Les critères de réussite sont précis et testables
- [ ] Les frontières (Toujours / Demander d'abord / Jamais) sont définies
- [ ] La spécification est enregistrée dans un fichier du dépôt
- [ ] Si la demande regroupe plusieurs capacités testables indépendamment, une cartographie des capacités (identifiants de modules, sens des dépendances, ordre de construction) a été approuvée avant qu'aucune spécification de module ne soit rédigée
- [ ] Chaque spécification de module est rattachée à un identifiant de module dans la cartographie approuvée
