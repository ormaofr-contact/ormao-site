---
name: systematic-debugging
description: À utiliser lors de la rencontre de tout bogue, échec de test ou comportement inattendu, avant de proposer des correctifs
---

# Débogage systématique

## Vue d'ensemble

**Principe fondamental :** TOUJOURS trouver la cause racine avant de tenter des correctifs. Corriger les symptômes est un échec.

**Enfreindre la lettre de ce processus, c'est enfreindre l'esprit du débogage.**

## La loi d'airain

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

Si vous n'avez pas terminé la Phase 1, vous ne pouvez pas proposer de correctifs.

## Quand l'utiliser

À utiliser pour TOUT problème technique :
- Échecs de tests
- Bogues en production
- Comportements inattendus
- Problèmes de performance
- Échecs de build
- Problèmes d'intégration

**À utiliser TOUT PARTICULIÈREMENT lorsque :**
- Vous êtes sous pression par le temps (l'urgence rend les suppositions tentantes)
- « Juste un correctif rapide » semble évident
- Vous avez déjà essayé plusieurs correctifs
- Le correctif précédent n'a pas fonctionné
- Vous ne comprenez pas entièrement le problème

**Ne pas sauter ce processus lorsque :**
- Le problème semble simple (les bogues simples ont aussi des causes racines)
- Vous êtes pressé (se précipiter garantit de devoir recommencer)
- Le responsable veut que ce soit réglé MAINTENANT (être systématique est plus rapide que de s'éparpiller)

## Les quatre phases

Vous DEVEZ terminer chaque phase avant de passer à la suivante.

### Phase 1 : Enquête sur la cause racine

**AVANT de tenter le MOINDRE correctif :**

1. **Lire attentivement les messages d'erreur**
   - Ne sautez pas les erreurs ou les avertissements
   - Ils contiennent souvent la solution exacte
   - Lisez les stack traces dans leur intégralité
   - Notez les numéros de ligne, les chemins de fichiers, les codes d'erreur

2. **Reproduire de manière constante**
   - Pouvez-vous le déclencher de manière fiable ?
   - Quelles sont les étapes exactes ?
   - Cela se produit-il à chaque fois ?
   - Si ce n'est pas reproductible → collectez plus de données, ne devinez pas

3. **Vérifier les changements récents**
   - Qu'est-ce qui a changé et pourrait causer cela ?
   - Git diff, commits récents
   - Nouvelles dépendances, modifications de configuration
   - Différences d'environnement

4. **Collecter des preuves dans les systèmes à composants multiples**

   **LORSQUE le système comporte plusieurs composants (CI → build → signing, API → service → database) :**

   **AVANT de proposer des correctifs, ajouter des instruments de diagnostic :**
   ```
   For EACH component boundary:
     - Log what data enters component
     - Log what data exits component
     - Verify environment/config propagation
     - Check state at each layer

   Run once to gather evidence showing WHERE it breaks
   THEN analyze evidence to identify failing component
   THEN investigate that specific component
   ```

   **Exemple (système multicouche) :**
   ```bash
   # Layer 1: Workflow
   echo "=== Secrets available in workflow: ==="
   echo "IDENTITY: $([ -n "${IDENTITY:-}" ] && echo SET || echo UNSET)"

   # Layer 2: Build script
   echo "=== Env vars in build script: ==="
   printenv IDENTITY >/dev/null 2>&1 && echo "IDENTITY in environment" || echo "IDENTITY not in environment"

   # Layer 3: Signing script
   echo "=== Keychain state: ==="
   security list-keychains
   security find-identity -v

   # Layer 4: Actual signing
   codesign --sign "$IDENTITY" --verbose=4 "$APP"
   ```

   **Cela révèle :** Quelle couche échoue (secrets → workflow ✓, workflow → build ✗)

5. **Tracer le flux de données**

   **LORSQUE l'erreur se situe profondément dans la pile d'appels :**

   Consultez `root-cause-tracing.md` dans ce répertoire pour la technique complète de remontée à la source.

   **Version rapide :**
   - D'où provient la mauvaise valeur ?
   - Qu'est-ce qui a appelé cela avec une mauvaise valeur ?
   - Continuez à remonter jusqu'à trouver la source
   - Corrigez à la source, pas au niveau du symptôme

### Phase 2 : Analyse des motifs

**Trouver le motif avant de corriger :**

1. **Trouver des exemples qui fonctionnent**
   - Localisez du code similaire fonctionnel dans la même base de code
   - Qu'est-ce qui fonctionne et ressemble à ce qui est cassé ?

2. **Comparer avec les références**
   - Si vous implémentez un patron, lisez l'implémentation de référence INTÉGRALEMENT
   - Ne survolez pas — lisez chaque ligne
   - Comprenez pleinement le patron avant de l'appliquer

3. **Identifier les différences**
   - Quelles sont les différences entre ce qui fonctionne et ce qui est cassé ?
   - Listez chaque différence, aussi petite soit-elle
   - Ne supposez pas que « cela ne peut pas avoir d'importance »

4. **Comprendre les dépendances**
   - De quels autres composants cela a-t-il besoin ?
   - Quels paramètres, quelle configuration, quel environnement ?
   - Quelles hypothèses cela implique-t-il ?

### Phase 3 : Hypothèse et test

**Méthode scientifique :**

1. **Formuler une hypothèse unique**
   - Énoncez clairement : « Je pense que X est la cause racine parce que Y »
   - Écrivez-le
   - Soyez précis, pas vague

2. **Tester de manière minimale**
   - Faites la plus PETITE modification possible pour tester l'hypothèse
   - Une variable à la fois
   - Ne corrigez pas plusieurs choses à la fois

3. **Vérifier avant de continuer**
   - Cela a-t-il fonctionné ? Oui → Phase 4
   - Cela n'a pas fonctionné ? Formulez une NOUVELLE hypothèse
   - N'empilez PAS d'autres correctifs par-dessus

4. **Quand vous ne savez pas**
   - Dites « Je ne comprends pas X »
   - Ne faites pas semblant de savoir
   - Demandez de l'aide
   - Faites davantage de recherches

### Phase 4 : Implémentation

**Corriger la cause racine, pas le symptôme :**

1. **Créer un cas de test qui échoue**
   - Reproduction la plus simple possible
   - Test automatisé si possible
   - Script de test ponctuel en l'absence de framework
   - DOIT obligatoirement être présent avant de corriger
   - Utilisez la compétence `superpowers:test-driven-development` pour écrire des tests qui échouent correctement

2. **Implémenter un correctif unique**
   - Traitez la cause racine identifiée
   - UNE SEULE modification à la fois
   - Pas d'améliorations « tant que j'y suis »
   - Pas de refactorisation groupée

3. **Vérifier le correctif**
   - Le test passe-t-il maintenant ?
   - Aucun autre test n'est cassé ?
   - Le problème est-il réellement résolu ?
   - Utilisez la compétence `superpowers:verification-before-completion` avant d'affirmer le succès

4. **Si le correctif ne fonctionne pas**
   - ARRÊTEZ-VOUS
   - Comptez : Combien de correctifs avez-vous essayés ?
   - Si < 3 : Retournez à la Phase 1, réanalysez avec les nouvelles informations
   - **Si ≥ 3 : ARRÊTEZ-VOUS et remettez en question l'architecture (étape 5 ci-dessous)**
   - Ne tentez PAS de correctif n°4 sans discussion architecturale

5. **Si 3 correctifs ou plus ont échoué : Remettre en question l'architecture**

   **Schéma indiquant un problème architectural :**
   - Chaque correctif révèle un nouvel état partagé / couplage / problème à un endroit différent
   - Les correctifs nécessitent une « refactorisation massive » pour être appliqués
   - Chaque correctif crée de nouveaux symptômes ailleurs

   **ARRÊTEZ-VOUS et remettez en question les fondamentaux :**
   - Ce patron est-il fondamentalement viable ?
   - Sommes-nous en train de « nous y accrocher par pure inertie » ?
   - Devrions-nous refactoriser l'architecture plutôt que de continuer à corriger des symptômes ?

   **Discutez avec votre partenaire humain avant de tenter d'autres correctifs**

   Il ne s'agit PAS d'une hypothèse erronée — il s'agit d'une mauvaise architecture.

## Signaux d'alerte - ARRÊTEZ-VOUS et suivez le processus

Si vous vous surprenez à penser :
- « Un correctif rapide pour l'instant, j'enquêterai plus tard »
- « Je vais juste essayer de modifier X et voir si ça marche »
- « Ajouter plusieurs changements, lancer les tests »
- « Sauter le test, je vérifierai manuellement »
- « C'est probablement X, je vais corriger ça »
- « Je ne comprends pas totalement mais ça pourrait marcher »
- « Le patron dit X mais je vais l'adapter différemment »
- « Voici les problèmes principaux : [liste des correctifs sans enquête préalable] »
- Proposer des solutions avant d'avoir tracé le flux de données
- **« Encore un essai de correctif » (après en avoir déjà tenté 2 ou plus)**
- **Chaque correctif révèle un nouveau problème à un endroit différent**

**TOUT cela signifie : ARRÊTEZ-VOUS. Retournez à la Phase 1.**

**Si 3 correctifs ou plus ont échoué :** Remettez en question l'architecture (voir Phase 4.5)

## Signaux de votre partenaire humain indiquant que vous vous y prenez mal

**Soyez attentif à ces recadrages :**
- « N'est-ce pas ce qui se passe ? » - Vous avez supposé sans vérifier
- « Est-ce que cela va nous montrer... ? » - Vous auriez dû ajouter des instruments de collecte de preuves
- « Arrête de deviner » - Vous proposez des correctifs sans comprendre
- « Réfléchis-y en profondeur » - Remettez en question les fondamentaux, pas seulement les symptômes
- « On est coincés ? » (frustré) - Votre approche ne fonctionne pas

**Lorsque vous constatez cela :** ARRÊTEZ-VOUS. Retournez à la Phase 1.

## Rationalisations courantes

| Excuse | Réalité |
|--------|---------|
| « Le problème est simple, pas besoin de processus » | Les problèmes simples ont aussi des causes racines. Le processus est rapide pour les bogues simples. |
| « C'est une urgence, pas le temps pour le processus » | Le débogage systématique est PLUS RAPIDE que de tâtonner au hasard. |
| « Essayons d'abord ça, puis j'enquêterai » | Le premier correctif donne le ton. Faites les choses bien dès le départ. |
| « J'écrirai le test après avoir confirmé que le correctif fonctionne » | Les correctifs non testés ne tiennent pas dans le temps. Le test préalable en apporte la preuve. |
| « Plusieurs correctifs à la fois fait gagner du temps » | Impossible d'isoler ce qui a fonctionné. Provoque de nouveaux bogues. |
| « La référence est trop longue, je vais adapter le modèle » | Une compréhension partielle garantit des bogues. Lisez-la intégralement. |
| « Je vois le problème, laisse-moi le corriger » | Voir les symptômes ≠ comprendre la cause racine. |
| « Encore une tentative de correctif » (après 2+ échecs) | 3+ échecs = problème architectural. Remettez en question le patron, n'appliquez pas un nouveau correctif. |

## Référence rapide

| Phase | Activités clés | Critères de succès |
|-------|----------------|-------------------|
| **1. Cause racine** | Lire les erreurs, reproduire, vérifier les changements, collecter des preuves | Comprendre QUOI et POURQUOI |
| **2. Motifs** | Trouver des exemples fonctionnels, comparer | Identifier les différences |
| **3. Hypothèse** | Formuler une théorie, tester a minima | Hypothèse confirmée ou nouvelle hypothèse |
| **4. Implémentation** | Créer un test, corriger, vérifier | Bogue résolu, tests au vert |

## Quand le processus ne révèle « aucune cause racine »

Si une enquête systématique révèle que le problème est véritablement lié à l'environnement, au timing ou à un facteur externe :

1. Vous avez mené le processus à son terme
2. Documentez ce que vous avez investigué
3. Implémentez la gestion appropriée (retry, timeout, message d'erreur)
4. Ajoutez de la surveillance/des logs pour les futures investigations

**Mais attention :** dans 95 % des cas, « pas de cause racine » signifie une enquête incomplète.

## Techniques complémentaires

Ces techniques font partie du débogage systématique et sont disponibles dans ce répertoire :

- **`root-cause-tracing.md`** - Remonter la pile d'appels pour trouver l'élément déclencheur initial d'un bogue
- **`defense-in-depth.md`** - Ajouter de la validation à plusieurs niveaux après avoir trouvé la cause racine
- **`condition-based-waiting.md`** - Remplacer les délais d'attente arbitraires par un sondage sur condition
