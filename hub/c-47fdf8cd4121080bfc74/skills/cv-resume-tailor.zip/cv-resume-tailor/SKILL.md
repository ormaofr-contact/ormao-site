---
name: resume-tailor
description: Personnaliser le CV pour des offres d'emploi spécifiques tout en maintenant la véracité
---

# Adaptateur de CV (Resume Tailor)

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Personnaliser son CV pour une offre d'emploi spécifique
- Ajuster son CV pour correspondre aux exigences du poste
- Créer une version ciblée de son CV
- Mentionne : « adapter CV », « personnaliser CV », « rôle ciblé », « poste spécifique », « faire correspondre à l'offre »

À utiliser APRÈS job-description-analyzer pour savoir sur quoi mettre l'accent.

## Capacités principales

- Réorganiser les sections d'expérience par pertinence par rapport au poste ciblé
- Ajuster le résumé professionnel pour un poste spécifique
- Ajouter les mots-clés manquants de l'offre d'emploi
- Modifier les puces de réalisations pour correspondre aux exigences du poste
- Maintenir l'authenticité tout en optimisant la correspondance
- Créer plusieurs versions ciblées de CV

## La philosophie d'adaptation

**Principe clé :** Vous ne mentez pas et n'inventez rien — vous METTEZ EN VALEUR les aspects les plus pertinents de votre expérience réelle.

Voyez l'ensemble de votre expérience comme une bibliothèque de réalisations. L'adaptation consiste à sélectionner les livres qui correspondent le mieux à ce que chaque employeur recherche.

## Processus d'adaptation

### Étape 1 : Analyser l'offre (utiliser Job Description Analyzer en premier)
- Identifier les compétences requises et les mots-clés
- Noter les priorités de l'entreprise
- Comprendre les responsabilités principales du poste

### Étape 2 : Auditer votre CV
Pour chaque section, demandez-vous :
- Cela appuie-t-il ma candidature pour CE poste précis ?
- Y a-t-il une meilleure façon de formuler ceci pour CE travail ?
- Cela devrait-il être placé plus haut ou plus bas en priorité ?

### Étape 3 : Effectuer des ajustements stratégiques

**Résumé professionnel :** Réécrire pour refléter les exigences clés de l'offre

**Section Compétences :** Réorganiser pour placer les compétences les plus pertinentes en premier, ajouter les mots-clés manquants

**Expérience :** 
- Réorganiser les postes si un rôle moins récent est plus pertinent
- Permuter l'ordre des puces pour commencer par les réalisations les plus pertinentes
- Intégrer naturellement les mots-clés dans les puces existantes

**Formation :** Mettre en avant les cours pertinents, les certifications

## Guide d'adaptation section par section

### Résumé professionnel

C'est votre « pitch d'ascenseur » — personnalisez-le pour chaque candidature.

**Résumé générique (À ÉVITER) :**
```
Results-driven professional with 5 years of experience in business operations. Strong analytical and communication skills. Looking for a challenging opportunity to grow.
```

**Adapté pour un rôle de Responsable des opérations :**
```
Operations Manager with 5 years optimizing supply chain processes and reducing costs by 25%. Expertise in Lean Six Sigma, vendor management, and cross-functional team leadership. Track record of improving operational efficiency while maintaining quality standards.
```

**Adapté pour un rôle de Chef de projet (même personne) :**
```
Project Manager with 5 years leading cross-functional initiatives from concept to delivery. PMP-certified with expertise in Agile methodology, stakeholder management, and budget oversight. Track record of on-time, under-budget project delivery across $10M+ portfolios.
```

### Réorganisation de la section Compétences

**L'offre d'emploi met l'accent sur :** Analyse de données, SQL, Python, communication avec les parties prenantes

**Avant (Ordre générique) :**
```
Skills: Microsoft Office, Communication, Project Management, Python, SQL, Data Visualization, Leadership
```

**Après (Ordre adapté) :**
```
Skills: SQL, Python, Data Analysis, Data Visualization, Stakeholder Communication, Project Management, Microsoft Office
```

### Section Expérience

**Stratégie 1 : Réorganiser les postes**

Si votre poste le plus récent est moins pertinent qu'un poste antérieur :

**Avant :**
1. Coordinateur marketing (actuel, mais postule pour un rôle dans les données)
2. Analyste de données (précédent, hautement pertinent)

**Après :**
1. Analyste de données (identifié avec les dates, remonté en premier)
2. Coordinateur marketing (toujours inclus, mais secondaire)

**Stratégie 2 : Intervertir l'ordre des puces**

Commencez par les puces les plus pertinentes pour le rôle ciblé.

**Candidature à un rôle de management — Commencer par :**
- « Dirigé une équipe de 12... »
- « Géré un budget de 2 M$... »

**Candidature à un rôle technique — Commencer par :**
- « Développé un système automatisé... »
- « Analysé plus de 500 000 points de données... »

**Stratégie 3 : Ajuster le vocabulaire des puces**

Incorporez les mots-clés de l'offre d'emploi tout en restant fidèle à la réalité.

**L'offre d'emploi dit :** « gestion des parties prenantes » (stakeholder management)
**Votre puce indique :** « A travaillé avec diverses équipes »
**Version adaptée :** « Géré les relations avec les parties prenantes à travers 5 départements, assurant l'alignement sur les priorités du projet »

## Modèles d'adaptation

### Pour chaque candidature, créez :

```markdown
## RESUME TAILORING PLAN

**Target Position:** [Job Title]
**Company:** [Company Name]
**Match Score:** [From JD Analyzer]

### Summary Customization
**Current:** [Your current summary]
**Tailored:** [Rewritten for this role]

### Skills Reordering
**Current Order:** [List]
**New Order:** [Reordered list with added keywords]
**Keywords Added:** [New skills from JD]

### Experience Adjustments

**Job 1: [Title]**
- Bullet to emphasize: [Which bullet to lead with]
- Keyword to add: [What phrase to incorporate]
- Bullet to de-emphasize: [Move down or remove if space needed]

**Job 2: [Title]**
[Same structure]

### Other Adjustments
- Education: [Any relevant coursework to add]
- Certifications: [Any to highlight]
- Projects: [Relevant projects to include]
```

## Scénarios d'adaptation courants

### Scénario 1 : Rôle technique dans une entreprise non technologique

**Défi :** Ils recherchent des compétences techniques mais aussi un sens aigu des affaires

**Stratégie :**
- Mettre en avant les réalisations techniques en tête
- Inclure l'impact commercial/business dans chaque puce technique
- Ajouter « vulgarisé des concepts techniques pour les parties prenantes métier »

### Scénario 2 : Rôle de direction (mais vous avez fait à la fois contributeur individuel et management)

**Défi :** Démontrer son leadership sans perdre sa crédibilité technique

**Stratégie :**
- Résumé : Mettre l'accent sur le leadership
- Expérience : Ouvrir avec les puces de gestion d'équipe
- Conserver quelques puces techniques pour prouver que vous maîtrisez le travail sur le terrain

### Scénario 3 : Startup (mais vous avez travaillé dans de grandes entreprises)

**Défi :** Montrer que vous pouvez évoluer dans l'ambiguïté et être polyvalent

**Stratégie :**
- Mettre en valeur le travail interfonctionnel
- Insister sur la prise d'initiative et l'autonomie
- Montrer une capacité de résolution de problèmes ingénieuse et créative
- Atténuer l'importance des processus rigides et des grandes structures d'équipe

### Scénario 4 : Grande entreprise (mais vous avez travaillé dans des startups)

**Défi :** Montrer que vous savez travailler au sein d'une structure et à grande échelle

**Stratégie :**
- Mettre l'accent sur l'amélioration des processus
- Mettre en avant les réalisations qui ont été déployées à grande échelle
- Démontrer la collaboration entre équipes
- Ajouter des indicateurs démontrant l'impact à grande échelle

## Règles d'intégration des mots-clés

### À FAIRE :
- Ajouter des mots-clés qui décrivent fidèlement votre travail
- Utiliser la formulation exacte de l'offre d'emploi lorsqu'elle est exacte
- Placer les mots-clés naturellement en contexte
- Inclure les mots-clés à plusieurs endroits (résumé, compétences, expérience)

### À NE PAS FAIRE :
- Ajouter des compétences que vous ne possédez pas réellement
- Bourrer de mots-clés (répéter le même terme 10 fois)
- Créer un sens différent de votre expérience réelle
- Sacrifier la lisibilité au profit de la densité de mots-clés

## La frontière entre vérité et adaptation

**Adaptation acceptable :**
- Réorganiser des informations véridiques
- Mettre l'accent sur l'expérience pertinente
- Utiliser la terminologie standard du secteur
- Apporter du contexte à des déclarations vagues
- Aligner le style de langage avec l'offre d'emploi

**Inacceptable (mensonge) :**
- Ajouter des compétences que vous n'avez pas
- Modifier les chiffres ou les métriques
- Créer de fausses expériences
- Prétendre avoir occupé des titres que vous n'aviez pas
- Déclarer des certifications que vous ne possédez pas

## Gestion des versions

### Maintenir un CV maître
- Conserver UN SEUL document complet avec TOUTES vos expériences
- Inclure chaque puce que vous avez rédigée au fil du temps
- C'est votre « source de vérité »

### Créer des versions ciblées
- Nommer clairement les fichiers : "JohnSmith_Resume_ProductManager_TechCorp.pdf"
- Noter quelle version a été envoyée à quelle entreprise
- Sauvegarder les notes d'adaptation pour la préparation des entretiens

### Convention de nommage des versions
```
[LastName]_Resume_[TargetRole]_[Company]_[Date].pdf

Examples:
- Smith_Resume_PM_Google_Jan2024.pdf
- Smith_Resume_DataAnalyst_Meta_Jan2024.pdf
- Smith_Resume_General_Master.docx (your master file)
```

## Liste de contrôle rapide pour l'adaptation

Avant de soumettre un CV :

1. ✅ Le résumé mentionne l'intitulé exact du poste/de la fonction
2. ✅ Les 5 compétences principales correspondent aux 5 exigences clés de l'offre d'emploi
3. ✅ L'expérience la plus pertinente est positionnée en premier
4. ✅ La première puce de chaque poste répond à l'exigence principale de l'offre
5. ✅ Les mots-clés de l'offre apparaissent naturellement partout
6. ✅ La terminologie de l'entreprise/du secteur est utilisée correctement
7. ✅ Toutes les déclarations sont véridiques
8. ✅ Le fichier est nommé de manière appropriée
9. ✅ Le formatage ATS est conservé
10. ✅ Le document est sauvegardé pour référence lors de la préparation de l'entretien

## Format de sortie

Lors de l'adaptation d'un CV, fournissez :

```markdown
# TAILORED RESUME CHANGES

## Target: [Job Title] at [Company]

### Professional Summary
**Before:** [Original]
**After:** [Tailored version]
**Keywords Added:** [List]

### Skills Section
**New Order:** [Reordered list]
**Added:** [New keywords]
**Removed:** [If any, for space]

### Experience Changes

**[Company Name] - [Title]**
- Move bullet X to position 1
- Modify bullet Y: [Before → After]
- Add keyword "[phrase]" to bullet Z

[Repeat for each relevant job]

### Overall Changes Summary
- Keywords added: X
- Bullets modified: Y
- Sections reordered: Yes/No
- Estimated new match score: Z%
```

## Notes d'implémentation

- Toujours commencer avec le job-description-analyzer
- Conserver les modifications d'adaptation documentées pour la préparation aux entretiens
- Maintenir le CV maître comme source de vérité
- Ne jamais sacrifier la compatibilité ATS au profit de l'adaptation
- Tester la correspondance des mots-clés après l'adaptation
