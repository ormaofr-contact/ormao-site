---
name: reference-list-builder
description: Formater correctement les références professionnelles et préparer les documents de recommandation
---

# Générateur de liste de références

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A besoin de créer une liste de références professionnelles
- Souhaite de l'aide pour choisir les bonnes références
- A besoin de mettre en forme correctement ses références
- Prépare ses références pour des candidatures à un emploi
- Mentionne : « références », « liste de références », « références professionnelles », « contrôle de références » ("references", "reference list", "professional references", "reference check")

## Capacités principales

- Mettre en forme des listes de références professionnelles
- Guider la stratégie de sélection des références
- Préparer les documents de briefing pour les références
- Anticiper les questions posées lors du contrôle des références
- Gérer les situations délicates liées aux références
- Coordonner la prise de contact avec les références

## Stratégie de références

### Qu'est-ce qu'une bonne référence ?

**Références idéales :**
- Anciens managers directs (le plus important)
- Collègues plus expérimentés ayant observé votre travail
- Partenaires transversaux (inter-équipes)
- Clients
- Collaborateurs directs / subordonnés (pour les rôles de direction)
- Professeurs ou tuteurs académiques (pour les jeunes diplômés)

**Hiérarchie des références :**
1. **La plus précieuse :** Supérieur hiérarchique direct récent
2. **Très précieuse :** Dirigeants ou cadres supérieurs qui connaissent votre travail
3. **Précieuse :** Pairs et partenaires transversaux
4. **Acceptable :** Clients, prestataires, professeurs
5. **À éviter :** Amis, famille, contacts RH uniquement

### Qui éviter

- ❌ Employeur actuel (sans son accord préalable)
- ❌ Personnes qui vous connaissent à peine
- ❌ Références datant uniquement de plus de 10 ans
- ❌ Amis personnels (sauf demande explicite)
- ❌ Personnes susceptibles de donner un avis mitigé
- ❌ Toute personne que vous n'avez pas contactée à l'avance

## Format de la liste de références

### Format standard

```
PROFESSIONAL REFERENCES

Jane Smith
Senior Director of Product
TechCorp Inc.
Phone: (555) 123-4567
Email: jane.smith@techcorp.com
Relationship: Direct supervisor for 3 years (2020-2023)

John Doe
VP of Engineering
Previous Company
Phone: (555) 234-5678
Email: john.doe@previous.com
Relationship: Cross-functional partner on 5 major projects
```

### Informations à inclure

**Obligatoire :**
- Nom complet
- Intitulé du poste actuel
- Entreprise actuelle
- Numéro de téléphone
- Adresse e-mail professionnelle
- Votre lien professionnel avec cette personne

**Facultatif :**
- Lien vers le profil LinkedIn
- Meilleur moment pour la contacter
- Méthode de contact préférée

### Directives de mise en page

- Adoptez le même style que votre CV (polices, mise en forme)
- 3 à 5 références (plus uniquement si demandé)
- Page distincte du CV
- L'en-tête doit correspondre à celui du CV
- Incluez « Références » ou « Références professionnelles » comme titre

## Préparation des références

### Étape 1 : Demander l'autorisation

**Avant d'inscrire qui que ce soit :**
- Appelez ou envoyez un e-mail pour demander l'autorisation
- Confirmez ses coordonnées
- Expliquez le poste pour lequel vous postulez
- Évaluez sa volonté et son enthousiasme

**Script :**
```
"Hi [Name], I hope you're doing well! I'm applying for a [Role] position at [Company] and was wondering if you'd be comfortable serving as a reference for me. The role involves [brief description], and I think your perspective on [specific project/skill] would be particularly valuable. Would you be willing to speak with them if they reach out?"
```

### Étape 2 : Briefer vos références

**Envoyez-leur :**
- Une copie de votre CV
- La description du poste
- Les points clés que vous souhaitez mettre en avant
- Les projets spécifiques à mentionner
- Le calendrier prévisionnel de prise de contact

**Modèle d'e-mail de briefing :**
```
Subject: Reference Preparation - [Role] at [Company]

Hi [Name],

Thank you so much for agreeing to be a reference! Here's some context to help:

**The Role:** [Job title] at [Company]
**What they're looking for:** [Key requirements]

**Points I'm emphasizing:**
- [Achievement 1]
- [Achievement 2]
- [Skill they should mention]

**Our work together they might ask about:**
- [Project 1]
- [Project 2]

I've attached my resume and the job description for reference. They may reach out in the next [timeframe].

Please let me know if you have any questions, and thank you again!

Best,
[Your name]
```

### Étape 3 : Assurer le suivi

Une fois les références contactées :
- Remerciez vos références quel que soit le résultat
- Tenez-les informées de l'issue
- Proposez de leur rendre la pareille

## Gestion des situations particulières

### L'employeur actuel n'est pas au courant

**Options :**
- Demander si la vérification des références peut attendre une étape ultérieure
- Faire appel à des collègues qui ont quitté l'entreprise
- Être transparent : « Mon employeur actuel ne sait pas que je suis en recherche »
- Utiliser d'autres références professionnelles

### Le manager a quitté l'entreprise

**Options :**
- Le retrouver sur LinkedIn
- Utiliser son adresse e-mail ou son numéro de téléphone personnel
- Indiquer sa nouvelle entreprise dans la liste de références
- Préciser « Ancien manager, actuellement chez [Nouvelle entreprise] »

### Mauvaise relation avec un ancien manager

**Options :**
- Faire appel à un autre superviseur de ce même poste
- Utiliser des collègues plus expérimentés à la place
- Choisir des références issues d'autres expériences professionnelles
- Se préparer à expliquer la situation si la question est posée

### Expérience professionnelle limitée

**Options :**
- Professeurs ou tuteurs académiques
- Maîtres de stage
- Responsables d'organisations bénévoles
- Coachs ou mentors
- Contacts clients

### La référence ne donnera pas d'avis positif

**Ne l'utilisez pas.** Il vaut mieux avoir moins de références qu'une référence mitigée ou négative.

## Ce que demandent les recruteurs lors de la prise de références

### Questions fréquentes

**Performance :**
- « Comment décririez-vous le travail de [nom] ? »
- « Quelles étaient ses principales responsabilités ? »
- « Comment se situait sa performance par rapport aux attentes ? »

**Compétences :**
- « Quels sont ses plus grands points forts ? »
- « Quels aspects pourrait-il/elle améliorer ? »
- « Comment évalueriez-vous sa maîtrise de [compétence spécifique] ? »

**Style de travail :**
- « Comment gérait-il/elle la pression ou les délais ? »
- « Comment travaillait-il/elle avec l'équipe ? »
- « Comment gérait-il/elle les conflits ? »

**Personnalité et réembauche :**
- « Le/La réembaucheriez-vous ? »
- « Y a-t-il autre chose que je devrais savoir ? »
- « Comment se situe-t-il/elle par rapport à ses pairs ? »

### La question « Le/La réembaucheriez-vous ? »

**La question la plus importante.** Prévenez vos références qu'elle risque d'être posée et assurez-vous qu'elles peuvent y répondre avec enthousiasme.

## Modèle de liste de références

```
[YOUR NAME]
[Your Email] | [Your Phone]

PROFESSIONAL REFERENCES

[REFERENCE 1 - MOST SENIOR/RELEVANT]
[Name]
[Title]
[Company]
Phone: [Number]
Email: [Email]
Relationship: [How you worked together, dates]

[REFERENCE 2]
[Name]
[Title]
[Company]
Phone: [Number]
Email: [Email]
Relationship: [How you worked together, dates]

[REFERENCE 3]
[Name]
[Title]
[Company]
Phone: [Number]
Email: [Email]
Relationship: [How you worked together, dates]

---
References available upon request for additional contacts.
```

## Calendrier des références

### Quand fournir les références

- **Ne les incluez pas dans la candidature initiale** (sauf demande expresse)
- **Apportez-les en entretien** (gardez-les prêtes)
- **Fournissez-les lorsqu'on vous les demande** (généralement après l'entretien final)
- **Demandez toujours l'autorisation avant de les transmettre** (reconfirmez l'accord à chaque fois)

### Déroulement type

1. **Candidature :** « Références disponibles sur demande » (facultatif sur le CV)
2. **Premier entretien :** Avoir la liste prête mais ne pas la proposer spontanément
3. **Dernières étapes :** « Pouvez-vous fournir des références ? » → Partager la liste
4. **Contrôle des références :** L'entreprise contacte vos références
5. **Offre :** Recontacter les références pour les remercier

## Format de sortie

Lors de la création d'une liste de références :

```markdown
# REFERENCE LIST

## Reference Strategy
**Target Role:** [Position]
**Company:** [Company]

## Recommended References

### Primary References (Use These)

**Reference 1: [Name]**
- Current Title: [Title]
- Company: [Company]
- Contact: [Phone/Email]
- Relationship: [Description]
- Why: [What they can speak to]
- Key points to highlight: [Specific projects/skills]

**Reference 2: [Name]**
[Same format]

**Reference 3: [Name]**
[Same format]

### Backup References (If Needed)

**Reference 4: [Name]**
[Same format]

## Briefing Notes

### For Each Reference, Send:
- [ ] Resume
- [ ] Job description
- [ ] Key talking points
- [ ] Timeline

### Key Points to Emphasize
- [Point 1 - who should mention]
- [Point 2 - who should mention]

## Reference Outreach

### Permission Request Script
[Customized script]

### Briefing Email
[Draft briefing email]

### Thank You Template
[Post-check thank you message]
```

## Liste de contrôle des références

- ✅ Avoir 3 à 5 références prêtes
- ✅ Toutes les références ont donné leur accord
- ✅ Les coordonnées sont à jour et exactes
- ✅ Les références sont informées du poste spécifique visé
- ✅ Chaque référence dispose de votre CV et des points clés à aborder
- ✅ Au moins un supérieur direct est inclus
- ✅ Les références couvrent différents aspects de votre travail
- ✅ Les références sont enthousiastes (et pas simplement consentantes)
- ✅ Des références de secours sont identifiées
- ✅ Des messages de remerciement sont prévus
