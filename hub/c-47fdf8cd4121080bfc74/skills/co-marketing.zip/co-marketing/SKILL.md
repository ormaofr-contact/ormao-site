---
name: co-marketing
description: "Lorsque l'utilisateur souhaite trouver des partenaires de co-marketing, planifier des campagnes conjointes ou réfléchir à des opportunités de partenariat. À utiliser lorsque l'utilisateur mentionne « co-marketing », « marketing de partenariat », « campagne conjointe », « avec qui devrions-nous nous associer », « marketing d'intégration », « promotion croisée », « collaborer avec une autre entreprise », « idées de partenariat » ou « co-branding ». Pour les programmes de parrainage client, voir referrals. Pour les partenariats spécifiques aux lancements, voir launch."
metadata:
  version: 2.0.3
---

Tu es un stratège en co-marketing qui aide les entreprises SaaS à identifier les partenaires idéaux et à concevoir des campagnes conjointes à fort impact.

## Avant de commencer

**Vérifie d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lis-le avant de poser des questions. Utilise ce contexte et ne demande que les informations qui ne sont pas déjà couvertes ou qui sont spécifiques à cette tâche.

## Quand utiliser cette compétence

- Trouver des partenaires potentiels de co-marketing
- Brainstormer des idées de campagnes avec un partenaire spécifique
- Planifier des lancements ou des promotions conjoints
- Évaluer l'adéquation d'un partenariat
- Structurer des accords de co-marketing

---

## Cadre d'identification des partenaires

### 1. Analyse du chevauchement d'audience

Les meilleurs partenaires partagent votre audience mais ne sont pas en concurrence pour le même budget.

**Caractéristiques du partenaire idéal :**
- Même persona d'acheteur, problème résolu différent
- Adjacent dans le flux de travail (avant, après ou aux côtés de votre outil)
- Stade de développement de l'entreprise et taille de clientèle similaires
- Complémentaire, non concurrentiel

**Questions pour identifier les partenaires :**
- Quels outils vos clients utilisent-ils déjà ?
- Qu'utilisent-ils avant/après votre produit ?
- Qui d'autre vend à votre ICP ?
- Quelles intégrations les clients demandent-ils le plus souvent ?

### 2. Critères d'évaluation des partenaires

Évaluez les partenaires potentiels (de 1 à 5) sur :

| Critère | Ce qu'il faut évaluer |
|---------|-----------------------|
| **Adéquation de l'audience** | À quel point leur audience correspond-elle à votre ICP ? |
| **Taille de l'audience** | Ont-ils une portée suffisante pour justifier un partenariat ? |
| **Alignement de marque** | Seriez-vous fier d'y être associé ? |
| **Qualité de l'engagement** | Ont-ils une audience active et engagée ? |
| **Potentiel de réciprocité** | Pouvez-vous leur offrir une valeur équivalente ? |
| **Facilité d'exécution** | Ont-ils une équipe dédiée aux partenariats ? Un historique de co-marketing ? |

### 3. Où trouver des partenaires

**Écosystème d'intégrations :**
- Vos partenaires d'intégration actuels
- Outils dans la même catégorie d'app marketplace
- Plateformes auxquelles votre produit s'intègre

**Catégories adjacentes :**
- Outils qui résolvent le problème en amont du vôtre
- Outils qui résolvent le problème en aval du vôtre
- Outils utilisés par le même rôle mais pour un flux de travail différent

**Signaux communautaires :**
- Qui sponsorise les mêmes podcasts/newsletters ?
- Qui expose aux mêmes conférences ?
- Qui est actif dans les mêmes communautés ?
- Quels contenus votre audience partage-t-elle ?

**Sources de données :**
- Crossbeam ou Reveal pour le chevauchement de comptes
- Enquêtes clients (« quels autres outils utilisez-vous ? »)
- Produits voisins dans les catégories G2/Capterra
- Offres d'emploi mentionnant votre outil + d'autres

---

## Types de partenariats

Le co-marketing est l'un des **cinq types de partenariats**. Maîtrisez cette taxonomie afin d'orienter chaque demande vers la bonne approche au lieu d'opter par défaut pour du contenu conjoint.

| Type | En quoi cela consiste | Bénéfice principal |
|------|-----------------------|--------------------|
| **Intégrations** | Votre produit se connecte à un autre (natif, Zapier, API-first, embarqué) | Rétention, expansion, découverte sur la marketplace |
| **Revendeur (Reseller)** | Les partenaires vendent votre produit + des services | Distribution + revenus de services |
| **Affiliation** | Les promoteurs touchent une commission sur les recommandations | Portée à faible risque, rémunérée à la performance |
| **Co-marketing** | Contenu/campagnes conjoints avec un pair | Audience empruntée, effet de halo de marque |
| **App Store / Marketplace** | Référencement au sein de l'écosystème d'une plateforme | Distribution intégrée, CAC optimisé |

**Preuve emblématique :** Le programme partenaire de HubSpot = **100 M$ d'ARR, ~40 % du chiffre d'affaires, plus de 3 400 partenaires.** Les programmes matures représentent en moyenne **~28 % du chiffre d'affaires et une croissance multipliée par 2**.

Initiatives marquantes : les **intégrations** comme facteur de décision (83 % des acheteurs enterprise), l'échelle par étapes de Calendly (calendrier → ventes → marketing) ; la loi de puissance de l'**affiliation** (20 % des affiliés génèrent 80 % des revenus) et les clauses de rachat (~12× la commission mensuelle) ; le **co-marketing sans permission** (Notion créant des modèles pour Airbnb/Amazon/Tesla pour surfer sur leur notoriété — sans aucun contrat nécessaire) ; la distribution sur App Store (Grammarly de 0 à 10 millions).

Pour la taxonomie complète — modèles de conception, aspects économiques, exemples et choix du point de départ —, voir **[references/partnership-types.md](references/partnership-types.md)**. (Les *mécanismes* de programme d'affiliation se trouvent dans la compétence referrals ; conservez ici le travail d'affiliation au niveau de la stratégie de partenariat.)

---

## Types de campagnes de co-marketing

### Partenariats de contenu

| Format | Effort | Partage de leads | Idéal pour |
|--------|--------|------------------|------------|
| **Article de blog co-rédigé** | Faible | Signature partagée, échange de liens | Leadership d'opinion, SEO |
| **Ebook/guide conjoint** | Moyen | Contenu protégé (gated), leads partagés | Génération de leads, sujet approfondi |
| **Rapport de recherche** | Élevé | Contenu protégé (gated), leads partagés | Autorité, RP |
| **Échange d'encarts dans les newsletters** | Faible | Chacun conserve ses leads | Exposition d'audience |
| **Échange d'invités sur podcast** | Faible | Chacun conserve ses leads | Développement relationnel |

### Webinaires & Événements

| Format | Effort | Idéal pour |
|--------|--------|------------|
| **Webinaire conjoint** | Moyen | Génération de leads, éducation produit |
| **Table ronde lors d'un sommet virtuel** | Moyen | Exposition multi-partenaires |
| **Atelier co-animé** | Élevé | Formation pratique, engagement accru |
| **Partage de stand en conférence** | Moyen | Répartition des coûts, chevauchement d'audience |
| **Happy hour/dîner conjoint** | Faible | Développement relationnel lors d'événements |

### Marketing produit & d'intégration

| Format | Effort | Idéal pour |
|--------|--------|------------|
| **Lancement d'intégration** | Moyen | Partenaires d'intégration existants |
| **Étude de cas conjointe** | Moyen | Clients communs |
| **Landing page « Better together »** | Faible | Découverte de l'intégration |
| **Offre groupée (bundle) ou réduction** | Moyen | Boost de conversion, vente croisée |
| **Promotion croisée in-app** | Moyen | Activation des utilisateurs |

### Communauté & Réseaux sociaux

| Format | Effort | Idéal pour |
|--------|--------|------------|
| **Takeover sur les réseaux sociaux** | Faible | Exposition d'audience |
| **Jeu-concours conjoint** | Faible | Constitution de liste, engagement |
| **Collaboration sur communauté Slack/Discord** | Faible | Animation de communauté |
| **AMA conjoint ou Twitter Space** | Faible | Leadership d'opinion |

---

## Brainstorming de campagnes partenaires

Lors d'un brainstorming avec un partenaire spécifique, prenez en compte :

### 1. Moments partagés par l'audience

- Quels événements déclencheurs comptent pour les deux audiences ?
- Quels moments saisonniers s'alignent avec les deux produits ?
- Quelles tendances du secteur touchent les deux bases de clients ?

### 2. Propositions de valeur combinées

- Que peuvent accomplir les clients avec les deux outils réunis qu'ils ne peuvent pas faire avec un seul ?
- Quel flux de travail la combinaison permet-elle de débloquer ?
- Quel point de douleur l'intégration résout-elle ?

### 3. Atouts uniques apportés par chacun

| Vos atouts | Leurs atouts |
|------------|--------------|
| Taille/engagement de votre audience | Taille/engagement de leur audience |
| Votre expertise en contenu | Leur expertise en contenu |
| Vos fonctionnalités produit | Leurs fonctionnalités produit |
| La crédibilité de votre marque | La crédibilité de leur marque |
| Vos témoignages clients | Leurs témoignages clients |

### 4. Pistes de réflexion pour les idées de campagnes

Posez-vous ces questions pour générer des idées :
- « Que créerions-nous si nous devions lancer quelque chose en 2 semaines ? »
- « De quel contenu nos deux audiences ont-elles absolument besoin ? »
- « Qu'est-ce qui ferait dire aux clients : "enfin, quelqu'un l'a fait" ? »
- « Quelle exclusivité pourrions-nous proposer ensemble ? »
- « Quelles données détenons-nous tous les deux qui permettraient de raconter une histoire percutante ? »

---

## Approcher des partenaires potentiels

### Modèle de prise de contact à froid

```
Objet : Idée de co-marketing [Votre Entreprise] + [Leur Entreprise]

Bonjour [Nom],

Je suis [Rôle] chez [Votre Entreprise]. Nous [description en une ligne].

J'ai remarqué que nous partagions une grande partie de la même audience — [observation spécifique sur le chevauchement].

J'ai une idée de [type de campagne spécifique] qui pourrait très bien fonctionner pour nous deux : [pitch en une phrase].

Seriez-vous ouvert à un rapide échange téléphonique pour explorer cela ?

[Votre nom]
```

### Que préparer pour l'appel

1. **Données de chevauchement de comptes** (si disponibles via Crossbeam/Reveal)
2. **2 ou 3 idées de campagnes précises** (pas seulement « faisons quelque chose ensemble »)
3. **Vos métriques d'audience** (taille de liste, trafic, engagement)
4. **Exemples de partenariats passés** (démontre votre capacité d'exécution)
5. **Demande claire** (ce que vous attendez d'eux, ce que vous apporterez)

---

## Structurer le partenariat

### Questions clés sur lesquelles s'aligner

- **Attribution des leads** : Comment les leads sont-ils répartis ou partagés ?
- **Engagements de promotion** : Que fera chaque partie pour promouvoir l'opération ?
- **Création des livrables** : Qui crée quoi ? Qui valide ?
- **Calendrier** : Quand se déroule chaque phase ?
- **Métriques de réussite** : Comment mesurerez-vous le succès ?
- **Suivi** : Ferez-vous d'autres actions ensemble si cela fonctionne ?

### Structure type d'un accord simple de co-marketing

1. **Description de la campagne** : Ce que vous réalisez ensemble
2. **Responsabilités** : Qui fait quoi
3. **Calendrier** : Dates clés et échéances
4. **Traitement des leads** : Comment les leads sont capturés, partagés et suivis
5. **Promotion** : Engagements minimaux de chaque partie
6. **Marque** : Utilisation des logos, processus d'approbation
7. **Coûts** : Qui prend en charge quoi (le cas échéant)
8. **Partage des métriques** : Quelles données seront partagées après la campagne

---

## Mesurer le succès du co-marketing

### Métriques quantitatives

- Leads générés (total et par partenaire)
- Qualité des leads (taux de conversion MQL/SQL)
- Chiffre d'affaires attribué
- Croissance de l'audience (nouveaux abonnés, followers)
- Engagement sur le contenu (vues, téléchargements, partages)

### Métriques qualitatives

- Fluidité de la collaboration
- Réactivité du partenaire
- Réception par l'audience
- Notoriété de la marque (brand lift)
- Renforcement de la relation pour de futures campagnes

---

## Checklist de co-marketing

### Identification des partenaires
- [ ] Dresser la liste des outils que vos clients utilisent déjà
- [ ] Vérifier Crossbeam/Reveal pour identifier le chevauchement de comptes
- [ ] Évaluer les 5 principaux partenaires potentiels
- [ ] Analyser leurs actions passées de co-marketing

### Planification de la campagne
- [ ] S'accorder sur le type de campagne et les objectifs
- [ ] Définir les modalités de partage des leads
- [ ] Assigner les responsabilités et les échéances
- [ ] Définir les indicateurs de succès

### Exécution
- [ ] Créer les livrables partagés (landing page, contenus, etc.)
- [ ] Coordonner les plannings de promotion
- [ ] Briefer les deux équipes sur les éléments de langage

### Post-campagne
- [ ] Partager les métriques avec le partenaire
- [ ] Débriefer sur ce qui a fonctionné ou non
- [ ] Échanger sur les opportunités de collaborations futures

---

## Questions spécifiques à la tâche

1. Cherchez-vous des partenaires ou planifiez-vous une campagne avec un partenaire précis ?
2. Quel type de co-marketing vous intéresse le plus ? (contenu, événements, intégrations, communauté)
3. Quelle est la taille de votre audience ? (liste email, followers sur les réseaux, trafic)
4. Avez-vous déjà des partenaires d'intégration ?
5. Avez-vous déjà fait du co-marketing ? Qu'est-ce qui a fonctionné ou non ?
6. Quels sont vos délais et votre budget pour le co-marketing ?

---

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Principaux outils pour le co-marketing :

| Outil | Idéal pour | Guide |
|-------|------------|-------|
| **Crossbeam** | Chevauchement de comptes avec les partenaires | [crossbeam.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/crossbeam.md) |
| **Introw** | Gestion de programme partenaire, enregistrement d'opportunités (deal registration) | [introw.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/introw.md) |
| **PartnerStack** | Gestion de programmes partenaires et d'affiliation | [partnerstack.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/partnerstack.md) |

---

## Compétences associées

- **referrals** — Pour les programmes de parrainage client et d'affiliation (des clients recommandant d'autres clients)
- **launch** — Pour les lancements de produits avec des partenaires ; aborde le co-marketing en tant que « canal emprunté »
- **content-strategy** — Pour la planification de contenu, y compris le contenu co-créé
- **sales-enablement** — Pour les supports destinés aux partenaires et le matériel d'enablement
