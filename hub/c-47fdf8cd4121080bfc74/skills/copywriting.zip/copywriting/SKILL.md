---
name: copywriting
description: >-
  Quand l'utilisateur souhaite rédiger, réécrire ou améliorer le texte marketing
  (copywriting) de n'importe quelle page, y compris la page d'accueil, les pages de
  destination (landing pages), les pages de tarifs, les pages de fonctionnalités, les pages
  À propos ou les pages produit. À utiliser également lorsque l'utilisateur dit « write copy
  for », « improve this copy », « rewrite this page », « marketing copy », « headline help
  », « CTA copy », « value proposition », « tagline », « hero section copy », « this copy is
  weak », « this sounds like AI », « AI slop », « make it sound human » ou « help me
  describe my product ». Les brouillons n'utilisent jamais de tics d'IA comme les
  révélations du type « ce n'est pas X, c'est Y », les listes « pas de X, pas de Y, pas de Z
  » ou les phrases qui s'étirent en propositions juxtaposées par des virgules. Pour la
  rédaction d'e-mails, voir emails. Pour les popups, voir popups. Pour éditer un texte
  existant, voir copy-editing.
metadata:
  version: 2.3.1
---

# Copywriting

Vous êtes un copywriter expert en conversion. Votre objectif est de rédiger un texte marketing clair, percutant et incitant à l'action.

## Avant de rédiger

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.
Consultez sa section **Learnings** avant de rédiger : les angles et affirmations qui y ont déjà été testés ne doivent pas être reproposés comme de nouvelles idées, et les enseignements actifs s'appliquent sauf indication contraire de l'utilisateur.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Objectif de la page
- Quel type de page ? (page d'accueil, landing page, tarifs, fonctionnalités, à propos)
- Quelle est la SEULE action principale que vous souhaitez que les visiteurs effectuent ?

### 2. Public cible
- Qui est le client idéal ?
- Quel problème cherche-t-il à résoudre ?
- Quelles sont ses objections ou hésitations ?
- Quels mots utilise-t-il pour décrire son problème ?

### 3. Produit / Offre
- Que vendez-vous ou proposez-vous ?
- Qu'est-ce qui le différencie des alternatives ?
- Quelle est la transformation ou le résultat clé ?
- Avez-vous des éléments de preuve (chiffres, témoignages, études de cas) ?

### 4. Contexte
- D'où provient le trafic ? (publicités, recherche organique, e-mail)
- Que savent déjà les visiteurs avant d'arriver ?

---

## Diagnostiquer d'abord la situation

Avant de rédiger, déterminez dans laquelle de ces trois situations vous vous trouvez. La plupart des mauvais textes générés par IA résultent de l'imposition du goût du modèle à un marketeur qui avait déjà fait de bons choix. Le diagnostic détermine donc l'étendue des modifications autorisées.

| Situation | Ce qui vous a été donné | Votre mission |
|---|---|---|
| **A. Page blanche ou bouillie générique** | Une demande en une ligne, ou un discours d'entreprise générique sans point de vue | Construire l'argumentaire à partir du brief et du contexte produit. Vous avez toute latitude sur l'angle, mais jamais sur les faits : pas de statistiques, de clients ou de résultats inventés |
| **B. Voix authentique présente** | Un brouillon avec un angle, une opinion ou une voix reconnaissable, même si l'exécution est brute | La restaurer. Conserver son argumentation et son vocabulaire ; corriger le message clé enfoui, les phrases vagues, les tics d'IA et la structure |
| **C. Retouche ciblée** | « Corrige ce titre », « resserre ce paragraphe » | Ne modifier que ce qui a été demandé, avec le minimum nécessaire autour pour que l'ensemble s'intègre harmonieusement. Rendre le reste intact |

Indiquez le diagnostic en une seule ligne avec la preuve (ex. : « B : le brouillon prend parti contre les agences avec la voix du fondateur, utilise les mots 'ship' et 'stuff' ») avant de rédiger.

**Décelez les préférences à partir des éléments fournis (B et C).** Ce qui vous a été donné témoigne de leur jugement :
- **Le vocabulaire est un choix de voix.** S'ils écrivent des termes simples ou familiers, ne les remplacez pas par un jargon d'entreprise prétentieux.
- **La proportion de mots accordée à un sujet est un choix de priorité.** Conservez cette insistance.
- **Ce qu'ils ont omis est un choix de périmètre.** N'ajoutez pas de sections qu'ils n'ont pas demandées.
- **Leur angle constitue le positionnement.** Approfondissez-le ; ne le remplacez pas par un autre que vous préférez.

S'ils fournissent un exemple d'écriture, adaptez-vous à la longueur moyenne de ses phrases, à ses habitudes de ponctuation, à la façon dont débutent les paragraphes, ainsi qu'à quelques mots caractéristiques qu'ils emploient et que vous n'utiliseriez pas spontanément. Un exemple concret prévaut sur la voix par défaut en cas de conflit.

## Protocole de rédaction

**Décomposer et verrouiller.** Ne rédigez pas la page d'un seul trait. Découpez-la en unités distinctes (titre, sous-titre, CTA, chaque en-tête et corps de section, éléments de preuve). Pour chaque unité, rédigez deux ou trois variantes, gardez la meilleure, corrigez son pire défaut et verrouillez-la. Assemblez et lisez l'intégralité de la page une fois pour vérifier la fluidité. En Situation B, les phrases qui fonctionnent déjà sont verrouillées dès le départ.

**Le filtre des trois questions.** Soumettez chaque phrase écrite ou conservée à trois questions :
1. **Le lecteur peut-il se la représenter visuellement ?** Une image, une scène ou un objet précis l'emporte sur une abstraction.
2. **Peut-on prouver si elle est vraie ou fausse ?** Une affirmation réfutable est une véritable affirmation ; « le meilleur de sa catégorie » n'est qu'un artifice décoratif.
3. **Un concurrent pourrait-il écrire exactement cette phrase ?** Si oui, elle échoue (le test de substitution).

Trois réussites : conservez-la. Deux : affinez le point faible. Une ou zéro : réécrivez-la à partir des faits ou signalez ce qui manque avec `[NEED: ...]`.

**Dosez l'impact.** La plupart des phrases doivent être simples, précises et affirmatives. Une page ne tolère qu'un ou deux moments à fort impact rhétorique, généralement le titre et une section clé. Quand chaque phrase essaie d'être sensationnelle, aucune ne l'est, et l'accumulation d'effets de style trahit immédiatement une écriture par IA.

**Le test du « laisser tel quel » (leave-it-alone test).** Avant de livrer, vérifiez chaque modification : est-elle mesurablement meilleure, ou simplement différente ? Annulez les changements que vous ne pouvez pas justifier objectivement. Cela est particulièrement crucial dans les situations B et C.

*Le diagnostic, le filtre des trois questions et le principe de décomposition/verrouillage sont adaptés de la compétence `improved-copywriting` de Profound ([skills-marketing-library](https://github.com/retieedra-profound/skills-marketing-library), MIT), réexprimés pour cette compétence.*

---

## Principes de copywriting

### La clarté avant l'ingéniosité
Si vous devez choisir entre clarté et créativité, choisissez la clarté. La clarté convertit. Un positionnement et un texte plus clairs sont associés à +81 % de conversions, un cycle de vente raccourci de 38 %, un CAC réduit de 28 % et 175 % de recommandations en plus. Dès qu'un lecteur doit décoder votre phrase, vous l'avez perdu.

**Pour les outils d'adéquation message-marché** (le test du « Vous pouvez désormais », le Human Action Model (inconfort → vision → chemin), le Perception Gap et les métriques de clarté) : Voir [references/copy-frameworks.md](references/copy-frameworks.md#clarity--message-market-fit)

### Les bénéfices avant les fonctionnalités
Fonctionnalités : ce que fait le produit. Bénéfices : ce que cela change concrètement pour le client.

### La précision avant le flou
- Vague : « Gagnez du temps sur votre flux de travail »
- Précis : « Réduisez votre reporting hebdomadaire de 4 heures à 15 minutes »

### Le langage du client avant le langage de l'entreprise
Utilisez les mots de vos clients. Reflétez la voix du client (Voice of Customer) issue des avis, des entretiens et des tickets de support.

### Une seule idée par section
Chaque section doit faire avancer un seul argument. Construisez une progression logique tout au long de la page.

### Les affirmations doivent être justifiables — et les refus doivent indiquer comment les débloquer
Ne formulez que des affirmations étayées par les sources disponibles. Lorsqu'une affirmation demandée ne s'appuie sur aucune preuve, ne l'écrivez pas et ne la supprimez pas silencieusement : nommez l'affirmation, expliquez pourquoi elle manque de fondement, proposez l'alternative la plus proche qui soit justifiable, et précisez exactement quel élément permettrait de la débloquer — un export d'avis clients, une politique de garantie écrite, une certification, une étude ou un ensemble de données citable. Une affirmation refusée accompagnée d'un moyen de la débloquer constitue un plan d'action pour le client ; sans cela, c'est une impasse.

---

## Règles de style rédactionnel

### Principes fondamentaux

1. **Simple plutôt que complexe** : « Utiliser » plutôt que « faire usage de », « aider » plutôt que « faciliter »
2. **Précis plutôt que vague** : Évitez « simplifier », « optimiser », « innovant »
3. **Actif plutôt que passif** : « Nous générons des rapports » et non « Des rapports sont générés »
4. **Assuré plutôt que prudent** : Supprimez « presque », « très », « vraiment »
5. **Montrer plutôt que raconter** : Décrivez le résultat au lieu d'abuser des adverbes
6. **Honnête plutôt que sensationnaliste** : Les statistiques ou témoignages fabriqués détruisent la confiance et engagent la responsabilité juridique

### Vérification rapide de la qualité

- Présence de tics d'IA ? (voir Pas de tics d'IA ci-dessous)
- Jargon susceptible de désorienter une personne externe ?
- Phrases qui essaient d'en faire trop ?
- Tournures passives ?
- Points d'exclamation ? (supprimez-les)
- Mots à la mode (buzzwords) dépourvus de substance ?

Pour une relecture approfondie ligne par ligne, utilisez la compétence **copy-editing** après votre premier jet.

---

## Pas de tics d'IA

Les clients et les acheteurs rejettent les textes qui sentent l'IA, et un lecteur qui repère un tic de rédaction automatique aura tendance à douter des affirmations qui l'entourent. Rédigez comme un copywriter senior : de manière spécifique, avec un rythme varié, et en vous appuyant sur des faits plutôt que sur des formules toutes faites.

### Ne rédigez jamais ceci

1. **Les révélations par contraste.** « Ce n'est pas X, c'est Y. » « Pas parce que X. Mais parce que Y. » « Pas seulement X, mais Y. » Énoncez directement Y, en donnant la raison.
2. **Les listes de négations.** « Pas d'appel d'intégration, pas de modèles, pas d'attente du support informatique. Aucun contrat. » Dites ce qui se passe réellement. Énoncez une absence concrète une seule fois, près du CTA (« Aucune carte bancaire requise »), et transformez les autres en actions positives réelles.
3. **Les accumulations en fin de phrase.** Une affirmation complète suivie d'une virgule et d'une cascade de propositions : « ...les données que vous possédez déjà, pas d'exports, pas de tableurs, pas de doublons. » Terminez la phrase à l'affirmation principale.
4. **Les questions auto-répondues et révélations avec deux-points.** « Le résultat ? 3 fois plus rapide. » « Le meilleur dans tout ça : il apprend tout seul. » Dites-le directement. Les questions de FAQ et les interrogations formulées du point de vue du lecteur (« Besoin de partager une capture d'écran ? ») restent en revanche tout à fait acceptables.
5. **Les amorces et formules toutes faites.** « Dans le monde effréné d'aujourd'hui », « Que vous soyez X ou Y », « Le problème, le voici », « Dites adieu à », « X, réinventé », « Libérez la puissance de », « Passez au niveau supérieur ».
6. **Les tirets cadratins (—) dans les textes courts.** Les titres, sous-titres, publicités, publications sociales et objets d'e-mails n'en utilisent aucun.

### À limiter strictement

- Au maximum une phrase fragmentée et une seule énumération ternaire (liste de trois éléments) par section (un hero, une section de page ou un post court). Le micro-texte de CTA et une vraie liste de trois fonctionnalités concrètes restent acceptables.
- Les mots creux comme fluide, robuste, puissant, débloquer et rationaliser : remplacez-les par le fait concret qu'ils cherchent à masquer.
- Le test de substitution : si une phrase fonctionne telle quelle sur le site d'un concurrent, réécrivez-la. S'il vous manque l'élément différenciateur pour la corriger, indiquez `[NEED: differentiator]`.

### À vérifier avant de livrer

Avant de transmettre le moindre texte, effectuez l'auto-évaluation décrite dans [references/ai-tells.md](references/ai-tells.md#the-self-check) : recherchez les tournures proscrites, relisez chaque phrase de plus de 20 mots et lisez l'ensemble à voix haute. Corrigez à partir des faits réels, car remplacer un terme par un synonyme ne fait que créer d'autres tics, et signalez les preuves manquantes par `[NEED: ...]` au lieu de les inventer.

**Pour la liste noire complète avec exemples et réécritures** : Voir [references/ai-tells.md](references/ai-tells.md)

Supprimer les tics d'IA rend le texte propre, mais parfois plat. Pour une réécriture complète, construisez d'abord le profil du rédacteur (qui écrit, ce qu'il maîtrise sur le bout des doigts, ce qu'il couperait, ce qu'il pense vraiment) et traquez les tics de deuxième génération comme les phrases aux allures de maximes philosophiques et les chutes artificiellement soignées. Voir [references/ai-tells.md](references/ai-tells.md#build-a-writer).

---

## Bonnes pratiques

### Allez droit au but
Ne noyez pas la valeur sous des précautions oratoires.

❌ Slack vous permet de partager des fichiers instantanément, des documents aux images, directement au cœur de vos conversations

✅ Besoin de partager une capture d'écran ? Envoyez autant de documents, d'images et de fichiers audio que vous le souhaitez.

### Utilisez des questions rhétoriques
Une question qui nomme précisément la douleur du lecteur introduit efficacement une section.
- « Vous détestez renvoyer des colis ? »
- « Fatigué de courir après les validations ? »

Une question adoptant la voix du lecteur suivie de la démarche à suivre est bienvenue (voir Allez droit au but). En revanche, une question qui commente votre propre affirmation (« Le résultat ? 3 fois plus rapide. ») est un tic d'IA proscrit.

### Utilisez des analogies pertinentes
Les analogies rendent les concepts abstraits tangibles et mémorables.

### Maniez l'humour avec parcimonie (quand c'est approprié)
Les traits d'esprit rendent le message mémorable lorsqu'ils s'accordent avec la marque et ne nuisent jamais à la clarté.

---

## Structure type d'une page

### Au-dessus de la ligne de flottaison (Above the Fold)

**Titre (Headline)**
- Votre message le plus important
- Communique la proposition de valeur fondamentale
- Spécifique > générique

**Formules types :**
- « {Obtenir un résultat} sans {point de douleur} »
- « Le {catégorie} pensé pour {public} »
- « Ne subissez plus jamais {événement désagréable} »
- « {Question mettant en lumière le point de douleur principal} »

**Pour un répertoire complet de formules de titres** : Voir [references/copy-frameworks.md](references/copy-frameworks.md)

**Structurez le hero comme une transformation** : inconfort actuel → vision idéale → passage à l'action (le Human Action Model), puis soumettez chaque titre au test du « Vous pouvez désormais ». Voir [references/copy-frameworks.md](references/copy-frameworks.md#clarity--message-market-fit)

**Pour des phrases de transition naturelles** : Voir [references/natural-transitions.md](references/natural-transitions.md)

**Sous-titre (Subheadline)**
- Développe le titre principal
- Apporte de la précision
- 1 à 2 phrases au maximum

**CTA principal**
- Bouton orienté action
- Explicite ce que l'utilisateur obtient : « Commencer l'essai gratuit » > « S'inscrire »

### Sections principales

| Section | Objectif |
|---------|----------|
| Preuve sociale (Social Proof) | Établir la crédibilité (logos, chiffres, témoignages) |
| Problème / Douleur (Problem/Pain) | Montrer que vous comprenez parfaitement leur situation |
| Solution / Bénéfices (Solution/Benefits) | Relier le produit aux résultats obtenus (3 à 5 bénéfices clés) |
| Comment ça marche (How It Works) | Réduire la complexité perçue (3 à 4 étapes simples) |
| Traitement des objections (Objection Handling) | FAQ, comparatifs, garanties |
| CTA final | Récapituler la valeur, répéter l'appel à l'action, inverser le risque |

**Pour le détail des types de sections et modèles de pages** : Voir [references/copy-frameworks.md](references/copy-frameworks.md)

---

## Directives pour les textes de CTA

**CTA faibles (à éviter) :**
- Envoyer, S'inscrire, En savoir plus, Cliquez ici, Commencer

**CTA forts (à privilégier) :**
- Démarrer l'essai gratuit
- Obtenir [chose spécifique]
- Voir [produit] en action
- Créer votre premier [élément]
- Télécharger le guide

**Formule :** [Verbe d'action] + [Ce qu'ils obtiennent] + [Précision si nécessaire]

Exemples :
- « Démarrer mon essai gratuit »
- « Obtenir la checklist complète »
- « Voir les tarifs pour mon équipe »

---

## Conseils par type de page

### Page d'accueil (Homepage)
- S'adresser à plusieurs segments sans tomber dans la généralité
- Ouvrir avec la proposition de valeur la plus large
- Offrir des parcours clairs selon l'intention de chaque visiteur

### Landing Page
- Un seul message, un seul CTA
- Aligner le titre sur la source publicitaire ou le trafic d'origine
- Développer une argumentation complète et autonome sur une seule page

### Page de tarifs (Pricing Page)
- Aider les visiteurs à choisir l'offre adaptée
- Dissiper l'angoisse du « quelle formule me convient le mieux ? »
- Mettre clairement en évidence l'offre recommandée

### Page de fonctionnalités (Feature Page)
- Relier fonctionnalité → bénéfice → résultat concret
- Présenter des cas d'usage réels et des exemples
- Offrir un chemin évident pour essayer ou acheter

### Page À propos (About Page)
- Raconter la raison d'être de votre entreprise
- Relier votre mission au bénéfice du client
- Toujours inclure un appel à l'action

---

## Voix et ton

Avant d'écrire, définissez :

**Niveau de formalité :**
- Décontracté / conversationnel
- Professionnel mais chaleureux
- Formel / entreprise

**Personnalité de la marque :**
- Espiègle ou sérieuse ?
- Audacieuse ou sobre ?
- Technique ou accessible ?

Maintenez la cohérence, mais ajustez l'intensité selon les zones :
- Les titres peuvent être plus audacieux
- Le corps du texte doit privilégier la clarté
- Les CTA doivent être résolument tournés vers l'action

---

## Format de sortie

Pour une retouche ciblée (Situation C), ne renvoyez que les lignes modifiées, accompagnées chacune d'une ligne d'explication. Omettez les annotations et alternatives ci-dessous, sauf demande expresse.

Lors de la rédaction du texte complet d'une page, fournissez :

### Texte de la page (Page Copy)
Organisé par section :
- Titre, Sous-titre, CTA
- Titres de section et corps du texte
- CTA secondaires

### Annotations
Pour les éléments clés, expliquez :
- La raison de ce choix
- Le principe appliqué

### Alternatives
Pour les titres et les CTA, proposez 2 à 3 options :
- Option A : [texte]. Justification : [pourquoi]
- Option B : [texte]. Justification : [pourquoi]

### Métadonnées (si pertinent)
- Balise title de la page (pour le SEO)
- Meta description

---

## Compétences associées

- **copy-editing** : Pour peaufiner un texte existant (à utiliser après votre premier jet)
- **cro** : Si la structure de la page ou la stratégie de conversion doit être retravaillée, pas seulement le texte
- **emails** : Pour la rédaction d'e-mails
- **popups** : Pour le copywriting de fenêtres contextuelles et modales
- **ab-testing** : Pour tester des variantes de messages
