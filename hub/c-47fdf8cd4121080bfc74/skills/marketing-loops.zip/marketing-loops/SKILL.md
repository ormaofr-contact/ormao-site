---
name: marketing-loops
description: >-
  Lorsque l'utilisateur souhaite mettre en place un flux de travail marketing récurrent et
  autonome — une boucle reproductible qu'un agent IA exécute selon une cadence
  (hebdomadaire, quotidienne, sur déclencheur) plutôt qu'une tâche ponctuelle. À utiliser
  également lorsque l'utilisateur mentionne « marketing loop », « flux de travail marketing
  récurrent », « automatiser mon marketing », « marketing en pilote automatique », « revue
  marketing hebdomadaire », « vérification de la fatigue publicitaire », « contrôle hebdo
  des pubs », « boucle de rafraîchissement de contenu », « surveillance du churn », « alerte
  baisse de classement », « gérer mon SEO », « opérateur SEO », « agent SEO quotidien », «
  gérer mon outbound », « SDR IA », « tri des réponses », « marketing permanent » ou «
  exécute ceci chaque semaine ». Utilisez cette compétence pour choisir, adapter et
  planifier une boucle marketing continue qui orchestre les autres compétences marketing.
metadata:
  version: 1.6.1
---

# Boucles marketing (Marketing Loops)

Vous aidez à mettre en place des **boucles marketing** — des flux de travail marketing reproductibles qu'un agent IA exécute selon une cadence définie, chacun doté d'un déclencheur précis, d'un ensemble d'étapes délimité, d'une auto-vérification et d'une condition d'arrêt explicite. Une boucle transforme une tâche marketing que vous feriez autrement manuellement (et que vous oublieriez) en un système permanent : l'analyse hebdomadaire des opportunités SEO, le renouvellement des créations publicitaires fatiguées, la surveillance des signaux d'attrition (churn).

C'est le pendant opérationnel de `marketing-ideas`. Les idées vous indiquent *ce qu'il faut tester une fois*. Les boucles vous indiquent *ce qu'il faut continuer à faire de manière régulière* — et articulent les autres compétences marketing entre elles pour y parvenir.

## Comment utiliser cette compétence

**Vérifiez d'abord le contexte de product marketing :** si le fichier `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien `product-marketing-context.md`), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement ce qui manque.

Ensuite :
1. **Clarifiez l'objectif.** Quel résultat cette boucle doit-elle protéger ou développer ? (classement/positions, efficacité publicitaire, activation, rétention, revenus, parrainages)
2. **Choisissez une boucle** dans le catalogue de `references/loop-catalog.md` — ou adaptez la plus proche.
3. **Ajustez la cadence** en fonction de la vitesse réelle de variation du signal sous-jacent (voir la règle de cadence ci-dessous).
4. **Confirmez le point de contrôle humain.** Décidez de ce que la boucle exécute de manière autonome par rapport à ce qu'elle prépare pour validation humaine avant publication ou dépense — voir `references/loop-guardrails.md`.
5. **Planifiez-la** (voir « Planifier une boucle » ci-dessous).

Vous construisez plusieurs boucles, ou tout un système d'exploitation marketing ? Consultez `references/loop-orchestration.md` pour savoir comment les boucles se composent et dans quel ordre les adopter (commencez par le tracking + une revue hebdomadaire ; ne les construisez pas toutes d'un coup).

## Anatomie d'une boucle marketing

Chaque boucle du catalogue comporte ces neuf éléments. Lorsque vous en concevez ou en adaptez une, renseignez-les tous — une boucle sans condition d'arrêt, sans auto-vérification ou sans gestion d'état est un risque, pas un atout.

| Élément | Ce qu'il définit |
|------|-----------------|
| **Cadence de vérification** | À quelle fréquence la boucle *observe* (hebdomadaire / quotidienne / sur déclencheur). Adaptez-la à la vitesse du signal. |
| **Déclencheur d'action** | La condition d'action — ce qui doit être vérifié pour *faire* réellement quelque chose, plutôt que de simplement vérifier et passer. La plupart des exécutions d'une bonne boucle se résument à « vérifié, rien à faire ». |
| **Objectif** | Le résultat unique que cette boucle a pour mission d'améliorer. |
| **Compétences utilisées** | Les compétences marketing que la boucle orchestre à chaque itération. |
| **Corps de la boucle** | Les étapes ordonnées exécutées à chaque itération. |
| **Auto-vérification** | La vérification effectuée *avant* d'agir — afin que la boucle n'agisse pas sur du bruit, un effet de saisonnalité ou un bug de tracking. |
| **État / idempotence** | Ce que la boucle mémorise entre deux exécutions : marqueur de dernière exécution, clé de déduplication, période de temporisation (cooldown), ensemble des éléments « déjà traités ». Sans cela, les boucles agissent deux fois, relancent les mêmes personnes ou renvoient la même alerte. Non négociable pour toute tâche planifiée — voir `references/loop-state.md` pour savoir où réside l'état et les schémas d'idempotence. |
| **Arrêt / sortie d'urgence** | Quand la boucle ignore, s'arrête, escalade à un humain ou se désactive — ainsi que son comportement en cas d'erreur. Chaque boucle en a besoin d'un, y compris les boucles de type pulsation/heartbeat (leur arrêt est « désactivation manuelle + arrêt sur erreur », jamais « n/a »). |
| **Sortie (Output)** | Où vont les résultats : un fichier, une PR, un brouillon en attente, une notification, un rapport. |

La distinction entre **Cadence de vérification / Déclencheur d'action** est cruciale : une boucle de signaux d'attrition peut *vérifier* quotidiennement mais n'*agir* que lorsqu'un compte franchit un seuil de risque pour lequel il n'a pas été contacté durant la période de cooldown. Confondre les deux produit des boucles qui soit ratent le coche, soit spamment.

## La règle de cadence

Adaptez la cadence à la vitesse réelle d'évolution du signal — et non à la fréquence à laquelle vous *aimeriez* recevoir une mise à jour.

| Signal | Cadence réaliste | Raison |
|--------|-------------------|-----|
| Positions/classements, backlinks, autorité de domaine | Hebdomadaire | Évoluent lentement ; les vérifications quotidiennes ne sont que du bruit |
| Fatigue des créas publicitaires, dérive du CPA | Tous les 2 à 3 jours | Les boucles de rétroaction Meta/Google se comptent en jours, pas en heures |
| Entonnoir d'activation / onboarding | Hebdomadaire | Nécessite suffisamment d'inscriptions pour être significatif |
| Signaux de churn (attrition) | Quotidien ou sur déclencheur | La fenêtre d'intervention précoce est courte |
| Déclin de contenu / copy (content decay) | Mensuel | L'érosion du trafic est progressive |
| Mouvements des concurrents | Hebdomadaire | Les changements de prix ou de positionnement sont peu fréquents mais importants |
| Écoute sociale / mentions | Quotidien | Les fenêtres d'engagement se referment vite |

Les boucles trop fréquentes sont la cause d'échec la plus courante : elles génèrent un faux sentiment d'activité, gaspillent du budget et vous habituent à ignorer leurs résultats.

## Quand NE PAS créer de boucle

Tout ne doit pas être automatisé de manière récurrente. Évitez de créer une boucle — ou ajoutez un point de contrôle humain obligatoire — lorsque :

- **La stratégie ou la direction créative constitue le cœur du travail.** Les boucles maintiennent et optimisent ; elles ne définissent pas le positionnement, n'inventent pas de campagnes et ne prennent pas de décisions de marque.
- **L'action publie ou dépense sans révision.** *Rédiger automatiquement un brouillon* de pub, d'e-mail ou de post ne pose pas de problème. *Publier automatiquement* ou *déplacer du budget automatiquement* requiert un point de contrôle humain, sauf si l'utilisateur a explicitement autorisé une action autonome et défini des garde-fous (plafonds, listes autorisées).
- **Le signal est trop rare pour être significatif.** Une boucle hebdomadaire de taux de conversion sur 40 visiteurs par semaine ne mesure que du bruit.
- **C'est une boucle de vanité.** Si personne n'agit en fonction des résultats, supprimez la boucle. Une boucle qui envoie par e-mail un tableau de bord que personne ne lit est pire que de ne rien faire.

Pour toute boucle qui envoie des messages, dépense de l'argent, publie ou touche à des données personnelles, appliquez `references/loop-guardrails.md` — le modèle d'action à deux niveaux (sans risque en autonome vs soumis à validation), les plafonds de dépenses/d'envoi, les règles CAN-SPAM/RGPD/FTC/Conditions d'utilisation, la liste des escalades obligatoires et un mécanisme d'arrêt d'urgence (kill switch) obligatoire.

## Planifier une boucle

Ces boucles sont indépendantes de l'agent — le *corps* fonctionne dans n'importe quel agent. La *planification* dépend de votre environnement :

- **Claude Code** — options natives : `/loop` (rythme autonome, jusqu'à une condition), `ScheduleWakeup` (rythme dynamique réagissant à l'état), et `CronCreate` (planification cron fixe). Si vous disposez d'une compétence de mécanique de boucle telle que `loopify`, utilisez-la pour choisir entre ces options et ajuster les délais ; sinon, les conseils ci-dessous suffisent.
- **Tout agent + cron** — encapsulez le corps de la boucle sous forme de prompt/script planifié (`0 9 * * 1` pour le lundi à 9h, etc.).
- **Cadence manuelle** — pour les boucles nécessitant beaucoup de jugement, « exécute cette compétence chaque lundi » est une excellente boucle. La valeur réside dans la reproductibilité du *corps*, pas dans l'automatisation.

Privilégiez par défaut un cron basé sur l'heure du jour pour les boucles de type revue (revue hebdomadaire, surveillance des classements) et un rythme dynamique pour les boucles de surveillance jusqu'à franchissement de seuil (surveillance du churn, suivi le jour du lancement).

## Le catalogue

`references/loop-catalog.md` contient la bibliothèque complète — 58 boucles marketing couvrant l'ensemble du funnel : SEO & Contenu, Payant (Paid), Organique/Réseaux sociaux/Partenariats, Outbound, Activation, Rétention, Revenus, Parrainage & Recommandation, et Opérations continues. Chacune est une spécification complète et adaptable. Commencez par là, sélectionnez celle qui correspond le mieux, et ajustez-la au produit, au stade de développement et aux outils de l'utilisateur.

## Gérer un canal complet : l'opérateur SEO

Lorsque l'utilisateur souhaite qu'un agent prenne en charge l'ensemble du SEO d'un site plutôt que d'exécuter une seule boucle, utilisez `references/seo-operator.md`. Il regroupe les boucles SEO (santé du site, dérive des revendications, poussée des mots-clés proches de la 1ère page [striking-distance push], vérification des réponses IA, écarts de mots-clés, déclin de contenu, veille concurrentielle, etc.) dans un planning unique avec une mémoire partagée dans `.agents/seo/`, une checklist de premier lancement, des règles opérationnelles, un sas de validation éditoriale et un rapport hebdomadaire synthétique sur un écran.

## Gérer l'outbound : l'opérateur outbound

Pour un agent qui gère l'outbound au quotidien (balayage des signaux, prospection par étapes, tri des réponses, santé des domaines d'envoi, rétrospectives hebdomadaires de séquences), utilisez `references/outbound-operator.md`. Il définit le brief, les arguments validés, les règles d'approbation par niveau, une mémoire partagée dans `.agents/outbound/` et un rapport hebdomadaire.

## Créer une nouvelle boucle

Si rien dans le catalogue ne convient, créez une nouvelle boucle à partir de `references/loop-template.md` — un modèle à copier-coller avec des invites à remplir, un exemple avant/après détaillé et une checklist de mise en production. Remplissez l'ensemble des neuf éléments anatomiques ; si vous ne pouvez pas définir concrètement l'auto-vérification, l'état/l'idempotence et l'arrêt/la sortie d'urgence, la boucle n'est pas prête à être exécutée.

## Anti-patterns

- Boucler sans condition d'arrêt → dépenses incontrôlées ou désabonnements infinis.
- Même cadence pour chaque boucle → la plupart s'exécutent trop souvent et finissent par être ignorées.
- Aucune auto-vérification → la boucle réagit à du bruit, à la saisonnalité ou à un bug de tracking.
- Aucun point de contrôle humain sur les actions de dépense ou de publication.
- Construire 10 boucles en même temps → commencez par une seule, prouvez sa rentabilité, puis passez à la suivante.

## Vocabulaire proscrit

À éviter : « configurez et oubliez », « marketing 100 % autonome », « l'IA fait tout », « 10x en pilote automatique », « machine de growth hacking ». Les boucles sont des systèmes rigoureux avec des points de contrôle, pas de la magie. Décrivez-les avec honnêteté.

## Compétences associées

- **marketing-ideas** — tactiques ponctuelles et inspiration (ce qu'il faut tester). Les boucles rendent opérationnelles celles qui méritent d'être répétées.
- **ab-testing** — la boucle d'expérimentation spécifiquement (hypothèse → test → promouvoir le gagnant → répéter).
- **analytics** — la plupart des boucles consultent les données analytiques pour décider s'il faut agir.
- Compétences par canal individuel (`ads`, `seo-audit`, `emails`, `social`, `churn-prevention`, `pricing`, `referrals`) — les corps de boucles orchestrent ces compétences.
