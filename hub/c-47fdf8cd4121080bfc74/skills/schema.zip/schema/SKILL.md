---
name: schema
description: Lorsque l'utilisateur souhaite ajouter, corriger ou optimiser le balisage schema et les données structurées sur son site. À utiliser également lorsque l'utilisateur mentionne « schema markup », « données structurées », « JSON-LD », « extraits enrichis », « rich snippets », « schema.org », « schema FAQ », « schema produit », « schema avis », « fil d'Ariane schema », « résultats enrichis Google », « knowledge panel », « notes avec étoiles dans la recherche » ou « ajouter des données structurées ». Utilisez cette compétence dès que quelqu'un souhaite que ses pages affichent des résultats enrichis dans Google. Pour les problématiques SEO plus larges, consultez seo-audit. Pour l'optimisation pour la recherche IA, consultez ai-seo.
metadata:
  version: 2.0.2
---

# Balisage Schema

Vous êtes un expert en données structurées et en balisage schema. Votre objectif est d'implémenter un balisage schema.org qui aide les moteurs de recherche à comprendre le contenu et permet d'obtenir des résultats enrichis dans les résultats de recherche.

## Évaluation initiale

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que des informations non encore couvertes ou spécifiques à cette tâche.

Avant d'implémenter un balisage schema, comprenez :

1. **Type de page** - Quel type de page ? Quel est le contenu principal ? Quels résultats enrichis sont possibles ?

2. **État actuel** - Y a-t-il un balisage schema existant ? Des erreurs d'implémentation ? Quels résultats enrichis apparaissent déjà ?

3. **Objectifs** - Quels résultats enrichis visez-vous ? Quelle est la valeur métier/commerciale ?

---

## Principes fondamentaux

### 1. L'exactitude avant tout
- Le balisage schema doit représenter fidèlement le contenu de la page
- Ne balisez pas de contenu inexistant
- Maintenez-le à jour lorsque le contenu change

### 2. Utiliser JSON-LD
- Google recommande le format JSON-LD
- Plus facile à implémenter et à maintenir
- Placez-le dans le `<head>` ou à la fin du `<body>`

### 3. Suivre les consignes de Google
- N'utilisez que le balisage pris en charge par Google
- Évitez les tactiques assimilées à du spam
- Vérifiez les critères d'éligibilité

### 4. Tout valider
- Testez avant de déployer
- Surveillez la Search Console
- Corrigez rapidement les erreurs

---

## Types de Schema courants

| Type | Utilisation | Propriétés requises |
|------|-------------|---------------------|
| Organization | Page d'accueil / à propos de l'entreprise | name, url |
| WebSite | Page d'accueil / identité du site | name, url |
| Article | Articles de blog, actualités | headline, image, datePublished, author |
| Product | Pages de produits | name, image, offers |
| SoftwareApplication | Pages SaaS / applications | name, offers |
| FAQPage | Contenu FAQ | mainEntity (tableau de Q&A) |
| HowTo | Tutoriels | name, step |
| BreadcrumbList | Toute page avec fil d'Ariane | itemListElement |
| LocalBusiness | Pages d'entreprises locales | name, address |
| Event | Événements, webinaires | name, startDate, location |

**Pour des exemples complets de JSON-LD** : Consultez [references/schema-examples.md](references/schema-examples.md)

### Vérifier d'abord la compatibilité des fonctionnalités Google

La validité du vocabulaire Schema.org ne garantit pas l'éligibilité aux fonctionnalités de Google. Avant d'implémenter un balisage pour une apparence de recherche demandée, vérifiez la [galerie des données structurées prises en charge](https://developers.google.com/search/docs/appearance/structured-data/search-gallery) actuelle de Google.

- **FAQPage :** Google a cessé d'afficher les résultats enrichis de FAQ le 7 mai 2026 et a retiré la documentation de cette fonctionnalité en juin. L'ancienne exception pour les sites gouvernementaux et de santé n'est plus un moyen d'obtenir des résultats enrichis de FAQ. Consultez les [mises à jour de la documentation](https://developers.google.com/search/updates) de Google.
- **HowTo :** Google a abandonné les résultats enrichis HowTo en septembre 2023. Consultez l'[annonce d'abandon](https://developers.google.com/search/blog/2023/08/howto-faq-changes).
- **WebSite / SearchAction :** Google a abandonné le champ de recherche associé aux liens de site (sitelinks search box) en novembre 2024 ; `WebSite` prend toujours en charge les noms de site. Consultez l'[annonce concernant le champ de recherche](https://developers.google.com/search/blog/2024/10/sitelinks-search-box).

Ces types peuvent toujours décrire le contenu visible correspondant dans Schema.org. Expliquez cette distinction, demandez quel consommateur a besoin du balisage et ne recommandez pas l'implémentation pour obtenir une apparence Google abandonnée. Ne considérez pas l'absence de rapports pour des fonctionnalités obsolètes ou la non-détection par l'outil de test des résultats enrichis comme une implémentation défectueuse, et ne supprimez pas de balisage pris en charge sans rapport.

---

## Référence rapide

### Organization (Page d'entreprise)
Requis : name, url
Recommandé : logo, sameAs (profils sociaux), contactPoint

### Article/BlogPosting
Requis : headline, image, datePublished, author
Recommandé : dateModified, publisher, description

### Product (Produit)
Requis : name, image, offers (prix + disponibilité)
Recommandé : sku, brand, aggregateRating, review

### FAQPage
Requis : mainEntity (tableau de paires Question/Réponse)
Balisage sémantique facultatif pour les FAQ visibles ; ce n'est pas un moyen d'obtenir des résultats enrichis de FAQ sur Google. Vérifiez les directives relatives à la prise en charge des fonctionnalités ci-dessus avant de proposer du code.

### BreadcrumbList (Fil d'Ariane)
Requis : itemListElement (tableau avec position, name, item)

---

## Types de Schema multiples

Vous pouvez combiner plusieurs types de schema sur une seule page en utilisant `@graph` :

```json
{
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Organization", ... },
    { "@type": "WebSite", ... },
    { "@type": "BreadcrumbList", ... }
  ]
}
```

---

## Validation et tests

### Outils
- **Google Rich Results Test** : https://search.google.com/test/rich-results — teste les fonctionnalités actuellement prises en charge par Google, pas tous les types Schema.org
- **Schema.org Validator** : https://validator.schema.org/
- **Search Console** : rapports d'améliorations disponibles pour les fonctionnalités prises en charge ; les types obsolètes ne nécessitent pas de rapport

### Erreurs courantes

**Propriétés requises manquantes** - Vérifiez la documentation de Google pour connaître les champs obligatoires

**Valeurs non valides** - Les dates doivent être au format ISO 8601, les URL complètes, les énumérations exactes

**Discordance avec le contenu de la page** - Le balisage schema ne correspond pas au contenu visible

---

## Implémentation

### Sites statiques
- Ajoutez le JSON-LD directement dans le template HTML
- Utilisez des includes/partials pour le balisage schema réutilisable

### Sites dynamiques (React, Next.js)
- Composant qui génère le balisage schema
- Rendu côté serveur (SSR) pour le SEO
- Sérialisez les données en JSON-LD

### CMS / WordPress
- Extensions (Yoast, Rank Math, Schema Pro)
- Modifications de thèmes
- Champs personnalisés convertis en données structurées

---

## Format de sortie

### Implémentation de Schema
```json
// Full JSON-LD code block
{
  "@context": "https://schema.org",
  "@type": "...",
  // Complete markup
}
```

### Liste de contrôle de test
- [ ] L'apparence Google demandée est actuellement prise en charge, ou un consommateur sémantique distinct est identifié
- [ ] Valide dans le validateur Schema.org ; les fonctionnalités prises en charge par Google réussissent également le test des résultats enrichis
- [ ] Erreurs de champs obligatoires résolues ; avertissements sur les champs recommandés examinés
- [ ] Correspond au contenu de la page
- [ ] Toutes les propriétés requises sont incluses

---

## Questions spécifiques à la tâche

1. Quel est le type de cette page ?
2. Quels résultats enrichis espérez-vous obtenir ?
3. Quelles données sont disponibles pour renseigner le balisage schema ?
4. Y a-t-il déjà un balisage schema sur la page ?
5. Quelle est votre stack technique ?

---

## Compétences associées

- **seo-audit** : Pour le SEO global, y compris l'audit du balisage schema
- **ai-seo** : Pour l'optimisation pour la recherche IA (le balisage schema aide l'IA à comprendre le contenu)
- **programmatic-seo** : Pour le balisage schema basé sur des modèles à grande échelle
- **site-architecture** : Pour la structure du fil d'Ariane et la planification du balisage de navigation
