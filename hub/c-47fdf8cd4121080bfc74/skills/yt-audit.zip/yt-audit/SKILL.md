---
name: yt-audit
description: >-
  Auditer une chaîne YouTube de bout en bout - packaging, régularité, les quinze
  premières secondes, et ce qu'il faut corriger en priorité. À utiliser pour
  « audite ma chaîne », « pourquoi ma chaîne ne décolle pas », « analyse mes vidéos »,
  ou lorsqu'une URL de chaîne est fournie.
---

# yt-audit

Un audit qui liste vingt problèmes est une façon d'éviter celui qui compte vraiment. Celui-ci débouche sur UN SEUL correctif.

## Avant d'écrire

1. Lis `~/.claude/youtube/voice.md` s'il existe. Il s'agit du profil vocal de l'utilisateur : sa façon
   de s'exprimer face caméra, les mots qu'il n'utilise jamais, à qui il s'adresse, ce qu'il refuse
   d'affirmer. S'il n'existe pas, demande **trois de ses propres vidéos**, visionne-les ou transcris-les,
   déduis-en le ton et la voix, puis rédige le fichier. Un script rédigé avec la mauvaise voix est pire
   que pas de script du tout, car il devra le lire à voix haute.
2. N'invente jamais un chiffre, un résultat ou une source. Si une donnée chiffrée pouvait renforcer le
   propos mais que tu n'en as pas, demande-la ou écris la phrase sans elle.

## Ce qu'il faut examiner, dans cet ordre

1. **Les dix derniers titres, pris comme un ensemble.** Lis-les sous forme de liste, de la même manière
   que la page de la chaîne les présente. Promettent-ils des choses différentes ? Passe-les au crible de
   `../yt-package/title.py`. Une chaîne dont chaque titre a la même structure souffre d'un problème de
   format, pas d'un problème de titre.
2. **Les miniatures, à la taille du flux.** Réduis-les. Qu'est-ce qui reste lisible ? Si trois d'entre
   elles sont illisibles à cette taille, c'est là qu'est le correctif et rien d'autre n'a d'importance
   pour le moment.
3. **Les quinze premières secondes des trois plus récentes.** Transcris-les et note-les avec
   `../yt-script/hookscore.py`. C'est là que la plupart des chaînes perdent leur audience.
4. **Le rythme de publication.** Pas la fréquence — la RÉGULARITÉ. Six vidéos en une semaine puis plus
   rien pendant un mois, c'est pire qu'une vidéo toutes les deux semaines pour toujours.
5. **La courbe de rétention**, s'ils peuvent l'exporter. `/yt-retention`.

## Ce qu'il faut restituer

- Le correctif prioritaire absolu, clairement identifié, avec les actions à mener cette semaine.
- Trois points qui fonctionnent déjà bien, pour éviter qu'ils ne les cassent. Sois précis ; « ton
  énergie est bonne » n'est pas une observation.
- Ce qu'il ne faut PAS encore faire, et pourquoi.

Ne commence jamais un audit par des éloges non sincères, et ne termine jamais par une liste de vingt
recommandations.

## Le point de contrôle

Rien de ce qui est produit ici n'est publié directement. Cette compétence rédige et l'utilisateur
publie. Chaque réponse se termine par un bloc que l'utilisateur peut copier, et la toute dernière ligne
de chaque exécution est la question suivante : **on valide, ou on modifie ?**
