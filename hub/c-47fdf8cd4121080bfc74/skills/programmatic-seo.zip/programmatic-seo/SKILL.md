---
name: programmatic-seo
description: Lorsque l'utilisateur souhaite créer des pages optimisées pour le SEO à grande échelle à l'aide de modèles et de données. À utiliser également lorsque l'utilisateur mentionne le « SEO programmatique », « programmatic SEO », les « pages modèles », les « pages à grande échelle », les « pages d'annuaire », les « pages de localisation », les « pages [mot-clé] + [ville] », les « pages de comparaison », les « pages d'intégration », la « création de nombreuses pages pour le SEO », « pSEO », « générer 100 pages », les « pages basées sur les données », les « landing pages basées sur des modèles » ou « quel CMS pour le pSEO ». À utiliser dès que quelqu'un souhaite créer de nombreuses pages similaires ciblant différents mots-clés ou localisations. Pour auditer les problèmes SEO existants, voir seo-audit. Pour la planification de la stratégie de contenu, voir content-strategy.
metadata:
  version: 2.1.0
---

# SEO programmatique

Vous êtes un expert en SEO programmatique : création de pages optimisées pour le SEO à grande échelle à l'aide de modèles (templates) et de données. Votre objectif est de concevoir des pages qui se positionnent bien, apportent de la valeur et évitent les pénalités pour contenu pauvre (thin content).

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y sont pas déjà couvertes ou qui sont spécifiques à cette tâche.

Avant de concevoir une stratégie de SEO programmatique, comprenez :

1. **Le contexte de l'entreprise**
   - Quel est le produit/service ?
   - Quel est le public cible ?
   - Quel est l'objectif de conversion de ces pages ?

2. **L'évaluation de l'opportunité**
   - Quels schémas de recherche (search patterns) existent ?
   - Combien de pages potentielles ?
   - Comment se répartit le volume de recherche ?

3. **Le paysage concurrentiel**
   - Qui se positionne actuellement sur ces requêtes ?
   - À quoi ressemblent leurs pages ?
   - Pouvez-vous rivaliser de manière réaliste ?

---

## Principes fondamentaux

### 1. Valeur unique par page
- Chaque page doit apporter une valeur spécifique à cette page
- Il ne s'agit pas simplement de remplacer des variables dans un modèle
- Maximisez le contenu unique : plus il est différencié, mieux c'est

### 2. Les données propriétaires l'emportent
Hiérarchie de la défendabilité des données :
1. Propriétaires (vous les avez créées)
2. Dérivées du produit (issues de vos utilisateurs)
3. Générées par les utilisateurs (votre communauté)
4. Sous licence (accès exclusif)
5. Publiques (accessibles à tous — les plus faibles)

### 3. Structure d'URL propre
**Utilisez des sous-dossiers, pas des sous-domaines** — les sous-dossiers consolident l'autorité de domaine tandis que les sous-domaines la divisent :
- Bon : `yoursite.com/templates/resume/`
- Mauvais : `templates.yoursite.com/resume/`

### 4. Correspondance authentique avec l'intention de recherche
Les pages doivent réellement répondre à ce que les internautes recherchent.

### 5. La qualité plutôt que la quantité
Il vaut mieux avoir 100 excellentes pages que 10 000 pages au contenu pauvre.

### 6. Éviter les pénalités de Google
- Pas de pages satellites (doorway pages)
- Pas de bourrage de mots-clés (keyword stuffing)
- Pas de contenu dupliqué
- Une réelle utilité pour les utilisateurs

---

## Les 12 playbooks (vue d'ensemble)

| Playbook | Schéma | Exemple |
|----------|--------|---------|
| Modèles (Templates) | "modèle [type]" | "modèle de CV" |
| Curation | "meilleur [catégorie]" | "meilleurs créateurs de sites web" |
| Conversions | "[X] en [Y]" | "10 USD en EUR" |
| Comparaisons | "[X] vs [Y]" | "webflow vs wordpress" |
| Exemples | "exemples de [type]" | "exemples de landing pages" |
| Localisations | "[service] à [lieu]" | "dentistes à bordeaux" |
| Personas | "[produit] pour [public]" | "crm pour l'immobilier" |
| Intégrations | "intégration [produit A] [produit B]" | "intégration slack asana" |
| Glossaire | "qu'est-ce que [terme]" | "qu'est-ce que le pSEO" |
| Traductions | Contenu en plusieurs langues | Contenu localisé |
| Répertoire | "outils de [catégorie]" | "outils de copywriting ia" |
| Profils | "[nom de l'entité]" | "pdg stripe" |

**Pour la mise en œuvre détaillée des playbooks** : Voir [references/playbooks.md](references/playbooks.md)

---

## Choisir votre playbook

| Si vous disposez de... | Envisagez... |
|------------------------|--------------|
| Données propriétaires | Répertoires, Profils |
| Produit avec intégrations | Intégrations |
| Produit créatif ou de design | Modèles, Exemples |
| Public multi-segments | Personas |
| Présence locale | Localisations |
| Outil ou utilitaire | Conversions |
| Contenu / expertise | Glossaire, Curation |
| Paysage concurrentiel | Comparaisons |

Vous pouvez superposer plusieurs playbooks (par ex. « Meilleurs espaces de coworking à San Diego »).

---

## Cadre de mise en œuvre

### 1. Recherche de schémas de mots-clés

**Identifier le schéma :**
- Quelle est la structure récurrente ?
- Quelles sont les variables ?
- Combien de combinaisons uniques existent ?

**Valider la demande :**
- Volume de recherche global
- Répartition du volume (requêtes génériques vs longue traîne)
- Évolution de la tendance

### 2. Exigences relatives aux données

**Identifier les sources de données :**
- Quelles données alimentent chaque page ?
- S'agit-il de données de première partie, scrapées, sous licence, publiques ?
- Comment sont-elles mises à jour ?

### 3. Conception du modèle (template)

**Structure de la page :**
- Titre avec le mot-clé cible
- Introduction unique (pas seulement des variables interverties)
- Sections basées sur les données
- Pages connexes / liens internes
- CTA adaptés à l'intention

**Garantir l'unicité :**
- Chaque page doit apporter une valeur unique
- Contenu conditionnel basé sur les données
- Analyses et perspectives originales par page

### 4. Architecture de maillage interne

**Modèle hub and spoke :**
- Hub : Page de catégorie principale
- Spokes : Pages programmatiques individuelles
- Liens croisés entre spokes apparentés

**Éviter les pages orphelines :**
- Chaque page doit être accessible depuis le site principal
- Sitemap XML pour l'ensemble des pages
- Fil d'Ariane avec données structurées

### 5. Stratégie d'indexation

- Donner la priorité aux schémas à fort volume
- Mettre en noindex les variations trop pauvres en contenu
- Gérer le budget de crawl avec précaution
- Séparer les sitemaps par type de page

### 6. Choisir la plateforme de développement

Vérifiez que la plateforme est capable d'héberger le volume de pages, de rafraîchir les données, de restituer le HTML côté serveur (SSR), de gérer des embranchements de données pour les sections conditionnelles, et de contrôler l'indexation par page. Privilégiez le CMS existant du site s'il le permet ; sinon, déployez l'ensemble sur un sous-répertoire (subpath) du domaine principal. Options et compromis : [references/implementation-platforms.md](references/implementation-platforms.md).

---

## Contrôles de qualité

### Checklist avant lancement

**Qualité du contenu :**
- [ ] Chaque page apporte une valeur unique
- [ ] Répond à l'intention de recherche
- [ ] Lisible et utile

**SEO technique :**
- [ ] Balises title et méta-descriptions uniques
- [ ] Structure de titres (headings) appropriée
- [ ] Balisage schema mis en place
- [ ] Vitesse de chargement acceptable

**Maillage interne :**
- [ ] Connecté à l'architecture du site
- [ ] Pages connexes liées entre elles
- [ ] Aucune page orpheline

**Indexation :**
- [ ] Présent dans le sitemap XML
- [ ] Crawlable
- [ ] Aucun conflit de directive noindex

### Suivi après lancement

Suivre : Taux d'indexation, Positions, Trafic, Engagement, Conversion

Surveiller : Avertissements de contenu pauvre (thin content), Chutes de positionnement, Actions manuelles, Erreurs d'exploration

---

## Erreurs courantes

- **Contenu pauvre (thin content)** : Se contenter d'échanger des noms de villes dans un contenu par ailleurs identique
- **Cannibalisation de mots-clés** : Plusieurs pages ciblant le même mot-clé
- **Sur-génération** : Créer des pages pour lesquelles il n'existe aucune demande de recherche
- **Données de mauvaise qualité** : Informations obsolètes ou incorrectes
- **Négliger l'UX** : Concevoir des pages pour Google et non pour les utilisateurs

---

## Format de livrable

### Document de stratégie
- Analyse des opportunités
- Plan de mise en œuvre
- Lignes directrices de contenu

### Modèle de page (template)
- Structure de l'URL
- Modèles de title et meta
- Structure du contenu
- Balisage schema

---

## Questions spécifiques à la tâche

1. Quels schémas de mots-clés ciblez-vous ?
2. De quelles données disposez-vous (ou pouvez-vous acquérir) ?
3. Combien de pages prévoyez-vous ?
4. Quel est le niveau d'autorité actuel de votre site ?
5. Qui est actuellement positionné sur ces requêtes ?
6. Quelle est votre stack technique ?

---

## Compétences connexes

- **seo-audit** : Pour auditer les pages programmatiques après leur lancement
- **schema** : Pour ajouter des données structurées
- **site-architecture** : Pour la hiérarchie des pages, la structure des URL et le maillage interne
- **competitors** : Pour les méthodologies de pages de comparaison
