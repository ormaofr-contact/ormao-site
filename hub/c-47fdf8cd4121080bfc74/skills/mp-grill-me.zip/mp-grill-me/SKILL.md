---
name: grill-me
description: Un entretien sans concession pour affiner un plan ou une conception.
disable-model-invocation: true
---

Appelez l'outil Skill avec "grilling".
