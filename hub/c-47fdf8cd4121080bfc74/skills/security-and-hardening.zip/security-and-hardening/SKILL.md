---
name: security-and-hardening
description: Sécurise et renforce le code contre les vulnérabilités. À utiliser lors de l'audit d'un gestionnaire d'entrées pour détecter des vulnérabilités, lors du traitement d'entrées utilisateur, de l'authentification, du stockage de données ou d'intégrations externes, ou lors de la vérification qu'un flux de connexion est protégé contre le Top 10 de l'OWASP. À utiliser lors du développement de toute fonctionnalité qui accepte des données non fiables, gère des sessions utilisateur ou interagit avec des services tiers. À utiliser lors de l'audit des dépendances pour détecter des vulnérabilités connues, du triage des résultats d'audit du gestionnaire de paquets ou de l'évaluation des risques liés à la chaîne logistique logicielle dans un nouveau paquet. À utiliser lorsque des données personnelles ou la conformité à la confidentialité (RGPD, CCPA) sont en jeu.
---

# Sécurité et durcissement

## Vue d'ensemble

Pratiques de développement axées sur la sécurité (security-first) pour les applications web. Considérez chaque entrée externe comme hostile, chaque secret comme sacré et chaque vérification d'autorisation comme obligatoire. La sécurité n'est pas une phase : c'est une contrainte sur chaque ligne de code qui touche aux données utilisateur, à l'authentification ou aux systèmes externes.

## Quand l'utiliser

- Construction de tout élément acceptant des entrées utilisateur
- Implémentation de l'authentification ou de l'autorisation
- Stockage ou transmission de données sensibles
- Intégration avec des API ou des services externes
- Ajout de téléversements de fichiers, de webhooks ou de rappels (callbacks)
- Traitement de données de paiement ou de données personnelles (PII)

## Processus : Modéliser les menaces d'abord

Les contrôles greffés sans modèle de menace ne sont que des suppositions. Avant de durcir le code, passez cinq minutes à penser comme un attaquant :

1. **Cartographiez les frontières de confiance.** Où les données non fiables pénètrent-elles dans votre système ? Requêtes HTTP, champs de formulaire, téléversements de fichiers, webhooks, API tierces, files de messages et **sorties de LLM** — ainsi que les valeurs locales qui semblent internes parce que l'OS vous les a transmises : la ligne de commande ou l'environnement d'un autre processus, les noms de fichiers sur un volume partagé, un chemin dans la charge utile d'un job. La confiance dépend de qui a *écrit* une valeur, et non du canal qui l'a transmise. Chaque frontière constitue une surface d'attaque.
2. **Nommez les actifs.** Qu'est-ce qui mérite d'être volé ou détruit ? Identifiants, PII, données de paiement, actions d'administration, mouvements de fonds.
3. **Appliquez STRIDE à chaque frontière** — une grille d'analyse rapide, pas une cérémonie :

| Menace | Question à poser | Atténuation typique |
|---|---|---|
| **S**poofing (Usurpation d'identité) | Quelqu'un peut-il usurper l'identité d'un utilisateur ou d'un service ? | Authentification, vérification de signature |
| **T**ampering (Falsification) | Les données peuvent-elles être altérées en transit ou au repos ? | Contrôles d'intégrité, requêtes paramétrées, HTTPS |
| **R**epudiation (Répudiation) | Une action peut-elle être niée ultérieurement ? | Journalisation d'audit des événements de sécurité |
| **I**nformation disclosure (Divulgation d'informations) | Des données peuvent-elles fuiter ? | Chiffrement, listes d'autorisation de champs, erreurs génériques |
| **D**enial of service (Déni de service) | Le système peut-il être saturé ? | Limitation de débit (rate limiting), plafonds de taille d'entrée, délais d'expiration (timeouts) |
| **E**levation of privilege (Élévation de privilèges) | Un utilisateur peut-il obtenir des droits qu'il ne devrait pas avoir ? | Vérifications d'autorisation, principe du moindre privilège |

4. **Rédigez les cas d'abus en parallèle des cas d'utilisation.** Pour chaque fonctionnalité, demandez-vous : « comment pourrais-je détourner ceci ? » — puis faites-en votre premier test.

Si vous ne pouvez pas nommer les frontières de confiance d'une fonctionnalité, vous n'êtes pas prêt à la sécuriser. Il s'agit du risque OWASP **A04: Insecure Design** — la plupart des failles commencent dès la conception, pas dans le code.

## Le système de frontières à trois niveaux

### Toujours faire (sans exception)

- **Valider toutes les entrées externes** à la frontière du système (routes d'API, gestionnaires de formulaires)
- **Paramétrer toutes les requêtes de base de données** — ne jamais concaténer d'entrées utilisateur dans du SQL
- **Échapper la sortie** pour empêcher les failles XSS (utiliser l'échappement automatique du framework, ne pas le contourner)
- **Utiliser HTTPS** pour toutes les communications externes
- **Hacher les mots de passe** avec bcrypt/scrypt/argon2 (ne jamais stocker en clair)
- **Définir les en-têtes de sécurité** (CSP, HSTS, X-Frame-Options, X-Content-Type-Options)
- **Utiliser des cookies httpOnly, secure et sameSite** pour les sessions
- **Exécuter l'audit natif du gestionnaire de paquets détecté** sur le lockfile versionné avant chaque publication

### Demander d'abord (nécessite une approbation humaine)

- Ajout de nouveaux flux d'authentification ou modification de la logique d'authentification
- Stockage de nouvelles catégories de données sensibles (PII, informations de paiement)
- Ajout de nouvelles intégrations de services externes
- Modification de la configuration CORS
- Ajout de gestionnaires de téléversement de fichiers
- Modification du rate limiting ou de la régulation de requêtes
- Attribution de permissions ou de rôles élevés

### Ne jamais faire

- **Ne jamais commiter de secrets** dans le gestionnaire de versions (clés d'API, mots de passe, jetons)
- **Ne jamais journaliser de données sensibles** (mots de passe, jetons, numéros complets de cartes de crédit)
- **Ne jamais faire confiance à la validation côté client** comme frontière de sécurité
- **Ne jamais désactiver les en-têtes de sécurité** par commodité
- **Ne jamais utiliser `eval()` ou `innerHTML`** avec des données fournies par l'utilisateur
- **Ne jamais stocker de sessions dans un espace de stockage accessible au client** (localStorage pour les jetons d'authentification)
- **Ne jamais exposer de traces de pile (stack traces)** ou de détails d'erreurs internes aux utilisateurs

## Contrôles de durcissement

Les règles ci-dessous constituent le flux de travail ; une implémentation concrète de chacune se trouve dans [references/hardening-patterns.md](references/hardening-patterns.md). Ouvrez la section dont vous avez besoin lorsque vous atteignez ce code, pas avant.

### Injection, XSS et contrôle d'accès

- Paramétrez chaque requête. Ne construisez jamais de commandes SQL, NoSQL ou shell à partir de chaînes d'entrée.
- Échappez la sortie via l'échappement automatique du framework. Si du HTML brut est inévitable, assainissez-le d'abord avec un outil d'assainissement basé sur une liste d'autorisation (allowlist).
- Vérifiez **l'autorisation** sur chaque requête, pas seulement l'authentification : l'utilisateur authentifié doit posséder la ressource spécifique demandée ou être autorisé à y accéder (A01, IDOR).

Modèles : [Injection](references/hardening-patterns.md#injection), [XSS](references/hardening-patterns.md#cross-site-scripting-xss), [Contrôle d'accès](references/hardening-patterns.md#broken-access-control).

### Authentification et sessions

- Hachez les mots de passe avec bcrypt (≥12 passes), scrypt ou argon2. Le secret de session provient de l'environnement, jamais du code.
- Les cookies de session sont `httpOnly`, `secure`, et `sameSite: 'lax'` ou `'strict'` (défense contre les CSRF ; `'none'` envoie le cookie lors des requêtes intersites), avec une durée `maxAge` limitée.

Modèle : [Authentification](references/hardening-patterns.md#broken-authentication).

### En-têtes, CORS et réponses

- En-têtes de sécurité sur chaque réponse (helmet ou l'équivalent du framework) ; la CSP commence par `default-src 'self'` et se renforce au lieu de s'assouplir.
- CORS limité à une liste explicite d'origines issue de la configuration. Jamais `*` avec des identifiants (credentials).
- Supprimez les champs sensibles (`passwordHash`, jetons de réinitialisation) avant toute réponse. Le corps des erreurs reste générique ; les détails internes ne vont que dans les journaux du serveur.

Modèles : [Mauvaise configuration](references/hardening-patterns.md#security-misconfiguration), [Exposition de données sensibles](references/hardening-patterns.md#sensitive-data-exposure).

### Validation des entrées et téléversements

- Validez à la frontière à l'aide d'un schéma : forme sur liste d'autorisation, longueurs, énumérations, formats. Rejetez avec une erreur 422 et des détails structurés ; le code en aval n'utilise que la valeur analysée et typée.
- Téléversements : liste d'autorisation pour les types MIME, plafonnement de la taille, vérification du contenu (octets magiques / magic bytes) lorsque c'est nécessaire. L'extension de fichier ne prouve rien.

Modèles : [Validation par schéma](references/hardening-patterns.md#schema-validation-at-boundaries), [Sécurité du téléversement de fichiers](references/hardening-patterns.md#file-upload-safety).

### Requêtes côté serveur (SSRF)

Toute URL influencée par l'utilisateur — webhooks, import depuis une URL, proxies d'images, aperçus de liens — peut cibler des services internes. Mettez sur liste d'autorisation le schéma et l'hôte, résolvez **tous** les enregistrements DNS et rejetez toute adresse privée ou réservée (loopback, lien local `169.254.169.254`, adresses privées et locales uniques, pour IPv4 et IPv6), et interdisez les redirections. Cette vérification comporte toujours une faille de type TOCTOU par DNS rebinding : pour les surfaces à haut risque, figez l'IP résolue ou placez un agent de filtrage en amont.

Modèle : [SSRF](references/hardening-patterns.md#server-side-request-forgery-ssrf).

### Opérations destructrices sur des chemins dérivés

Une suppression, un déplacement ou un écrasement n'est sûr qu'à la mesure de la valeur désignant sa cible, et la confiance dépend de qui a *écrit* cette valeur, non du canal qui l'a transmise : la ligne de commande d'un autre processus est tout aussi contrôlée par un attaquant qu'un champ de formulaire. Une vérification de format prouve la bonne syntaxe, pas l'autorisation. Avant l'appel, exigez ces trois conditions : la cible résolue (liens symboliques résolus) se trouve sous une **racine sur liste d'autorisation** ; elle est située au moins un niveau **en dessous** de cette racine ; et elle comporte une **preuve de propriété lue avant l'opération**. En cas de refus, journalisez la cible rejetée et arrêtez-vous ; ne basculez jamais vers un chemin par défaut plus large.

Pourquoi cette vérification est plus fragile qu'il n'y paraît (auto-attestation de marqueurs, concurrence entre vérification et utilisation) : [Chemins destructeurs](references/hardening-patterns.md#destructive-operations-on-derived-paths). Exemple de code : `../../references/security-checklist.md`.

### Limitation de débit (Rate limiting)

Limitez l'API de manière globale et les points de terminaison d'authentification de manière stricte (environ 10 tentatives par 15 minutes). Dès que plusieurs processus gèrent le trafic, les compteurs en mémoire deviennent silencieusement `max × instances`, ou ne se déclenchent jamais en serverless : adossez le limiteur à un magasin de données partagé.

Modèle : [Limitation de débit](references/hardening-patterns.md#rate-limiting).

### Secrets

Les secrets proviennent de l'environnement. `.env.example` est versionné avec des valeurs d'exemple ; les vrais fichiers `.env*` et les éléments de clés sont ignorés par git ; inspectez par grep le diff indexé avant de commiter. **Un secret qui atteint un dépôt distant est compromis dès son arrivée : renouvelez-le d'abord, puis purgez l'historique.**

Modèle : [Gestion des secrets](references/hardening-patterns.md#secrets-management).

### Dépendances et chaîne logistique

1. **Déterminez la frontière d'installation et le gestionnaire.** Utilisez la racine de l'espace de travail qui possède le lockfile, ou un projet imbriqué indépendant uniquement lorsqu'il est hors de cet espace de travail. Vérifiez la concordance entre `packageManager` (lorsqu'il est présent), le lockfile et la CI ; arrêtez-vous en cas de divergence ou de lockfiles concurrents. Figez la version du gestionnaire.
2. **Bloquez les scripts de dépendances avant la première exécution.** Initialisez avec les scripts désactivés ou une politique stricte de refus par défaut documentée, inspectez le code source du script en attente, n'approuvez que le strict minimum, commitez la politique, puis vérifiez avec une installation propre, figée/immuable. N'accordez jamais d'approbation globale aveugle.
3. **Exécutez l'audit natif sur le lockfile versionné avant chaque publication.** Triez les alertes critiques/élevées selon leur **accessibilité** (chemins au runtime, au build, aux tests, au déploiement) et la disponibilité d'un correctif. N'appliquez jamais de remédiation forcée (`npm audit fix --force` ou équivalent) de manière automatique, car les correctifs forcés peuvent dépasser les plages de dépendances déclarées ; prévisualisez, lisez les journaux de modifications (changelogs) et testez chaque mise à niveau. Documentez chaque report avec un motif et une date de révision.
4. **Les audits ne détectent que les avis de sécurité connus.** Ils ne repèrent pas un paquet récemment corrompu ou issu d'un typosquatting (`cross-env` vs `crossenv`). Passez en revue ensemble les nouvelles dépendances, les diffs de lockfile et les changements de politique de scripts : propriété, maintenance, ancienneté de la version, provenance, graphe transitif. Vérifiez les signatures du registre lorsque c'est pris en charge (`npm audit signatures`, `pnpm audit signatures`) et traitez leur absence comme un signal d'investigation, non comme une preuve automatique de compromission (A06, LLM03).

Arbre de décision pour le triage : [Triage d'audit des dépendances](references/hardening-patterns.md#dependency-audit-triage). Matrice des gestionnaires et filtrage des scripts d'installation : `../../references/security-checklist.md`.

### Données personnelles et confidentialité

Le durcissement se demande « un attaquant peut-il lire ces données ? ». La confidentialité se demande « devons-*nous* vraiment les détenir, et pour combien de temps ? ». Les données les moins chères à protéger, à gérer en cas de fuite et à conformer sont celles que vous n'avez jamais collectées ; considérez les données personnelles comme une dette à minimiser.

- **Classifiez les champs au fur et à mesure que vous les ajoutez** (non personnels, PII, sensibles) et traitez chaque catégorie en conséquence. Vous ne pouvez pas protéger, ni honorer une demande de suppression pour des données que vous ne pouvez pas localiser.
- **Ne collectez qu'en fonction d'une finalité déclarée.** « Cela pourrait être utile plus tard » constitue un risque latent d'exposition en cas de brèche, pas une finalité. Ne mettez pas de PII dans la télémétrie (la compétence `observability-and-instrumentation` formule le même constat du point de vue opérationnel).
- **Définissez la durée de conservation dès le départ, puis supprimez réellement.** Tout stockage de données personnelles nécessite un TTL et une procédure de suppression fonctionnelle, incluant les sauvegardes, les caches, les index de recherche et les copies analytiques.
- **Prenez en charge les droits des personnes concernées selon votre juridiction** (RGPD, CCPA et similaires) : exportation, rectification, suppression. Concevez le schéma de manière à ce que les données d'un utilisateur soient identifiables et effaçables, et non disséminées de manière irréversible à travers les systèmes.
- **Le consentement conditionne la collecte et le partage avec des tiers, et doit être auditable.** Envoyer des PII à un fournisseur d'analyse, de publicité ou de LLM constitue un partage ; ce prestataire nécessite un accord de traitement des données (DPA). Faites de la région une règle configurable, pas une hypothèse codée en dur.

Tableau de classification : [Classification des données](references/hardening-patterns.md#data-classification). Un incident de confidentialité déclenche le compte à rebours de notification de violation ; menez le post-mortem avec la compétence `debugging-and-error-recovery`.

### Fonctionnalités d'IA / LLM

L'appel à un LLM — agents conversationnels, outils de résumé, agents, RAG — introduit une nouvelle surface d'attaque ; associez-la au [Top 10 OWASP pour les applications LLM (2025)](https://genai.owasp.org/llm-top-10/) :

- **La sortie du modèle est une entrée non fiable** (LLM05). Ne l'injectez jamais dans `eval`, du SQL, un shell, `innerHTML` ou un chemin de fichier ; analysez-la défensivement, validez-la par rapport à un schéma, puis appliquez un échappement.
- **Les prompts peuvent être détournés (prompt injection)** (LLM01). Tout texte non fiable dans le contexte — message utilisateur, page récupérée, PDF — peut comporter des instructions. Le prompt système ne constitue pas une frontière de sécurité ; appliquez les permissions dans le code.
- **Gardez les secrets, les données d'autres locataires (tenants) et l'intégralité du prompt système hors de la fenêtre de contexte** (LLM02, LLM07) ; limitez les permissions des outils (tools), validez chaque argument d'outil et confirmez les actions destructrices (LLM06) ; plafonnez les jetons (tokens), le débit de requêtes et la profondeur de récursion (LLM10) ; partitionnez les plongements (embeddings) RAG par locataire et validez les documents avant l'indexation (LLM08).

Modèle : [Traitement des sorties de LLM](references/hardening-patterns.md#llm-output-handling).

## Liste de contrôle pour la révision

Avant validation finale, parcourez `../../references/security-checklist.md` : elle couvre l'authentification, l'autorisation, les entrées, la protection des données et la confidentialité, les en-têtes et CORS, les dépendances et la chaîne logistique, l'IA/LLM et la gestion des erreurs, ainsi que les tableaux de référence rapide OWASP.

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « C'est un outil interne, la sécurité n'a pas d'importance » | Les outils internes se font compromettre. Les attaquants visent le maillon le plus faible. |
| « Nous ajouterons la sécurité plus tard » | Rétro-adapter la sécurité est 10 fois plus difficile que de la concevoir dès le départ. Intégrez-la maintenant. |
| « Personne n'essaierait d'exploiter cela » | Les scanners automatisés le trouveront. La sécurité par l'obscurité n'est pas de la sécurité. |
| « Le framework gère la sécurité » | Les frameworks fournissent des outils, pas des garanties. Vous devez toujours les utiliser correctement. |
| « Ce n'est qu'un prototype » | Les prototypes finissent en production. Adoptez les réflexes de sécurité dès le premier jour. |
| « La modélisation des menaces est disproportionnée ici » | Cinq minutes passées à se demander « comment pourrais-je attaquer ceci ? » évitent les défauts de conception qu'aucun correctif ne pourra réparer plus tard. |
| « C'est juste une sortie de LLM, ce n'est que du texte » | Ce « texte » peut être une instruction SQL, une balise script ou une commande shell. Traitez-le comme toute entrée non fiable. |
| « L'audit a réussi, la dépendance est donc sûre » | Les audits ne repèrent que les avis de sécurité connus. Ils ne détectent pas un paquet devenu malveillant récemment et ne rendent pas sûre l'exécution de scripts d'installation non vérifiés. |
| « Collectons-le maintenant, nous pourrions en avoir besoin plus tard » | Les données que vous ne possédez pas ne peuvent pas être compromises, réquisitionnées par la justice ou supprimées par erreur. « En avoir besoin plus tard » est une surface de violation potentielle, pas une finalité. |
| « Nous traiterons les demandes de suppression manuellement » | L'effacement manuel oublie les sauvegardes, les caches et les copies d'analyse. Si le schéma ne permet pas de retrouver les données d'un utilisateur, vous ne pouvez pas honorer la demande — concevez le système pour cela. |
| « La conformité est le problème du service juridique, pas le nôtre » | L'exportation, la suppression, la conservation et le consentement s'inscrivent dans le schéma et le code. Le service juridique ne peut pas les greffer après coup si vous avez disséminé des PII sur dix systèmes différents. |

## Signaux d'alerte (Red Flags)

- Entrée utilisateur transmise directement à des requêtes de base de données, des commandes shell ou du rendu HTML
- Une suppression, un déplacement ou un écrasement dont la cible provient d'une charge utile, d'une valeur de configuration ou de la ligne de commande d'un autre processus, protégé uniquement par une vérification de la forme syntaxique du chemin
- Secrets dans le code source ou l'historique des commits
- Points de terminaison d'API sans vérifications d'authentification ou d'autorisation
- Configuration CORS manquante ou origines avec joker (`*`)
- Absence de limitation de débit sur les points de terminaison d'authentification, ou limiteur en mémoire placé devant plusieurs instances
- Traces de pile ou erreurs internes exposées aux utilisateurs
- Dépendances avec des vulnérabilités critiques connues, lockfiles concurrents à une même frontière d'installation, installations non reproductibles ou scripts approuvés sans discernement
- Le serveur interroge des URL fournies par l'utilisateur sans liste d'autorisation (SSRF)
- Sortie de LLM/modèle transmise à une requête, au DOM, à un shell ou à `eval`
- Secrets, PII ou prompt système intégral placés dans la fenêtre de contexte d'un LLM
- Données personnelles collectées sans finalité déclarée, limite de conservation ou procédure de suppression
- PII envoyées à des fournisseurs d'analyse/publicité/LLM sans consentement ni accord de traitement des données (DPA)
- Fonction « Supprimer mon compte » qui se contente de basculer un booléen alors que les données personnelles subsistent dans les bases et sauvegardes

## Vérification

Après avoir implémenté du code touchant à la sécurité :

- [ ] L'audit natif n'a aucune vulnérabilité critique/élevée exploitable non atténuée ; la CI conserve le lockfile de référence et bloque les scripts de dépendances non revus
- [ ] Aucun secret dans le code source ou l'historique git
- [ ] Toutes les entrées utilisateur sont validées aux frontières du système
- [ ] Les opérations destructrices sur le système de fichiers résolvent les liens symboliques, puis vérifient la racine autorisée, la profondeur minimale et la propriété avant l'exécution
- [ ] L'authentification et l'autorisation sont vérifiées sur chaque point de terminaison protégé
- [ ] Les en-têtes de sécurité sont présents dans la réponse (à vérifier avec les DevTools du navigateur)
- [ ] Les réponses d'erreur n'exposent pas de détails internes
- [ ] La limitation de débit est active sur les points d'authentification, adossée à un magasin partagé lorsque plus d'une instance traite le trafic
- [ ] Les requêtes d'URL côté serveur sont validées par rapport à une liste d'autorisation (pas de SSRF)
- [ ] La sortie du LLM/modèle est validée et encodée avant utilisation (si des fonctionnalités d'IA sont présentes)
- [ ] Les données personnelles sont classifiées, limitées au strict nécessaire selon une finalité déclarée et soumises à une durée de conservation
- [ ] Les demandes de suppression et d'exportation fonctionnent de bout en bout (y compris sur les sauvegardes, les caches et les copies d'analyse)
