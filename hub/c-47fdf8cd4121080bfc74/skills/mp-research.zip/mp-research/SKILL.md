---
name: research
description: Enquêter sur une question auprès de sources primaires de confiance et consigner les conclusions dans un fichier Markdown au sein du dépôt. À utiliser lorsque l'utilisateur souhaite faire des recherches sur un sujet, recueillir des informations documentaires ou des faits sur une API, ou déléguer le travail de lecture à un agent en arrière-plan.
---

Lancez un **agent en arrière-plan** pour effectuer les recherches, afin de continuer à travailler pendant qu'il lit.

Sa mission :

1. Examiner la question à partir de **sources primaires** (documentation officielle, code source, spécifications, API de référence), et non d'une synthèse secondaire de celles-ci. Remonter chaque affirmation jusqu'à la source qui en a la paternité.
2. Rédiger les conclusions dans un unique fichier Markdown, en citant la source de chaque affirmation.
3. L'enregistrer à l'endroit où le dépôt conserve déjà ce type de notes ; respecter la convention existante et, s'il n'y en a aucune, le placer à un endroit pertinent et indiquer son emplacement.
