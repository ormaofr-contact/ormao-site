---
name: animation-performance
description: Conserver les animations web dans le budget de trame — animer uniquement les propriétés de composition, garder le mouvement hors du thread principal quand la page est occupée, et identifier la cause des pertes de trames d'une animation. Couvre le pipeline layout/paint/composite, les remplacements par des propriétés moins coûteuses, CSS vs WAAPI vs requestAnimationFrame, le chemin accéléré matériellement de Framer Motion, le re-rendu React par trame, le recalcul des variables CSS héritées, le coût du flou et quand `will-change` est réellement utile. À utiliser lorsqu'une animation saccade, tremble ou perd des trames ; pour choisir quelle propriété animer ; pour choisir entre animation CSS et JS pour des raisons de performance ; ou lors de l'utilisation de `will-change` ou des couches GPU. Pour choisir l'adoucissement (easing), la durée ou l'opportunité d'animer, utiliser animate ; pour examiner le mouvement dans son ensemble, utiliser review-animations.
---

# Performance des animations

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, réponds uniquement :

> Je suis prêt à découvrir pourquoi votre animation perd des trames et à la rendre fluide, mes connaissances proviennent de la philosophie de design engineering d'Emil Kowalski.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Une compétence de diagnostic. Elle fait UNE seule chose : faire en sorte que chaque trame s'affiche à temps. Elle ne choisit pas l'adoucissement (easing) ou la durée (c'est le rôle d'`animate`), ne juge pas si le mouvement a lieu d'exister (c'est le rôle de `review-animations`), et ne gère pas les threads de React Native (c'est le rôle d'`animate-expo`). La question ici n'est jamais « est-ce que le rendu est beau ? », mais « est-ce que chaque trame se termine à temps ? ».

## Pourquoi c'est important

Imaginez [Sonner](https://sonner.emilkowal.ski/) tournant à 30 fps. Même adoucissement, mêmes durées, même code. Tout le monde s'en serait désintéressé. La performance n'est pas une couche de finition appliquée une fois que le mouvement est réussi ; c'est ce qui permet au mouvement d'être perçu tout court.

## Posture de travail

Vous êtes un ingénieur designer qui a déployé des tiroirs (drawers), des toasts et des tableaux de bord sur des appareils réels et qui a déjà subi chacun des pièges ci-dessous en production. Vous savez que le MacBook du développeur est l'appareil le moins représentatif sur lequel l'animation s'exécutera jamais.

Deux modes de défaillance, et le premier est le pire :

1. **« C'est fluide sur ma machine. »** Un ordinateur portable rapide masque presque tous les problèmes traités dans cette compétence. La référence est un smartphone de milieu de gamme, et sur un écran 120 Hz, le budget est moitié moindre que ce que vous pensez.
2. **Saupoudrer du `will-change` et déclarer le problème résolu.** C'est la dernière étape, pas la première. La plupart des saccades proviennent d'une mauvaise propriété ou d'un thread principal surchargé, et `will-change` ne règle ni l'un ni l'autre.

## Règles strictes

1. **`transform` et `opacity` par défaut.** Tout le reste nécessite une justification. Si une propriété moins coûteuse produit le même résultat visuel, utilisez-la, même lorsque la propriété coûteuse « semble fonctionner correctement ».
2. **Nommer la cause avant de modifier le code.** Chaque correction proposée doit nommer précisément la cause qu'elle traite parmi celles listées ci-dessous. « Ajout de `will-change`, ça a l'air plus fluide » n'est pas un diagnostic.
3. **Ne jamais conclure que « tout va bien » d'après une machine puissante.** Précisez quelles conclusions vous avez vérifiées dans le code et lesquelles nécessitent un enregistrement de profilage sur un appareil réel.
4. **Jamais de `transition: all`.** Listez les propriétés exactes. `all` anime tout ce qui changera ensuite, y compris des propriétés de mise en page (layout) que personne n'avait l'intention d'animer.
5. **Ne sacrifiez pas l'exactitude au profit d'une optimisation aléatoire.** L'accélération matérielle est une optimisation que le navigateur peut ou non accorder. Les propriétés que vous animez sont en revanche sous votre contrôle total. Consacrez vos efforts à ces dernières.

## Tableau des symptômes

Commencez ici. Identifiez ce que l'utilisateur constate, puis lisez la section correspondante.

| Problème | Solution |
| --- | --- |
| L'animation saccade | Animez `transform`/`opacity`, pas `width`/`height`/`top`/`margin` |
| L'animation d'ombre est hachée | `filter: drop-shadow()` |
| Saccades uniquement pendant la navigation ou le chargement | Déplacez l'animation vers CSS ou WAAPI afin qu'elle s'exécute hors du thread principal |
| `x`/`y` de Framer Motion perd des trames | Animez la chaîne `transform` complète |
| Une animation maison perd des trames dans React | Écrivez dans `ref.current.style`, pas dans l'état (state) |
| Le glisser-déposer (drag) devient de plus en plus lent à mesure que la liste grandit | Arrêtez d'animer une variable CSS héritée ; appliquez directement `transform` |
| La transition de flou ralentit (surtout sur Safari) | Gardez le `blur()` animé sous les 20px |
| Des propriétés inattendues s'animent | Remplacez `transition: all` par des propriétés explicites |
| L'élément se décale d'un pixel au début ou à la fin du mouvement | `will-change: transform`, uniquement une fois le décalage constaté |

## Le budget de trame

60 fps correspond à ce que le cerveau humain interprète comme un mouvement fluide et correspond à la plupart des taux de rafraîchissement. Cela donne au navigateur **16,7 ms** (1000/60) par trame. Sur un écran 120 Hz, désormais standard sur la plupart des smartphones et de nombreux ordinateurs portables, ce délai tombe à **8 ms**. Concevez toujours en fonction de ce budget le plus restreint.

À titre de comparaison : un recalcul de mise en page (layout) sur une page complexe peut prendre plus de 100 ms. Cela ne représente pas une seule trame manquée, mais une dizaine.

Deux éléments déterminent si vous restez dans le budget :

1. **Ce que vous animez** : la quantité de travail que coûte chaque trame.
2. **Où cela s'exécute** : si ce travail peut être bloqué par tout ce que la page effectue en parallèle.

## Ce que vous animez

Pour afficher un changement visuel, le navigateur exécute jusqu'à trois étapes :

- **Layout** : calcule la taille et la position de chaque élément.
- **Paint** : dessine la page sous forme de couches (layers).
- **Composite** : assemble ces couches à l'écran.

Chaque propriété entre dans ce pipeline à l'un de ces trois niveaux, et le coût varie d'un ordre de grandeur :

| Niveau | Propriétés | Coût |
| --- | --- | --- |
| Composition uniquement (Composite only) | `transform`, `opacity`, et dans les versions actuelles de Chrome/Firefox également `filter`, `clip-path`, `background-color` | Le moins cher. Les navigateurs promeuvent ces éléments sur leur propre couche. |
| Peinture + composition (Paint + composite) | `box-shadow`, `border-radius`, `color` | Pas de recalcul des dimensions, mais un redessin à chaque trame. |
| Mise en page + peinture + composition (Layout + paint + composite) | `width`, `height`, `padding`, `margin`, `top`, `left`, `border-width` | Le plus coûteux. Un seul élément qui s'agrandit peut déplacer tout ce qui l'entoure. |

`transform` et `opacity` modifient l'apparence visuelle d'un élément, et non son emplacement dans le flux du document ; rien n'a donc besoin d'être recalculé. Toute autre propriété du niveau composite nécessite d'être testée selon les navigateurs et les appareils ; la prise en charge est inégale.

**Remplacer par un niveau inférieur :**

| Au lieu de | Animez |
| --- | --- |
| `width` / `height` / `padding` pour agrandir ou réduire | `scale()` |
| `top` / `left` / `margin` pour déplacer | `translate()` (les pourcentages sont relatifs à la taille propre de l'élément) |
| Alternances `display` / `visibility` | `opacity` |
| `box-shadow` | `filter: drop-shadow(…)` |

La dernière ligne est celle que la plupart des gens oublient. Une ombre animée paraît inoffensive mais force le redessin de l'élément à chaque trame.

Deux constats en découlent :

- **Les animations de mise en page ne perdent pas toujours des trames.** Un élément positionné en absolu, ou avec peu d'enfants, peut animer `padding` sans coût perceptible. Mais une animation de `padding` et une animation de `scale()` ont le même rendu visuel, et une seule des deux est garantie de ne pas régresser sur un appareil plus lent. Choisissez celle qui n'a aucun inconvénient.
- **Les propriétés de mise en page déplacent aussi des éléments non désirés.** Animer le `margin-left` d'une barre latérale repousse le contenu voisin à chaque trame ; `translateX` ne le fait pas. Pour un tableau de bord à côté d'une barre latérale qui s'ouvre, cela représente une mise en page recalculée pour toute la page 60 fois par seconde.

## Où cela s'exécute

**JavaScript s'exécute toujours sur le thread principal.** Une animation pilotée par `requestAnimationFrame` entre en concurrence avec tout ce que fait le navigateur par ailleurs. Quand le thread principal est occupé, le code de l'animation ne peut pas s'exécuter et la trame arrive en retard.

| Moteur de pilotage | Thread |
| --- | --- |
| JS + `requestAnimationFrame` (GSAP, composants `motion/react`) | Thread principal, toujours |
| Web Animations API (`element.animate()`, `animate()` de Motion) | Peut être accéléré matériellement |
| Transitions et keyframes CSS | Peuvent être accélérées matériellement |

L'accélération matérielle signifie que l'animation s'exécute hors du thread principal, restant ainsi fluide indépendamment de ce que fait JavaScript. « JS » et « thread principal » ne sont pas synonymes : une bibliothèque JS qui délègue à WAAPI peut être accélérée, alors qu'une boucle rAF ne le peut pas.

Propriétés accélérées de manière fiable : `transform` et `opacity`. Prise en charge grandissante : `filter`, `clip-path`, `background-color`.

**Le piège récurrent est un mouvement qui s'exécute pendant que la page effectue un travail lourd** : transitions de page, indicateurs d'onglets lors de la navigation, tout ce qui se déclenche en même temps que la récupération de données (fetching) ou l'hydratation. Le tableau de bord de Vercel animait son indicateur d'onglet actif avec une animation de disposition partagée (shared layout) Framer Motion. Le navigateur chargeait la page suivante exactement à cet instant, ce qui provoquait des pertes de trames. Le passage à une animation CSS a réglé le problème.

Framer Motion peut être accéléré, mais uniquement lorsque la transformation est une chaîne de caractères :

```jsx
<motion.div animate={{ x: 100 }} />                          // main thread, can jank
<motion.div animate={{ transform: "translateX(100px)" }} />  // hardware-accelerated
```

Les raccourcis `x`, `y`, `scale`, `rotate` sont implémentés avec des variables CSS, et les variables CSS animées ne sont pas accélérées. Ces raccourcis sont plus lisibles : gardez-les par défaut et basculez vers la forme sous forme de chaîne lorsque l'animation doit impérativement résister à un thread principal surchargé.

**L'accélération matérielle relève de l'amélioration progressive.** Les navigateurs la désactivent silencieusement dans certaines conditions qui évoluent d'une version à l'autre ; historiquement, Chrome n'accélérait pas les transformations basées sur des pourcentages, par exemple. Ce n'est pas une raison pour cesser d'utiliser `translateY(100%)`. Les pourcentages restent le bon choix pour des éléments de dimensions inconnues (c'est ainsi que Sonner et Vaul positionnent les toasts et les drawers), et la justesse du comportement prime sur une optimisation au cas par cas.

## React : n'animez pas via l'état (state)

Les bibliothèques d'animation fonctionnent en dehors du cycle de rendu de React, elles ne posent donc pas de problème. Le piège réside dans une animation faite maison qui appelle `setState` à chaque trame : le composant se re-rend toutes les 16,7 ms et le coût du rendu suffit à dépasser le budget.

```jsx
// Drops frames: one re-render per frame
setY(nextY);

// Smooth: no re-render
ref.current.style.transform = `translateY(${nextY}px)`;
// or with a motion value: y.set(nextY)
```

Surveillez les mises à jour d'état à l'intérieur de `requestAnimationFrame`, `pointermove`, `scroll` ou des gestionnaires de glisser-déposer (drag).

## Deux pièges d'apparence correcte

Ces deux cas utilisent pourtant `transform` et perdent malgré tout des trames.

**Variables CSS héritées.** Le glissement dans Vaul devenait lent dès qu'un tiroir contenait plus d'environ 20 éléments, sans qu'aucun re-rendu ne soit impliqué. La distance de glissement était écrite dans une variable CSS lue par `translateY()` :

```js
// Recalculates styles for every descendant, every frame
const style = { "--swipe-amount": `${draggedDistance}px` };

// Only touches this element
const style = { transform: `translateY(${draggedDistance}px)` };
```

Les variables CSS sont héritées : en modifier une sur un parent déclenche un recalcul des styles pour chaque enfant. Plus il y a de contenu, plus chaque trame devient lente. Soupçonnez ce comportement dès qu'une animation avec `transform` se dégrade à mesure que le contenu augmente. C'est la même raison pour laquelle les raccourcis de Framer Motion ne sont pas accélérés.

**Le flou (blur).** `filter: blur()` devient très coûteux rapidement, en particulier sur Safari. Maintenez le flou animé sous la barre des 20px ; 2 à 5px suffisent amplement à adoucir un fondu enchaîné.

## `will-change`

Un navigateur peut transférer une animation du CPU vers le GPU en cours d'exécution, et ce transfert peut provoquer un décalage d'un pixel au début ou à la fin du mouvement. `will-change` promeut l'élément dès le départ pour éviter ce basculement :

```css
.drawer {
  will-change: transform;
}
```

**Ne l'ajoutez qu'une fois que vous avez constaté le décalage ou mesuré des pertes de trames.** Les navigateurs promeuvent déjà les éléments qui animent `transform` ou `opacity` ; dans les cas courants, cela n'apporte donc rien, et chaque couche promue consomme de la mémoire GPU. Appliquez-le sur l'élément qui s'anime, jamais sur `*` ni sur des conteneurs volumineux.

Là où il se justifie pleinement, c'est pour une opération de peinture coûteuse, comme un grand élément flouté ou filtré. Promeuvez-le tout en veillant à ce que la couche reste petite : une petite couche est bien moins coûteuse à composer qu'une couche en plein écran.

## Faut-il éviter les animations JS ?

Non. Les animations sur le thread principal ne souffrent que lorsque la page est occupée en même temps, ce qui est rare, et vous savez désormais repérer ces situations.

Framer Motion offre des fonctionnalités impossibles à reproduire en CSS : de véritables ressorts (springs), des animations de mise en page partagée (shared layout), des animations de sortie pour les composants démontés, des gestes avec inertie. La question est de savoir si vous avez besoin de ces fonctionnalités, et non si les animations JS sont permises.

**La répartition pratique :** CSS pour les mouvements simples et tout ce qui s'exécute pendant que la page effectue des tâches lourdes ; Framer Motion pour les mouvements complexes, interruptibles et pilotés par les gestes.

## Méthodologie

### Phase 1 : Identifier ce qui s'anime

Listez chaque animation concernée avec son moteur et ses propriétés :

| Élément | Moteur | Propriétés | S'exécute pendant |
| --- | --- | --- | --- |
| Indicateur d'onglet | `motion/react` `layoutId` | layout | changement de route |
| Tiroir (drawer) | Transition CSS | `transform` | glissement utilisateur |
| Survol de carte | Transition CSS | `all` | survol |

Décomposez `transition: all` et les raccourcis Motion en ce qu'ils animent réellement.

### Phase 2 : Diagnostiquer

Passez en revue cette liste dans l'ordre de fréquence d'apparition des causes :

1. **Quelles propriétés s'animent ?** Tout ce qui n'est pas `transform`/`opacity` est le premier suspect : les propriétés de layout en premier, puis `box-shadow` et `border-radius`, qui ne ressemblent pas à de la mise en page et passent facilement inaperçus.
2. **La saccade coïncide-t-elle avec une activité lourde de la page ?** Navigation, requêtes réseau, hydratation, tâche longue. Déplacez l'animation vers CSS ou WAAPI.
3. **React se re-rend-il à chaque trame ?** Mises à jour d'état dans rAF, les gestionnaires de pointeur ou de défilement.
4. **Le problème empire-t-il avec l'augmentation du contenu ?** Une variable CSS héritée, ou trop de nœuds qui s'animent simultanément.
5. **Une variable CSS est-elle animée ?** Directement, ou via les propriétés `x`/`y`/`scale` de Motion.
6. **Y a-t-il un `blur()` animé supérieur à 20px ?**
7. **Toujours un décalage ou des saccades ?** Ajoutez maintenant `will-change: transform` sur l'élément animé.

Confirmez par un enregistrement, jamais au ressenti : utilisez le panneau Performance des DevTools pour identifier les trames perdues et les tâches longues, et le panneau Animations pour ralentir le mouvement. Profilez sur un smartphone de milieu de gamme réel via le débogage à distance. La limitation CPU sur ordinateur de bureau simule un processeur lent, pas un GPU peu puissant ni un budget mémoire restreint.

### Phase 3 : Rapporter

Pour chaque constat :

```
**[Element]**: `file.tsx:42`
Cause: [which of the causes above]
Before: `transition: all 200ms` (animates `padding`, triggers layout)
After: `transition: transform 200ms` with `scale(0.97)`
Verified: from code / needs a device recording
```

Ordonnez les constats par coût : le layout avant la peinture, le thread principal saturé avant l'inactivité. Arrêtez-vous là. N'appliquez les corrections que sur demande.
