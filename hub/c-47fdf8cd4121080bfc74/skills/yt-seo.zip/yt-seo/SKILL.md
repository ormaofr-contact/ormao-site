---
name: yt-seo
description: >-
  Rédige la description, les tags et le texte orienté recherche pour une vidéo YouTube,
  en ciblant la requête qu'une vraie personne tape. À utiliser pour « rédige ma description »,
  « tags », « SEO », « aide cette vidéo à être trouvée », « personne ne trouve cette vidéo ».
---

# yt-seo

La recherche est un levier moins puissant que le packaging, mais plus important qu'on ne le pense pour les vidéos intemporelles (evergreen).
Pour une vidéo destinée au flux des abonnés, précise-le et concentre plutôt tes efforts sur `/yt-package`.

## Avant de rédiger

1. Lis `~/.claude/youtube/voice.md` s'il existe. Il s'agit du profil de voix de l'utilisateur : sa façon de s'exprimer
   face caméra, les mots qu'il n'utilise jamais, à qui il s'adresse, ce qu'il refuse d'affirmer. S'il
   n'existe pas, demande **trois de ses propres vidéos**, lis-les ou transcris-les, déduis-en la voix,
   et écris le fichier. Un script rédigé avec la mauvaise voix est pire que pas de script du tout, car l'utilisateur doit
   le lire à voix haute.
2. N'invente jamais un chiffre, un résultat ou une source. Si une donnée chiffrée peut renforcer le propos sans que tu en
   disposes, demande-la ou écris la phrase sans elle.

## La description

- **Les deux premières lignes sont les seules que tout le monde lit.** Elles s'affichent au-dessus de « ...plus » et constituent
  l'extrait affiché dans les résultats de recherche. Explique ce que la vidéo leur apporte, avec les mots exacts qu'ils auraient tapés.
- Place ensuite le lien ou la ressource, s'il y en a un, pour qu'il apparaisse au-dessus de la ligne de flottaison.
- Ajoute ensuite les chapitres (`/yt-chapters` s'en charge).
- Développe ensuite la version détaillée : ce qui est abordé, à qui cela s'adresse, les prérequis éventuels.

## Les tags, en toute franchise

Les tags constituent un signal faible, et YouTube l'a confirmé. Utilise-les pour lever les ambiguïtés — variantes orthographiques,
noms d'outils, abréviations que les gens tapent réellement — et arrête-toi là. Quinze tags suffisent largement. Accumuler un mur
de tags n'est pas une stratégie, et en insérer sans rapport avec le sujet enfreint les conditions d'utilisation.

## Le test de requête

Avant de livrer quoi que ce soit, écris les trois requêtes de recherche sur lesquelles cette vidéo devrait se positionner en tête, et vérifie
que le titre et les deux premières lignes de description contiennent bien les mots de ces requêtes. Si ce n'est pas le cas, le
problème vient du titre, pas de la description.

## Le point de contrôle

Rien ici n'est publié automatiquement. Cette compétence rédige et c'est toi qui publies. Chaque résultat se termine par un bloc que l'utilisateur
peut copier, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
