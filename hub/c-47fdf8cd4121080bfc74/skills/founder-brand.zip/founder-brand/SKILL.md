---
name: founder-brand
description: >-
  Votre designer de marque. Trouve le nom de l'entreprise (avec les vérifications
  de marques déposées, de noms de domaine et d'identifiants à effectuer avant d'avoir
  un coup de cœur pour un nom), rédige le ton de voix, une promesse en une ligne
  et un slogan, et définit le brief visuel : couleurs, typographies, logo et les
  premiers éléments vus par le client, afin qu'ils correspondent au positionnement
  choisi par le directeur marketing. À utiliser lorsque l'utilisateur dit « trouve
  un nom pour mon entreprise », « crée la marque », « logo », « identité de marque »,
  « à quoi cela devrait ressembler », « slogan » ou « ton de marque ».
argument-hint: "[idées de noms, le cas échéant]"
---

# founder-brand

Une marque est la promesse dont un client se souvient. Cette compétence la rend
spécifique au positionnement déjà identifié par le groupe, et non un simple moodboard
de jolies couleurs.

## Étape 1 : lire le brief

`founder/idea.md`, `founder/marketing.md` (la phrase de positionnement et la
première audience cible), `founder/competitors.md` (les noms et styles visuels à
éviter), ainsi que les raisons d'achat du panel (`founder/panel/results.md`). Si le
positionnement est manquant, demandez-le ou lancez d'abord `/founder-marketing`.

## Étape 2 : propositions de noms

Dix propositions réparties sur différents styles (descriptif, évocateur, inventé,
nom du fondateur, lieu). Pour chacune : ce qu'elle exprime, sa sonorité à l'oral,
sa lisibilité sur une enseigne ou une icône d'application, et les risques associés.
Ensuite, sélectionnez trois noms finalistes et lancez les vérifications que
l'utilisateur devra finaliser lui-même :

- **Marque déposée** : recherchez sur le registre officiel de chaque marché
  (USPTO aux États-Unis, CIPO au Canada, EUIPO dans l'UE, UKIPO au Royaume-Uni)
  la disponibilité du nom dans la même classe de produits et services. Fournissez
  les liens de recherche et les classes à vérifier.
- **Domaine** : vérifiez si le .com et le domaine local sont disponibles
  (vérifiez concrètement, ne faites pas de suppositions) ; proposez de bonnes
  alternatives si ce n'est pas le cas.
- **Identifiants** : Instagram, TikTok, X, YouTube.
- **Confusion** : aucun nom trop proche d'un concurrent listé dans
  `founder/competitors.md`.

Précisez clairement que vous n'effectuez que des recherches publiques, qu'un
avocat en droit des marques doit confirmer la faisabilité, et que rien n'est
déposé tant que l'utilisateur ne procède pas lui-même à l'enregistrement.

## Étape 3 : voix et promesse

- La promesse en une ligne (ce sur quoi le client peut compter, à chaque fois).
- Un slogan, trois options.
- Le ton de voix en trois adjectifs, chacun avec une consigne « à faire » et
  « à éviter », ainsi qu'une réécriture avant/après d'une ligne issue de
  `founder/pitch.md`.

## Étape 4 : le brief visuel

- **Couleurs** : 2 à 3 couleurs principales avec leurs codes hexadécimaux et le
  rôle de chacune, accompagnées d'un test de contraste pour le texte sur chaque
  fond (au minimum WCAG AA).
- **Typographie** : une police de titrage et une police de texte courant,
  gratuites ou payantes, avec l'indication de l'endroit où se les procurer.
  Aucune police pour laquelle l'utilisateur ne dispose pas d'une licence.
- **Brief du logo** : ce qu'il doit communiquer, où il doit fonctionner (une
  enseigne, un gobelet, une icône d'application en 32 px), ce qu'il faut éviter.
  Proposez de générer des concepts avec un outil d'image si l'utilisateur en
  dispose ; présentez clairement les concepts générés comme des ébauches et non
  comme un logo finalisé.
- **Les cinq premiers points de contact** : l'enseigne ou la page d'accueil,
  l'emballage, le reçu ou la confirmation de commande, la première publication
  sur les réseaux sociaux, la réponse à la première réclamation client.

## Règles

- Ne copiez jamais le nom, le logo, les couleurs ou le slogan d'un concurrent.
- N'utilisez aucune police, image ou icône pour laquelle l'utilisateur n'a pas
  les droits d'utilisation.
- Ne constitue pas un conseil juridique en matière de propriété intellectuelle.

## Livrable

`founder/brand.md`. Étapes suivantes : `/founder-ops` et `/founder-launch`.
