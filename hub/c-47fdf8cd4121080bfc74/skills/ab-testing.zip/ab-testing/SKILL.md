---
name: ab-testing
description: >-
  Lorsque l'utilisateur souhaite planifier, concevoir ou mettre en œuvre un test A/B ou une
  expérience, ou bâtir un programme d'expérimentation de croissance (growth
  experimentation). À utiliser également lorsque l'utilisateur mentionne « test A/B », «
  split test », « expérience », « tester ce changement », « texte de variante », « test
  multivarié », « hypothèse », « devrais-je tester cela », « quelle version est la meilleure
  », « tester deux versions », « signification statistique », « combien de temps dois-je
  faire tourner ce test », « expériences de croissance », « vélocité d'expérimentation », «
  backlog d'expériences », « score ICE », « programme d'expérimentation » ou « playbook
  d'expérimentation ». Utilisez cette compétence dès que quelqu'un compare deux approches et
  souhaite mesurer laquelle est la plus performante, ou lorsqu'il souhaite mettre en place
  une pratique systématique d'expérimentation. Pour l'implémentation du tracking, voir
  analytics.
metadata:
  version: 2.0.2
---

# Configuration d'un test A/B

Vous êtes un expert en expérimentation et en tests A/B. Votre objectif est d'aider à concevoir des tests qui produisent des résultats exploitables et statistiquement valides.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que des informations non couvertes ou spécifiques à cette tâche.

Avant de concevoir un test, comprenez :

1. **Le contexte du test** - Qu'essayez-vous d'améliorer ? Quel changement envisagez-vous ?
2. **L'état actuel** - Taux de conversion de référence ? Volume de trafic actuel ?
3. **Les contraintes** - Complexité technique ? Calendrier ? Outils disponibles ?

---

## Principes fondamentaux

### 1. Partir d'une hypothèse
- Pas simplement « voyons ce qui se passe »
- Prédiction précise du résultat
- Fondée sur un raisonnement ou des données

### 2. Ne tester qu'une seule chose
- Une seule variable par test
- Sinon, impossible de savoir ce qui a fonctionné

### 3. Rigueur statistique
- Déterminer la taille de l'échantillon à l'avance
- Ne pas jeter un coup d'œil pour arrêter le test prématurément
- S'engager à respecter la méthodologie

### 4. Mesurer ce qui compte
- Métrique principale liée à la valeur métier
- Métriques secondaires pour le contexte
- Métriques garde-fous pour éviter tout impact négatif

---

## Cadre d'hypothèse

### Structure

```
Parce que [observation/données],
nous pensons que [changement]
entraînera [résultat attendu]
pour [audience].
Nous saurons que cela est vrai lorsque [métriques].
```

### Exemple

**Faible** : « Changer la couleur du bouton pourrait augmenter les clics. »

**Solide** : « Parce que les utilisateurs signalent des difficultés à trouver le CTA (selon les heatmaps et les retours), nous pensons qu'agrandir le bouton et utiliser une couleur contrastée augmentera les clics sur le CTA de 15 %+ pour les nouveaux visiteurs. Nous mesurerons le taux de clics entre la vue de la page et le début de l'inscription. »

---

## Types de tests

| Type | Description | Trafic requis |
|------|-------------|---------------|
| A/B | Deux versions, un seul changement | Modéré |
| A/B/n | Plusieurs variantes | Plus élevé |
| MVT | Plusieurs changements combinés | Très élevé |
| Split URL | URL différentes pour les variantes | Modéré |

---

## Taille de l'échantillon

### Référence rapide

| Référence (Baseline) | Hausse de 10 % | Hausse de 20 % | Hausse de 50 % |
|----------------------|----------------|----------------|----------------|
| 1 % | 150k/variante | 39k/variante | 6k/variante |
| 3 % | 47k/variante | 12k/variante | 2k/variante |
| 5 % | 27k/variante | 7k/variante | 1,2k/variante |
| 10 % | 12k/variante | 3k/variante | 550/variante |

**Calculateurs :**
- [Calculateur d'Evan Miller](https://www.evanmiller.org/ab-testing/sample-size.html)
- [Calculateur d'Optimizely](https://www.optimizely.com/sample-size-calculator/)

**Pour des tableaux détaillés de taille d'échantillon et de calcul de durée** : Voir [references/sample-size-guide.md](references/sample-size-guide.md)

---

## Sélection des métriques

### Métrique principale
- La métrique unique la plus importante
- Directement liée à l'hypothèse
- Celle qui servira à trancher l'issue du test

### Métriques secondaires
- Aident à interpréter la métrique principale
- Expliquent pourquoi/comment le changement a fonctionné

### Métriques garde-fous
- Éléments qui ne doivent pas se dégrader
- Arrêter le test en cas d'impact négatif significatif

### Exemple : Test sur une page de tarification
- **Principale** : Taux de sélection d'une formule
- **Secondaires** : Temps passé sur la page, répartition des formules choisies
- **Garde-fou** : Tickets de support, taux de remboursement

---

## Conception des variantes

### Que faire varier

| Catégorie | Exemples |
|-----------|----------|
| Titres / Textes | Angle du message, proposition de valeur, précision, ton |
| Design visuel | Mise en page, couleur, images, hiérarchie |
| CTA | Texte du bouton, taille, emplacement, nombre |
| Contenu | Informations incluses, ordre, quantité, preuve sociale |

### Bonnes pratiques
- Un changement unique et significatif
- Suffisamment marqué pour faire une différence
- Fidèle à l'hypothèse

---

## Répartition du trafic

| Approche | Répartition | Quand l'utiliser |
|----------|-------------|------------------|
| Standard | 50/50 | Par défaut pour l'A/B |
| Prudente | 90/10, 80/20 | Limiter le risque d'une variante néfaste |
| Progressive | Démarrer petit, puis augmenter | Atténuation des risques techniques |

**Points d'attention :**
- Cohérence : Les utilisateurs revoient la même variante à leur retour
- Exposition équilibrée selon les heures de la journée et les jours de la semaine

---

## Implémentation

### Côté client (Client-Side)
- JavaScript modifie la page après le chargement
- Rapide à mettre en place, peut provoquer un effet de scintillement (flicker)
- Outils : PostHog, Optimizely, VWO

### Côté serveur (Server-Side)
- Variante déterminée avant le rendu
- Aucun scintillement, nécessite du développement
- Outils : PostHog, LaunchDarkly, Split

---

## Exécution du test

### Liste de contrôle avant lancement
- [ ] Hypothèse documentée
- [ ] Métrique principale définie
- [ ] Taille d'échantillon calculée
- [ ] Variantes correctement implémentées
- [ ] Tracking vérifié
- [ ] QA effectuée sur toutes les variantes

### Pendant le test

**À FAIRE :**
- Surveiller les problèmes techniques
- Vérifier la qualité des segments
- Documenter les facteurs externes

**À ÉVITER :**
- Jeter un œil aux résultats pour arrêter prématurément
- Modifier les variantes en cours de route
- Ajouter du trafic issu de nouvelles sources

### Le problème du coup d'œil prématuré (Peeking Problem)
Regarder les résultats avant d'avoir atteint la taille d'échantillon et arrêter le test trop tôt entraîne des faux positifs et de mauvaises décisions. Engagez-vous à l'avance sur la taille de l'échantillon et faites confiance au processus.

---

## Analyse des résultats

### Signification statistique
- Pour un test à horizon fixe pré-spécifié, comparez sa p-value au seuil de significativité choisi (généralement α = 0,05).
- Une p-value décrit à quel point les données sont incompatibles avec le modèle nul : il s'agit de la probabilité, **en supposant ce modèle et ses hypothèses**, d'obtenir un résultat au moins aussi extrême que celui observé. Ce n'est pas la probabilité que le résultat soit dû au hasard, que l'hypothèse nulle soit vraie, ou qu'une variante gagne à nouveau.
- Un intervalle de confiance à 95 % provient d'une procédure qui présente une couverture de 95 % sur des échantillons répétés sous ses hypothèses. Ce n'est pas une probabilité a posteriori de 95 % que cet intervalle particulier contienne le véritable effet. Indiquez l'intervalle et la taille de l'effet aux côtés de la p-value.
- Utilisez l'analyse et la règle d'arrêt planifiées. Les tests séquentiels et les analyses bayésiennes ont leur propre interprétation ; ne convertissez pas chaque score de « confiance » d'une plateforme en une p-value à horizon fixe.

Ces distinctions suivent la [déclaration sur les p-values de l'American Statistical Association](https://www.amstat.org/asa/files/pdfs/p-valuestatement.pdf). La seule signification statistique n'établit pas la valeur commerciale et ne justifie pas à elle seule le déploiement d'une variante.

### Liste de contrôle d'analyse

1. **Taille de l'échantillon atteinte ?** Si non, le résultat est préliminaire
2. **Statistiquement significatif ?** Vérifier les intervalles de confiance
3. **Taille de l'effet significative ?** Comparer au MDE (effet minimal détectable), projeter l'impact
4. **Métriques secondaires cohérentes ?** Corroborent-elles la métrique principale ?
5. **Préoccupations sur les garde-fous ?** Quelque chose s'est-il dégradé ?
6. **Différences de segments ?** Mobile vs ordinateur ? Nouveaux vs récurrents ?

### Interprétation des résultats

| Résultat | Conclusion |
|----------|------------|
| Gagnant significatif | Vérifier la taille de l'effet, l'incertitude et les garde-fous avant de déployer |
| Perdant significatif | Conserver le contrôle, comprendre pourquoi |
| Aucune différence significative | Rapporter l'intervalle d'effet : il peut encore laisser place à un bénéfice ou un préjudice notable, ou bien exclure des effets valant la peine d'être poursuivis. Suivre la règle d'arrêt prévue ; ne pas prolonger un test à horizon fixe terminé jusqu'à ce qu'il devienne significatif. Planifier un nouveau test si nécessaire. |
| Signaux mitigés | Vérifier la qualité des données et les métriques prévues ; qualifier les constats de segments non planifiés d'exploratoires et les confirmer dans un nouveau test |

---

## Documentation

Documentez chaque test avec :
- L'hypothèse
- Les variantes (avec captures d'écran)
- Les résultats (échantillon, métriques, significativité)
- La décision et les apprentissages

**Pour des modèles** : Voir [references/test-templates.md](references/test-templates.md)

---

## Programme d'expérimentation de croissance

Les tests isolés sont utiles. Un programme d'expérimentation continu est un actif à effet cumulé. Cette section explique comment gérer les expériences comme un moteur de croissance continu, et non comme de simples tests ponctuels.

### La boucle d'expérimentation

```
1. Générer des hypothèses (à partir des données, de la recherche, de la concurrence, des retours clients)
2. Prioriser avec le score ICE
3. Concevoir et exécuter le test
4. Analyser les résultats avec rigueur statistique
5. Intégrer les variantes gagnantes dans un playbook
6. Générer de nouvelles hypothèses à partir des apprentissages
→ Répéter
```

### Génération d'hypothèses

Alimentez votre backlog d'expériences à partir de multiples sources :

| Source | Que rechercher |
|--------|----------------|
| Analytics | Points de friction/abandon, pages à faible conversion, segments sous-performants |
| Recherche client | Points de douleur, confusion, attentes non satisfaites |
| Analyse concurrentielle | Fonctionnalités, messages ou modèles d'UX qu'ils utilisent et pas vous |
| Tickets de support | Questions ou plaintes récurrentes sur les parcours de conversion |
| Heatmaps / enregistrements | Endroits où les utilisateurs hésitent, cliquent avec frustration (rage-click) ou abandonnent |
| Expériences passées | Les tests « perdants significatifs » révèlent souvent de nouveaux angles à essayer |

### Priorisation ICE

Notez chaque hypothèse de 1 à 10 sur trois dimensions :

| Dimension | Question |
|-----------|----------|
| **Impact** | Si cela fonctionne, dans quelle mesure cela fera-t-il évoluer la métrique principale ? |
| **Confiance** | À quel point sommes-nous certains que cela fonctionnera ? (Basé sur des données, pas sur l'intuition.) |
| **Facilité (Ease)** | Avec quelle rapidité et à quel coût pouvons-nous déployer et mesurer cela ? |

**Score ICE** = (Impact + Confiance + Facilité) / 3

Exécutez d'abord les expériences ayant obtenu les scores les plus élevés. Réévaluez mensuellement en fonction de l'évolution du contexte.

### Vélocité d'expérimentation

Suivez votre rythme d'expérimentation comme indicateur avancé de croissance :

| Métrique | Cible |
|----------|-------|
| Expériences lancées par mois | 4 à 8 pour la plupart des équipes |
| Taux de réussite (Win rate) | 20 à 30 % est courant pour les programmes matures (un taux durablement plus élevé peut indiquer des hypothèses trop frileuses) |
| Durée moyenne d'un test | 2 à 4 semaines |
| Profondeur du backlog | 20+ hypothèses en attente |
| Gain cumulé | Gains composés issus de l'ensemble des variantes gagnantes |

### Le Playbook d'expérimentation

Lorsqu'un test est gagnant, ne vous contentez pas de l'implémenter — documentez le schéma (pattern) :

```
## [Nom de l'expérience]
**Date** : [date]
**Hypothèse** : [l'hypothèse]
**Taille de l'échantillon** : [n par variante]
**Résultat** : [gagnant / perdant / non concluant] — [métrique principale] a varié de [X %] (IC à 95 % : [plage], p=[valeur])
**Garde-fous** : [toutes les métriques garde-fous et leurs résultats]
**Écarts par segment** : [différences notables par appareil, segment ou cohorte]
**Pourquoi cela a fonctionné / échoué** : [analyse]
**Schéma (Pattern)** : [l'enseignement réutilisable — ex. : « la preuve sociale près des CTA de prix augmente la sélection d'une formule »]
**À appliquer à** : [autres pages/parcours où ce schéma pourrait fonctionner]
**Statut** : [implémenté / mis en attente / nécessite un test de suivi]
```

Au fil du temps, votre playbook devient une bibliothèque de schémas de croissance éprouvés, spécifiques à votre produit et à votre audience.

### Rythme des expériences

**Hebdomadaire (30 min)** : Examiner les expériences en cours pour détecter d'éventuels problèmes techniques et vérifier les métriques garde-fous. Ne désignez pas de gagnants trop tôt — mais arrêtez les tests dont les garde-fous sont significativement négatifs.

**Bihebdomadaire** : Conclure les expériences terminées. Analyser les résultats, mettre à jour le playbook, lancer l'expérience suivante depuis le backlog.

**Mensuel (1 heure)** : Examiner la vélocité des expériences, le taux de réussite, le gain cumulé. Réapprovisionner le backlog d'hypothèses. Reprioriser avec ICE.

**Trimestriel** : Auditer le playbook. Quels schémas ont été largement appliqués ? Quels schémas gagnants n'ont pas encore été déployés à grande échelle ? Quelles zones du funnel sont sous-testées ?

---

## Erreurs courantes

### Conception du test
- Tester un changement trop minime (indétectable)
- Tester trop de choses à la fois (impossible d'isoler la cause)
- Absence d'hypothèse claire

### Exécution
- Arrêter le test trop tôt
- Modifier des éléments en cours de test
- Ne pas vérifier la bonne implémentation

### Analyse
- Ignorer les intervalles de confiance
- Sélectionner arbitrairement des segments favorables (cherry-picking)
- Surinterpréter des résultats non concluants

---

## Questions spécifiques à la tâche

1. Quel est votre taux de conversion actuel ?
2. Quel est le volume de trafic sur cette page ?
3. Quel changement envisagez-vous et pourquoi ?
4. Quelle est la plus petite amélioration qui vaille la peine d'être détectée ?
5. De quels outils disposez-vous pour effectuer des tests ?
6. Avez-vous déjà testé cette zone auparavant ?

---

## Compétences associées

- **cro** : Pour générer des idées de tests basées sur les principes de CRO
- **analytics** : Pour configurer la mesure des tests
- **copywriting** : Pour rédiger les textes des variantes
