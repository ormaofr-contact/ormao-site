---
name: li-post
description: >-
  Rédige un post LinkedIn à partir d'une idée brute en utilisant 21 formules
  d'accroches éprouvées, avec la voix propre de l'utilisateur, humanisé pour ne
  pas ressembler à de l'IA. À utiliser dès que l'utilisateur veut un post
  LinkedIn, une accroche, un brouillon pour le fil, « publie sur X »,
  « transforme ceci en post LinkedIn », ou demande des options d'accroches.
  Génère trois options d'accroches, un brouillon complet et un bloc prêt à copier
  qui n'est jamais publié sans un accord explicite.
---

# li-post

Transforme une idée brute en un post LinkedIn qui sonne exactement comme la personne qui l'a publié.

## Avant d'écrire

1. Lis `~/.claude/linkedin/voice.md` s'il existe. Ce fichier correspond au profil vocal de l'utilisateur : sa façon de parler, ce qu'il ne dit jamais, à qui il s'adresse. S'il n'existe pas, demande **trois de ses propres posts passés**, déduis-en la voix à partir de ceux-ci, et rédige le fichier. Ne saute pas cette étape et n'invente pas de voix. Un post rédigé avec la mauvaise voix est pire que pas de post du tout.
2. Lis `hooks.json` dans ce dossier. Les 21 formules s'y trouvent, avec leurs modèles, des exemples remplis, l'utilité de chacune et la façon dont chacune est habituellement gâchée.
3. Si l'idée est trop mince (« fais un post sur l'IA »), ne la meuble pas. Pose une seule question groupée : que s'est-il passé, à qui, et combien cela a-t-il coûté ou rapporté ? Un post a besoin d'un fait précis et vrai. Obtiens-le avant d'écrire.

## La structure

LinkedIn valorise le temps d'arrêt (dwell time), les enregistrements et les commentaires, dans cet ordre. Par conséquent :

```
Ligne 1    l'accroche. Seule. Elle doit survivre à la troncature à environ 140 caractères sur mobile.
Ligne 2    le dénouement de la ligne 1, pas une mise en place pour la ligne 3.
Corps      paragraphes courts, de 1 à 3 lignes chacun, une ligne vide entre chaque.
           Pas de pavé. L'espace blanc constitue le format.
Le pivot   une ligne qui recadre ce qui a précédé.
Clôture    une question précise, ou une consigne. Jamais les deux.
```

Longueur : 900 à 1 300 caractères est la plage efficace pour un post textuel. Moins de 400 ressemble à une simple pensée, pas à un post. Plus de 2 000 doit mériter chaque ligne, et le clic sur « voir plus » doit être rentabilisé dès la ligne 2.

## La boucle

**1. Choisis trois accroches, pas une seule.** Passe l'idée au crible de `hooks.json` et choisis les trois formules qui lui correspondent véritablement. Des formules différentes, pas trois déclinaisons d'une même formule. Présente-les sous la forme de trois lignes numérotées et indique celle que tu retiendrais et pourquoi, en une phrase.

**2. Rédige le post complet** sur l'accroche la plus forte.

**3. Humanise-le.** Passe le brouillon dans `/li-human` avant de le montrer. Chaque post issu de cette compétence est livré humanisé. Il ne s'agit pas d'une étape optionnelle, c'est la raison pour laquelle le brouillon vaut la peine d'être lu.

**4. Affiche le bloc.** Prêt à copier, dans un bloc de code délimité, exactement tel qu'il doit être collé. Ensuite, en dessous :

```
POST READY
hook:      #17 Time Anchor
length:    1,140 characters
humanizer: 6 artefacts stripped, human score 84 PASS
post at:   Tuesday 8:15am ET (from your plan)

Reply "yes" to log it, or tell me what to change.
```

**5. Ne publie jamais.** Cette compétence produit du texte. L'utilisateur le publie. En cas de « oui », ajoute le post à la fin de `~/.claude/linkedin/log.md` avec la date, l'accroche utilisée et la première ligne, afin que `/li-audit` dispose d'un historique sur lequel travailler plus tard.

## Les règles qui font la différence

- **Une seule idée par post.** Si le brouillon en contient deux, tu as deux posts. Dis-le.
- **Des chiffres plutôt que des adjectifs.** « 4 200 $ » vaut mieux que « beaucoup ». Si l'utilisateur ne t'a pas fourni de chiffre, demande-lui-en un plutôt que de contourner le manque par l'écriture.
- **Pas d'incitation artificielle à l'engagement (engagement bait).** « Qu'en pensez-vous ? » et « D'accord avec ça ? » sont dépassés. La question de clôture doit être une question que seul ce post spécifique pouvait poser.
- **Trois hashtags au maximum**, tout en bas, et uniquement s'il s'agit de véritables catégories suivies par des utilisateurs.
- **Aucun lien dans le corps du post.** LinkedIn bride la portée des posts contenant des liens sortants. Place le lien dans le premier commentaire et précise-le dans le récapitulatif.
- **N'invente jamais rien.** Aucun chiffre, client, montant de revenu ou résultat inventé sous le nom de l'utilisateur, même à titre temporaire. Si un chiffre est nécessaire et inconnu, laisse `{{your number}}` dans le brouillon et signale-le.

## Exemple

```
/li-post we built an internal tool that cut proposal time from 5 hours to 20 min
```

```
HOOKS
1. #17 Time Anchor    Writing a proposal used to take me 5 hours. It now takes 20 minutes.
2. #12 Comparison     A $12,000 proposal writer vs a weekend and a template. The weekend won.
3. #3  Mistake        For two years I charged clients for hours I was wasting on formatting.

Shipping #17: the ratio is believable and the number is yours.
