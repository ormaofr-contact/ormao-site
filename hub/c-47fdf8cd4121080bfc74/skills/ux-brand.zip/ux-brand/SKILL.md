---
name: brand
description: Voix de marque, identité visuelle, cadres de messages, gestion des ressources, cohérence de marque. Activer pour le contenu de marque, le ton de voix, les ressources marketing, la conformité de marque, les guides de style.
argument-hint: "[update|review|create] [args]"
metadata:
  author: claudekit
  version: "1.0.0"
---

# Brand

Identité de marque, voix, messages, gestion des ressources et cadres de cohérence.

## Quand l'utiliser

- Définition de la voix de marque et directives sur le ton du contenu
- Normes d'identité visuelle et développement de guides de style
- Création de cadres de messages
- Examen et audit de cohérence de marque
- Organisation, nommage et approbation des ressources
- Gestion de la palette de couleurs et spécifications typographiques

## Chemins des scripts

Les chemins des scripts dans cette compétence et ses `references/` sont relatifs au répertoire qui contient ce SKILL.md, et non au projet : `scripts/<file>` correspond au propre dossier `scripts/` de cette compétence, et `../<skill>/scripts/<file>` est une sous-compétence sœur installée à ses côtés. Construisez le chemin complet à partir de ce répertoire (Claude Code l'indique comme le répertoire de base de la compétence lors de son chargement) et conservez le répertoire de travail à la racine du projet — les scripts lisent et écrivent les fichiers du projet tels que `docs/brand-guidelines.md`, `assets/design-tokens.json` ou `src/` relativement à celui-ci.

## Démarrage rapide

**Injecter le contexte de marque dans les prompts :**
```bash
node scripts/inject-brand-context.cjs
node scripts/inject-brand-context.cjs --json
```

**Valider une ressource :**
```bash
node scripts/validate-asset.cjs <asset-path>
```

**Extraire/comparer les couleurs :**
```bash
node scripts/extract-colors.cjs --palette
node scripts/extract-colors.cjs <image-path>
```

## Flux de synchronisation de la marque

```bash
# 1. Modifier docs/brand-guidelines.md (ou utiliser /brand update)
# 2. Synchroniser vers les design tokens
node scripts/sync-brand-to-tokens.cjs
# 3. Vérifier
node scripts/inject-brand-context.cjs --json | head -20
```

La synchronisation s'arrête lorsqu'elle détecte des fichiers de tokens existants, des propriétés personnalisées `:root`
ou des variables Tailwind v4 `@theme` dans les points d'entrée CSS courants et leurs imports
CSS locaux, ou des couleurs de thème et presets Tailwind. Examinez la source signalée
avant de continuer. Si les fichiers détectés sont les sorties gérées
`assets/design-tokens.*` d'une synchronisation précédente et que leur remplacement est
intentionnel, réexécutez avec `--force`.

**Fichiers synchronisés :**
- `docs/brand-guidelines.md` → Source de vérité
- `assets/design-tokens.json` → Définitions des tokens
- `assets/design-tokens.css` → Variables CSS

## Sous-commandes

| Sous-commande | Description | Référence |
|---------------|-------------|-----------|
| `update` | Mettre à jour l'identité de marque et synchroniser vers tous les design systems | `references/update.md` |

## Références

| Sujet | Fichier |
|-------|---------|
| Cadre de voix | `references/voice-framework.md` |
| Identité visuelle | `references/visual-identity.md` |
| Messages | `references/messaging-framework.md` |
| Cohérence | `references/consistency-checklist.md` |
| Modèle de directives | `references/brand-guideline-template.md` |
| Organisation des ressources | `references/asset-organization.md` |
| Gestion des couleurs | `references/color-palette-management.md` |
| Typographie | `references/typography-specifications.md` |
| Utilisation du logo | `references/logo-usage-rules.md` |
| Liste de contrôle d'approbation | `references/approval-checklist.md` |

## Scripts

| Script | Rôle |
|--------|------|
| `scripts/inject-brand-context.cjs` | Extraire le contexte de marque pour l'injection dans les prompts |
| `scripts/sync-brand-to-tokens.cjs` | Synchroniser brand-guidelines.md → design-tokens.json/css |
| `scripts/validate-asset.cjs` | Valider le nommage, la taille et le format des ressources |
| `scripts/extract-colors.cjs` | Extraire et comparer les couleurs par rapport à la palette |

## Modèles

| Modèle | Rôle |
|--------|------|
| `templates/brand-guidelines-starter.md` | Modèle de départ complet pour de nouvelles marques |

## Routage

1. Analyser la sous-commande à partir de `$ARGUMENTS` (premier mot)
2. Charger le fichier `references/{subcommand}.md` correspondant
3. Exécuter avec les arguments restants
