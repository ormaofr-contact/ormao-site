---
name: ig-dm
description: >-
  Rédiger des DM Instagram qui obtiennent des réponses : l'envoi suite à un mot-clé, le premier
  message à quelqu'un qui a interagi, le pitch de collaboration et les deux relances. À utiliser
  lorsque l'utilisateur dit "envoie un DM à cette personne", "qu'est-ce que je lui envoie", "message
  de prospection", "comment relancer", "pitcher cette marque", ou lorsqu'il contacte
  une personne en particulier.
---

# ig-dm

Les DM Instagram sont le seul endroit de la plateforme où l'argent change
véritablement de mains, et c'est aussi là que la plupart des comptes détruisent le
capital sympathie que leur contenu a généré. Toute la différence réside dans la
personne qui a fait le premier pas.

## Les trois types de DM, et seuls trois méritent d'être écrits

**1. La réponse à une main levée.** La personne a commenté le mot-clé, répondu
au sondage, réagi à une story, ou enregistré et posé une question. Elle a fait le premier
pas. Cela représente 90 % des DM qui valent la peine d'être envoyés, et cela convertit
parce qu'il ne s'agit pas de démarchage à froid.

**2. L'approche tiède.** Quelqu'un dont l'utilisateur commente sincèrement les
publications depuis des semaines. Un fil de discussion partagé existe déjà.

**3. Le pitch de collaboration ou de marque.** Une proposition spécifique adressée à un
compte précis, avec une justification claire de ce choix.

Tout le reste relève du DM à froid envoyé à des inconnus, ce que tout le monde fait,
et c'est précisément pourquoi les taux de réponse sont si bas. Si l'utilisateur demande
une séquence à froid, dites-lui clairement qu'il s'agit de l'action la moins rentable qu'il
puisse accomplir avec ce même temps imparti, et proposez-lui l'alternative : commenter les
publications de ces dix comptes pendant deux semaines d'abord. Rédigez-la ensuite s'il le
souhaite toujours.

## Avant de rédiger, obtenez les éléments précis

Demandez en une seule fois :

1. **Qui** : l'identifiant, ce qu'elle fait, et ce qu'elle a publié ou fait pour
   déclencher cela.
2. **Le déclencheur** : la véritable raison d'envoyer un message aujourd'hui. Un mot-clé
   commenté, une story à laquelle elle a répondu, une publication partagée. Pas simplement "elle correspond
   au client idéal".
3. **Ce que veut l'utilisateur** : une conversation, une vente, une collaboration, une recommandation.
   Soyez honnête avec vous-même, même si le message n'attaque pas directement par cela.

S'il n'y a pas de déclencheur, il n'y a pas de message. Dites-le.

## L'envoi suite à un mot-clé

Le DM le plus courant de ce pack et le plus facile à gâcher. La personne a commenté
un seul mot. Elle s'attend à recevoir la ressource promise. Alors :

```
{their name}, here it is: {the thing, or the link}.

{one line on how to use it}

{one question they can answer in four words}
```

Envoyez la ressource **en premier**, dès le premier message, sans aucune condition préalable. Un
post avec mot-clé qui livre un "avant de te l'envoyer, puis-je te demander ce que tu fais dans la vie ?"
est perçu comme un piège et ne s'oublie pas. La question à la fin est ce qui engage
la conversation, et elle reste facultative pour la personne.

Les réponses automatisées aux mots-clés sont une fonctionnalité prise en charge pour les comptes
professionnels, via les outils natifs d'Instagram ou un partenaire approuvé. L'utiliser ne pose
aucun problème. Envoyer des DM en masse non sollicités en pose un, et c'est le moyen le plus
rapide de voir son compte restreint.

## Le premier message à une audience tiède

- **Deux à quatre phrases.** Un pavé de texte équivaut à une suppression immédiate.
- **Faire référence à l'élément précis.** Le commentaire, le post, la réponse. Avec ses
  propres mots.
- **Donner avant de demander.** Un chiffre, un template, un nom, une réponse.
- **Une seule demande, modeste.** "Partant pour un court échange ?" fonctionne bien mieux que
  "laisse-moi te faire une démonstration de la plateforme".
- **Pas de lien ni de lien Calendly dans le premier message.** Cela ressemble à un tunnel de vente,
  parce que c'en est un.
- **Pas de note vocale à un inconnu.** C'est un excellent outil, mais réservé aux personnes qui
  connaissent déjà la voix de l'utilisateur.

## Le pitch de collaboration

Quatre lignes, dans cet ordre : ce que vous l'avez vu faire, l'idée précise,
ce qu'elle y gagne, ce dont vous avez besoin de sa part. Un post en collaboration s'affiche sur les deux
grilles et touche les deux audiences, ce qui constitue le levier de croissance le plus puissant
sur Instagram sans débourser un centime. Présentez-le sous cet angle et soyez
concret sur la répartition des rôles.

## Les relances

Deux. C'est le chiffre exact.

- **+4 jours** : apporter un élément nouveau. Jamais de "je me permets de remonter ce message". S'il n'y a
  rien de nouveau, il n'y a pas de relance.
- **+10 jours** : le message de clôture. Indiquez que vous n'insisterez plus, et tenez parole.
  Ce message génère une part surprenante du total des réponses, car il lève
  toute pression.

Ensuite, arrêtez. Une troisième relance ne convertit personne et détruit la relation.

## À ne jamais faire

- N'automatisez jamais les DM de prospection, et n'utilisez jamais un outil qui envoie des messages
  programmés à des personnes qui n'ont pas interagi. Cela enfreint les Conditions d'utilisation d'Instagram
  et entraîne la restriction du compte.
- N'inventez jamais avoir regardé un contenu, avoir un contact en commun ou quoi que ce soit de partagé.
- Ne commencez jamais par "Hello ! Petite question" pour ensuite ne poser aucune question.
- N'envoyez jamais le pitch dans le même message que le compliment.

## Format de sortie

Le message, le nombre de caractères, et les deux relances avec le jour d'envoi de chacune,
le tout passé au crible de `/ig-human`. L'utilisateur envoie chacun d'entre eux
manuellement, ou via sa propre automatisation approuvée uniquement pour les réponses par mot-clé.
