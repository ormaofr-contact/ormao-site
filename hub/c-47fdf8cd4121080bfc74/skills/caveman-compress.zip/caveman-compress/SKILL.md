---
name: caveman-compress
description: >
  Compresse un fichier de mémoire tel que CLAUDE.md ou une liste de tâches au format homme des cavernes
  pour économiser des jetons d'entrée, tout en conservant une sauvegarde lisible. Envoie le texte du fichier au
  fournisseur de modèle configuré. Déclencheur : /caveman-compress.
---

# Caveman Compress

## Objectif

> **Les données quittent la machine.** La compression envoie le texte intégral du fichier au fournisseur de modèle pour lequel `scripts/compress.py` est configuré : le CLI `claude`, l'API Anthropic ou un point de terminaison compatible OpenAI. Les fichiers dont le nom ressemble à des secrets (`.env`, `credentials`, `secrets`, `.netrc`, …) sont refusés avant d'être lus. Ne compressez pas un fichier que le fournisseur ne devrait pas voir.

Compresse les fichiers en langage naturel (CLAUDE.md, todos, préférences) en langage "homme des cavernes" (caveman-speak) pour réduire les jetons d'entrée. La version compressée écrase l'original. Une sauvegarde lisible par un humain est enregistrée sous `<filename>.original.md`, mais PAS à côté du fichier source — elle réside dans un répertoire de données hors de l'arborescence (`$XDG_DATA_HOME/caveman-compress/backups/<parent-dir-name>/`, ou `%LOCALAPPDATA%\caveman-compress\backups\<parent-dir-name>\` sous Windows) afin que les chargeurs automatiques de compétences ne la réingèrent pas en tant que fichier actif.

## Déclencheur

`/caveman-compress <filepath>` ou lorsque l'utilisateur demande de compresser un fichier de mémoire.

**Nécessite un chemin de fichier explicite.** Si l'utilisateur colle du texte brut au lieu de nommer un fichier, n'improvisez PAS une compression en ligne — demandez-lui le chemin du fichier à compresser, ou proposez d'enregistrer d'abord le texte collé dans un fichier. Écrire votre propre raisonnement/commentaire sur la demande dans la sortie compressée (par ex. "L'utilisateur a transmis le texte directement, pas un chemin de fichier...") est exactement l'erreur contre laquelle cette règle protège — ne laissez jamais cela fuiter dans un fichier enregistré.

## Processus

1. Les scripts de compression se trouvent dans `scripts/` (adjacents à ce SKILL.md). Si le chemin n'est pas immédiatement disponible, recherchez `scripts/__main__.py` à côté de ce SKILL.md.

2. Depuis le répertoire contenant ce SKILL.md, exécutez :

python3 -m scripts <absolute_filepath>

3. Le CLI va :
- détecter le type de fichier (aucun jeton)
- appeler Claude pour compresser
- valider la sortie (aucun jeton)
- en cas d'erreurs : corriger de manière ciblée avec Claude (corrections ciblées uniquement, pas de recompression)
- réessayer jusqu'à 2 fois
- si l'échec persiste après 2 tentatives : signaler l'erreur à l'utilisateur, laisser le fichier d'origine intact

4. Retourner le résultat à l'utilisateur

## Règles de compression

### Supprimer
- Articles : a, an, the
- Mots de remplissage : just, really, basically, actually, simply, essentially, generally
- Formules de politesse : "sure", "certainly", "of course", "happy to", "I'd recommend"
- Formulations hésitantes : "it might be worth", "you could consider", "it would be good to"
- Tournures redondantes : "in order to" → "to", "make sure to" → "ensure", "the reason is because" → "because"
- Connecteurs superflus : "however", "furthermore", "additionally", "in addition"

### Conserver EXACTEMENT (ne jamais modifier)
- Blocs de code (délimités par ``` et indentés)
- Code inline (`contenu entre backticks`)
- URL et liens (URL complètes, liens markdown)
- Chemins de fichiers (`/src/components/...`, `./config.yaml`)
- Commandes (`npm install`, `git commit`, `docker build`)
- Termes techniques (noms de bibliothèques, noms d'API, protocoles, algorithmes)
- Noms propres (noms de projets, personnes, entreprises)
- Dates, numéros de version, valeurs numériques
- Variables d'environnement (`$HOME`, `NODE_ENV`)

### Conserver la structure
- Tous les titres markdown (garder le texte exact du titre, compresser le corps en dessous)
- Hiérarchie des puces (garder le niveau d'imbrication)
- Listes numérotées (garder la numérotation)
- Tableaux (compresser le texte des cellules, conserver la structure)
- En-têtes Frontmatter/YAML dans les fichiers markdown

### Compresser
- Utiliser des synonymes courts : "big" et non "extensive", "fix" et non "implement a solution for", "use" et non "utilize"
- Fragments acceptés : "Run tests before commit" et non "You should always run tests before committing"
- Supprimer les "you should", "make sure to", "remember to" — indiquer simplement l'action
- Fusionner les puces redondantes qui expriment la même chose différemment
- Conserver un seul exemple lorsque plusieurs exemples illustrent le même modèle

RÈGLE CRITIQUE :
Tout ce qui se trouve à l'intérieur de ``` ... ``` doit être copié EXACTEMENT.
Ne pas :
- supprimer les commentaires
- supprimer les espaces
- réordonner les lignes
- raccourcir les commandes
- simplifier quoi que ce soit

Le code inline (`...`) doit être conservé EXACTEMENT.
Ne modifiez rien à l'intérieur des backticks.

Si le fichier contient des blocs de code :
- Traiter les blocs de code comme des zones en lecture seule
- Compresser uniquement le texte en dehors de ceux-ci
- Ne pas fusionner les sections autour du code

## Modèle

Original :
> You should always make sure to run the test suite before pushing any changes to the main branch. This is important because it helps catch bugs early and prevents broken builds from being deployed to production.

Compressé :
> Run tests before push to main. Catch bugs early, prevent broken prod deploys.

Original :
> The application uses a microservices architecture with the following components. The API gateway handles all incoming requests and routes them to the appropriate service. The authentication service is responsible for managing user sessions and JWT tokens.

Compressé :
> Microservices architecture. API gateway route all requests to services. Auth service manage user sessions + JWT tokens.

## Limites

- Compresser UNIQUEMENT les fichiers en langage naturel (.md, .txt, .typ, .typst, .tex, sans extension)
- Ne JAMAIS modifier : .py, .js, .ts, .json, .yaml, .yml, .toml, .env, .lock, .css, .html, .xml, .sql, .sh
- Si le fichier a un contenu mixte (prose + code), compresser UNIQUEMENT les sections de texte
- En cas de doute sur le fait qu'un élément soit du code ou de la prose, le laisser inchangé
- Le fichier original est sauvegardé sous FILE.original.md avant d'être écrasé — dans le répertoire de données de sauvegarde hors de l'arborescence (voir Objectif), pas à côté du fichier source
- Ne jamais compresser FILE.original.md (l'ignorer)
