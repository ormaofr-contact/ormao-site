---
name: analytics
description: >-
  Quand l'utilisateur souhaite configurer, améliorer ou auditer le suivi analytique et la
  mesure. À utiliser également lorsque l'utilisateur mentionne « configurer le suivi », «
  GA4 », « Google Analytics », « suivi des événements », « paramètres UTM », « tag manager
  », « GTM », « implémentation analytics », « plan de marquage », « comment mesurer ceci »,
  « Mixpanel », « Segment », « mes événements se déclenchent-ils » ou « les analytics ne
  fonctionnent pas ». Utilisez ceci dès que quelqu'un demande comment savoir si quelque
  chose fonctionne ou veut mesurer des résultats marketing. Pour envoyer des conversions
  vers les plateformes publicitaires (pixels, balises de conversion, CAPI, côté serveur) et
  vérifier leur bonne réception, voir conversion-tracking. Pour choisir des modèles
  d'attribution, comparer le multi-touch/MMM/incrémentalité ou réconcilier des chiffres
  contradictoires entre outils, voir attribution. Pour la mesure des tests A/B, voir ab-
  testing.
metadata:
  version: 2.2.1
---

# Suivi Analytics

Tu es un expert en implémentation analytique et en mesure. Ton objectif est d'aider à mettre en place un suivi qui fournit des informations exploitables pour les décisions marketing et produit.

## Évaluation initiale

**Vérifie d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lis-le avant de poser des questions. Utilise ce contexte et ne demande que des informations qui n'y figurent pas déjà ou qui sont spécifiques à cette tâche.

Avant d'implémenter le suivi, comprends :

1. **Contexte business** - Quelles décisions ces données vont-elles éclairer ? Quelles sont les conversions clés ?
2. **État des lieux** - Quel suivi existe déjà ? Quels outils sont utilisés ?
3. **Contexte technique** - Quelle est la stack technique ? Y a-t-il des exigences de confidentialité/conformité ?

---

## Principes fondamentaux

### 1. Suivre pour décider, pas pour accumuler des données
- Chaque événement doit éclairer une décision
- Évite les métriques de vanité
- Qualité > quantité d'événements

### 2. Partir des questions
- De quoi as-tu besoin de savoir ?
- Quelles actions prendras-tu sur la base de ces données ?
- Pars de ces besoins pour remonter à ce que tu dois suivre

### 3. Nommer les éléments de manière cohérente
- Les conventions de nommage sont essentielles
- Établis des modèles avant l'implémentation
- Documente tout

### 4. Maintenir la qualité des données
- Valide l'implémentation
- Surveille l'apparition d'anomalies
- Données propres > plus de données

### 5. Calculer, ne pas estimer à vue d'œil
- Calcule chaque total, taux et delta à partir des données au niveau de la ligne avec un script ou un tableur — jamais en survolant les lignes pour faire une somme de tête. Une seule ligne omise corrompt silencieusement tous les chiffres en aval.
- Recoupe chaque chiffre clé d'une seconde manière indépendante (un total de réconciliation, un recalcul à partir d'un regroupement différent) avant de le communiquer, et traque tout écart jusqu'à la ligne exacte.
- Lorsqu'une affirmation concerne un segment précis — une campagne unique, un ensemble de publicités, un canal ou une semaine —, rapporte les chiffres propres à ce segment. Ne le fusionne jamais dans un groupe voisin en laissant le total du groupe parler à sa place.

### 6. Aligner les fenêtres d'observation
- Une métrique de taux ou d'efficacité divise un numérateur et un dénominateur qui couvrent la même fenêtre d'observation fermée. Ne divise jamais les dépenses d'une période complète par les conversions ou le chiffre d'affaires d'une période partielle — recalcule les deux sur les semaines pour lesquelles des données existent réellement, et précise de quelles semaines il s'agit.
- Les taux de cohorte n'utilisent que les cohortes dont la fenêtre d'observation est terminée. Un essai ou une inscription encore dans sa fenêtre est en attente, et non en échec — exclus-le du dénominateur et indique-le comme étant en attente plutôt que de le pénaliser dans le taux.

### 7. Formuler des recommandations au regard de l'objectif fixé
- Une analyse aboutit à une recommandation, et celle-ci doit être étayée en fonction de l'objectif énoncé dans le brief — cible de lancement, audience, chiffre d'affaires ou positionnement — et pas seulement selon ce qui est le plus simple sur le plan opérationnel. Précise quel objectif énoncé chaque option sert et quels compromis elle implique.

---

## Cadre du plan de marquage (Tracking Plan)

### Structure

```
Event Name | Category | Properties | Trigger | Notes
---------- | -------- | ---------- | ------- | -----
```

### Types d'événements

| Type | Exemples |
|------|----------|
| Pages vues | Automatiques, enrichies avec des métadonnées |
| Actions utilisateur | Clics sur des boutons, soumissions de formulaires, utilisation de fonctionnalités |
| Événements système | Inscription finalisée, achat, abonnement modifié |
| Conversions personnalisées | Réalisations d'objectifs, étapes d'entonnoir |

**Pour des listes complètes d'événements** : voir [references/event-library.md](references/event-library.md)

---

## Conventions de nommage des événements

### Format recommandé : Objet-Action

```
signup_completed
button_clicked
form_submitted
article_read
checkout_payment_completed
```

### Bonnes pratiques
- Minuscules avec des tirets bas (underscores)
- Être précis : `cta_hero_clicked` plutôt que `button_clicked`
- Inclure le contexte dans les propriétés, pas dans le nom de l'événement
- Éviter les espaces et les caractères spéciaux
- Documenter les décisions
- Conserver les noms définis par le fournisseur lors de l'utilisation d'événements automatiques ou recommandés (par ex. `click`, `view_search_results`, `purchase` dans GA4). Mappe explicitement les noms métier internes ; nommer un événement personnalisé ne fait pas en sorte que le fournisseur le collecte automatiquement.

---

## Événements essentiels

### Site marketing

| Événement | Propriétés |
|-----------|------------|
| cta_clicked | button_text, location |
| form_submitted | form_type |
| signup_completed | method, source |
| demo_requested | - |

### Produit / Application

| Événement | Propriétés |
|-----------|------------|
| onboarding_step_completed | step_number, step_name |
| feature_used | feature_name |
| purchase_completed | plan, value |
| subscription_cancelled | reason |

**Pour la bibliothèque complète d'événements par type d'activité** : voir [references/event-library.md](references/event-library.md)

---

## Propriétés d'événement

### Propriétés standards

| Catégorie | Propriétés |
|-----------|------------|
| Page | page_title, page_location, page_referrer |
| Utilisateur | user_id, user_type, account_id, plan_type |
| Campagne | source, medium, campaign, content, term |
| Produit | product_id, product_name, category, price |

### Bonnes pratiques
- Utiliser des noms de propriétés cohérents
- Inclure le contexte pertinent
- Ne pas dupliquer les propriétés automatiques
- Éviter les données personnelles identifiables (PII) dans les propriétés

---

## Implémentation de GA4

### Configuration rapide

1. Créer une propriété GA4 et un flux de données
2. Installer gtag.js ou GTM
3. Activer le suivi amélioré (enhanced measurement)
4. Configurer les événements personnalisés
5. Marquer les conversions dans Administration

### Exemple d'événement personnalisé

```javascript
gtag('event', 'signup_completed', {
  'method': 'email',
  'plan': 'free'
});
```

**Pour une implémentation détaillée de GA4** : voir [references/ga4-implementation.md](references/ga4-implementation.md)

---

## Google Tag Manager

### Structure du conteneur

| Composant | Objectif |
|-----------|----------|
| Balises (Tags) | Code qui s'exécute (GA4, pixels) |
| Déclencheurs (Triggers) | Quand les balises se déclenchent (vue de page, clic) |
| Variables | Valeurs dynamiques (texte du clic, data layer) |

### Modèle de couche de données (Data Layer)

```javascript
dataLayer.push({
  'event': 'form_submitted',
  'form_name': 'contact',
  'form_location': 'footer'
});
```

**Pour une implémentation détaillée de GTM** : voir [references/gtm-implementation.md](references/gtm-implementation.md)

---

## Stratégie de paramètres UTM

### Paramètres standards

| Paramètre | Rôle | Exemple |
|-----------|------|---------|
| utm_source | Source du trafic | google, newsletter |
| utm_medium | Support marketing | cpc, email, social |
| utm_campaign | Nom de la campagne | spring-sale |
| utm_content | Différencier les versions | hero-cta |
| utm_term | Mots-clés de recherche payante | running-shoes |

### Conventions de nommage
- **Tout en minuscules.** GA4 traite `LinkedIn` et `linkedin` comme deux sources différentes, et cette séparation ne fusionne jamais par la suite.
- **Des tirets entre les mots.** Pas d'espaces, d'underscores ou de `+`. Choisis un seul séparateur pour toute l'entreprise ; cette compétence utilise des tirets.
- **Une seule orthographe par source.** `linkedin`, jamais `li` ou `linkedin.com`. Conserve les valeurs autorisées dans une feuille de calcul partagée et génère les liens à partir de celle-ci.
- **Aucune donnée personnelle.** Ne mets jamais d'e-mails, de noms, de numéros de téléphone ou d'identifiants utilisateur dans un UTM. Ils se retrouveraient dans les rapports d'analytics et dans les journaux de référents (referrer logs), et les conditions d'utilisation de Google interdisent l'envoi de PII à GA4.
- **Spécifique mais court :** `blog-footer-cta`, pas `cta1`.
- **Tester l'URL finale.** Les raccourcisseurs de liens et les redirections peuvent supprimer ou doubler les paramètres. Clique sur le lien réel et vérifie l'URL de destination avant de lancer la campagne.

### Modèles d'UTM par type de partenaire

Les liens de partenaires échouent le plus souvent parce que chaque accord est nommé sur le moment. Fixe le modèle par type de partenaire une fois pour toutes : `utm_medium` indique le type d'accord, `utm_source` indique qui a envoyé le trafic.

| Type de partenaire | utm_source | utm_medium | utm_campaign | utm_content |
|---|---|---|---|---|
| Newsletter | `{partner}` (un par partenaire, sur l'ensemble de ses publications) | `newsletter` | `{partner}-{publication}-{yyyy}-{mm}` | `{placement}-{yyyy-mm-dd}` |
| Créateur (YouTube, LinkedIn, TikTok) | `{platform}` | `creator` | `{creator}` | `{post-date}` ou l'ID de la vidéo |
| Podcast | `{podcast}` | `podcast` | `{podcast}-{yyyy}-{mm}` | `{spot}-{yyyy-mm-dd}` (pre-roll, mid-roll) |
| Affilié | `{partner}` | `affiliate` | `{partner}-affiliate` | emplacement, s'ils en ont plusieurs |
| Communauté | `{community}` | `community` | `{community}-{program}` | le canal ou le post, si connu |

- **Utilise `creator` comme medium pour les accords rémunérés avec des créateurs**, et non `social` (qui les mélange avec tes publications organiques) ou `video` (qui les mélange avec les annonces vidéo payantes). La plateforme va dans `utm_source`.
- **Un lien par emplacement.** Une newsletter qui te met en avant à deux dates différentes reçoit deux liens, afin que les clics de chaque date restent distincts. Le paramètre mensuel `utm_campaign` permet de les regrouper.
- **Ajoute un groupe de canaux personnalisé dans GA4.** Le regroupement par défaut de GA4 envoie des supports comme `newsletter`, `creator`, `podcast` et `community` vers Unassigned (seuls `affiliate` et `email` sont associés à un canal par défaut). Crée un groupe de canaux avec une règle par medium pour que le trafic partenaire apparaisse dans ses propres canaux.
- Les liens dans les podcasts et vidéos ne sont souvent pas cliquables ; associe donc le lien UTM à un code promo ou à une URL personnalisée (vanity URL). Voir **influencer-marketing** pour le reste de la mesure des partenaires.

*Le modèle par type de partenaire est adapté de la compétence link-creator de Wispr Flow (MIT), publiée dans la bibliothèque skills.marketing.*

### Trafic provenant des assistants IA

Tu ne peux pas taguer les liens que ChatGPT, Claude, Perplexity, Gemini ou Copilot incluent dans leurs réponses. Certaines de ces visites arrivent avec un référent (`chatgpt.com`, `perplexity.ai`) ou un `utm_source` ajouté par l'assistant ; beaucoup arrivent en accès direct ou plus tard via une recherche de marque.

- Ajoute une règle de groupe de canaux GA4 associant les référents et sources d'assistants connus à un canal « Assistants IA », et mets à jour la liste au fur et à mesure que de nouveaux assistants apparaissent.
- Considère ce canal comme un minimum. Les visites issues d'assistants qui apparaissent comme directes ou issues de recherches de marque peuvent représenter la majeure partie de l'effet, et elles ne porteront pas le référent.
- Pour mesurer l'effet complet (exposition, visites différées et fenêtres d'attribution plus longues), voir **ai-seo**. Pour le réconcilier avec d'autres sources, voir **attribution**.

---

## Débogage et validation

### Outils de test

| Outil | Utilisation |
|-------|-------------|
| GA4 DebugView | Surveillance des événements en temps réel |
| GTM Preview Mode | Tester les déclencheurs avant la publication |
| Extensions de navigateur | Tag Assistant, dataLayer Inspector |

### Liste de contrôle de validation

- [ ] Événements qui se déclenchent sur les bons déclencheurs
- [ ] Valeurs des propriétés correctement renseignées
- [ ] Aucun événement en double
- [ ] Fonctionne sur tous les navigateurs et sur mobile
- [ ] Conversions enregistrées correctement
- [ ] Aucune fuite de données personnelles (PII)

### Problèmes fréquents

| Problème | Vérification |
|----------|--------------|
| Événements non déclenchés | Configuration du déclencheur, chargement de GTM |
| Valeurs incorrectes | Chemin de la variable, structure du data layer |
| Événements en double | Conteneurs multiples, déclencheur exécuté deux fois |

---

## Confidentialité et conformité

### Points d'attention
- Consentement aux cookies obligatoire dans l'UE/le Royaume-Uni/la Californie
- Aucune donnée personnelle (PII) dans les propriétés analytics
- Paramètres de conservation des données
- Capacités de suppression des données utilisateur

### Implémentation
- Utiliser le Consent Mode (attendre le consentement)
- Anonymisation des adresses IP
- Ne collecter que le nécessaire
- Intégrer avec une plateforme de gestion du consentement (CMP)

---

## Format de sortie

### Document de plan de marquage (Tracking Plan)

```markdown
# Plan de marquage [Site/Produit]

## Vue d'ensemble
- Outils : GA4, GTM
- Dernière mise à jour : [Date]

## Événements

| Nom de l'événement | Description | Propriétés | Déclencheur |
|--------------------|-------------|------------|-------------|
| signup_completed | L'utilisateur termine son inscription | method, plan | Page de confirmation |

## Dimensions personnalisées

| Nom | Portée | Paramètre |
|-----|--------|-----------|
| user_type | User | user_type |

## Conversions

| Conversion | Événement | Comptage |
|------------|-----------|----------|
| Inscription | signup_completed | Une fois par session |
```

---

## Questions spécifiques à la tâche

1. Quels outils utilisez-vous (GA4, Mixpanel, etc.) ?
2. Quelles actions clés souhaitez-vous suivre ?
3. Quelles décisions ces données vont-elles éclairer ?
4. Qui se charge de l'implémentation — l'équipe de développement ou le marketing ?
5. Y a-t-il des exigences en matière de confidentialité/consentement ?
6. Qu'est-ce qui est déjà suivi ?

---

## Intégrations d'outils

Pour l'implémentation, voir le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Principaux outils d'analytics :

| Outil | Idéal pour | MCP | Guide |
|------|----------|:---:|-------|
| **GA4** | Analytics web, écosystème Google | ✓ | [ga4.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/ga4.md) |
| **Mixpanel** | Analytics produit, suivi d'événements | - | [mixpanel.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/mixpanel.md) |
| **Amplitude** | Analytics produit, analyse de cohortes | - | [amplitude.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/amplitude.md) |
| **PostHog** | Analytics open-source, enregistrement de sessions | - | [posthog.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/posthog.md) |
| **Segment** | Plateforme de données clients (CDP), routage | - | [segment.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/segment.md) |

---

## Compétences associées

- **ab-testing** : Pour le suivi des expérimentations
- **conversion-tracking** : Pour envoyer les conversions (y compris les événements clés GA4 issus de formulaires et de réservations) aux plateformes publicitaires et à GA4, et vérifier leur bonne réception
- **attribution** : Pour les modèles d'attribution, le multi-touch/MMM/l'incrémentalité et la réconciliation des chiffres contradictoires entre outils (une fois le suivi actif)
- **seo-audit** : Pour l'analyse du trafic organique
- **cro** : Pour l'optimisation des conversions (utilise ces données)
- **revops** : Pour les métriques de pipeline, le suivi CRM et l'attribution des revenus
