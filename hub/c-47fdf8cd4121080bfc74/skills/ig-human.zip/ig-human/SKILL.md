---
name: ig-human
description: >-
  Éliminez l'empreinte machine de tout brouillon — tirets cadratins, clichés d'IA,
  caractères de filigrane invisibles — et évaluez-le à l'aide d'un panel de détection
  à cinq contrôles avant publication. À utiliser chaque fois qu'un texte doit paraître
  humain, quand l'utilisateur demande d'humaniser, demande « est-ce que ça fait IA »,
  « supprime les tirets cadratins », « enlève le blabla IA », « ça ressemble à du ChatGPT »,
  ou avant de montrer à l'utilisateur une légende, un script, un commentaire, une réponse ou un DM.
---

# ig-human

Deux outils se trouvent dans ce dossier et ils s'exécutent réellement tous les deux. Utilisez-les. Ne faites pas cela au jugé.

```bash
python3 humanize.py draft.txt --report        # clean it, show what changed
python3 detect.py draft.txt                    # score it, five checks
python3 detect.py before.txt after.txt         # prove the delta
```

Tous deux lisent `slop.json` : 154 mots et expressions clichés avec leurs équivalents en langage courant, 18 classes de caractères invisibles, 11 substitutions typographiques et 16 tics structurels. Le dernier bloc de chaque liste est spécifique à Instagram, avec le vocabulaire propre aux légendes et aux voix off. Il est fait pour être modifié. Si l'utilisateur emploie systématiquement un mot que le lexique supprime, retirez-le du fichier.

## Pourquoi cela compte plus sur Instagram qu'il n'y paraît

Les légendes sont courtes et les scripts sont dits à voix haute. Une phrase au style trop écrit dans une légende de 600 caractères représente une proportion bien plus grande du texte que dans un essai, et une voix off que personne ne pourrait prononcer naturellement saute aux yeux dès la première prise. Le signal d'alerte ici n'est pas un détecteur signalant la publication. Le signal d'alerte, c'est une personne qui fait défiler son écran devant un texte sonnant comme une marque, ou un créateur qui trébuche sur son propre script.

## Ce qui est corrigé automatiquement

**1. Les caractères invisibles.** Espaces et liants sans chasse, liants de mots, traits d'union conditionnels, marques d'ordre des octets (BOM), caractères d'étiquettes Unicode, séparateurs invisibles, espaces insécables et fines. Un clavier ne produit pas ces caractères. Ils survivent au copier-coller, ils sont invisibles dans n'importe quel éditeur, et constituent l'élément le plus mécanique des textes générés. `humanize.py` supprime chacun d'eux, y compris tout caractère de formatage Unicode restant auquel il ne peut attribuer de nom.

**2. La typographie.** Tiret cadratin en virgule, tiret demi-cadratin en trait d'union, guillemets courbes en guillemets droits, ellipse en trois points, puce en tiret. La passe sur les tirets cadratins est la plus importante : elle réduit le tiret à une virgule, puis nettoie la double ponctuation et les points orphelins que cela engendre.

**3. Le lexique de remplissage (slop).** delve, leverage, robust, seamless, crucial, testament to, « in today's fast-paced world », ainsi que le bloc Instagram : « stop scrolling », « in today's video », « follow for more », « tag someone who needs this », « the algorithm loves », « run don't walk ». Chacun est remplacé par un mot simple ou supprimé, tout en conservant la casse d'origine et en laissant les URL intactes.

## Ce qui n'est PAS corrigé automatiquement

Les tics structurels sont **signalés, pas réécrits**, car changer la structure d'une phrase nécessite du jugement :

- « It's not just X, it's Y » et « not only X but also Y »
- La règle de trois (triades)
- Les phrases de question rhétorique en un mot : « The result? »
- Le préambule vidéo : « in this video I'm going to show you »
- Les listes à puces d'emojis
- Trois mots criés (en majuscules) ou plus d'affilée
- Les murs de hashtags
- Les pièges à engagement réflexes : « follow for more », « tag someone who », « double tap if »

Cette liste relève de votre rôle. Réécrivez chaque ligne signalée à la main, en préservant le sens, puis relancez `detect.py`. C'est l'étape qui permet de faire passer le score de REVIEW à PASS, et qu'un script ne peut pas faire.

## Les cinq contrôles

`detect.py` évalue cinq signaux de 0 à 100, un score plus élevé étant plus humain :

| contrôle | ce qu'il mesure | à quoi ressemble la machine |
| --- | --- | --- |
| BURSTINESS | variation de longueur des phrases | toutes les phrases ont la même longueur |
| SPECIFICITY | nombres, noms, marqueurs concrets pour 100 mots | noms abstraits, aucun chiffre |
| SLOP DENSITY | occurrences du lexique pour 100 mots | vocabulaire préfabriqué |
| FINGERPRINT | caractères invisibles, tirets cadratins, guillemets courbes pour 1 000 car. | typographiquement parfait |
| VOICE | contractions, personne, tics structurels | pas de contractions, révélations théâtralisées |

Le verdict pondère la moyenne à 60 % et le **contrôle individuel le plus faible** à 40 %, car un seul signal suffit. Un résultat PASS exige un score global de 70+ sans aucun contrôle sous 55.

## Dites-le honnêtement

Il s'agit de cinq heuristiques locales modélisées d'après les signaux sur lesquels se basent les détecteurs publics. Elles s'exécutent entièrement sur la machine de l'utilisateur et rien n'est mis en ligne. Ce ne sont **pas** GPTZero, Originality, Copyleaks, Winston ou Turnitin ; elles n'appellent pas ces API et ne peuvent garantir leurs verdicts. Corriger ce qu'elles mesurent a tendance à faire évoluer ces scores, car elles mesurent les mêmes éléments sous-jacents. Voilà ce que l'on peut affirmer. Ne faites pas de promesse plus grande au nom de l'utilisateur, et ne lui dites pas que son texte est indétectable.

## Ordre des opérations

1. `humanize.py draft.txt -o clean.txt --report`
2. Lisez les signalements structurels. Réécrivez ces lignes vous-même.
3. `detect.py draft.txt clean.txt` pour afficher l'avant et l'après.
4. Si le verdict n'est pas PASS, corrigez le contrôle le plus faible indiqué dans la sortie et recommencez. Deux passages sont normaux. Cinq signifient que le brouillon a été rédigé selon une formule toute faite, et la solution réside dans un nouveau brouillon, pas dans davantage de passes.
5. Montrez à l'utilisateur le texte nettoyé ainsi que le score. Jamais le score seul.
