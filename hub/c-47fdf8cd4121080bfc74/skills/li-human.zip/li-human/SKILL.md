---
name: li-human
description: >-
  Supprimez l'empreinte de la machine de n'importe quel brouillon (tirets cadratins,
  mots-clichés d'IA, caractères invisibles de filigrane) et évaluez-le par rapport à un
  panel de détection à cinq critères avant publication. À utiliser dès qu'un texte doit
  paraître humain, lorsque l'utilisateur demande d'humaniser, demande « est-ce que ça
  fait IA », « retire les tirets cadratins », « nettoie ce jargon IA », « est-ce que ça
  va être détecté », ou avant de présenter à l'utilisateur tout post, commentaire,
  réponse ou message privé LinkedIn.
---

# li-human

Deux outils se trouvent dans ce dossier et ils fonctionnent réellement tous les deux. Utilisez-les. Ne faites pas d'évaluation au jugé.

```bash
python3 humanize.py draft.txt --report        # clean it, show what changed
python3 detect.py draft.txt                    # score it, five checks
python3 detect.py before.txt after.txt         # prove the delta
```

Tous deux lisent `slop.json`, qui constitue le lexique : plus de 100 mots et expressions clichés avec des équivalents en langage simple, 17 classes de caractères invisibles, 11 substitutions typographiques et 11 indices structurels révélateurs. Il est conçu pour être modifié. Si l'utilisateur a un mot qu'il emploie systématiquement et que le lexique supprime, retirez-le du fichier.

## Ce qui est corrigé automatiquement

**1. Caractères invisibles.** Espaces et liants sans chasse, liants de mots, traits d'union conditionnels, marques d'ordre des octets (BOM), caractères d'étiquettes Unicode, espaces insécables et fines. Un clavier ne produit pas ces caractères. Ils survivent au copier-coller, ils sont invisibles dans tous les éditeurs, et ils constituent l'élément le plus purement mécanique des textes générés. `humanize.py` les supprime tous, y compris tout caractère de format Unicode restant pour lequel il n'a pas de nom.

**2. Typographie.** Tiret cadratin transformé en virgule, tiret demi-cadratin en trait d'union, guillemets courbes en guillemets droits, points de suspension en trois points, puce en trait d'union. La passe sur le tiret cadratin est la plus importante : elle réduit ` — ` en `, ` puis nettoie la double ponctuation laissée derrière.

**3. Le lexique du jargon d'IA.** delve, leverage, robust, seamless, crucial, tapestry, testament to, moreover, "in today's fast-paced world", "let that sink in" et les autres, chacun remplacé par un mot simple, avec conservation de la casse et respect absolu des URL.

## Ce qui n'est PAS corrigé automatiquement

Les indices structurels révélateurs sont **signalés, non réécrits**, car changer la forme d'une phrase requiert du discernement :

- « Ce n'est pas seulement X, c'est Y » et « non seulement X mais aussi Y »
- Les triades (règle de trois)
- Les questions rhétoriques d'un seul mot : « Le résultat ? »
- Les émojis fusée, feu, ampoule, étincelles et cible
- Les murs de hashtags
- Les amorces d'engagement réflexes : « Qu'en pensez-vous ? », « D'accord ? », « Qui d'autre ? »
- La longueur uniforme des phrases et la longueur uniforme des puces

Cette liste relève de votre responsabilité. Réécrivez manuellement chaque ligne signalée en conservant le sens, puis relancez `detect.py`. C'est cette étape qui fait passer le score de REVIEW à PASS, et c'est la partie qu'un script ne peut pas réaliser.

## Les cinq vérifications

`detect.py` attribue une note de 0 à 100 à cinq signaux ; plus la note est élevée, plus le texte est humain :

| vérification | ce qu'elle mesure | à quoi ressemble une machine |
| --- | --- | --- |
| BURSTINESS | variation de la longueur des phrases | toutes les phrases ont la même longueur |
| SPECIFICITY | nombres, noms, marqueurs concrets pour 100 mots | noms abstraits, aucun chiffre |
| SLOP DENSITY | occurrences du lexique cliché pour 100 mots | vocabulaire standardisé et prévisible |
| FINGERPRINT | caractères invisibles, tirets cadratins, guillemets courbes pour 1 000 caractères | typographiquement parfait |
| VOICE | contractions, personne, indices structurels | pas de contractions, révélations théâtralisées |

Le verdict pondère la moyenne à 60 % et la **vérification individuelle la plus faible** à 40 %, car il suffit d'un seul signal pour qu'un détecteur se déclenche. L'obtention de PASS nécessite un score global de 70+ sans aucun contrôle sous la barre des 55.

## Soyez transparent à ce sujet

Il s'agit de cinq heuristiques locales modélisées d'après les signaux sur lesquels s'appuient les détecteurs publics. Elles s'exécutent entièrement sur la machine de l'utilisateur et rien n'est téléversé. Elles ne **sont pas** GPTZero, Originality, Copyleaks, Winston ou Turnitin, elles n'appellent pas ces API et ne peuvent pas garantir leurs verdicts. Corriger ce qu'elles mesurent a tendance à faire évoluer ces scores, car elles mesurent les mêmes mécanismes sous-jacents. Telle est la seule promesse. N'en faites pas de plus grande au nom de l'utilisateur, et n'affirmez jamais à un utilisateur que son texte est indétectable.

## Ordre des opérations

1. `humanize.py draft.txt -o clean.txt --report`
2. Lisez les alertes structurelles. Réécrivez vous-même ces lignes.
3. `detect.py draft.txt clean.txt` pour afficher l'avant et l'après.
4. Si le verdict n'est pas PASS, corrigez le contrôle le plus faible indiqué dans la sortie et recommencez. Deux itérations sont normales. Cinq signifient que le brouillon a été écrit de manière stéréotypée selon une formule, et la solution consiste à repartir sur un autre brouillon, pas à multiplier les passes.
5. Présentez à l'utilisateur le texte nettoyé ainsi que le score. Jamais le score seul.
