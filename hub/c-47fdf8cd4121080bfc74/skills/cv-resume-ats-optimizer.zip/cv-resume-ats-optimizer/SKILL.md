---
name: resume-ats-optimizer
description: Optimiser les CV pour les systèmes de suivi des candidatures (ATS), vérifier la compatibilité ATS et analyser la correspondance des mots-clés
---

# Optimiseur de CV pour ATS

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Optimiser son CV pour les systèmes de suivi des candidatures (ATS - Applicant Tracking Systems)
- Vérifier si son CV passera les étapes de filtrage automatisé
- Comprendre pourquoi ses candidatures ne reçoivent pas de réponses
- Mentionne des mots-clés tels que : « ATS », « pas d'entretiens », « CV qui ne marche pas », « optimiser le CV », « optimisation des mots-clés »

À utiliser également lorsque l'utilisateur fournit un fichier de CV et mentionne qu'il postule à des offres d'emploi.

## Capacités principales

- Analyser le CV et tester sa compatibilité ATS
- Extraire et analyser les mots-clés par rapport aux descriptions de poste
- Identifier les problèmes de mise en page qui bloquent les analyseurs ATS
- Calculer des scores de correspondance entre le CV et les offres d'emploi
- Suggérer des ajouts et des emplacements stratégiques de mots-clés
- Générer des recommandations de mise en page adaptées aux ATS

## La problématique des ATS

75 % des CV sont rejetés par les systèmes de suivi des candidatures avant même qu'un être humain ne les voie. Les entreprises utilisent les ATS pour :
- Éliminer automatiquement les candidats non qualifiés
- Rechercher des mots-clés spécifiques issus des critères du poste
- Convertir les CV en données structurées
- Classer les candidats selon leur pourcentage de correspondance des mots-clés

Raisons fréquentes pour lesquelles les CV échouent aux ATS :
1. Mauvaise mise en page (tableaux, colonnes, en-têtes/pieds de page)
2. Mots-clés manquants par rapport à la description du poste
3. Intitulés de sections non standardisés
4. Polices non standard ou caractères spéciaux
5. Texte intégré dans des images
6. Format de fichier incorrect

## Liste de contrôle de compatibilité ATS

### Format de fichier
- ✅ Utiliser .docx ou .pdf (pas .pages, .odt)
- ✅ Le PDF doit être basé sur du texte, pas une image numérisée
- ✅ Nom de fichier : "FirstName_LastName_Resume.pdf"

### Polices et mise en forme
- ✅ Polices standard : Arial, Calibri, Georgia, Times New Roman
- ✅ Taille de police : 10-12 pt pour le corps du texte, 14-16 pt pour les titres
- ✅ Pas de zones de texte, de tableaux ou de colonnes
- ✅ Pas d'en-têtes/pieds de page (placer les coordonnées dans le corps du texte)
- ✅ Pas d'images, de graphiques ou d'icônes
- ✅ Formats de date cohérents (MM/AAAA)
- ✅ Puces standard (•, -, *)

### Intitulés de section
Utiliser des en-têtes standard et facilement reconnaissables :
- ✅ "Professional Experience" ou "Work Experience" (pas "Where I've Been")
- ✅ "Education" (pas "Academic Background")
- ✅ "Skills" (pas "Core Competencies")
- ✅ "Summary" ou "Professional Summary"

### Coordonnées
```
John Smith
email@example.com | (555) 123-4567 | LinkedIn: linkedin.com/in/johnsmith
San Francisco, CA
```

PAS dans l'en-tête/pied de page, et éviter :
- ❌ Les tableaux pour aligner les coordonnées
- ❌ Les caractères spéciaux dans l'adresse e-mail
- ❌ Les numéros de téléphone multiples
- ❌ L'adresse postale complète (la ville et la région/le code postal suffisent)

## Processus d'optimisation des mots-clés

### Étape 1 : Extraire les mots-clés de la description de poste

Identifier trois types de mots-clés :

**Compétences techniques (Hard Skills)**
- Langages de programmation (Python, Java, SQL)
- Outils et plateformes (Salesforce, AWS, Excel)
- Certifications (PMP, CPA, CFA)
- Méthodologies (Agile, Six Sigma, SDLC)

**Compétences comportementales (Soft Skills)**
- Leadership, collaboration, communication
- Résolution de problèmes, esprit d'analyse
- Gestion de projet, gestion des parties prenantes

**Termes propres au secteur**
- B2B, SaaS, e-commerce
- Enterprise, SMB, mid-market
- ARR, MRR, churn rate

### Étape 2 : Analyse de correspondance

Pour chaque mot-clé de la description de poste :
1. Vérifier si l'expression exacte apparaît dans le CV
2. Rechercher les synonymes ou variantes
3. Compter la fréquence d'apparition
4. Noter l'emplacement (résumé, expérience, compétences)

### Étape 3 : Calculer le score de correspondance

```
Match Score = (Keywords Matched / Total Required Keywords) × 100

Example:
Job has 20 required keywords
Your resume has 15 of them
Match Score = 75%

Target: 80%+ for strong match
```

### Étape 4 : Stratégie de placement des mots-clés

**Priorité 1 : Résumé professionnel (haut du CV)**
- Inclure 5 à 8 des mots-clés les plus importants
- Les intégrer naturellement dans un paragraphe de 3 à 4 phrases
- Exemple : « Data Scientist avec 5+ ans d'expérience utilisant Python, SQL et le machine learning pour générer des insights stratégiques... »

**Priorité 2 : Section Compétences**
- Lister explicitement les mots-clés
- Les regrouper par catégorie si nécessaire
- Utiliser la formulation exacte issue de la description de poste

**Priorité 3 : Puces de la section Expérience**
- Intégrer les mots-clés dans les descriptions de réalisations
- Ne pas forcer l'ajout de mots-clés de manière artificielle
- Varier les formulations à travers le CV

**Directives sur la densité des mots-clés :**
- Mots-clés critiques : doivent apparaître 2 à 4 fois sur l'ensemble du CV
- Mots-clés importants : doivent apparaître 1 à 2 fois
- Pas de bourrage de mots-clés (« keyword stuffing ») — le texte doit rester fluide
- Varier les formulations (par ex., « a dirigé une équipe » et « leadership d'équipe »)

## Format de sortie de l'analyse

Lors de l'analyse d'un CV, fournir ce rapport structuré :

```markdown
# ATS COMPATIBILITY REPORT

## Overall Score: [X]/100

### File Format Check ✅/❌
- Format: [DOCX/PDF]
- Text extraction: [Success/Failed]
- File size: [X KB/MB]

### Formatting Issues
✅ No tables or columns detected
❌ Contact info in header (move to body)
⚠️  Two different font sizes in skills section

### Keyword Analysis

JOB REQUIREMENTS vs YOUR RESUME:

**Critical Keywords (Must Have):**
✅ Project Management - Found 3x
✅ Agile/Scrum - Found 2x
❌ Stakeholder Management - MISSING (mentioned 5x in JD)
❌ Budget Management - MISSING (mentioned 3x in JD)

**Important Keywords:**
✅ Cross-functional teams - Found 1x
⚠️  "Risk management" - You have "risk mitigation" (close but not exact match)
✅ Process improvement - Found 2x

**Match Score: 65%**
Target: 80%+ recommended

### Recommended Changes

**1. Add Missing Keywords:**

In Professional Summary, change:
"Experienced project manager with proven track record..."

To:
"Experienced project manager with proven track record in stakeholder management and budget oversight..."

In Experience section, add bullet:
"Managed stakeholder communication across 3 departments and executive leadership team"
"Directed budget management for $2.5M project portfolio"

**2. Fix Formatting:**
- Move contact information from header to body of resume
- Make all skill section items same font size (currently 10pt and 11pt mixed)

**3. Strengthen Existing Keywords:**
Change "risk mitigation" to "risk management" for exact match

### Estimated New Match Score: 85%
```

## Schémas d'échec fréquents face aux ATS

### Schéma 1 : Mise en page trop créative
```
❌ PROBLEM:
[Two-column layout with graphics]
[Skill bars and proficiency charts]
[Text in colored boxes]

✅ SOLUTION:
- Single column layout
- Text-only skills list
- Simple bullet points
```

### Schéma 2 : Intitulés de section non conventionnels
```
❌ PROBLEM:
"My Journey" (instead of Experience)
"What I Bring to the Table" (instead of Skills)
"Academic Pursuits" (instead of Education)

✅ SOLUTION:
Use standard headers ATS recognizes
```

### Schéma 3 : Mots-clés manquants
```
❌ PROBLEM:
Job requires: "Python, SQL, Data Visualization"
Resume says: "Programming, databases, making charts"

✅ SOLUTION:
Use exact terminology from job description
```

### Schéma 4 : Bourrage de mots-clés (Keyword Stuffing)
```
❌ PROBLEM:
Skills: Python, Python programming, Python developer, Python expert, Python specialist, Advanced Python...

✅ SOLUTION:
Skills: Python, SQL, JavaScript, React, Node.js
(Then incorporate naturally in bullets)
```

## Considérations spécifiques par secteur

### CV Tech
- Mettre l'accent sur les langages de programmation et les frameworks
- Inclure GitHub et les liens de portfolio dans la section Compétences (pas dans l'en-tête)
- Les certifications et formations ont un poids très important

### Finance / Gestion / Business
- Mettre l'accent sur la maîtrise des logiciels (Excel, SAP, Salesforce)
- Certifications indispensables (CPA, CFA, PMP)
- Mots-clés sectoriels (P&L, ROI, KPI)

### Santé
- Diplômes, licences d'exercice et certifications requis
- Logiciels et systèmes spécifiques (Epic, Cerner, MEDITECH)
- Mots-clés réglementaires et de conformité (HIPAA, Joint Commission)

### Marketing
- Maîtrise des plateformes (HubSpot, Salesforce, Google Analytics)
- Mots-clés par canaux (SEO, SEA/PPC, email marketing)
- Indicateurs chiffrés et vocabulaire axé sur les résultats

## Cas particuliers et situations spécifiques

### Reconversion professionnelle
- Mettre l'accent sur les compétences transférables
- Utiliser les mots-clés du secteur CIBLE, pas seulement du secteur d'origine
- Deux versions de CV peuvent être nécessaires selon les ATS

### Jeunes diplômés
- La section Formation devient prioritaire pour l'intégration des mots-clés
- Inclure les cours pertinents et les projets académiques
- Les stages comptent comme de l'expérience professionnelle — intégrer ces mots-clés

### Postes de direction (Executive)
- L'ATS reste important même pour les postes de direction
- Privilégier les mots-clés stratégiques
- Mentionner l'expérience auprès de conseils d'administration, le volume de P&L géré, la taille des équipes

### Trous dans le parcours professionnel
- N'utiliser que les années (pas les mois) si cela permet d'atténuer les écarts
- Inclure les missions de freelance/consulting en y associant des mots-clés
- Le bénévolat peut permettre d'intégrer des mots-clés pertinents

## Liste de contrôle pour l'accompagnement

Lors de l'optimisation pour un utilisateur :

1. ✅ Analyser le CV actuel pour détecter les problèmes de compatibilité ATS
2. ✅ Analyser la description de poste pour en extraire les mots-clés requis
3. ✅ Calculer le score de correspondance initial
4. ✅ Identifier précisément les mots-clés manquants
5. ✅ Suggérer des emplacements précis pour insérer les nouveaux mots-clés
6. ✅ Signaler les anomalies de mise en page
7. ✅ Fournir des exemples concrets avant/après
8. ✅ Recalculer le score estimé après application des modifications suggérées
9. ✅ Vérifier le format et le nommage du fichier
10. ✅ Tester avec un simulateur ATS si possible

## Indicateurs de réussite

Après optimisation, le CV doit :
- Obtenir un score de correspondance d'au moins 80 % avec les descriptions de poste cibles
- Passer le test d'analyse ATS avec succès (toutes les sections correctement identifiées)
- Ne comporter aucune anomalie de mise en page
- Inclure tous les mots-clés critiques à raison de 2 à 4 occurrences chacun
- Offrir une lecture naturelle et agréable pour un humain (sans saturation artificielle)
- Être immédiatement prêt à l'envoi
