---
name: ig-comment
description: >-
  Rédige des commentaires sur les publications et reels Instagram d'autres
  comptes qui donnent l'impression d'une vraie personne ayant un avis, et non
  d'un bot. À utiliser lorsque l'utilisateur colle une publication ou un reel et
  souhaite un commentaire, dit « commente ça », « interagis avec ceci »,
  « qu'est-ce que je dis ici », ou souhaite un lot pour sa session quotidienne
  d'engagement.
---

# ig-comment

Commenter représente les vingt minutes au plus fort effet de levier sur
Instagram, et les plus faciles à rater. Un commentaire placé en haut d'un reel
à 40 000 vues est vu par plus de personnes que les publications de la plupart
des comptes, et c'est le seul endroit où un inconnu peut cliquer directement
pour accéder à un profil.

Un commentaire générique est pire que pas de commentaire du tout. Il coûte un
clic qui ne mène nulle part et catalogue le compte comme adepte des « engagement
pods » aux yeux de la seule personne dont l'avis comptait : le créateur.

## Entrée

L'utilisateur colle le texte de la publication ou du reel, ou une capture
d'écran, avec le nom du compte. S'il fournit une URL que vous ne pouvez pas
ouvrir, demandez-lui de coller le contenu. N'utilisez pas d'outil de navigation
pour scraper le fil et ne publiez rien.

## Les neuf types de commentaires

Choisissez en fonction de la nature réelle de la publication. Ne choisissez
jamais le type 1 par défaut.

| # | type | quand | forme |
| --- | --- | --- | --- |
| 1 | **Ajouter une donnée** | la publication fait une affirmation que vous pouvez appuyer avec un chiffre | « Pareil pour nous : 40 % de... » |
| 2 | **Ajouter le cas manquant** | la publication a raison mais est incomplète | « Cela reste vrai jusqu'à {condition}. » |
| 3 | **Désaccord respectueux** | vous pensez sincèrement que c'est faux | formuler d'abord le point d'accord, puis la divergence |
| 4 | **Prolonger une phrase** | une phrase en particulier est excellente | la citer, rebondir dessus |
| 5 | **Poser la vraie question** | la publication a esquivé le point difficile | une question, précise |
| 6 | **La preuve par l'expérience** | vous avez fait ce qu'ils décrivent | ce qui s'est passé, en deux phrases |
| 7 | **La correction** | il y a une erreur factuelle | avoir raison, être bref, être bienveillant, être sûr de soi |
| 8 | **Le recadrage** | bons faits, mauvais angle | « Une autre façon de voir les choses : » |
| 9 | **La formule courte** | la publication n'a besoin de rien, vous voulez de la présence | moins de 10 mots, doit être drôle ou vraie |

## Règles

- **Une à trois phrases.** Les commentaires Instagram sont lus dans une colonne
  étroite sous une vidéo. Un paragraphe est masqué derrière « plus » et personne
  ne clique dessus.
- **Ne jamais commencer par** « Super post », « J'adore », « Tellement vrai »,
  « Tellement ça 👏 », « J'avais besoin de lire ça aujourd'hui », ou le prénom
  du créateur suivi d'un point d'exclamation. Tous sont invisibles.
- **Pas de commentaires uniquement composés d'emojis** et aucun emoji comme
  premier caractère.
- **Ne jamais reformuler le reel.** Tous ceux qui lisent viennent de le regarder.
- **Une seule idée.** Un commentaire avec deux points distincts ressemble à une
  tentative de monopoliser l'attention.
- **Dire quelque chose de précis.** Si le commentaire pouvait convenir sous
  n'importe quelle publication sur le sujet, ce n'est pas un commentaire, c'est
  du bruit.
- **Aucune promo, jamais.** Ni offre, ni lien, ni « venez voir ma page ». C'est
  le moyen le plus rapide de se faire bloquer précisément par la personne que
  vous essayiez d'atteindre.
- **Être précoce compte plus ici qu'ailleurs.** Un commentaire posté dès la
  première heure sur un reel qui perce ensuite est propulsé avec lui.

## Sortie

Fournissez **deux options de types différents**, étiquetées, plus une ligne
indiquant celle que vous publieriez et pourquoi. Passez d'abord les deux par
`/ig-human` : les commentaires sont courts, donc un tiret cadratin ou une
formule convenue se remarque proportionnellement bien plus que dans une légende.

```
COMMENT OPTIONS  (on @acct's reel about pricing)

[6 · Receipt]
We raised ours 40% last March and lost exactly one client, who was the one
taking up half the inbox. Took eight months to stop being scared of it.

[3 · Respectful disagree]
Agree on the anchoring. The part I would push back on is doing it mid-project.
We tried that and it cost us a renewal that was otherwise fine.

Post the first. It concedes something and it has a number in it.
```

## Mode par lot

Pour une session d'engagement, demandez les 5 à 10 publications sous forme de
texte collé dans un seul message, renvoyez un commentaire pour chacune dans un
seul bloc, et tenez à jour une note dans `~/.claude/instagram/log.md` recensant
les comptes commentés cette semaine. Commenter les mêmes trois comptes chaque
jour se remarque et laisse paraître exactement ce que c'est.

## À ne jamais faire

Ne publiez pas automatiquement, n'automatisez pas les commentaires et n'utilisez
pas d'outil de navigation pour publier à la place de l'utilisateur.
L'engagement automatisé enfreint les conditions d'utilisation d'Instagram et
entraîne le blocage des actions du compte. Cette compétence rédige le
commentaire. L'utilisateur le publie.
