---
name: ig-audit
description: >-
  Bilan post-mortem des publications existantes de l'utilisateur : quels reels
  ont réellement fonctionné, pourquoi, et ce qu'il faut cesser de produire.
  À utiliser lorsque l'utilisateur partage ses statistiques Instagram ou ses
  anciennes publications et demande « qu'est-ce qui fonctionne », « pourquoi ce
  flop », « analyse mes statistiques », « audite mon contenu », ou souhaite
  savoir sur quoi capitaliser.
---

# ig-audit

La seule source fiable pour savoir ce qui fonctionne pour un compte, c'est ce compte lui-même. Chaque règle de chaque guide Instagram, y compris ceux de ce pack, n'est qu'une hypothèse de départ. Les 30 dernières publications de l'utilisateur constituent les véritables preuves.

## Données d'entrée

Demande à l'utilisateur ce dont il dispose :

- Les statistiques par publication : vues, couverture, interactions, temps de visionnage, enregistrements, partages, abonnements et proportion de non-abonnés touchés. Des captures d'écran conviennent parfaitement.
- Ou le graphique de rétention de ses meilleurs et pires reels récents. Cette seule capture d'écran a plus de valeur que tout le reste réuni.
- Ou simplement la liste des publications avec leur nombre de vues, ce qui suffit pour une première analyse.

Consulte également `~/.claude/instagram/log.md` s'il existe, car il consigne la formule d'accroche employée pour chaque publication.

## Ce qu'il faut réellement mesurer

Le nombre brut de vues est le chiffre le moins utile de la page, car il dépend principalement du nombre d'abonnés actuels du compte. Calcule plutôt ces métriques et détaille le calcul :

| métrique | méthode de calcul | ce que cela indique |
| --- | --- | --- |
| **Outlier multiple** | vues / médiane des vues du compte | si la publication a été un vrai succès ou une performance ordinaire |
| **Non-follower reach** | % de la couverture provenant de non-abonnés | si le contenu a réellement voyagé au-delà de l'audience existante |
| **Hold at 3s** | spectateurs encore présents à 3 s / spectateurs au démarrage | si l'accroche a fonctionné. C'est la note de l'accroche. |
| **Average watch time** | directement tiré des statistiques | si le corps de la vidéo a captivé |
| **Sends per reach** | partages / couverture | le signal le plus puissant qu'un contenu puisse générer. Un partage privé signifie qu'une personne engage sa réputation dessus. |
| **Follows per reach** | abonnements / couverture | si le profil a su convertir l'attention générée |

Classe les publications par multiple atypique (outlier multiple) et par partages par couverture (sends per reach), et non par vues. Un reel à 4 000 vues avec 90 partages privés surpasse un reel à 60 000 vues avec 11 partages.

## Identifier ensuite les schémas récurrents

En comparant le top 5 et le flop 5 côte à côte, cherche ce qui les différencie, et sois prêt à tirer une conclusion qui pourrait déplaire à l'utilisateur :

- **Rétention à 3 secondes.** Si le haut et le bas du classement divergent ici, c'est l'accroche et uniquement l'accroche qui est en cause, et tout le reste n'est qu'une distraction.
- **Formule d'accroche.** Quels identifiants issus de `ig-reel/hooks.json` figurent dans le top 5 ?
- **Format.** Reel, carrousel, image unique.
- **Durée.** Regroupe par tranches : moins de 15 s, 15 à 30 s, 30 à 60 s, plus de 60 s.
- **Thématique.**
- **Réponses aux commentaires.** L'utilisateur a-t-il répondu aux commentaires au cours de la première heure ?
- **Jour et heure de publication.** Vérifie ce point en **dernier** et uniquement si les autres critères ne révèlent rien. Ce n'est presque jamais la cause, même si c'est ce que l'on a tendance à blâmer.

Formule le constat sous forme d'affirmation étayée par les données observées, en précisant le niveau de certitude. Avec 30 publications, une tendance se dessine. Avec 6 publications, ce n'est pas le cas, et il vaut mieux le reconnaître plutôt que d'inventer une tendance inexistante.

## La distinction qui fait gagner des mois

**Un reel qui accumule des vues mais aucun abonnement n'est pas un mauvais reel : c'est un problème de profil.** Un reel qui ne fait aucune vue est un problème d'accroche. Dissocie clairement les deux avant de faire la moindre recommandation. Si la couverture hors abonnés est élevée mais que le ratio abonnements/couverture est faible, cesse de réécrire des accroches et oriente-toi vers `/ig-profile`.

## Format de sortie

```
AUDIT  ·  31 posts  ·  Jun 12 - Sep 5  ·  median views 4,100

TOP 5 BY OUTLIER MULTIPLE
  18.2x  #3  Nobody Tells You   74,600 views  62% non-follower  hold@3s 71%  128 sends
   6.4x  #1  Cost Confession    26,300 views  48% non-follower  hold@3s 64%   71 sends
  ...

BOTTOM 5
   0.3x  #11 Numbered            1,200 views  9% non-follower   hold@3s 31%    2 sends
  ...

WHAT THE DATA SAYS
1. Hold at 3 seconds is the whole story. Top five average 66%, bottom five 33%.
   Everything else you are worried about is downstream of the first two seconds.
2. The posts where you were the one who looked bad: mean 8.1x vs 0.9x for
   everything else. n=5. Strongest signal here and it is not close.
3. Tool listicles get views and nothing else. High reach, no sends, no follows.
   Three of your bottom five.
4. Day of week shows nothing. Your Tuesday and Friday means are inside the
   noise. Stop optimising it.

STOP: listicles.
DO MORE: the ones with a cost you paid and a number attached.
```

Transmets ensuite les conclusions à `/ig-plan` pour bâtir le calendrier de la semaine suivante sur les données réelles de l'utilisateur plutôt que sur des réglages par défaut, et à `/ig-viral` pour filtrer le swipe file selon les formules qui fonctionnent spécifiquement pour ce compte.
