---
name: founder-offer
description: >-
  Construit une offre impossible à refuser. Liste chaque problème rencontré par l'acheteur
  sur le chemin du résultat souhaité, transforme chacun en solution, ne retient que ce qui est
  peu coûteux à délivrer et précieux pour l'acheteur, et empile le tout avec des bonus
  honnêtes, une garantie que le CFO peut assumer, une urgence réelle et un nom clair.
  Évalue l'offre selon l'équation de la valeur (résultat, probabilité, délai, effort)
  et la re-teste auprès d'un panel d'acheteurs rapide. À utiliser lorsque l'utilisateur
  dit « améliore mon offre », « pourquoi les gens n'achètent pas », « que devrais-je inclure »,
  « garantie », « bonus », « grand slam offer », ou après qu'un panel montre que les gens passent leur tour.
argument-hint: "[ce que vous vendez]"
---

# founder-offer

La plupart des entreprises vendent un produit. Les bonnes entreprises vendent une offre : le produit plus tout ce qui fait de son achat une évidence. Cette compétence construit cela, en utilisant le prisme des offres dans `../founder-board/lenses.md` comme méthode (un résumé du cadre de *$100M Offers* d'Alex Hormozi ; ne le présentez jamais comme ses propres mots).

## Étape 1 : lire ce qui est déjà connu

- `founder/idea.md` et `founder/pitch.md` : ce qui est vendu aujourd'hui.
- `founder/panel/results.md` : pourquoi les acheteurs passent leur tour, avec leurs propres mots. C'est la matière première : chaque objection majeure doit trouver une réponse dans l'offre.
- `founder/numbers.json` : ce que coûte chaque ajout, pour que le pack reste rentable.
- `founder/board.md` : les conditions fixées par le board.

## Étape 2 : la liste des problèmes

Listez chaque obstacle entre l'acheteur et le résultat qu'il souhaite, avec les mots de l'acheteur : avant l'achat (doute, prix, effort pour changer), pendant (attente, apprentissage, inconvénients), après (est-ce durable, que se passe-t-il en cas d'échec). Visez entre 15 et 30 problèmes. Puisez d'abord dans les objections du panel et les plaintes concernant les concurrents.

## Étape 3 : solutions, triées et empilées

Transformez chaque problème en solution (une fonctionnalité, un service, une garantie, un format). Notez chacune sur la valeur pour l'acheteur (1 à 5) et le coût de délivrance (1 à 5, d'après les chiffres du CFO). Gardez une valeur élevée et un coût faible. Empilez ce qui reste dans :

- **Le cœur** : la chose elle-même, décrite par le résultat obtenu, et non par ses composants.
- **Les bonus** : deux ou trois, chacun éliminant une objection précise.
- **La garantie** : ce qui se passe si le résultat n'est pas atteint. Modélisez son coût avec un taux de réclamation réaliste à l'aide de l'outil du CFO avant de la promettre.
- **Urgence et rareté** : uniquement si elles sont réelles (une semaine de lancement, un premier lot limité). Ne simulez jamais un compte à rebours ou un « plus que 3 disponibles ».
- **Le nom** : un nom clair et précis pour l'offre, pas pour l'entreprise.

## Étape 4 : noter l'offre

Sur l'équation de la valeur, avant et après, de 1 à 10 pour chacun : résultat rêvé, probabilité perçue de l'atteindre, délai jusqu'au résultat, effort et sacrifice. Précisez quel élément de l'offre fait évoluer chaque note.

## Étape 5 : re-tester l'offre

Inscrivez la nouvelle offre dans `founder/pitch.md` (gardez l'ancienne sous `founder/pitch-v1.md`) et lancez `/founder-consumer --quick` avec le même seed. Rapportez le taux d'achat avant et après ainsi que les objections qui ont disparu. Si rien n'a bougé, dites-le : le problème vient peut-être du marché ou du prix, pas de l'offre.

## Règles

- Chaque promesse doit pouvoir être tenue et être abordable ; vérifiez les coûts avec le CFO.
- Pas de faux avis, témoignages, rareté artificielle, remises trompeuses ou mentions « vu à la télé ».
- Respectez les règles de publicité et de protection des consommateurs du marché de l'utilisateur pour les garanties et les promesses (en particulier les allégations de santé). Ne constitue pas un conseil juridique.

## Sortie

`founder/offer.md` (liste des problèmes, structure de l'offre, coûts, scores de l'équation de la valeur, résultat du nouveau test) et le fichier `founder/pitch.md` mis à jour. Étape suivante : `/founder-cfo` pour recalculer les chiffres avec la nouvelle offre, puis `/founder-marketing`.
