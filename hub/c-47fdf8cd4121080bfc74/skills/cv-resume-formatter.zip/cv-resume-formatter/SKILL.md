---
name: resume-formatter
description: Garantir un formatage optimisé pour les ATS et créer des mises en page claires et faciles à parcourir
---

# Formateur de CV (Resume Formatter)

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A besoin d'aide pour la mise en page et le formatage de son CV
- Possède un CV désordonné ou difficile à lire
- Souhaite garantir la compatibilité ATS grâce au formatage
- A besoin d'un design épuré et professionnel
- Mentionne : « formater CV », « mise en page CV », « design CV », « CV propre », « format professionnel »

## Capacités principales

- Structurer les CV pour une lisibilité optimale
- Assurer la compatibilité ATS grâce au formatage
- Créer une hiérarchie visuelle
- Optimiser les espaces blancs et les marges
- Sélectionner les polices et les tailles appropriées
- Équilibrer l'attrait esthétique et la fonctionnalité

## Fondamentaux du formatage

### Le défi du double public

Votre CV doit fonctionner pour :
1. **Les ATS (Applicant Tracking Systems)** - Des robots qui analysent le texte
2. **Les lecteurs humains** - Des recruteurs qui le parcourent rapidement

**La solution :** Un formatage propre et simple qui satisfait les deux.

## Configuration du document

### Longueur de page
- **Débutant (0-5 ans) :** 1 page
- **Intermédiaire (5-15 ans) :** 1-2 pages
- **Sénior/Cadre dirigeant (15+ ans) :** 2 pages (max 3 pour les cadres dirigeants)

### Marges
- **Recommandé :** 0,5" à 1" (1,27 cm à 2,54 cm) de tous les côtés
- **Minimum :** 0,5" (ne pas aller en dessous)
- **Maximum :** 1" (ne pas gaspiller d'espace)

### Choix de la police

**Polices sûres et compatibles ATS :**
- **Sans-serif :** Arial, Calibri, Helvetica, Verdana
- **Serif :** Times New Roman, Georgia, Garamond

**Tailles de police :**
- **Nom :** 16-20 pt
- **Titres de section :** 12-14 pt
- **Corps de texte :** 10-12 pt
- **Minimum lisible :** 10 pt

### Espacement
- **Interligne :** 1,0 à 1,15
- **Espace après les paragraphes :** 6-12 pt
- **Espacement des sections :** 12-16 pt entre les sections

## Règles de formatage compatibles ATS

### À FAIRE :
- ✅ Utiliser des polices standards
- ✅ Utiliser des puces simples (•, -, *)
- ✅ Utiliser le gras et l'italique avec modération
- ✅ Utiliser des titres de section standards
- ✅ Enregistrer au format .docx ou .pdf basé sur du texte
- ✅ Placer les coordonnées dans le corps du texte (pas dans l'en-tête)
- ✅ Utiliser une mise en page sur une seule colonne
- ✅ Conserver un formatage cohérent d'un bout à l'autre

### À NE PAS FAIRE :
- ❌ Utiliser des tableaux (sauf des tableaux simples pour les coordonnées)
- ❌ Utiliser des zones de texte
- ❌ Utiliser des colonnes (mises en page multicolonnes)
- ❌ Utiliser les en-têtes/pieds de page pour des informations importantes
- ❌ Utiliser des images ou des graphiques
- ❌ Utiliser des polices atypiques
- ❌ Utiliser des barres de compétences ou des jauges de progression
- ❌ Utiliser des caractères spéciaux ou des émojis
- ❌ Utiliser de la couleur pour des informations essentielles

## Organisation des sections

### Ordre standard des sections

```
1. Coordonnées
2. Profil professionnel (facultatif)
3. Compétences / Compétences techniques
4. Expérience professionnelle
5. Formation
6. Certifications (si pertinent)
7. Éléments supplémentaires (bénévolat, langues, etc.)
```

### Formatage des titres de section

**Titres reconnus par les ATS :**
- EXPÉRIENCE PROFESSIONNELLE ou EXPÉRIENCE
- FORMATION
- COMPÉTENCES ou COMPÉTENCES TECHNIQUES
- PROFIL PROFESSIONNEL ou RÉSUMÉ
- CERTIFICATIONS
- PROJETS

**Options de format :**
```
EXPÉRIENCE PROFESSIONNELLE
━━━━━━━━━━━━━━━━━━━━━━━━━━

ou

Expérience professionnelle
__________________________

ou

EXPÉRIENCE PROFESSIONNELLE
```

## Disposition des coordonnées

### Format recommandé
```
JEAN DUPONT
jean.dupont@email.com | 06 12 34 56 78 | linkedin.com/in/jeandupont
Paris, France
```

### Format alternatif
```
JEAN DUPONT
Paris, France
jean.dupont@email.com | 06 12 34 56 78
LinkedIn : linkedin.com/in/jeandupont | GitHub : github.com/jeandupont
```

### Ce qu'il faut inclure
- ✅ Nom complet
- ✅ Adresse e-mail professionnelle
- ✅ Numéro de téléphone
- ✅ Ville, Pays/Département (pas besoin de l'adresse postale complète)
- ✅ URL LinkedIn
- ✅ Portfolio/GitHub (si pertinent)

### Ce qu'il faut exclure
- ❌ Adresse postale complète
- ❌ Photo
- ❌ Date de naissance
- ❌ Situation familiale
- ❌ Multiples numéros de téléphone
- ❌ Réseaux sociaux personnels

## Formatage de la section Expérience

### Format standard
```
NOM DE L'ENTREPRISE | Ville, Pays
Intitulé du poste | Mois Année - Mois Année

• Point d'accomplissement avec métriques et résultats
• Point d'accomplissement avec métriques et résultats
• Point d'accomplissement avec métriques et résultats
```

### Format alternatif
```
Intitulé du poste
NOM DE L'ENTREPRISE, Ville, Pays          Mois Année - Mois Année

• Point d'accomplissement avec métriques et résultats
• Point d'accomplissement avec métriques et résultats
```

### Formatage des dates
- **Format cohérent :** Utiliser le même format d'un bout à l'autre
- **Recommandé :** Mois Année (Janv. 2020 - Présent)
- **Également acceptable :** MM/AAAA (01/2020 - Présent)
- **À éviter :** Dates complètes (15 janvier 2020)

### Directives pour les puces
- **Longueur :** 1 à 2 lignes chacune
- **Format :** Commencer par un verbe d'action, terminer par un résultat
- **Quantité :** 3 à 6 puces par poste (davantage pour les plus récents, moins pour les anciens)
- **Symbole :** Utiliser des puces standard (•, -, *)

## Formatage de la section Compétences

### Option 1 : Liste simple
```
COMPÉTENCES
Python, JavaScript, SQL, React, Node.js, AWS, Docker, Git, Agile, JIRA
```

### Option 2 : Par catégories
```
COMPÉTENCES TECHNIQUES
Langages : Python, JavaScript, TypeScript, SQL
Frameworks : React, Node.js, Django, Flask
Outils : AWS, Docker, Kubernetes, Git, Jenkins
```

### Option 3 : En colonnes (attention aux ATS)
```
COMPÉTENCES
Langages         Frameworks       Outils
Python           React            AWS
JavaScript       Node.js          Docker
SQL              Django           Git
```

**Remarque :** Les mises en page multicolonnes peuvent causer des problèmes avec les ATS. Testez avant d'utiliser.

## Formatage de la section Formation

### Format standard
```
FORMATION
Licence en Informatique
Université de Bordeaux | 2018
Mention : Très Bien
```

### Avec mentions/détails
```
FORMATION
Master en Finance et Stratégie | HEC Paris | 2020
• Diplômé avec les félicitations du jury
• Cours pertinents : Finance d'entreprise, Stratégie M&A
```

## Principes de hiérarchie visuelle

### Ordre hiérarchique
1. **Nom** - Le plus grand, le plus visible
2. **Titres de section** - Délimitations claires
3. **Intitulés de poste / Noms d'entreprise** - Faciles à repérer
4. **Puces** - Les détails

### Créer une hiérarchie
- Utiliser la TAILLE de la police pour créer des niveaux
- Utiliser le **GRAS** pour insister (noms, titres, en-têtes)
- Utiliser les MAJUSCULES pour les titres de section
- Utiliser un espacement cohérent pour séparer les sections

## Gestion des espaces blancs

### Bons espaces blancs :
- Entre les sections (séparation nette)
- Après les titres (respiration visuelle)
- Entre les puces (ne pas tasser)
- Autour des marges (encadrer le contenu)

### Mauvais espaces blancs :
- Écarts énormes entre les sections
- Espacement incohérent
- Pages à moitié vides
- Marges excessives dévorant l'espace

## Erreurs de formatage fréquentes

### Erreur 1 : Pavé de texte
**Problème :** Paragraphes denses sans puces
**Solution :** Utiliser des listes à puces, garder les paragraphes courts

### Erreur 2 : Formatage incohérent
**Problème :** Polices, tailles ou styles différents tout au long du document
**Solution :** Choisir un format unique et s'y tenir

### Erreur 3 : Trop de créativité
**Problème :** Designs fantaisistes qui perturbent les ATS
**Solution :** Réserver la créativité au portfolio, pas au CV

### Erreur 4 : Trop d'informations
**Problème :** Tout entasser sur une seule page
**Solution :** Éditer de manière impitoyable, prioriser la pertinence

### Erreur 5 : Pas assez d'informations
**Problème :** CV d'une demi-page avec des marges énormes
**Solution :** Ajouter des détails, réduire les marges (à 0,5" / 1,27 cm)

## Directives sur les formats de fichier

### Pour les candidatures en ligne
- **.docx** - Idéal pour l'analyse ATS
- **.pdf** - Convient s'il est généré depuis Word (non scanné)

### Pour un envoi direct / par e-mail
- **.pdf** - Préserve la mise en page

### Nommage des fichiers
```
Prenom_Nom_CV.pdf
JeanDupont_CV_ProductManager.pdf
```

**À éviter :**
- cv_final_v2_misajour_FINAL.docx
- cv (1).pdf
- Document sans titre.docx

## Format de restitution

Lors du formatage d'un CV :

```markdown
# EXAMEN DU FORMATAGE DU CV

## Problèmes actuels
- [ ] [Problème 1]
- [ ] [Problème 2]
- [ ] [Problème 3]

## Modifications recommandées

### Configuration du document
- Marges : [Actuel] → [Recommandé]
- Police : [Actuel] → [Recommandée]
- Tailles de police : [Actuel] → [Recommandé]

### Ordre des sections
**Actuel :** [Ordre actuel]
**Recommandé :** [Nouvel ordre et justification]

### Améliorations visuelles
- [Changement spécifique 1]
- [Changement spécifique 2]

### Corrections de compatibilité ATS
- [Correction 1]
- [Correction 2]

## Aperçu Avant/Après

### Avant :
[Description ou exemple du formatage actuel]

### Après :
[Description ou exemple du formatage amélioré]
```

## Liste de contrôle rapide du formatage

Avant de soumettre tout CV :
- ✅ Une page (ou deux si justifié)
- ✅ Police standard (10-12 pt pour le corps)
- ✅ Formatage cohérent d'un bout à l'autre
- ✅ Titres de section clairs
- ✅ Espaces blancs appropriés
- ✅ Pas de tableaux, de zones de texte ou de colonnes
- ✅ Coordonnées dans le corps du document (pas dans l'en-tête)
- ✅ Enregistré en .docx ou .pdf
- ✅ Nom de fichier adapté
- ✅ Relecture effectuée pour assurer la cohérence
