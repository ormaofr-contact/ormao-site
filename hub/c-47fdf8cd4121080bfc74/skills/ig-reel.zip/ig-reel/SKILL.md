---
name: ig-reel
description: >-
  Rédigez un Reel Instagram à partir d'une idée brute - options d'accroches issues de 26 formules, script oral, texte à l'écran et découpage rythmé minuté - avec la voix propre de l'utilisateur et évalué avant le tournage. À utiliser dès que l'utilisateur veut un Reel, un script vidéo court, une accroche, une voix off, "fais un reel sur X", "que devrais-je dire dans cette vidéo", ou s'apprête à enregistrer sans avoir encore la première phrase.
---

# ig-reel

Transforme une idée brute en un Reel que l'on regarde jusqu'au bout.

Deux outils se trouvent dans ce dossier et fonctionnent réellement. Utilisez-les. Ne jugez pas l'accroche au pifomètre et ne devinez pas la durée au hasard.

```bash
python3 hookscore.py hooks.txt              # rank your hook options
python3 hookscore.py --hook "one line"      # score a single one
python3 beats.py script.txt --target 30     # timed beat sheet before you shoot
```

## Avant d'écrire

1. Lisez `~/.claude/instagram/voice.md` s'il existe. C'est le profil vocal de
   l'utilisateur : comment il s'exprime face caméra, ce qu'il ne dit jamais, à
   qui il s'adresse. S'il n'existe pas, demandez **trois de ses propres reels**,
   transcrivez-les ou lisez-les, déduisez-en la voix et rédigez le fichier. Un
   script rédigé avec le mauvais ton est inutilisable, car l'utilisateur doit le
   prononcer à voix haute.
2. Lisez `hooks.json` dans ce dossier. 26 formules, chacune avec un modèle, un
   exemple rempli, la version à l'écran, son objectif et la façon dont elle peut
   être gâchée. Quatre d'entre elles s'y trouvent parce qu'elles revenaient
   constamment dans de vraies accroches, et non pour compléter un schéma
   théorique.
3. Si l'idée est mince, ne faites pas de remplissage. Posez une seule question
   groupée : que s'est-il passé, pour qui, et combien cela a-t-il coûté ou
   rapporté ? Un Reel a besoin d'un fait réel et précis. Obtenez-le avant
   d'écrire.
4. Si `~/.claude/instagram/swipe.md` existe, lisez-le. `/ig-viral` écrit ce
   fichier, et il constitue la preuve concrète pour l'utilisateur des formules
   qui fonctionnent dans sa niche en ce moment. Il prévaut sur les valeurs par
   défaut de ce fichier.

## La structure

Le sort d'un Reel se joue dans les deux premières secondes, et l'attention se
retient dans les cinq suivantes.

```
0:00 - 0:02   HOOK        the claim. Spoken line and on-screen line, written
                          separately. Motion in the first frame, not a static face.
0:02 - 0:07   THE STAKE   why this matters to the person watching. One line.
0:07 - ...    THE BODY    one idea per beat, and the frame changes every beat.
LAST 3s       THE PAYOFF  deliver what the hook promised, then the single ask.
LAST LINE     THE LOOP    echo one word from the hook so the replay lands clean.
```

Durée : 15 à 45 secondes est la fourchette idéale. Les Reels peuvent aller
jusqu'à 3 minutes, mais presque personne ne devrait le faire. En dessous de 7
secondes, les vues en boucle gonflent artificiellement, mais rien d'autre.

## Le processus

**1. Choisissez trois accroches, pas une seule.** Passez l'idée dans
`hooks.json`, choisissez trois formules qui lui correspondent véritablement,
puis écrivez la phrase parlée et le texte à l'écran pour chacune. Des formules
différentes, pas trois réécritures d'une même formule.

**2. Notez-les.** Mettez les trois phrases parlées dans un fichier, une par
ligne, et lancez `hookscore.py`. Affichez le classement à l'utilisateur. Si la
meilleure est inférieure à 50, vous n'avez pas encore la bonne accroche et
aucune retouche n'y changera rien.

**3. Écrivez le script** sur l'accroche gagnante. Un langage parlé simple, comme
l'utilisateur s'exprime réellement. Des phrases courtes, du parlé naturel.
Aucune phrase qu'il aurait besoin de répéter plusieurs fois.

**4. Chronométrez-le.** Exécutez `beats.py script.txt --target {length}`.
Corrigez chaque alerte : une accroche dépassant 3 secondes, tout temps fort
(beat) de plus de 4 secondes, une suite de beats sans élément concret,
l'absence de boucle. Relancez jusqu'à ce que tout soit propre.

**5. Humanisez-le.** Passez le script dans `/ig-human` avant de le présenter.
Une phrase qui sonne "écrite" saute aux yeux dès qu'on la prononce à voix
haute.

**6. Affichez le résultat.** Le script dans un bloc de code, le texte à l'écran
sous forme de liste distincte avec minutage, puis :

```
REEL READY
hook:       #3 Nobody Tells You, scored 86 STRONG
length:     28.4s across 9 beats at 165 wpm
on-screen:  6 cards
humanizer:  4 artefacts stripped, human score 81 PASS
caption:    run /ig-caption next

Reply "yes" to log it, or tell me what to change.
```

**7. Ne publiez jamais.** Cette compétence produit un script. L'utilisateur le
tourne et le publie. En cas de réponse « yes », ajoutez l'entrée à
`~/.claude/instagram/log.md` avec la date, la formule d'accroche utilisée et la
première phrase, pour que `/ig-audit` dispose d'un historique par la suite.

## Le texte à l'écran est un script à part entière

Rédigez-le séparément, à chaque fois. Il est lu avant d'être entendu.

- **Six mots ou moins par carte.** Il est lu à bout de bras par quelqu'un qui
  n'écoute pas encore.
- **La carte d'accroche s'affiche dès la première image**, pas après un silence.
- **Restez dans la zone de sécurité (safe zone).** Sur une image de 1080x1920,
  rien au-dessus de y=230 ou en dessous de y=1440, et gardez les 230 pixels de
  droite dégagés. L'interface recouvre tout ce qui dépasse de cette zone : la
  légende, la barre d'actions, la piste audio.
- **Ne placez jamais l'accroche là où se trouve la légende.** C'est le bas du
  cadre et c'est masqué.
- **Incrustez les sous-titres pour le corps de la vidéo.** La plupart des gens
  regardent d'abord sans le son.

## Les règles qui font la différence

- **Une seule idée par Reel.** Si le script en contient deux, vous avez deux
  Reels. Dites-le.
- **Des chiffres plutôt que des adjectifs.** « 4 200 $ » vaut mieux que
  « beaucoup ». Si l'utilisateur n'a pas donné de chiffre, demandez-en un plutôt
  que de meubler autour du vide.
- **Supprimez l'introduction.** Pas de salutations, pas de « dans cette vidéo »,
  pas de nom, pas de jingle logo. La vidéo commence directement par la phrase
  que vous prononceriez normalement à la sixième seconde.
- **Changez de plan à chaque temps fort (beat).** Un plan fixe pendant 8 secondes
  fait fuir l'audience, et `beats.py` le signalera.
- **Un seul appel à l'action à la fin.** Commenter un mot-clé, enregistrer ou
  s'abonner. Un seul.
- **N'inventez jamais rien.** Aucune métrique, client, chiffre d'affaires ou
  résultat inventé sous le nom de l'utilisateur, même à titre temporaire. Si un
  chiffre est nécessaire et inconnu, laissez `{{your number}}` dans le script et
  signalez-le.
- **N'écrivez pas de script autour d'un audio tendance que l'utilisateur ne peut
  pas exploiter.** Si l'idée nécessite la voix propre de l'utilisateur,
  précisez-le.

## Exemple

```
/ig-reel we cut proposal time from 5 hours to 20 minutes with one template
```

```
HOOKS  (scored)
  86  STRONG  #5  Time Collapse   "Proposals used to take me five hours. Twenty minutes now."
                                  on screen: 5 HOURS -> 20 MIN
  71  STRONG  #1  Cost Confession "I billed four hours a week for formatting. For two years."
                                  on screen: 2 YEARS WASTED
  54  OK      #9  The Steal       "Steal the proposal template that did it."
                                  on screen: STEAL THIS

Shooting #5: the ratio is believable, it reads in one glance on screen,
and the number is yours.
