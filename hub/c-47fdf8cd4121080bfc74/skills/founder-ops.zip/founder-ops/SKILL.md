---
name: founder-ops
description: >-
  Votre responsable des opérations. Détermine le fonctionnement concret de
  l'entreprise dès le premier jour : les fournisseurs et leurs coûts, qui
  travaille quand, les routines pas à pas pour l'ouverture, le service ou
  l'expédition et la fermeture, les outils nécessaires, les licences et permis à
  vérifier, ainsi qu'un registre des risques avec la marche à suivre en cas de
  problème. Transmet les coûts réels au CFO. À utiliser lorsque l'utilisateur dit
  « comment faire tourner ça », « opérations », « fournisseurs », « personnel »,
  « SOP », « de quoi ai-je besoin pour ouvrir », « permis » ou « jour un ».
argument-hint: "[ville ou pays]"
---

# founder-ops

Un plan qui fonctionne sur le papier échoue le lundi matin à 7 h. Cette compétence
s'assure que le premier jour, la première semaine et le premier mois peuvent
réellement être gérés sur le terrain, et que les chiffres du CFO intègrent ce que
l'exploitation coûte véritablement.

## Étape 1 : ce que l'entreprise doit faire chaque jour

À partir de `founder/idea.md`, `founder/offer.md` et `founder/numbers.json`, rédigez
le cycle quotidien sous la forme d'une liste d'étapes, de la première à la dernière
tâche (pour un café : livraisons, préparation, ouverture, service, nettoyage, clôture
de caisse, commandes ; pour une boutique en ligne : réception des commandes,
préparation, emballage, expédition, retours, support). Indiquez quelles étapes sont
visibles par le client.

## Étape 2 : les fournisseurs

Pour chaque intrant figurant dans les coûts variables du CFO et chaque équipement :
deux ou trois vrais fournisseurs que l'utilisateur peut contacter, leurs tarifs
publics ou la marche à suivre pour obtenir un devis, les commandes minimales, les
délais de livraison et les conditions de paiement. Ajoutez des liens vers les
sources. Lorsqu'un devis est indispensable pour connaître le prix, précisez-le et
ajoutez-le aux questions en suspens. Si un prix réel diffère de
`founder/numbers.json`, mettez-le à jour et indiquez que le CFO doit recalculer.

## Étape 3 : le personnel

Qui fait quoi et quand : un planning hebdomadaire pour le volume d'activité prévu et
pour le premier mois de démarrage. Les rôles, les horaires et l'hypothèse de
rémunération (fournie par l'utilisateur ou issue d'une source publique avec lien pour
le salaire minimum et les salaires habituels locaux). Les charges sociales et
patronales au-delà du salaire varient selon les pays ; signalez-les à l'attention du
comptable.

## Étape 4 : les routines (SOP)

Des procédures courtes et numérotées pour les moments décisifs de l'activité :
l'ouverture, le cœur de service ou le traitement des commandes, la gestion d'une
réclamation, la fermeture et le réapprovisionnement hebdomadaire. Chacune doit tenir
sur une seule page et pouvoir être suivie par une personne dès son premier jour.

## Étape 5 : les outils

La pile d'outils minimale pour fonctionner : paiements, point de vente ou boutique en
ligne, plannings, comptabilité, inventaire. De vrais produits avec leurs prix
publics, et les raisons de chaque choix.

## Étape 6 : licences, permis et assurances

Une liste de contrôle de ce dont les entreprises de ce type ont généralement besoin
dans la ville ou le pays de l'utilisateur (immatriculation, numéros fiscaux, permis
sanitaires ou alimentaires, autorisations d'enseigne, assurances), chacune
accompagnée du lien vers la page officielle pour vérification. Précisez clairement
que les règles varient selon le lieu et évoluent dans le temps, et que l'utilisateur
doit confirmer chaque élément auprès de l'autorité compétente ou d'un professionnel.
Ne constitue pas un conseil juridique.

## Étape 7 : registre des risques

Les dix imprévus les plus susceptibles de survenir (rupture chez un fournisseur,
absence d'une personne clé pour maladie, panne du terminal de carte bancaire, avis
négatif, mois creux), avec pour chacun le niveau de probabilité, l'impact et le plan
d'action.

## Résultat

`founder/ops.md`, ainsi qu'une mise à jour de `founder/numbers.json` si les coûts
réels ont changé. Étape suivante : `/founder-launch`.
