---
name: animation-vocabulary
description: Glossaire inversé transformant une vague description d'une animation web ou d'un effet de mouvement en son terme exact (« le truc avec un rebond quand un popover s'ouvre » → Pop in ; « le défilement élastique sur iOS » → Rubber-banding). À utiliser lorsque l'utilisateur demande « comment s'appelle l'effet où… » ou décrit un effet de mouvement sans connaître son nom et cherche le mot juste pour prompter une IA ou échanger avec un designer. Sert à nommer un effet, non à le concevoir ou le construire.
---

# Vocabulaire de l'animation

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, réponds uniquement :

> Je suis prêt à nommer n'importe quel effet de mouvement que vous décrivez ; mes connaissances s'appuient sur la philosophie d'animation d'Emil Kowalski.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Transforme une description vague d'un mouvement ou d'un effet en un terme précis, pour que l'utilisateur sache exactement quoi demander.

## Démarrage rapide

L'utilisateur décrit un effet de manière approximative. Tu renvoies le ou les termes correspondants sous ce format :

```
**Stagger** — Animate several items one after another with a small delay between each, creating a cascade.
```

Si plusieurs termes peuvent convenir, indique la meilleure correspondance en premier, puis 1 ou 2 alternatives accompagnées d'une note d'une ligne expliquant leurs différences.

## Instructions

1. **Interpréter l'intention, pas les mots-clés.** Les utilisateurs décrivent ce qu'ils *voient* ou ce qu'ils *ressentent* (« avec du rebond », « glisse vers l'extérieur », « se dessine »), et non le nom technique. Fais correspondre cette sensation avec le glossaire ci-dessous.
2. **Citer le glossaire au mot près.** Ses descriptions font autorité : utilise-les telles quelles, ne les paraphrase pas.
3. **Désambiguïser les termes proches.** Quand deux termes sont en concurrence (*Clip-path* vs *Mask*, *Pop in* vs *Bounce*, *Shared element transition* vs *Layout animation*), compare-les pour que l'utilisateur puisse choisir.
4. **Quand rien ne correspond exactement,** cite le terme le plus proche en précisant clairement qu'il s'agit d'une approximation, ou décris l'effet en utilisant le vocabulaire du glossaire (ex. : « c'est un *stagger* d'entrées en *scale-in* »).
5. **Rester dans les limites de ce glossaire.** Si un terme ne s'y trouve vraiment pas, indique-le plutôt que d'en inventer un — bien que tu puisses expliquer le concept à l'aide de ces mots.
6. **Être concis.** Une question de dénomination attend un nom, pas une dissertation. Donne le terme en premier ; ne développe que si on te le demande.

## Exemples

**Exemple 1 — basé sur le ressenti**
Utilisateur : « Comment s'appelle l'effet lorsqu'un popover semble émerger du bouton sur lequel on a cliqué au lieu d'apparaître depuis son centre ? »
Sortie :
```
**Origin-aware animation** — An element animates out of its trigger, like a popover growing from the button that opened it instead of from its own center which is the default in CSS.
```

**Exemple 2 — désambiguïsation**
Utilisateur : « Le truc où une image se transforme en une autre image. »
Sortie :
```
**Morph** — One shape smoothly turns into another shape, e.g. Dynamic Island.

Close alternates:
- **Crossfade** — if they simply fade over each other in the same spot.
- **Shared element transition** — if an element travels and transforms from one position into another.
```

**Exemple 3 — sensation physique**
Utilisateur : « Ce défilement sur iOS où ça résiste et revient d'un coup sec quand on tire trop loin. »
Sortie :
```
**Rubber-banding** — Resistance and snap-back when you drag past a boundary (the iOS overscroll feel).
```

## Glossaire

_Un instantané sélectionné reflétant la page `/vocabulary` du projet ; garde les deux synchronisés dès que l'un d'eux change._

### Entrées et sorties — comment les éléments apparaissent et disparaissent
- **Fade in / Fade out** — L'élément apparaît ou disparaît en modifiant son opacité.
- **Slide in** — L'élément entre en glissant depuis l'extérieur de l'écran (gauche, droite, haut ou bas).
- **Scale in** — L'élément grandit depuis une taille réduite jusqu'à sa taille réelle à mesure qu'il apparaît, souvent combiné avec un fondu.
- **Pop in** — L'élément apparaît avec un léger dépassement, comme s'il rebondissait en se mettant en place.
- **Reveal** — Le contenu est dévoilé progressivement, souvent en animant un chemin de découpe (clip-path) ou un masque.
- **Enter / Exit** — L'animation qu'un élément exécute lorsqu'il est ajouté à l'écran ou retiré de celui-ci.

### Séquençage et timing — coordonner plusieurs éléments ou moments
- **Keyframes** — Points définis d'une animation (0 %, 50 %, 100 %) entre lesquels le navigateur comble les intervalles.
- **Interpolation / Tween** — Génération de toutes les images intermédiaires entre une valeur de départ et une valeur de fin, afin que le mouvement soit continu.
- **Stagger** — Animer plusieurs éléments les uns après les autres avec un léger décalage entre chacun, créant un effet de cascade.
- **Orchestration** — Chronométrer délibérément plusieurs animations pour qu'elles donnent l'impression d'un mouvement unique et coordonné.
- **Delay** — Temps d'attente avant le démarrage d'une animation.
- **Duration** — Temps que dure une animation.
- **Fill mode** — Indique si un élément conserve les styles de sa première ou de sa dernière image clé avant le début de l'animation ou après sa fin (par exemple, forwards).
- **Stepped animation** — Une animation découpée en étapes discrètes, comme un compte à rebours.

### Mouvements et transformations — modifier la position, la taille ou l'angle d'un élément
- **Translate** — Déplacer un élément le long de l'axe X ou Y.
- **Scale** — Agrandir ou rétrécir un élément.
- **Rotate** — Faire pivoter un élément autour d'un point.
- **Skew** — Incliner un élément le long de l'axe X ou Y, déformant ainsi sa forme rectangulaire.
- **3D tilt / Flip** — Rotation dans l'espace 3D (rotateX / rotateY) pour ajouter de la profondeur.
- **Perspective** — Intensité perçue de l'effet 3D — une valeur plus faible exagère la profondeur, comme si l'observateur était plus proche.
- **Transform origin** — Le point d'ancrage à partir duquel s'opère un changement d'échelle ou une rotation.
- **Origin-aware animation** — L'élément s'anime à partir de son déclencheur, comme un popover qui grandit depuis le bouton qui l'a ouvert au lieu de son propre centre, qui est le comportement par défaut en CSS.

### Transitions d'état — relier un état, une vue ou un élément à un autre
- **Crossfade** — Un élément disparaît en fondu au moment où un autre apparaît en fondu, au même endroit.
- **Continuity transition** — Un changement qui préserve les repères de l'utilisateur en reliant visuellement l'avant et l'après. Par exemple, agrandir et rétrécir le même rectangle.
- **Morph** — Une forme se transforme de manière fluide en une autre forme, comme la Dynamic Island.
- **Shared element transition** — Un élément se déplace et se transforme d'une position à une autre, comme une vignette qui s'agrandit pour devenir une carte.
- **Layout animation** — Lorsque la taille ou la position d'un élément change, il s'anime vers son nouvel emplacement au lieu d'y sauter instantanément.
- **Accordion / Collapse** — Une section ajuste fluidement sa hauteur pour afficher ou masquer du contenu en se dépliant ou se repliant.
- **Direction-aware transition** — Le contenu glisse dans une direction en avançant et dans la direction opposée en revenant en arrière, pour donner un sens d'orientation à la navigation.

### Défilement — mouvements liés au scroll ou à la navigation entre les vues
- **Scroll reveal** — Les éléments apparaissent en fondu ou glissent en place lorsqu'ils entrent dans la zone d'affichage (viewport).
- **Scroll-driven animation** — Une animation dont la progression est directement liée à la position de défilement.
- **Parallax** — L'arrière-plan et le premier plan se déplacent à des vitesses différentes pendant le défilement, créant un effet de profondeur.
- **Page transition** — Une animation qui se joue lors de la navigation d'une page ou d'une route à une autre.
- **View transition** — Le navigateur métamorphose l'affichage entre deux états ou pages, en reliant les éléments partagés.

### Retour visuel et interaction — répondre aux actions de l'utilisateur
- **Hover effect** — Modification visuelle lorsque le curseur survole un élément.
- **Press / Tap feedback** — Une légère réduction d'échelle lorsqu'on clique sur un élément, pour lui donner une sensation physique.
- **Hold to confirm** — Un effet de progression qui se remplit tant que l'utilisateur maintient un bouton enfoncé.
- **Drag** — Déplacer un élément en le saisissant, souvent avec de l'élan lorsqu'il est relâché.
- **Drag to reorder** — Faire glisser des éléments dans une liste pour les réorganiser, tandis que les autres se déplacent pour faire de la place.
- **Swipe to dismiss** — Faire glisser un élément hors de l'écran pour le fermer, comme un tiroir ou un toast.
- **Rubber-banding** — Résistance et retour élastique lorsqu'on tire au-delà d'une limite (la sensation de surdéfilement sur iOS).
- **Shake / Wiggle** — Un tremblement latéral rapide signalant une erreur ou une saisie refusée.
- **Ripple** — Un cercle qui s'étend à partir du point d'impact d'un appui, confirmant la pression.

### Easing — comment la vitesse évolue au cours d'une animation
- **Easing** — La vitesse à laquelle une animation accélère ou ralentit.
- **Ease-out** — Démarre rapidement, se termine lentement. Le comportement par défaut pour la plupart des interfaces et tout ce qui répond à l'utilisateur.
- **Ease-in** — Démarre lentement, se termine rapidement. Généralement évité ; peut sembler lourd ou poussif.
- **Ease-in-out** — Lent, rapide, lent. Idéal pour les éléments déjà à l'écran qui se déplacent d'un point A à un point B.
- **Linear** — Vitesse constante. À éviter pour les interfaces ; à réserver aux indicateurs de chargement (spinners) ou aux bandeaux défilants (marquees).
- **Cubic-bezier** — Une courbe de bézier personnalisée que l'on définit pour un contrôle précis.
- **Asymmetric easing** — Une courbe qui accélère et décélère à des rythmes différents. Donne une impression plus vivante qu'une courbe symétrique.

### Animations de type ressort (Spring) — mouvements basés sur la physique comme alternative à l'easing à durée fixe
- **Spring** — Mouvement régi par la physique (tension, masse, amortissement) plutôt que par une durée définie.
- **Stiffness / Tension** — La force avec laquelle le ressort tire vers sa cible. Plus elle est élevée, plus le mouvement est réactif et sec.
- **Damping** — La rapidité avec laquelle un ressort se stabilise. Un amortissement plus faible entraîne plus de rebonds et d'oscillations.
- **Mass** — Le poids perçu de l'élément animé. Une masse plus élevée le rend plus lent et plus lourd.
- **Bounce** — Un ressort qui dépasse sa cible avant de se stabiliser, ajoutant un côté ludique.
- **Perceptual duration** — Le temps au bout duquel un ressort donne l'impression d'avoir terminé, même s'il continue de micro-osciller en arrière-plan.
- **Momentum** — Mouvement qui conserve son élan et sa vélocité, en particulier après un glissement ou une interruption.
- **Velocity** — La vitesse et la direction dans lesquelles un élément se déplace. Un ressort transmet cette vélocité à l'animation suivante en cas d'interruption, de sorte qu'un élément propulsé d'un coup sec conserve son élan.
- **Interruptible animation** — Une animation qui peut être redirigée fluidement en plein vol sans devoir se terminer d'abord.

### Boucles et mouvements d'ambiance — animations qui tournent de manière autonome
- **Marquee** — Texte ou contenu qui défile en continu dans une boucle infinie.
- **Loop** — Une animation qui se répète, un nombre défini de fois ou indéfiniment.
- **Alternate (yoyo)** — Une boucle qui s'exécute vers l'avant puis s'inverse à chaque itération, au lieu de revenir brusquement au début.
- **Orbit** — Un élément tournant autour d'un autre selon une trajectoire continue.
- **Pulse** — Un léger changement d'échelle ou d'opacité qui se répète pour attirer l'attention.
- **Float** — Une oscillation verticale douce et continue qui donne vie à un élément statique et lui confère une impression d'apesanteur.
- **Idle animation** — Mouvement subtil qui se joue lorsqu'un élément est simplement immobile, en attente d'interaction.

### Finitions et effets — les petits détails qui font toute la différence
- **Blur** — Un filtre de flou utilisé pour adoucir un élément ou masquer d'infimes imperfections.
- **Clip-path** — Découpage d'un élément selon une forme, utilisé pour les apparitions progressives, les masques et les curseurs avant/après.
- **Mask** — Masquage ou révélation de parties d'un élément à l'aide d'une forme ou d'un dégradé — similaire au clip-path, mais avec des contours doux pouvant être fondus.
- **Before / after slider** — Un séparateur déplaçable qui balaie deux images superposées pour les comparer.
- **Line drawing** — Un tracé SVG qui se dessine lui-même, comme si un stylo invisible le traçait.
- **Text morph** — Texte qui s'anime caractère par caractère lorsqu'il change, attirant l'attention sur la nouvelle valeur.
- **Skeleton / Shimmer** — Un espace réservé affichant un reflet lumineux en mouvement pendant le chargement du contenu.
- **Number ticker** — Chiffres qui défilent ou s'incrémentent jusqu'à atteindre une valeur cible.
- **Tabular numbers** — Chiffres à chasse fixe pour éviter que les nombres ne bougent lorsqu'ils changent. Essentiel pour les compteurs, les minuteurs et les tickers.
- **Typewriter** — Texte apparaissant un caractère à la fois, comme s'il était tapé à la machine.

### Performance — ce qui préserve la fluidité du mouvement et évite les saccades
- **Frame rate (FPS)** — Nombre d'images affichées par seconde. 60 fps est la base pour un mouvement fluide ; 120 fps sur les écrans plus récents.
- **Jank** — Saccade visible lorsque le navigateur saute des images parce qu'il ne parvient pas à suivre l'animation.
- **Dropped frame** — Image que le navigateur n'a pas eu le temps de dessiner, causant un micro-accrochage dans le mouvement.
- **Compositing** — Déléguer au GPU le déplacement ou le fondu d'un élément sur son propre calque sans recalculer la mise en page (layout) ni le tracé (paint).
- **will-change** — Indication CSS signalant qu'un élément est sur le point d'être animé, permettant au navigateur de le promouvoir à l'avance sur son propre calque.
- **Layout thrashing** — Animation de propriétés telles que width, height, top ou left forçant le navigateur à recalculer la mise en page à chaque image, provoquant des saccades (jank).

### Principes à connaître — notions guidant quand et comment animer
- **Purposeful animation** — Le mouvement doit remplir une fonction — orienter, donner un retour, clarifier des relations — et non être une simple décoration.
- **Anticipation** — Un léger élan dans la direction opposée avant un mouvement, suggérant ce qui va se produire.
- **Follow-through** — Certaines parties d'un élément continuent de bouger et se stabilisent légèrement après l'arrêt du mouvement principal, ajoutant de la consistance et du poids.
- **Squash & stretch** — Déformation d'un élément lors de son mouvement pour exprimer son poids, sa vitesse et sa souplesse.
- **Perceived performance** — Une bonne animation donne l'impression qu'une interface est plus rapide, même lorsque ce n'est pas le cas.
- **Frequency of use** — Plus un utilisateur est exposé à une animation, plus celle-ci doit être brève et subtile.
- **Spatial consistency** — Animer de manière à ce qu'un élément préserve son identité et sa position à travers les différents états, afin que l'utilisateur ne perde jamais le fil.
- **Hardware acceleration** — Animer transform et opacity permet au GPU de maintenir un mouvement fluide.
- **Reduced motion** — Respecter la préférence de l'utilisateur prefers-reduced-motion en atténuant ou en désactivant le mouvement.
