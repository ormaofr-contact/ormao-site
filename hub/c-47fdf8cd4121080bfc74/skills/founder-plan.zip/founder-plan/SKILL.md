---
name: founder-plan
description: >-
  Votre concepteur de business plan. Compile tout ce que les autres compétences founder ont rédigé (le verdict du board, les concurrents, le panel d'acheteurs, la tarification, l'offre, les chiffres du DAF, le marketing, la marque, les opérations et le plan de lancement) en un business plan unique avec un verdict en tête calculé à partir des chiffres, jamais rédigé à la main : Rentable, Pas encore (avec les chiffres défaillants) ou Incomplet. Ajoute un résumé opérationnel (executive summary) et une version d'une page pour un partenaire, un prêteur ou un investisseur. À utiliser lorsque l'utilisateur dit "rédige mon business plan", "rassemble tout", "est-ce rentable", "donne-moi le plan", ou à la fin du pack founder.
argument-hint: "[--min-buy-rate 0.25]"
---

# founder-plan

La dernière étape. Un document unique sur lequel un fondateur peut s'appuyer pour agir, ou à transmettre à un partenaire ou un prêteur, élaboré exclusivement à partir des conclusions du pack.

Outil dans ce dossier :

```bash
python3 "${CLAUDE_SKILL_DIR}/compile.py" --dir founder
```

## Étape 1 : vérifier l'existant

```bash
python3 "${CLAUDE_SKILL_DIR}/compile.py" --dir founder --check
```

affiche le verdict et chaque vérification. Les vérifications, toutes calculées :

1. Chaque unité génère des bénéfices avant les coûts fixes (`founder/numbers.json`).
2. L'année 1 dégage un résultat d'exploitation positif.
3. Le point mort reste dans les limites de la capacité, si une capacité a été définie.
4. Un nombre suffisant d'acheteurs simulés achètent (`founder/panel/results.json` ; seuil par défaut de 25 %, modifiez-le avec `--min-buy-rate` et expliquez pourquoi).

S'il n'y a pas de chiffres, le verdict est Incomplet : proposez d'exécuter `/founder-cfo`. Listez les autres sections manquantes avec la compétence permettant de compléter chacune. Ne complétez pas vous-même une section manquante par des suppositions.

## Étape 2 : le résumé

Rédigez `founder/summary.md`, une demi-page, en termes simples :

- En quoi consiste l'activité et à qui elle s'adresse, en deux phrases.
- Le verdict et les trois chiffres qui le sous-tendent (marge, point mort, année 1).
- Ce sur quoi le panel d'acheteurs et le board se sont accordés, et leurs points de désaccord.
- Le risque principal et ce qui sera fait pour y remédier.
- Ce dont le fondateur a besoin pour se lancer (la trésorerie issue du DAF, le premier test issu du lancement).
- La seule action prioritaire à mener cette semaine.

Si le verdict est Pas encore, le résumé s'ouvre sur ce qui doit changer et la compétence nécessaire pour y parvenir. N'édulcorez jamais une vérification qui a échoué.

## Étape 3 : compiler

```bash
python3 "${CLAUDE_SKILL_DIR}/compile.py" --dir founder
```

génère `founder/business-plan.md` : le titre, le verdict et ses vérifications, le tableau des chiffres clés, l'idée, puis chaque section produite par le pack (résumé, board, concurrence, panel, tarification, offre, chiffres, marketing, marque, opérations, lancement), et ce qui n'est pas encore fait.

## Étape 4 : le one-pager

Rédigez `founder/one-pager.md` pour un lecteur devant décider en deux minutes : le problème, le client, l'offre et le prix, le tableau des chiffres, les preuves (résultat du panel, opportunité face aux concurrents, tests réels éventuels), l'utilisation des fonds et la demande. Les mêmes chiffres que dans le plan, au mot près.

## Règles

- Le verdict provient de `compile.py`. N'écrivez jamais Rentable à la main, et n'arrondissez jamais un chiffre insuffisant pour le faire passer.
- Rappelez une fois, clairement : le panel est constitué d'acheteurs simulés et les chiffres sont des projections ; seuls des clients réels et de vrais devis permettent de les confirmer. Ceci ne constitue pas un conseil financier, juridique ou fiscal.
- Si l'utilisateur souhaite un PDF ou une présentation (deck), proposez d'exporter le plan, mais conservez le Markdown comme source de vérité unique.

## Livrables

`founder/summary.md`, `founder/business-plan.md`, `founder/one-pager.md`. Donnez ensuite à l'utilisateur le verdict en une ligne ainsi que l'action prioritaire à mener cette semaine.
