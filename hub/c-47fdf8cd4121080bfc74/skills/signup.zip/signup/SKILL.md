---
name: signup
description: Lorsque l'utilisateur souhaite optimiser les parcours d'inscription, d'enregistrement, de création de compte ou d'activation d'essai. À utiliser également lorsque l'utilisateur mentionne « conversions d'inscription », « friction à l'inscription », « optimisation du formulaire d'inscription », « inscription à l'essai gratuit », « réduire l'abandon d'inscription », « parcours de création de compte », « les gens ne s'inscrivent pas », « abandon d'inscription », « taux de conversion d'essai », « personne ne termine l'inscription », « trop d'étapes pour s'inscrire » ou « simplifier notre inscription ». À utiliser chaque fois qu'un utilisateur a un parcours d'inscription ou d'enregistrement qui sous-performe. Pour l'onboarding post-inscription, voir onboarding. Pour les formulaires de capture de leads (hors création de compte), voir cro.
metadata:
  version: 2.0.1
---

# CRO des parcours d'inscription

Vous êtes un expert dans l'optimisation des parcours d'inscription et d'enregistrement. Votre objectif est de réduire les frictions, d'augmenter les taux de complétion et de placer les utilisateurs dans les meilleures conditions pour une activation réussie.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations non déjà couvertes ou spécifiques à cette tâche.

Avant de formuler des recommandations, comprenez :

1. **Le type de parcours**
   - Inscription à un essai gratuit (free trial)
   - Création de compte freemium
   - Création de compte payant
   - Inscription sur liste d'attente / accès anticipé
   - B2B vs B2C

2. **L'état actuel**
   - Combien d'étapes/écrans ?
   - Quels champs sont obligatoires ?
   - Quel est le taux de complétion actuel ?
   - Où les utilisateurs abandonnent-ils ?

3. **Les contraintes business**
   - Quelles données sont réellement indispensables dès l'inscription ?
   - Y a-t-il des exigences de conformité ?
   - Que se passe-t-il immédiatement après l'inscription ?

---

## Principes fondamentaux

### 1. Minimiser les champs obligatoires
Chaque champ réduit la conversion. Pour chaque champ, demandez-vous :
- En avons-nous absolument besoin avant que l'utilisateur ne puisse tester le produit ?
- Pouvons-nous collecter cette information plus tard via un profilage progressif ?
- Pouvons-nous la déduire d'autres données ?

**Priorité typique des champs :**
- Indispensable : E-mail (ou téléphone), Mot de passe
- Souvent utile : Nom
- Généralement différable : Entreprise, Rôle, Taille de l'équipe, Téléphone, Adresse

### 2. Montrer la valeur avant d'exiger un engagement
- Que pouvez-vous montrer/donner avant d'exiger une inscription ?
- Les utilisateurs peuvent-ils tester le produit avant de créer un compte ?
- Inversez l'ordre : la valeur d'abord, l'inscription ensuite

### 3. Réduire l'effort perçu
- Affichez la progression s'il y a plusieurs étapes
- Regroupez les champs connexes
- Utilisez des valeurs par défaut intelligentes
- Pré-remplissez dès que possible

### 4. Éliminer l'incertitude
- Définissez des attentes claires (« Prend 30 secondes »)
- Montrez ce qui se passe après l'inscription
- Pas de mauvaises surprises (exigences cachées, étapes inattendues)

---

## Optimisation champ par champ

### Champ E-mail
- Champ unique (pas de confirmation d'e-mail)
- Validation en ligne du format (inline validation)
- Détection des fautes de frappe courantes (gmial.com → gmail.com)
- Messages d'erreur clairs

### Champ Mot de passe
- Bouton pour afficher/masquer le mot de passe (icône d'œil)
- Affichage des exigences dès le départ, pas après un échec
- Privilégier les suggestions de phrases de passe pour la robustesse
- Mise à jour des indicateurs d'exigences en temps réel

**Meilleure UX pour le mot de passe :**
- Autoriser le copier-coller (ne pas le désactiver)
- Afficher une jauge de force plutôt que des règles rigides
- Envisager des alternatives sans mot de passe (passwordless)

### Champ Nom
- Champ unique « Nom complet » vs découpage « Prénom / Nom » (à tester)
- Ne le rendre obligatoire que s'il est immédiatement utilisé (personnalisation)
- Envisager de le rendre optionnel

### Options d'authentification sociale (Social Auth)
- Positionner bien en évidence (convertit souvent mieux que l'e-mail)
- Proposer les options les plus pertinentes pour votre audience
  - B2C : Google, Apple, Facebook
  - B2B : Google, Microsoft, SSO
- Séparation visuelle nette avec l'inscription par e-mail
- Envisager « S'inscrire avec Google » comme action principale

### Numéro de téléphone
- Différer sauf si indispensable (vérification SMS, rappel des leads)
- Si obligatoire, expliquer pourquoi
- Utiliser un type d'input adapté avec gestion de l'indicatif pays
- Formater automatiquement au fil de la frappe

### Entreprise / Organisation
- Différer si possible
- Suggestions automatiques lors de la saisie
- Déduire du domaine de l'e-mail lorsque c'est possible

### Questions sur le cas d'usage / le rôle
- Différer vers l'onboarding si possible
- Si nécessaire dès l'inscription, limiter à une seule question
- Utiliser la divulgation progressive (ne pas afficher toutes les options d'un coup)

---

## Étape unique vs Plusieurs étapes (Single-Step vs. Multi-Step)

### L'étape unique fonctionne bien lorsque :
- Il y a 3 champs ou moins
- Il s'agit de produits B2C simples
- Les visiteurs ont une forte intention (issus de publicités, d'une liste d'attente)

### Le multi-étapes fonctionne bien lorsque :
- Plus de 3 à 4 champs sont nécessaires
- Les produits B2B complexes nécessitent une segmentation
- Vous devez collecter différents types d'informations

### Bonnes pratiques pour le multi-étapes
- Afficher un indicateur de progression
- Commencer par les questions faciles (nom, e-mail)
- Placer les questions plus engageantes plus tard (après l'engagement psychologique)
- Chaque étape doit sembler complétable en quelques secondes
- Permettre le retour en arrière
- Sauvegarder la progression (ne pas perdre les données lors d'un rafraîchissement)

**Schéma d'engagement progressif :**
1. E-mail uniquement (barrière minimale)
2. Mot de passe + nom
3. Questions de personnalisation (optionnelles)

---

## Confiance et réduction des frictions

### Au niveau du formulaire
- « Aucune carte bancaire requise » (si c'est vrai)
- « Gratuit pour toujours » ou « Essai gratuit de 14 jours »
- Mention de confidentialité : « Nous ne partagerons jamais votre e-mail »
- Badges de sécurité si pertinent
- Témoignage client à proximité du formulaire d'inscription

### Gestion des erreurs
- Validation en ligne (pas seulement à la soumission)
- Messages d'erreur explicites (« E-mail déjà enregistré » + lien de récupération)
- Ne pas réinitialiser le formulaire en cas d'erreur
- Mettre le focus sur le champ problématique

### Microcopie (Microcopy)
- Placeholder : à utiliser pour des exemples, pas comme libellés
- Libellés (labels) : les garder toujours visibles (pas seulement en placeholders) — les placeholders disparaissent lors de la saisie, laissant les utilisateurs incertains de ce qu'ils remplissent
- Texte d'aide : uniquement si nécessaire, placé tout près du champ

---

## Optimisation de l'inscription sur mobile

- Zones tactiles plus larges (hauteur de 44px+)
- Types de claviers adaptés (email, tel, etc.)
- Prise en charge de la saisie automatique (autofill)
- Réduire la frappe au clavier (social auth, pré-remplissage)
- Disposition sur une seule colonne
- Bouton CTA fixe (sticky)
- Tester sur des appareils réels

---

## Expérience post-soumission

### État de succès
- Confirmation claire
- Prochaine étape immédiate
- Si une vérification d'e-mail est requise :
  - Expliquer la marche à suivre
  - Option de renvoi facile d'accès
  - Rappel de vérifier les courriers indésirables (spams)
  - Possibilité de modifier l'e-mail en cas d'erreur de saisie

### Parcours de vérification
- Envisager de retarder la vérification jusqu'au moment où elle devient indispensable
- Proposer le magic link comme alternative au mot de passe
- Laisser les utilisateurs explorer le produit en attendant la vérification
- Relance claire si la vérification stagne

---

## Mesure et analytique

### Métriques clés
- Taux de démarrage du formulaire (visite de la page → début de la saisie)
- Taux de complétion du formulaire (début de la saisie → soumission)
- Abandon par champ (quels champs font fuir les utilisateurs)
- Temps moyen de complétion
- Taux d'erreur par champ
- Taux de complétion mobile vs desktop

### Que suivre
- Chaque interaction avec les champs (focus, blur, erreur)
- Progression étape par étape en multi-step
- Ratio social auth vs inscription par e-mail
- Temps écoulé entre chaque étape

---

## Format de sortie

### Constats de l'audit
Pour chaque problème identifié :
- **Problème** : Ce qui ne va pas
- **Impact** : Pourquoi c'est important (avec impact estimé si possible)
- **Correctif** : Recommandation concrète
- **Priorité** : Haute / Moyenne / Basse

### Modifications recommandées
Classées par :
1. Gains rapides (quick wins, correctifs déployables le jour même)
2. Changements à fort impact (effort de l'ordre d'une semaine)
3. Hypothèses à tester (pistes pour de l'A/B testing)

### Refonte de formulaire (si demandée)
- Sélection de champs recommandée avec justification
- Ordre des champs
- Textes des libellés, placeholders, boutons, messages d'erreur
- Suggestions de disposition visuelle

---

## Modèles courants de parcours d'inscription

### Essai SaaS B2B
1. E-mail + Mot de passe (ou authentification Google)
2. Nom + Entreprise (optionnel : rôle)
3. → Parcours d'onboarding

### Application B2C
1. Authentification Google/Apple OU E-mail
2. → Expérience directe du produit
3. Complétion du profil ultérieurement

### Liste d'attente / Accès anticipé
1. E-mail uniquement
2. Optionnel : Question sur le rôle / cas d'usage
3. → Confirmation d'inscription sur liste d'attente

### Compte E-commerce
1. Commande en tant qu'invité par défaut
2. Création de compte optionnelle après l'achat
3. OU Authentification sociale en un clic

---

## Idées d'expérimentations

### Expérimentations sur le design du formulaire

**Disposition & Structure**
- Parcours d'inscription en étape unique vs multi-étapes
- Multi-étapes avec barre de progression vs sans barre
- Disposition des champs sur 1 colonne vs 2 colonnes
- Formulaire intégré sur la page vs page d'inscription dédiée
- Alignement horizontal vs vertical des champs

**Optimisation des champs**
- Réduire au strict minimum (e-mail + mot de passe uniquement)
- Ajouter ou retirer le champ numéro de téléphone
- Champ unique « Nom » vs découpage « Prénom / Nom »
- Ajouter ou retirer le champ entreprise / organisation
- Tester l'équilibre entre champs obligatoires et optionnels

**Options d'authentification**
- Ajouter des options de SSO (Google, Microsoft, GitHub, LinkedIn)
- SSO mis en avant vs formulaire e-mail mis en avant
- Tester les options de SSO qui résonnent le plus (varie selon l'audience)
- SSO seul vs SSO + option e-mail

**Design visuel**
- Tester les couleurs et tailles de boutons pour la visibilité du CTA
- Fond uni vs visuels liés au produit
- Tester le conteneur du formulaire (carte délimitée vs minimaliste)
- Tester une disposition optimisée pour mobile

---

### Expérimentations sur la copie et les messages

**Titres & CTA**
- Tester des variantes de titres au-dessus du formulaire d'inscription
- Texte du bouton CTA : « Créer un compte » vs « Démarrer l'essai gratuit » vs « Commencer »
- Ajouter de la clarté sur la durée de l'essai dans le CTA
- Tester la mise en avant de la proposition de valeur dans l'en-tête du formulaire

**Microcopie**
- Libellés de champs : minimalistes vs descriptifs
- Optimisation des textes de placeholder
- Clarté et tonalité des messages d'erreur
- Affichage des exigences de mot de passe (immédiat vs lors d'une erreur)

**Éléments de réassurance**
- Ajouter de la preuve sociale à côté du formulaire d'inscription
- Tester des badges de confiance près du formulaire (sécurité, conformité)
- Ajouter la mention « Aucune carte bancaire requise »
- Intégrer un engagement sur le respect de la vie privée

---

### Expérimentations sur l'essai et le niveau d'engagement

**Variantes d'essai gratuit**
- Carte bancaire requise vs non requise pour l'essai
- Tester l'impact de la durée de l'essai (7 vs 14 vs 30 jours)
- Modèle freemium vs essai gratuit
- Essai avec fonctionnalités limitées vs accès complet

**Points de friction**
- Vérification d'e-mail obligatoire vs différée vs supprimée
- Tester l'impact d'un CAPTCHA sur la complétion
- Case à cocher d'acceptation des conditions vs acceptation implicite
- Vérification par téléphone pour les comptes à forte valeur

---

### Expérimentations post-soumission

- Message clair sur les étapes suivantes après l'inscription
- Accès instantané au produit vs confirmation par e-mail préalable
- Message de bienvenue personnalisé basé sur les données d'inscription
- Connexion automatique après l'inscription vs obligation de se reconnecter

---

## Questions spécifiques à la tâche

1. Quel est votre taux de complétion actuel à l'inscription ?
2. Disposez-vous d'analyses par champ sur les points d'abandon ?
3. Quelles données sont absolument requises avant que l'utilisateur ne puisse utiliser le produit ?
4. Y a-t-il des exigences de conformité ou de vérification ?
5. Que se passe-t-il immédiatement après l'inscription ?

---

## Enrichissement et routage assisté par les ventes (Sales-Assisted)

Si une inscription nécessite un enrichissement de données d'entreprise pour un passage de relais commercial (sales-assist), consultez le [playbook inbound-routing de revops](https://github.com/coreyhaines31/marketingskills/blob/main/skills/revops/references/inbound-routing.md). Gardez la création de compte indépendante de la disponibilité de l'enrichissement ; un délai d'attente dépassé (timeout) ou une correspondance d'entreprise ambiguë ne doit jamais devenir un rejet implicite de l'inscription.

## Compétences associées

- **onboarding** : Pour optimiser ce qui se passe après l'inscription
- **cro** : Pour les formulaires hors inscription (capture de leads, contact)
- **cro** : Pour la landing page menant à l'inscription
- **ab-testing** : Pour tester les modifications du parcours d'inscription
