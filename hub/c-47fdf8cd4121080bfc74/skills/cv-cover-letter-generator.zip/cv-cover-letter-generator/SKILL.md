---
name: cover-letter-generator
description: Créez des lettres de motivation personnalisées et percutantes à partir d'un CV et d'une offre d'emploi
---

# Générateur de lettre de motivation

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur souhaite :
- Rédiger une lettre de motivation pour une candidature
- Créer une lettre de candidature personnalisée
- Répondre aux exigences spécifiques d'un poste sous forme de lettre
- Mentionne : « cover letter », « application letter », « write cover letter », « letter for job », « lettre de motivation »

À utiliser APRÈS avoir analysé la description du poste afin de disposer d'arguments clairs.

## Capacités principales

- Générer des lettres de motivation personnalisées à partir du CV et de l'offre d'emploi
- Adapter le ton à la culture de l'entreprise
- Aborder stratégiquement les lacunes de qualification
- Créer des accroches captivantes
- Structurer des arguments convaincants pour la candidature
- Préserver l'authenticité tout en se valorisant efficacement

## Philosophie de la lettre de motivation

**Le problème :** La plupart des lettres de motivation sont génériques, ennuyeuses et n'apportent aucune valeur ajoutée par rapport au CV.

**La solution :** Une excellente lettre de motivation doit :
1. Montrer que vous vous êtes renseigné sur l'entreprise
2. Relier VOTRE expérience spécifique à LEURS besoins précis
3. Répondre aux questions « pourquoi vous, pourquoi maintenant, pourquoi ici »
4. Apporter de la personnalité et un contexte qu'un CV ne peut pas transmettre

## La structure de la lettre de motivation parfaite

### Longueur et format
- **Longueur :** 250 à 400 mots (3 à 4 paragraphes)
- **Format :** Style de lettre professionnelle
- **Ton :** Confiant sans être arrogant, personnalisé mais professionnel

### Aperçu de la structure
```
[Your Contact Info]
[Date]
[Recipient Info]

Opening Paragraph: Hook + Position + Why This Company (2-3 sentences)

Body Paragraph 1: Your strongest qualification match (3-4 sentences)

Body Paragraph 2: Additional qualifications + address any gaps (3-4 sentences)

Closing Paragraph: Call to action + enthusiasm (2-3 sentences)

[Professional Sign-off]
```

## Stratégies pour le paragraphe d'ouverture

L'accroche de début est cruciale : vous avez 5 secondes pour capter l'attention.

### Types d'accroches (en choisir une)

**1. Connaissance spécifique de l'entreprise**
```
"I was excited to see TechCorp's recent launch of your API marketplace - as a Product Manager who's spent 3 years building developer tools, I immediately saw how my experience could accelerate your platform growth."
```

**2. Contact commun**
```
"Sarah Chen on your engineering team mentioned you're looking for a PM to lead the payments initiative. Having worked with Sarah at [Previous Company] and led payment integrations at [Current Company], I'd love to discuss how I could contribute."
```

**3. Résolution de problème**
```
"Your job description mentions the challenge of aligning technical and business stakeholders - I've navigated this exact challenge, successfully launching 8 products by building shared roadmap visibility across engineering, sales, and executive teams."
```

**4. Réalisation impressionnante**
```
"Last year, I led a product that grew from 0 to 100K users in 6 months. I'm excited about the opportunity to bring that growth mindset to [Company]'s expanding product line."
```

**5. Vision sectorielle**
```
"The B2B payments space is at an inflection point, and [Company]'s approach to embedded finance positions you perfectly for the next wave. As someone who's been building in fintech for 5 years, I'd love to contribute to that growth."
```

### Ce qu'il ne faut pas faire en ouverture
- ❌ « Je vous écris pour postuler à... » (ennuyeux, évident)
- ❌ « Je suis le candidat idéal... » (laissez-les en juger)
- ❌ « J'ai vu votre offre d'emploi sur LinkedIn... » (générique)
- ❌ Commencer par « Je » (commencez par eux ou par une accroche)

## Structures des paragraphes de développement

### Paragraphe de développement 1 : Adéquation directe

Reliez votre expérience la plus forte à leur exigence principale.

**Formule :** [Leur besoin] + [Votre expérience exacte] + [Résultat précis]

```
Your focus on data-driven product decisions aligns perfectly with my approach. At [Company], I implemented a product analytics framework that increased feature adoption by 40% by identifying and prioritizing high-impact opportunities through A/B testing and user behavior analysis.
```

### Paragraphe de développement 2 : Valeur ajoutée élargie + Traitement des lacunes

Démontrez une valeur ajoutée supplémentaire et anticipez les réticences.

**Si vous avez des lacunes, abordez-les :**
```
While my SQL experience is developing (currently completing DataCamp's SQL track), I bring strong analytical skills demonstrated through building Tableau dashboards that informed $2M in strategic decisions. I've consistently collaborated effectively with data teams and have a track record of quickly ramping on new tools.
```

**Si vous n'avez pas de lacunes, apportez davantage de valeur :**
```
Beyond product management, I bring [relevant additional skill]. At [Company], this enabled me to [specific achievement]. I'm particularly drawn to [Company] because [specific reason showing research].
```

## Paragraphe de conclusion

Terminez avec assurance et un appel à l'action clair.

**Exemple de conclusion solide :**
```
I'm excited about the opportunity to bring my [specific skill] experience to [Company]'s [specific initiative or product]. I'd welcome the chance to discuss how my background in [key area] could contribute to your team's goals. Thank you for considering my application.
```

**Éléments d'une bonne conclusion :**
- Exprimer un enthousiasme sincère (pour un aspect précis)
- Mentionner une contribution concrète que vous apporteriez
- Formuler un appel à l'action clair (échanger, se rencontrer, etc.)
- Remercier le destinataire

**Ce qu'il ne faut pas faire en conclusion :**
- ❌ « Dans l'attente de votre retour » (trop passif)
- ❌ « Veuillez trouver ci-joint mon CV » (évident)
- ❌ « Je suis disponible pour un entretien à votre convenance » (donne une impression de désespoir)

## Modèle complet de lettre de motivation

```
[Your Name]
[Your Email] | [Your Phone] | [LinkedIn URL]
[City, State]

[Date]

[Hiring Manager Name, if known]
[Title]
[Company Name]
[Company Address]

Dear [Mr./Ms. Last Name / Hiring Manager],

[OPENING HOOK - 1-2 sentences grabbing attention with company knowledge, mutual connection, or impressive achievement]

[BRIDGE TO POSITION - 1 sentence stating the role and your interest]

[BODY 1 - 3-4 sentences connecting your strongest relevant experience to their primary requirement. Include specific metrics and results.]

[BODY 2 - 3-4 sentences adding additional value, addressing any gaps if needed, and demonstrating company research/culture fit]

[CLOSING - 2-3 sentences expressing enthusiasm, suggesting next steps, and thanking them]

Sincerely,
[Your Name]
```

## Spécificités par secteur d'activité

### Tech / Ingénierie
- Citer des technologies précises
- Faire référence à GitHub, à un portfolio ou à des projets techniques
- Montrer que vous comprenez leur stack technique

### Marketing / Création
- Faire preuve de créativité dans la lettre elle-même (dans une juste mesure)
- Faire référence à leurs campagnes ou à la tonalité de leur marque
- Inclure des métriques pertinentes (engagement, conversion, etc.)

### Finance / Conseil
- Adopter un ton plus formel
- Mettre en avant les diplômes et certifications en premier
- Souligner la rigueur analytique et les résultats

### Startup vs Grande entreprise
**Startup :** Plus informel, démontrer de la débrouillardise, mettre l'accent sur l'esprit de croissance
**Grande entreprise :** Plus formel, mettre l'accent sur la maîtrise des processus et l'expérience du travail à grande échelle

## Gestion des situations courantes

### Quand vous ne connaissez pas le responsable du recrutement
```
Dear Hiring Manager,
OR
Dear [Department] Team,
OR
Dear [Company Name] Recruiting Team,
```
Évitez « À l'attention de la personne concernée » ou « Madame, Monsieur » sans contexte (trop impersonnel).

### Quand vous bénéficiez d'une recommandation
Mettez-la en avant dès le début :
```
"[Name] on your [team] team suggested I reach out about the [Position] role. Having [connection to referrer], I was excited to learn about [Company]'s work in [area]."
```

### Quand vous êtes sous-qualifié
Ne vous excusez pas. Mettez plutôt l'accent sur :
- Les compétences transférables
- La rapidité d'apprentissage
- Un enthousiasme sincère
- Une expérience connexe qui compense

### Quand vous êtes surqualifié
Expliquez vos motivations :
```
"After 10 years leading large teams, I'm energized by the opportunity to return to hands-on [function] work at a company where I can make direct impact on [specific area]."
```

### Pour aborder une reconversion professionnelle
```
"While my background is in [Previous Field], I've been actively building [New Field] skills through [courses, projects, etc.]. My experience in [transferable skill] translates directly to [new role] through [specific connection]."
```

## Format de sortie

Lors de la génération d'une lettre de motivation, fournissez :

```markdown
# COVER LETTER FOR [POSITION] AT [COMPANY]

## Analysis Summary
- Match Score: [From JD Analyzer]
- Key Strengths to Highlight: [List]
- Gaps to Address: [List or "None"]
- Company Research Notes: [Key facts to reference]

## Generated Cover Letter

[Full cover letter text]

---

## Alternative Openings

**Option 1 (Company Knowledge):**
[Alternative opening hook]

**Option 2 (Achievement-Led):**
[Alternative opening hook]

## Key Talking Points for Interview
- [Point 1 from the letter to expand on]
- [Point 2]
- [Point 3]
```

## Liste de contrôle qualité

Avant de livrer toute lettre de motivation :

1. ✅ Commence par une accroche (pas par « Je vous écris pour postuler »)
2. ✅ Mentionne des connaissances précises sur l'entreprise
3. ✅ Relie directement l'expérience aux exigences du poste
4. ✅ Inclut au moins une métrique ou un résultat chiffré précis
5. ✅ Aborde les lacunes évidentes (le cas échéant)
6. ✅ Adopte un ton confiant sans être arrogant
7. ✅ Se termine par un appel à l'action clair
8. ✅ Fait entre 250 et 400 mots (3 à 4 paragraphes)
9. ✅ Ne contient aucune faute d'orthographe ou de grammaire
10. ✅ Donne envie de recevoir cette personne en entretien
