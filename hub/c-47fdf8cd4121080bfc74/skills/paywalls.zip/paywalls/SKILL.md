---
name: paywalls
description: Quand l'utilisateur souhaite créer ou optimiser des paywalls in-app, des écrans de mise à niveau (upgrade screens), des modales d'upsell ou des feature gates. À utiliser également lorsque l'utilisateur mentionne « paywall », « upgrade screen », « upgrade modal », « upsell », « feature gate », « convert free to paid », « freemium conversion », « trial expiration screen », « limit reached screen », « plan upgrade prompt », « in-app pricing », « free users won't upgrade », « trial to paid conversion » ou « how do I get users to pay ». Utilisez ceci pour tout moment au sein du produit où vous demandez aux utilisateurs de passer à un forfait supérieur. Distinct des pages de tarification publiques (voir cro) — ceci se concentre sur les moments d'upgrade in-product où l'utilisateur a déjà expérimenté de la valeur. Pour les décisions tarifaires, voir pricing.
metadata:
  version: 2.0.0
---

# CRO des paywalls et écrans d'upgrade

Vous êtes un expert des paywalls in-app et des parcours d'upgrade. Votre objectif est de convertir les utilisateurs gratuits en clients payants, ou de faire passer les utilisateurs à des forfaits supérieurs, aux moments précis où ils ont perçu suffisamment de valeur pour justifier cet engagement.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui ne sont pas déjà couvertes ou qui sont spécifiques à cette tâche.

Avant de formuler des recommandations, comprenez :

1. **Contexte d'upgrade** - Freemium → Payant ? Essai (trial) → Payant ? Montée en gamme de forfait ? Vente incitative de fonctionnalité (feature upsell) ? Limite d'utilisation ?

2. **Modèle de produit** - Qu'est-ce qui est gratuit ? Qu'est-ce qui est derrière le paywall ? Quels sont les déclencheurs des incitations ? Quel est le taux de conversion actuel ?

3. **Parcours utilisateur** - Quand cela apparaît-il ? Qu'ont-ils expérimenté ? Que tentent-ils de faire ?

---

## Principes fondamentaux

### 1. La valeur avant la demande
- L'utilisateur doit d'abord avoir expérimenté une réelle valeur
- L'upgrade doit sembler être la suite logique
- Timing : Après le « moment aha », pas avant

### 2. Montrez au lieu de simplement décrire
- Démontrez la valeur des fonctionnalités payantes
- Donnez un aperçu de ce qu'ils manquent
- Rendez l'upgrade tangible

### 3. Un parcours sans friction
- Facile de passer à la version payante dès qu'ils sont prêts
- Ne les forcez pas à chercher la tarification

### 4. Respectez le refus
- Ne tendez pas de piège et ne mettez pas la pression
- Permettez de continuer facilement en version gratuite
- Préservez la confiance pour une conversion future

---

## Points de déclenchement du paywall

### Feature Gates (blocages de fonctionnalités)
Lorsque l'utilisateur clique sur une fonctionnalité exclusivement payante :
- Explication claire des raisons pour lesquelles elle est payante
- Montrez ce que fait la fonctionnalité
- Chemin rapide pour débloquer
- Option pour continuer sans

### Limites d'utilisation
Lorsque l'utilisateur atteint une limite :
- Indication claire que la limite est atteinte
- Montrez ce qu'apporte la mise à niveau
- Ne bloquez pas brutalement

### Expiration de la période d'essai
Lorsque la période d'essai se termine :
- Alertes anticipées (7, 3, 1 jour)
- Précision claire sur « ce qui se passe » à l'expiration
- Récapitulez la valeur reçue

### Relances basées sur le temps
Après X jours d'utilisation gratuite :
- Rappel doux pour passer à la version supérieure
- Mettez en avant les fonctionnalités payantes non utilisées
- Facile à fermer/ignorer

---

## Composants d'un écran de paywall

1. **Titre (Headline)** - Concentrez-vous sur ce qu'ils obtiennent : « Débloquez [Fonctionnalité] pour [Bénéfice] »

2. **Démonstration de valeur** - Aperçu, avant/après, « Avec Pro, vous pourriez... »

3. **Comparaison des fonctionnalités** - Mettez en évidence les différences clés, plan actuel identifié

4. **Tarification** - Claire, simple, options annuelle vs mensuelle

5. **Preuve sociale** - Citations de clients, « X équipes utilisent cet outil »

6. **CTA** - Spécifique et orienté valeur : « Commencez à obtenir [Bénéfice] »

7. **Porte de sortie** - Un « Pas maintenant » ou « Continuer avec l'offre gratuite » bien visible

---

## Types de paywalls spécifiques

### Feature Lock Paywall
```
[Lock Icon]
This feature is available on Pro

[Feature preview/screenshot]

[Feature name] helps you [benefit]:
• [Capability]
• [Capability]

[Upgrade to Pro - $X/mo]
[Maybe Later]
```

### Usage Limit Paywall
```
You've reached your free limit

[Progress bar at 100%]

Free: 3 projects | Pro: Unlimited

[Upgrade to Pro]  [Delete a project]
```

### Trial Expiration Paywall
```
Your trial ends in 3 days

What you'll lose:
• [Feature used]
• [Data created]

What you've accomplished:
• Created X projects

[Continue with Pro]
[Remind me later]  [Downgrade]
```

---

## Timing et fréquence

### Quand l'afficher
- Après un moment de valeur, avant la frustration
- Après l'activation / le moment aha
- Lorsque de véritables limites sont atteintes

### Quand NE PAS l'afficher
- Pendant l'onboarding (trop tôt)
- Lorsqu'ils sont en plein flux de travail (flow)
- De manière répétée après fermeture

### Règles de fréquence
- Limite par session
- Période de temporisation (cool-down) après fermeture (en jours, pas en heures)
- Suivre les signaux d'agacement

---

## Optimisation du flux d'upgrade

### Du paywall au paiement
- Réduire au minimum les étapes
- Garder dans le contexte applicatif si possible
- Pré-remplir les informations déjà connues

### Après l'upgrade
- Accès immédiat aux fonctionnalités
- Confirmation et reçu
- Guide vers les nouvelles fonctionnalités

---

## A/B Testing

### Que tester
- Timing de déclenchement
- Variations de titres / de copywriting
- Présentation des prix
- Durée de la période d'essai
- Mise en avant des fonctionnalités
- Design / mise en page

### Métriques à suivre
- Taux d'impression du paywall
- Taux de clics vers l'upgrade
- Taux de finalisation
- Revenu par utilisateur (ARPU)
- Taux d'attrition (churn) après l'upgrade

**Pour des idées complètes d'expérimentations** : Voir [references/experiments.md](references/experiments.md)

---

## Anti-patterns à éviter

### Dark patterns
- Masquer le bouton de fermeture
- Sélection de forfait déroutante ou ambiguë
- Copywriting culpabilisant

### Tueurs de conversion
- Demander avant d'avoir délivré de la valeur
- Sollicitations trop fréquentes
- Bloquer des parcours critiques
- Processus d'upgrade complexe

---

## Questions spécifiques à la tâche

1. Quel est votre taux de conversion actuel gratuit → payant ?
2. Quels événements déclenchent aujourd'hui les incitations à l'upgrade ?
3. Quelles fonctionnalités se trouvent derrière le paywall ?
4. Quel est votre « moment aha » pour les utilisateurs ?
5. Quel est votre modèle de tarification ? (par utilisateur/siège, à l'usage, forfait fixe)
6. Application mobile, application web, ou les deux ?

---

## Compétences associées

- **churn-prevention** : Pour les flux d'annulation, les offres de rétention et la réduction du churn post-upgrade
- **cro** : Pour l'optimisation des pages de tarification publiques
- **onboarding** : Pour amener au moment aha avant l'upgrade
- **ab-testing** : Pour tester des variations de paywalls
