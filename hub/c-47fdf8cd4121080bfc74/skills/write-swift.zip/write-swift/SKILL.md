---
name: write-swift
description: Comment bien écrire du Swift moderne — modélisation avec les types valeur, sécurité contre les courses de données de Swift 6 et concurrence abordable (@concurrent, main-actor par défaut, acteurs, groupes de tâches), protocoles et génériques (some vs any), conception d'API, performances et ARC, Swift Testing, macros, ainsi que les fonctionnalités modernes du langage que les agents ne connaissent pas encore. À utiliser lors de l'écriture, de la revue ou de la migration de code Swift, ou lorsqu'il faut corriger une erreur de concurrence, un blocage, une course de données, un cycle de rétention ou un problème de performance.
---

# Écrire du Swift

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question précise, réponds uniquement :

> Je suis prêt à vous aider à écrire du Swift moderne, tel que le langage a été conçu pour être écrit.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Comment écrire du Swift tel que le langage demande à être écrit, à jour jusqu'à Swift 6.4.

**Version de référence de la chaîne d'outils : Swift 6.3** (version actuelle en août 2026). Tout ce qui figure ici compile sous 6.3, sauf mention ⚠ qui signale les fonctionnalités non publiées de Swift 6.4. Les directives sur la concurrence reposent sur le modèle de Swift 6.2 — si le projet utilise 6.1 ou une version antérieure, les règles du §3 concernant `async` et `@concurrent` ne s'appliquent pas.

Le fil conducteur : **Swift est un langage à divulgation progressive (*progressive disclosure*). Commencez par ce qu'il y a de plus simple, de plus statique et de plus monothread qui fonctionne, et n'adoptez le dynamisme — concurrence, sémantique de référence, existentiels, pointeurs non sécurisés — que lorsque vous pouvez en justifier la raison.** Chaque règle ci-dessous en est une application.

Suivez cette hiérarchie de choix par défaut. Ne descendez d'un niveau que si vous pouvez en énoncer la raison :

| Besoin       | Privilégier             | Descendre d'un niveau uniquement quand                     |
| ------------ | ----------------------- | ---------------------------------------------------------- |
| Données      | `struct` / `enum`       | vous avez besoin d'identité, de partage ou d'héritage      |
| Abstraction  | type concret            | vous avez du code dupliqué entre plusieurs types           |
| Polymorphisme| `some P` (générique)    | vous avez besoin d'un stockage hétérogène → `any P`        |
| Exécution    | main actor, synchrone   | le profilage révèle un blocage → `async` → `@concurrent` → `actor` |
| Mémoire      | `Array`, `String`       | le profilage en montre le coût → `InlineArray`, `Span`     |
| Sécurité     | API sécurisée           | interopérabilité C ou chemin critique mesuré → `Unsafe*`   |

---

## 1. Modéliser les données avec des types valeur

Les types valeur constituent le choix par défaut en Swift, et non une exception.

- **Par défaut, utilisez `struct` et `enum`. N'utilisez `class` que pour l'identité, l'état mutable partagé, l'héritage ou la gestion de la durée de vie d'une ressource.** Une fenêtre, une connexion à une base de données, une entité stockée dans un moteur de rendu — tout cela possède une identité. Un `Point`, un `Drink`, un `Material` n'en possèdent pas.
- **`let` par défaut ; `var` uniquement lorsque vous mutez.** C'est la même discipline que `some` avant `any` et la valeur avant la référence : commencez étroit, élargissez avec justification.
- **Une structure contenant une propriété mutable de type référence n'est ni une valeur ni une référence.** Les copies partagent l'objet ; les mutations fuient d'une copie à l'autre. Soit vous conservez le type référencé immuable, soit vous n'exposez que des propriétés calculées qui relaient vers lui, soit vous en faites une propriété stockée `private` protégée par une copie sur écriture (*copy-on-write*).
- **Le copy-on-write est la façon d'obtenir à la fois un stockage hors ligne (*out-of-line*) _et_ une sémantique de valeur.** Enveloppez une classe `final` dans une structure et vérifiez `isKnownUniquelyReferenced(&storage)` avant de muter ; copiez au préalable si la référence n'est pas unique. C'est exactement ainsi que fonctionnent `Array`, `String` et `Dictionary`.
- **Les enums sont l'outil idéal pour « un ensemble fixe d'éléments » et pour les états mutuellement exclusifs.** Remplacer un amas de propriétés stockées optionnelles (`isSharing`, `selectedRows`, `shareTarget`) par un unique `enum State` rend les combinaisons invalides impossibles à représenter et rend le changement d'état atomique au lieu d'une suite d'écritures de propriétés que l'on risquerait d'oublier de terminer.
- **Composer des valeurs produit une valeur.** Une structure dont toutes les propriétés stockées sont des types valeur bénéficie gratuitement d'une sémantique de valeur — ce qui permet à l'annulation (*undo*), au calcul de différences (*diffing*) et à la restauration d'état de reposer sur un unique chemin de code au lieu d'un par propriété.

```swift
struct Material {                       // sémantique de valeur préservée
  var roughness: Double
  private var _texture: Texture         // une classe

  var color: Color {
    get { _texture.color }
    set {
      if !isKnownUniquelyReferenced(&_texture) { _texture = Texture(copying: _texture) }
      _texture.color = newValue
    }
  }
}
```

**Les types non copiables** (`~Copyable`) expriment une propriété unique : un descripteur de fichier, un virement bancaire, une ressource ouverte. Supprimer la copie transforme l'exigence « vous ne devez pas exécuter ceci deux fois » d'une simple assertion en une erreur de compilation, et donne un sens à `deinit` sur une structure. Marquez la méthode finale par `consuming` afin que le compilateur prouve qu'il s'agit de la dernière utilisation. La propriété des paramètres devient explicite : `borrowing` (lecture seule, valeur par défaut), `consuming` (prend possession), `inout`/`mutating` (accès en écriture temporaire).

---

## 2. Erreurs et optionnels — rendre les chemins d'échec visibles

La gestion des erreurs en Swift repose sur trois principes : les sources d'erreur sont signalées pour ne pas surprendre ; les erreurs fournissent suffisamment de contexte pour agir ; et **les erreurs récupérables sont différentes des erreurs du programmeur**.

- **Récupérable → `throw`. Erreur de programmation → `precondition`/`fatalError`.** Un appel réseau qui échoue laisse le programme tourner. Un indice hors limites signifie que le code est incorrect et doit s'interrompre avant que le bug ne devienne un problème de sécurité.
- **Les énumérations avec valeurs associées constituent les meilleurs types d'erreurs.** `case duplicateFriend(String)` est bien supérieur à `case duplicateFriend` — le contexte fait tout l'intérêt.
- **`guard` pour les conditions d'erreur**, car il impose un chemin de sortie. `if let` pour le déballage ordinaire.
- **Les lancers typés (`throws(MyError)`) sont réservés aux fonctions internes, au code générique relayant des erreurs et aux environnements contraints** où encapsuler un `any Error` coûte trop cher. Pour une API publique, le `throws` non typé préserve votre liberté de changer le type d'erreur plus tard. Remarquez l'unification : `throws` équivaut à `throws(any Error)`, et ne rien lancer équivaut à `throws(Never)` — ce qui permet à `map` d'abstraire les deux cas.
- **Ne forcez le déballage (`!`) que là où vous pouvez énoncer l'invariant**, et préférez un `#require`/`precondition` explicite avec message à un simple `!`.

---

## 3. Concurrence : rester en monothread jusqu'à ce que le profilage dise le contraire

C'est la section sur laquelle les agents se trompent le plus souvent, car le modèle a changé dans Swift 6.2.

Commencez chaque application entièrement sur le thread principal. Le code monothread va très loin, et la plupart des applications n'ont jamais besoin de le quitter.

**La progression, dans l'ordre. Ne sautez pas d'étapes.**

1. **Monothread sur le main actor.** Aucune concurrence. Parfait pour la majorité des applications.
2. **`async`/`await`** pour masquer la latence (réseau, disque). Toujours pas de concurrence de votre côté — les API du SDK comme `URLSession.data(from:)` s'en chargent pour vous en arrière-plan.
3. **`@concurrent`** pour déporter _votre_ travail lourd hors du thread principal — uniquement après qu'Instruments a mis en évidence un blocage (*hang*).
4. **`actor`** pour déplacer l'_état_ hors du main actor — uniquement lorsque trop d'état sur le main actor force les tâches à faire constamment des allers-retours (*hop*).

**Activez d'abord les bons réglages de compilation.** Activez **Approachable Concurrency** dans chaque projet. Pour les modules de l'application et ceux orientés interface utilisateur, définissez également **Default Actor Isolation** sur **MainActor** — c'est le réglage par défaut des nouveaux projets d'applications dans Xcode 26, et cela supprime la majorité de vos annotations `@MainActor`. Dans un paquet : `swiftSettings: [.defaultIsolation(MainActor.self)]`. **Ne configurez pas main-actor par défaut pour une bibliothèque d'usage général** — les bibliothèques doivent fournir des API `nonisolated` et laisser les appelants décider où s'exécute le travail.

### La règle qui a changé

**Dans Swift 6.2, marquer une fonction `async` ne la retire _pas_ de l'acteur courant.** Elle s'exécute là d'où elle a été appelée. C'est ce qui rend « le code le plus naturel à écrire » exempt de courses de données par défaut.

- **`@concurrent`** — bascule systématiquement vers le pool de threads concurrents. Utilisez-le sur _votre_ code consommateur de CPU.
- **`nonisolated`** — s'exécute là d'où il est appelé. **C'est le bon choix par défaut pour les API de bibliothèque**, car c'est l'appelant qui décide. Placer `nonisolated` sur un type rend tous ses membres non isolés (Swift 6.1+).
- Ni l'un ni l'autre — reste sur l'acteur de l'appelant.

```swift
nonisolated struct PhotoProcessor {          // découplé du main actor
  @concurrent                                // garanti de tourner en arrière-plan
  func process(_ data: Data) async -> ProcessedPhoto {
    async let sticker = extractSticker(data)  // deux tâches indépendantes, en parallèle
    async let colors  = extractColors(data)
    return await ProcessedPhoto(sticker: sticker, colors: colors)
  }
}
```

- **Profilez avant de déporter.** Utilisez Instruments (Time Profiler, hangs). Si le code peut être accéléré sans concurrence, faites-le toujours en premier. La concurrence a un coût réel — allocation de tâches, ordonnancement et complexité de raisonnement.
- **Ne créez pas une tâche pour une opération triviale.** Une tâche enfant pour lire une valeur dans `UserDefaults` coûte plus cher qu'elle ne rapporte.
- **Une tâche par opération de bout en bout.** Le travail qui doit se dérouler dans l'ordre va dans _une seule_ tâche ; les opérations indépendantes reçoivent des tâches distinctes pour que le runtime puisse les entrelacer.
- **`await` est un point de suspension, et il brise l'atomicité.** L'état peut changer pendant que vous êtes suspendu, et vous pouvez reprendre sur un thread différent. Revérifiez vos hypothèses après chaque `await`. Ne conservez jamais un verrou à travers un `await`. Ne vous fiez jamais au stockage local au thread (*thread-local storage*) à travers un `await`.

### Réentrance des acteurs

Les acteurs garantissent l'exclusion mutuelle, pas les transactions. Entre deux `await` sur le même acteur, d'autres travaux s'exécutent.

- **Mutez l'état d'un acteur dans des méthodes synchrones.** Le code synchrone sur un acteur s'exécute jusqu'au bout sans interruption — c'est votre frontière transactionnelle.
- **Gardez les méthodes asynchrones d'un acteur concises**, composées d'opérations transactionnelles synchrones, et laissez l'acteur dans un état cohérent à chaque `await`.
- Le bug classique : vérifier le cache → `await` téléchargement → écrire dans le cache. Deux tâches manquent le cache, téléchargent toutes les deux, et la seconde écrase la première. Revérifiez après le `await`, ou dédupliquez le travail en cours.
- **Les acteurs ne sont pas FIFO.** Ils exécutent le travail de plus haute priorité en premier, précisément pour éviter l'inversion de priorité. Si vous avez besoin d'un ordre strict, utilisez une tâche (qui s'exécute du début à la fin) ou un `AsyncStream`, pas un acteur.

---

## 4. Sendable et partage de données

`Sendable` marque un type comme sûr à partager entre domaines d'isolation. Le compilateur le vérifie à chaque frontière de tâche et d'acteur.

- **Les types valeur sont `Sendable` dès lors que leur stockage l'est** — inféré automatiquement pour les types non publics. **Les types publics ne bénéficient jamais de l'inférence de sendabilité** : marquer un type public `Sendable` est un engagement envers vos clients, donc Swift vous oblige à l'écrire explicitement.
- **Les acteurs et les classes `@MainActor` sont implicitement `Sendable`**, car leur état est isolé.
- **La plupart des classes de modèle ne devraient être ni `@MainActor` ni `Sendable`.** Laissez-les non-`Sendable` à dessein — cela empêche que la moitié du modèle soit mutée sur le thread principal pendant que l'autre moitié l'est en arrière-plan. Si elles doivent quitter le main actor, rendez-les `nonisolated`, pas `Sendable`.
- **Vous pouvez toujours _envoyer_ un objet non-`Sendable` d'un domaine à un autre** à condition que l'expéditeur cesse de l'utiliser. Effectuez toutes vos mutations _avant_ de le transmettre ; y toucher après coup constitue une erreur.
- Les fermetures (*closures*) capturent également de l'état. Ne marquez un type de fonction par `@Sendable` que s'il traverse réellement des frontières de domaine.
- **`@unchecked Sendable` est une promesse que le compilateur ne peut pas vérifier.** Réservez-le aux types dotés d'une véritable synchronisation interne (un `Mutex`, un verrou). Même règle pour `nonisolated(unsafe)` sur une variable globale — un dernier recours, pas un moyen de masquer les avertissements.

**Lorsque vous rencontrez une erreur de course de données, suivez cette liste :**

1. **Ne le partagez pas.** Déplacez l'objet partagé dans une variable locale pour que chaque tâche concurrente reçoive sa propre instance. (C'est la solution pour l'écrasante majorité des erreurs réelles.)
2. **Transformez-le en type valeur `Sendable`**, de sorte que « partager » revienne en réalité à copier.
3. **Isolez-le sur un acteur** — le main actor, ou votre propre acteur.
4. Seulement ensuite, faites appel à `Mutex`/`Atomic` du module `Synchronization` (stockez-les dans des propriétés `let`), ou à `@unchecked Sendable`.

**Les variables globales et statiques constituent la source d'erreurs la plus courante.** Par ordre de préférence : transformez-la en `let` ; placez-la sur `@MainActor` ; enveloppez-la dans un `Mutex` ; `nonisolated(unsafe)`. Notez qu'en Swift, les globales sont initialisées de manière paresseuse (*lazy*) _et_ atomique — contrairement au C.

**Faire le pont avec les anciennes API à rappels (*callbacks*) :** annotez les protocoles de délégués avec `@MainActor` si vous en avez le contrôle. Si ce n'est pas le cas, marquez la méthode `nonisolated` et utilisez `MainActor.assumeIsolated { }` — cela émet une assertion au lieu de basculer de thread, ce qui provoque un crash immédiat et explicite plutôt qu'une course silencieuse. `@preconcurrency` sur la conformité est le raccourci pour la même chose. Utilisez `@preconcurrency import` pour faire taire temporairement les avertissements de sendabilité d'un module qui n'a pas encore migré ; les avertissements réapparaîtront — à juste titre — dès qu'il aura migré.

---

## 5. Concurrence structurée

Préférez toujours les tâches structurées.

Les tâches structurées (`async let`, groupes de tâches) sont délimitées comme des variables locales : elles ne peuvent pas survivre au bloc, elles sont attendues automatiquement et héritent de l'annulation, de la priorité et des valeurs locales à la tâche à travers l'arborescence des tâches. Les tâches non structurées (`Task { }`, `Task.detached`) ne vous offrent rien de tout cela automatiquement.

- **`async let`** pour un nombre fixe et statiquement connu d'enfants concurrents.
- **`withTaskGroup`** lorsque le nombre est dynamique. Les groupes de tâches se conforment à `AsyncSequence` — itérez sur les résultats au fur et à mesure qu'ils arrivent. Utilisez **`withDiscardingTaskGroup`** lorsque les enfants ne renvoient rien : il libère immédiatement les ressources de chaque enfant et annule les autres dès la première erreur.
- **`Task { }`** uniquement lorsque la durée de vie du travail ne rentre pas dans une portée lexicale — réagir à un rappel de délégué, un tap sur un bouton, l'apparition d'une vue. Elle hérite de l'isolation d'acteur et de la priorité ; vous devez gérer l'annulation vous-même.
- **`Task.detached`** presque jamais. Elle n'hérite de rien — ni isolation, ni priorité, ni valeurs locales à la tâche. Si vous avez besoin d'une racine détachée, placez un groupe de tâches _à l'intérieur_ plutôt que de détacher de multiples tâches.

**L'annulation est coopérative.** Annuler positionne un indicateur ; cela n'arrête rien. Vérifiez `Task.isCancelled` ou `try Task.checkCancellation()` **avant d'entamer un travail coûteux**, ainsi que dans les fonctions d'aide synchrones. Pour le travail suspendu plutôt qu'en cours d'exécution (le `next()` d'une `AsyncSequence`), utilisez `withTaskCancellationHandler` — et rappelez-vous que le gestionnaire s'exécute immédiatement et de manière concurrente avec le corps, de sorte que l'état auquel il touche nécessite une vraie synchronisation (un atomique ou un verrou, pas un acteur — vous ne pouvez garantir l'ordonnancement sur un acteur).

**Bornez votre concurrence.** Ne lancez pas un enfant par élément sur une liste non bornée. Démarrez N enfants, puis ajoutez-en un nouveau chaque fois qu'un enfant se termine.

**Les valeurs locales à la tâche** (`@TaskLocal`) propagent du contexte — un identifiant de requête, une trace — le long de l'arborescence de tâches sans avoir à faire passer un paramètre dans chaque signature. Rendez-les optionnelles pour que les lectures sans liaison aient une valeur par défaut cohérente.

**Faire le pont avec les callbacks :** `withCheckedContinuation` / `withCheckedThrowingContinuation`. Le contrat est de **reprendre exactement une fois sur chaque chemin** — ne jamais reprendre bloque l'appelant indéfiniment ; reprendre deux fois constitue une erreur fatale. Pour les API de délégué qui se déclenchent plus tard, stockez la continuation et mettez-la à `nil` lors de la reprise. (Swift 6.4 — non publié — ajoute un type `Continuation` qui vérifie la reprise unique à la compilation.)

**`AsyncSequence` :** itérez avec `for await` / `for try await`. Adaptez une API existante basée sur des gestionnaires ou des délégués avec `AsyncStream` / `AsyncThrowingStream` — construisez la source dans la fermeture, appelez `yield` depuis le gestionnaire et nettoyez dans `onTermination`.

---

## 6. Concurrence dans SwiftUI

- **`View` est isolée sur `@MainActor`**, tout comme tout ce qu'elle contient, y compris vos `@State`. Vous n'avez presque jamais besoin d'écrire `@MainActor` sur une vue ou un view model — et avec main-actor par défaut, vous pouvez supprimer ceux existants.
- **SwiftUI exécute délibérément une partie de votre code hors du thread principal** pour préserver la fluidité des images (*frames*). L'indicateur est la présence de `@Sendable` dans la signature de l'API : `visualEffect`, `Shape.path(in:)`, exigences de `Layout`, `onGeometryChange`. Lorsque vous rencontrez une erreur d'isolation dans l'une de ces fermetures, **n'envoyez pas `self` — copiez la seule valeur dont vous avez besoin dans la liste de capture de la fermeture.**

```swift
.visualEffect { [pulse] effect, proxy in    // copie le Bool, ne capture pas self
  effect.blur(radius: pulse ? 2 : 0)
}
```

- **Les callbacks d'action de SwiftUI sont synchrones à dessein.** Les mises à jour d'interface sensibles au temps — déclencher une animation en réponse à un geste ou un événement de défilement — doivent avoir lieu sur la même frame que l'événement. Placez le changement d'état `withAnimation` dans le callback synchrone ; n'ouvrez une `Task` que pour le travail long qui suit.
- **Placez une portion d'état à la jonction entre l'interface et le travail asynchrone.** La vue déclenche une tâche ; la couche asynchrone effectue une mutation synchrone lorsqu'elle se termine ; l'interface réagit. Cela conserve la logique de vue synchrone et rend la logique asynchrone testable sans importer SwiftUI.

---

## 7. Protocoles et génériques

Ne commencez pas par une classe. **Ne commencez pas non plus par un protocole.**

La méthodologie : **écrire des types concrets → repérer le code répété entre eux → factoriser la capacité partagée dans un protocole → écrire du code générique reposant dessus.** Les surcharges aux corps quasi identiques sont le signe qu'il est temps de généraliser.

- **Un protocole sans personnalisation par type est un protocole inutile.** Si chaque conformité devait utiliser la même implémentation par défaut, écrivez plutôt une extension contrainte sur un protocole existant. Les hiérarchies de protocoles complexes (« zoologie des types ») coûtent du temps de compilation et de la taille de binaire sans rien apporter.
- **Préférez la composition à l'héritage (*has-a* plutôt que *is-a*).** Si seules certaines opérations d'un protocole ont du sens pour votre type, ne le raffinez pas — enveloppez-le dans une structure générique et exposez exactement l'API voulue (`GeometricVector<Storage: SIMD>` plutôt que `GeometricVector: SIMD`).
- **Une exigence de protocole est un point de personnalisation** — elle est répartie dynamiquement (*dynamically dispatched*), et l'implémentation du type conforme l'emporte partout. **Une méthode présente uniquement dans une extension est répartie statiquement**, de sorte que la version d'un type conforme la _masque_ (*shadows*) au lieu de la surcharger, et le code qui ne connaît que `any P` appelle celle de l'extension. Si un type doit pouvoir personnaliser quelque chose, faites-en une exigence.
- **La composition plutôt que l'héritage.** L'héritage de classes est monolithique (une seule superclasse), intrusif (vous héritez des propriétés stockées et de la complexité des initialiseurs) et laisse des contrats non écrits sur ce qui peut être surchargé et quand appeler `super`. Composez plutôt de petites valeurs.
- **Un transtypage forcé (*downcast*) est une mauvaise odeur de code (*code smell*)** — cela signifie généralement qu'une relation de type a été perdue au profit d'une hiérarchie de classes ou d'un existentiel.

### `some` vs `any`

- **Écrivez `some P` par défaut. Passez à `any P` lorsque vous avez besoin de stocker des types arbitraires.** C'est la même discipline que `let` avant `var`.
- `some P` — un type sous-jacent fixe par portée. Vous conservez chaque relation de type, y compris les types associés, et le compilateur peut spécialiser.
- `any P` — boîte avec effacement de type (*type-erased box*), le type dynamique varie à l'exécution. Nécessaire pour les collections hétérogènes, pour l'optionalité du type sous-jacent et pour masquer complètement l'abstraction. Vous en payez le prix : les relations de types associés sont effacées jusqu'à leurs bornes supérieures, et les appels sont opaques pour l'optimiseur.
- **Vous ne pouvez pas appeler une méthode qui prend un type associé sur un `any P`.** L'effacement fonctionne en position de production (le résultat est effacé jusqu'à sa borne supérieure), mais pas en position de consommation. La solution consiste à passer l'existentiel à une fonction prenant `some P` — le compilateur le déballe (*unboxes*), et à l'intérieur de cette portée, le type est à nouveau fixé.
- **Les existentiels contraints et les types opaques** — `some Collection<Element>`, `any Collection<any Animal>` — permettent de masquer `LazyFilterSequence<[Animal]>` tout en exposant le type d'élément. Déclarez des types associés primaires sur vos propres protocoles (`protocol Container<Item>`) pour le type que les appelants fournissent réellement, non pour des détails d'implémentation comme `Iterator`.
- **Les exigences de même type dans les clauses `where`** permettent de fixer les relations entre protocoles (`where Self.CropType.FeedType == Self`). Sans elles, enchaîner les opérations ne passe pas au typage, et des conformités erronées compilent.

---

## 8. Conception d'API — clarté sur le lieu d'utilisation

La clarté sur le lieu d'utilisation est l'objectif qui prime sur tous les autres ici.

- **Pas de préfixes de type dans les API purement Swift.** Les modules évitent les ambiguïtés. Ne conservez les préfixes que là où l'API fait écho à une API Objective-C. Évitez toutefois les noms très généraux issus de frameworks spécifiques — ils se lisent mal hors contexte et obligent à une désambiguïsation manuelle.
- **Supprimez le `get` initial** des alternatives asynchrones et de tout ce qui retourne directement son résultat. `persistentPosts`, pas `getPersistentPosts`.
- **Le contrôle d'accès sert de documentation.** `private` (fichier), `internal` (module, et valeur par défaut), `package`, `public`. Être explicite aux frontières est ce qui force les décisions de sendabilité et d'évolution d'API décrites plus haut.
- **Concevez le modèle pour que les états illégaux ne puissent pas être formulés.** Des modificateurs privés associés à une méthode de mutation validante ; des enums pour les ensembles fermés ; un `UUID` fortement typé plutôt qu'une `String`.
- **Les wrappers de propriétés (*property wrappers*)** factorisent une _politique d'accès_ (`@Argument`, `@Published`, copie défensive, paresseux, thread-local) pour que le lieu de déclaration énonce la politique en un seul mot. Combinez avec `@dynamicMemberLookup` sur un key path pour projeter à travers un wrapper (c'est ainsi que fonctionne `$binding.title`).
- **Les *result builders*** pour les DSL déclaratifs. **Les macros** lorsque le code répétitif (*boilerplate*) est du code que le compilateur aurait pu écrire (§12).

---

## 9. Performances — mesurer, puis choisir

Les performances de bas niveau en Swift sont dominées par quatre coûts. Sachez lequel vous payez.

1. **Les appels de fonction** — copies d'arguments, répartition statique vs dynamique, allocation du cadre d'appel (*call frame*) et optimisations bloquées.
2. **L'agencement mémoire** — stockage en ligne (*inline*) vs hors ligne (*out-of-line*) ; types à taille dynamique.
3. **L'allocation** — globale (gratuite), pile (très peu coûteuse : une soustraction), tas (coûteuse : recherche plus verrouillage).
4. **Les copies** — retains/releases et copies récursives de structures.

**Effectuez d'abord le travail algorithmique.** Chaque fois que vous écrivez une boucle, essayez de la remplacer par un appel à un algorithme. Les plus grands gains ne sont presque jamais des micro-optimisations :

- **Connaissez la complexité de ce que vous appelez.** `Array.remove(at:)` est en O(n) ; l'appeler dans une boucle est en O(n²). `removeAll(where:)` est en O(n) au total. Construire une `Data` en redécoupant octet par octet est en O(n²) ; `popFirst()` est en O(1). Ces deux cas étaient des régressions de plus de 100× masquées derrière du code d'apparence propre.
- **Les chaînages `map`/`flatMap`/`filter` allouent un tableau à chaque étape.** Élégant ≠ rapide. Si un pipeline s'exécute par pixel ou par élément dans une boucle critique, dimensionnez la sortie une seule fois et écrivez dedans.
- **Ensuite, profilez.** Utilisez Time Profiler et Allocations d'Instruments, exécutés sur un _test_ (clic secondaire sur le bouton d'exécution du test → Profile) afin de mesurer précisément le code qui vous intéresse. La présence dominante de `platform_memmove` dans un flame graph signale des copies accidentelles ; un million d'allocations éphémères trahit des tableaux intermédiaires ; `swift_beginAccess` indique des vérifications d'exclusivité à l'exécution ; `swift_retain`/`swift_release` révèle le trafic de comptage de références.

**Leviers concrets, par ordre approximatif de gain :**

- **`final` sur les classes que vous ne comptez pas dériver** rend la répartition statique et permet l'inlining. L'optimisation globale du module (*whole-module optimization*) permet au compilateur de le prouver à votre place dans de nombreux cas — et permet la spécialisation générique, moment où les génériques cessent de coûter quoi que ce soit.
- **Le stockage d'une structure est inline ; celui d'une classe est out-of-line.** Les petites structures sont gratuites ; une grande structure avec trois champs de type référence coûte trois retains _par copie_, contre un seul pour une classe. Si vous la copiez souvent, utilisez le copy-on-write.
- **Un existentiel `any P` dispose d'un tampon inline de 3 mots.** Les valeurs qui y rentrent y résident ; les plus grandes sont allouées sur le tas à chaque copie. La même technique s'applique : donnez au grand type un stockage indirect avec copy-on-write et il rentrera à nouveau dans le tampon.
- **Un tableau homogène `[MyModel]` surpasse `[any Model]`** — densément compacté, informations de type passées une seule fois, spécialisable. `[any Model]` est l'option flexible mais opaque ; choisissez-la quand vous en avez besoin.
- **Contraindre un paramètre générique à une classe** (`T: AnyObject`) donne au compilateur une représentation connue même sans spécialisation.
- **`InlineArray<N, T>`** (Swift 6.2) pour un stockage à taille fixe : éléments stockés inline, taille dans le type via les génériques de valeur, aucune allocation sur le tas, aucun comptage de références, aucune vérification d'unicité ou d'exclusivité. Mauvais choix s'il doit être copié ou partagé.
- **`Span` / `RawSpan` / `OutputSpan`** (Swift 6.2) remplacent `withUnsafeBufferPointer` pour un accès direct à un stockage contigu. Ils sont non échappables, de sorte que le compilateur lie leur durée de vie au conteneur — vous obtenez les performances d'un pointeur sans bugs de durée de vie, et les retains/releases disparaissent.
- **Déplacer des propriétés stockées d'une classe imbriquée vers la structure parente** supprime les vérifications d'exclusivité à l'exécution.
- Disponible dans Swift 6.3, lorsque la mesure en démontre le besoin : `@inline(always)` (à associer à `final` sur les méthodes) et `@specialized(where T == ...)` (SE-0460) pour pré-spécialiser un générique pour des types concrets critiques.
- Prévu pour Swift 6.4 (**non publié** — voir la note sous le §15) : accesseurs `borrow`/`mutate` au lieu de `get`/`set` pour les grandes valeurs stockées, `UniqueArray`/`UniqueBox`, et `Ref`/`MutableRef` pour extraire une recherche répétée hors d'une boucle.

**Les fonctions asynchrones** conservent leur état sur un allocateur slab par tâche plutôt que sur la pile C, et se divisent en fonctions partielles à chaque point de suspension. Leur profil de coût est similaire à celui des fonctions synchrones avec un surcoût d'appel légèrement supérieur — une raison de plus de ne pas rendre `async` une fonction qui n'a rien à attendre.

**Les allers-retours vers et depuis le main actor coûtent un véritable changement de contexte.** Traitez par lots (*batch*) : déplacez la boucle _dans_ `loadArticles`/`updateUI` pour qu'elles prennent des tableaux, plutôt que de changer de thread deux fois par itération.

---

## 10. ARC et durée de vie des objets

- **La durée de vie garantie d'un objet se termine à sa dernière utilisation, pas à l'accolade fermante.** Les durées de vie observées sont une propriété émergente de l'optimiseur et _vont_ changer. Un code qui dépend du moment où un `deinit` s'exécute est un bug latent.
- **`weak`/`unowned` servent uniquement à briser les cycles de référence — à rien d'autre.** Lire une référence `weak` après la dernière utilisation du propriétaire fort peut légitimement donner `nil`. Une liaison optionnelle y est _pire_ qu'un déballage forcé : elle transforme un crash explicite en un résultat erroné silencieux.
- **Mieux que `weak` : ne créez pas le cycle.** Factorisez les données partagées dans un troisième type auquel les deux côtés font référence, transformant ainsi le cycle en arbre.
- **Alternative suivante : reconcevez l'API** pour que l'objet ne soit accessible qu'au moyen d'une référence forte. `withExtendedLifetime` fonctionne mais fait reposer la correction sur vous et a tendance à se propager dans la base de code — traitez-le comme un correctif temporaire, pas comme une conception.
- **Gardez les effets secondaires de `deinit` locaux.** Publier des métriques ou déclencher un effet global depuis `deinit` s'ordonnance au gré des décisions de l'optimiseur. Utilisez plutôt `defer` sur le site d'appel, et réservez `deinit` aux vérifications.
- Le réglage de compilation Xcode **Optimize Object Lifetimes** raccourcit les durées de vie observées pour les rapprocher du minimum garanti, et mettra précisément ces bugs en évidence.

---

## 11. Tests — Swift Testing par défaut

Utilisez **Swift Testing** pour les nouveaux tests. XCTest ne reste requis que pour trois choses très précises : l'automatisation d'interface (`XCUIApplication`), les métriques de performance (`XCTMetric`) et les tests qui doivent être écrits en Objective-C ou qui interceptent des exceptions Objective-C.

- **`@Test` sur n'importe quelle fonction** — globale, statique ou d'instance ; `async`, `throws` et isolée sur un acteur global fonctionnent tous.
- **`#expect(...)` accepte des expressions ordinaires.** Aucune panoplie de fonctions du type `XCTAssertEqual` à mémoriser — `#expect(a == b)`, `#expect(list.isEmpty)`, `#expect(!x.contains(y))` capturent et affichent toutes les valeurs des sous-expressions en cas d'échec.
- **`try #require(...)`** pour interrompre le test en cas d'échec, et pour déballer un optionnel en toute sécurité. Cela remplace `continueAfterFailure = false` et vous permet de choisir pour chaque attente.
- **Les suites sont des `struct`s.** Une nouvelle instance est créée pour chaque fonction de test, afin que l'état ne puisse pas fuiter d'un test à l'autre. Utilisez `init` pour la préparation (*setup*) ; n'utilisez une `class`/un `actor` que lorsque vous avez besoin de `deinit` pour le nettoyage (*teardown*). Imbriquez les suites pour les regrouper.
- **Paramétrez au lieu de copier-coller ou de faire des boucles.** `@Test(arguments: [...])` exécute chaque cas de manière indépendante, en parallèle, rejouable individuellement, avec l'argument défaillant nommé dans les résultats. Deux collections d'arguments produisent le produit cartésien complet — utilisez `zip()` lorsque vous souhaitez plutôt des paires associées.
- **Les traits expriment l'intention :** `.enabled(if:)` / `.disabled("reason")` pour les conditions (ne commentez jamais un test — un test désactivé continue de compiler), `.bug(url)` pour le suivi, `.tags(...)` pour lier des tests entre différents fichiers et cibles, `.timeLimit`, `.serialized` lorsqu'un test ne peut véritablement pas s'exécuter en parallèle. Utilisez `@available` plutôt qu'une vérification à l'exécution `#available` pour que la bibliothèque de test en soit informée.
- **`withKnownIssue { }`** pour un test qui échoue à cause d'un élément hors de votre contrôle — il continue de compiler et de s'exécuter, et vous avertit lorsque le problème est résolu, contrairement à `.disabled`.
- **`confirmation`** pour les callbacks qui se déclenchent N fois ; `withCheckedContinuation` pour les callbacks uniques sans surcharge asynchrone.
- **Les tests s'exécutent en parallèle par défaut, dans un ordre aléatoire.** C'est un atout : cela met au jour les dépendances cachées entre tests. Refactorisez plutôt que de recourir à `.serialized`.
- **Les tests de sortie (*exit tests*)** — `#expect(processExitsWith: .failure) { ... }` — couvrent les chemins `precondition`/`fatalError` dans un processus enfant isolé. Sur macOS, Linux, FreeBSD, Windows uniquement.
- Migration : les deux frameworks coexistent dans une même cible, migrez donc progressivement et écrivez les nouveaux tests avec Swift Testing dès aujourd'hui. L'**interopérabilité des frameworks de test** (swift-testing ST-0021 ; vérifiez la disponibilité selon votre version de Xcode) permet aux fonctions d'aide qui encapsulent `XCTFail` d'être appelées depuis des tests Swift Testing et inversement ; définissez le mode sur **complete** ou **strict** (pas **limited**, et jamais **none**) afin que les problèmes inter-frameworks restent des erreurs et vous orientent vers le remplacement par `Issue.record`.

---

## 12. Macros

Ne recourez à une macro que lorsque vous écrivez du code que le compilateur pourrait déduire — et seulement dans ce cas.

- **Les macros sont vérifiées au niveau des types avant expansion.** Les arguments sont validés par rapport à la signature déclarée de la macro, de sorte qu'une mauvaise utilisation produit une erreur claire sur le site d'appel, et non un fouillis dans le code généré.
- **Autonomes (`#foo`)** : elles produisent une expression ou une déclaration. **Attachées (`@Foo`)** : elles enrichissent une déclaration selon l'un des cinq rôles : member, peer, accessor, member-attribute, conformance. Les rôles se composent — `@Observable` combine member + member-attribute + conformance.
- **Testez les macros comme de pures transformations d'arbres syntaxiques** avec `assertMacroExpansion`. C'est la boucle de rétroaction la plus rapide, et c'est ainsi que vous évitez les bugs dans un code que personne ne relit. Placez un point d'arrêt dans `expansion` et faites un `po` sur le nœud syntaxique pour comprendre sa structure.
- **Émettez de vrais diagnostics lorsque la macro ne s'applique pas.** Lancez une erreur, ou utilisez `context.addDiagnostic` pour afficher des avertissements et des corrections suggérées (*fix-its*) à un emplacement précis. Ne laissez jamais une macro générer silencieusement du code qui ne compilera pas.
- Le code déployé reste du Swift ordinaire : inspectable (« Expand Macro »), débogable, exécutable pas à pas.

---

## 13. Journalisation et débogage

- **`Logger` de `os`, pas `print`.** Créez-en un par sous-système et par catégorie. Les messages sont stockés sous forme optimisée et ne sont restitués que lors de l'affichage, de sorte que la journalisation est suffisamment économique pour être laissée en production.
- **Les interpolations non numériques sont masquées par défaut.** Activez la visibilité au cas par cas avec `privacy: .public` uniquement pour les données qui ne sont véritablement pas à caractère personnel. Utilisez `.private(mask: .hash)` lorsque vous devez corréler des valeurs sans les exposer.
- **Les niveaux contrôlent la persistance et le coût :** `debug` (jamais persisté, le plus rapide — la construction du message est entièrement éliminée par l'optimiseur hors flux en direct), `info`, `notice` (par défaut), `error`, `fault` (les plus persistants, les plus lents). Journalisez en `error`/`fault` pour les éléments indispensables dans un rapport de bug.
- **Journalisez un identifiant de corrélation** (un UUID de tâche ou de requête) et vous pourrez filtrer tout l'historique d'un échec dans une archive de journaux d'appareil sans avoir à le reproduire. `log collect --device --start ...`, puis filtrez par sous-système dans Console.
- `format:` et `align:` sont gratuits — utilisez-les pour que les journaux soient lisibles et alignés en colonnes.
- LLDB comprend les tâches Swift : il passe à travers `await` d'un thread à l'autre, `swift task info` affiche la priorité et les enfants, et les tâches nommées apparaissent aussi bien dans le débogueur que dans le modèle Swift Concurrency d'Instruments.

---

## 14. Code non sécurisé et interopérabilité

- **« Unsafe » signifie que l'API ne peut pas valider entièrement ses entrées, de sorte que violer ses préconditions engendre un comportement indéfini** — et non pas qu'elle plante. Les API sécurisées s'interrompent délibérément (*trap*) ; une erreur fatale propre est le comportement attendu d'un code sûr.
- **Préférez `Span` à `Unsafe*Pointer`.** Depuis Swift 6.2, il existe un moyen sûr, non échappable et tout aussi rapide d'accéder à un stockage contigu. Réservez les pointeurs bruts à l'interopérabilité avec le C.
- Si vous devez utiliser des pointeurs : gardez la région non sécurisée aussi réduite que possible, utilisez des pointeurs de type **buffer** (adresse + compte) plutôt que des pointeurs nus afin que les limites soient suivies, ne laissez jamais un pointeur s'échapper de la fermeture qui le fournit et activez **Address Sanitizer**.
- Activez la **sécurité mémoire stricte (*strict memory safety*)** dans les modules critiques pour la sécurité — cela oblige à expliciter dans le code source chaque utilisation non sécurisée, ce qui rend l'audit possible. L'attribut `@diagnose` de Swift 6.4 (non publié) vous permet de l'activer pour des fonctions individuelles.
- **L'interopérabilité est bidirectionnelle et progressive.** Les types C, Objective-C et C++ s'associent directement en Swift (y compris la sémantique de valeur C++, les conteneurs sous forme de collections Swift et les types à déplacement exclusif sous forme de `~Copyable`). L'attribut `@c` de Swift 6.3 expose les fonctions Swift en C (avec `@implementation` lorsque la déclaration existe déjà dans un en-tête). Adoptez Swift un fichier à la fois ; ne réécrivez pas tout d'un coup.

---

## 15. Syntaxe moderne à adopter

Les agents écrivent régulièrement l'ancienne forme, plus verbeuse, de chacune de ces syntaxes.

**Les lignes signalées par ⚠ concernent Swift 6.4, qui n'est pas encore disponible.** La version actuelle est la 6.3.x. Ces propositions sont acceptées et implémentées dans la branche principale (main) ; il est donc prudent de concevoir votre architecture en en tenant compte, mais imprudent de les employer aujourd'hui en production — vérifiez la chaîne d'outils du projet avant d'en utiliser une, et préférez l'ancienne syntaxe si le projet cible 6.3 ou une version antérieure.

| Au lieu de                                                            | Écrire                                                                                                   | Depuis |
| --------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- | ------ |
| Opérateurs ternaires imbriqués ; fermeture immédiatement appelée pour initialiser un `let` | **expressions** `if`/`switch`                                                                            | 5.9    |
| Surcharges pour 1, 2, 3… arguments                                    | **paquets de paramètres (*parameter packs*)** (`each T`), et `for` sur un paquet                         | 5.9    |
| `ObservableObject` + `@Published` sur chaque propriété                | **`@Observable`**                                                                                        | 5.9    |
| Scruter (*polling*) les changements d'un objet                        | **`Observations { ... }`** — une `AsyncSequence` de mises à jour transactionnelles                       | 6.2    |
| `NotificationCenter` avec un `userInfo` typé par des chaînes           | types de notifications concrets (`MainActorMessage` / `AsyncMessage`)                                    | 6.2    |
| `Process` + pipes pour les scripts                                    | le paquet **Subprocess** (`AsyncBufferSequence.strings()` pour une sortie ligne par ligne ; 1.0 sort avec 6.4) | 6.2+   |
| Calculs manuels d'indices de chaînes                                  | **Swift Regex** — littéraux pour la concision, `RegexBuilder` pour la structure                          | 5.7    |
| `[String]` de taille fixe dans un chemin critique                     | **`InlineArray<N, T>`**                                                                                  | 6.2    |
| `withUnsafeBufferPointer`                                             | **`.span`** / **`.bytes`** (`RawSpan`) / `OutputSpan`                                                    | 6.2    |
| Gestion manuelle de `Task.isCancelled` pour terminer une écriture     | **bouclier d'annulation (*cancellation shield*)** de `Task` (SE-0504)                                    | 6.4 ⚠  |
| Reconstruire un dictionnaire à la main pour utiliser la clé           | **`mapKeyedValues`**                                                                                     | 6.4 ⚠  |
| `@available(iOS ..., macOS ..., tvOS ..., watchOS ..., visionOS ...)` | **`@available(anyAppleOS ...)`**                                                                         | 6.4 ⚠  |
| `Rocket.SaturnV` lorsqu'un type masque un module                      | **sélecteur de module** `Rocket::SaturnV`                                                                | 6.3    |
| « Warnings as errors » global et indiscriminé                         | **`@diagnose`** par déclaration / groupe d'avertissements                                                | 6.4 ⚠  |
| `@unchecked Sendable` à cause d'un `weak var`                         | `weak let` ; ou déclarer la non-sendabilité avec **`~Sendable`**                                         | 6.4 ⚠  |
| Parser manuellement des formats binaires avec des pointeurs           | **Swift Binary Parsing** (`ParserSpan`, initialiseurs de parsing avec vérification de dépassement)       | 6.2    |
| Noms de fonctions de test maladroits                                  | **identifiants bruts (*raw identifiers*)** : `` @Test func `fruits have a tropical climate`() ``        | 6.0    |

Bon à savoir également : **les parseurs Swift Regex se composent avec les vrais parseurs de Foundation** (`.date(...)`, `.currency(...)`) — ne recréez jamais à la main un parseur de dates ou de nombres dans une regex. Rendez la locale explicite plutôt que d'hériter de celle du système. Et utilisez `NegativeLookahead` ou `Local` (groupes atomiques) pour empêcher un motif de revenir en arrière (*backtracking*) sur l'ensemble d'une entrée.

---

## 16. Migrer une base de code existante vers Swift 6

L'ordre compte, et mélanger les étapes est la meilleure façon de bloquer une migration.

1. **Compilez d'abord avec le nouveau compilateur.** La compatibilité des sources garantit que cela doit fonctionner directement, en mode Swift 5.
2. **Cible par cible, activez la vérification complète de concurrence** (mode Swift 5 + tous les avertissements Swift 6). Commencez par la **couche UI/application**, et non par les frameworks sous-jacents — une grande partie est déjà annotée pour le main actor par le SDK, le taux de résolution y est donc élevé.
3. **Corrigez les avertissements, en commençant par les plus simples.** Attendez-vous à des centaines d'avertissements découlant d'une poignée de causes racines : des globales `var` qui devraient être `let`, des fonctions libres qui relèvent de `@MainActor`, une structure publique qui nécessite `: Sendable`. Une seule ligne peut en résoudre des dizaines.
4. **Basculez la cible vers le mode de langage Swift 6** pour pérenniser le travail accompli.
5. **Passez à la cible suivante et répétez.**
6. **Refactorisez ensuite, séparément.** Ne combinez jamais un refactoring significatif avec l'activation de la sécurité contre les courses de données — vous seriez contraint d'annuler les deux.

Vous pouvez désactiver à nouveau la vérification stricte et livrer ; chaque correction apportée reste une amélioration réelle et pérenne. Activez **Approachable Concurrency** et, pour les modules applicatifs, main-actor par défaut _avant_ de commencer — les deux réduisent considérablement le volume d'erreurs que vous rencontrerez, et Xcode fournit des outils de migration qui appliquent une grande partie des changements automatiquement (swift.org/migration).

---

## Aide-mémoire rapide

| Besoin                             | Privilégier                     | Éviter                                    |
| ---------------------------------- | ------------------------------- | ----------------------------------------- |
| Un type de données                 | `struct` / `enum`               | `class` sans identité ni partage          |
| État mutable partagé               | `actor`, ou classe `@MainActor` | `class` + un verrou qu'il faut penser à poser |
| Déporter du travail hors du main thread | `@concurrent func … async` | `Task.detached`, `DispatchQueue.global()` |
| Isolation d'une API de bibliothèque | `nonisolated`                  | `@MainActor`, `@concurrent`               |
| Nombre fixe de tâches parallèles   | `async let`                     | N `Task`s non structurées                 |
| Nombre dynamique de tâches parallèles | `withTaskGroup` (borné)      | une tâche par élément, non bornée         |
| Enfants qui ne renvoient rien      | `withDiscardingTaskGroup`       | `withTaskGroup` que l'on ne vide jamais   |
| Travail lié à un événement d'interface | `Task { }` dans le callback | rendre le callback `async`                |
| Corriger une course de données     | cesser de partager l'objet      | `@unchecked Sendable`                     |
| Une classe de modèle partagée      | non-`Sendable`, ou `@MainActor` | `Sendable` + verrouillage manuel          |
| Primitive bloquante à travers `await` | rien — restructurer           | `DispatchSemaphore`, `NSCondition`        |
| Polymorphisme                      | `some P`                        | `any P` sauf besoin réel de stockage      |
| Collection hétérogène              | `[any P]`                       | une hiérarchie de classes                 |
| Comportement partagé, sans personnalisation | `extension` contrainte | un nouveau protocole                      |
| Un point de personnalisation       | **exigence** de protocole       | une méthode présente seulement dans une extension |
| Briser un cycle de référence       | restructurer en arbre           | `weak` + `withExtendedLifetime`           |
| Supprimer des éléments correspondants | `removeAll(where:)` — O(n)   | `remove(at:)` dans une boucle — O(n²)     |
| Accès direct à la mémoire contiguë | `.span`                         | `withUnsafeBufferPointer`                 |
| Tampon de taille fixe en chemin critique | `InlineArray<N, T>`       | `Array`                                   |
| Un nouveau test                    | `@Test` + `#expect`             | `XCTestCase` + `XCTAssertEqual`           |
| Le même test sur de nombreuses entrées | `@Test(arguments:)`         | une boucle `for`, ou du copier-coller     |
| Interrompre un test sur échec      | `try #require`                  | `continueAfterFailure = false`            |
| Un test temporairement défaillant  | `withKnownIssue`                | `.disabled`, ou le commenter              |
| Diagnostics en production          | `Logger` + un identifiant de corrélation | `print`                          |
| Décider d'optimiser                | Instruments sur un test profilé | l'intuition                               |
