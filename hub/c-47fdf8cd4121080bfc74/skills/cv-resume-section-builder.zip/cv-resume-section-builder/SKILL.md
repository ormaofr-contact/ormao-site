---
name: resume-section-builder
description: Créer des sections de CV ciblées et optimisées pour différents niveaux d'expérience et postes
---

# Créateur de sections de CV

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A besoin d'aide pour des sections spécifiques de son CV
- Souhaite optimiser une partie précise de son CV
- N'est pas certain de ce qu'il faut inclure dans une section
- A besoin de conseils ciblés par section
- Mentionne : "sections de CV", "section compétences", "section résumé", "section expérience", "que mettre dans"

## Fonctionnalités principales

- Rédiger des résumés professionnels ciblés
- Structurer efficacement les sections de compétences
- Optimiser les sections d'expérience
- Concevoir la section formation de manière appropriée
- Ajouter des sections complémentaires de manière stratégique
- Adapter les sections aux différentes étapes de carrière

## Section Résumé professionnel

### Quand l'inclure

**Inclure un résumé si :**
- Reconversion professionnelle (besoin d'expliquer la transition)
- Professionnels seniors (synthétiser une longue carrière)
- Retour sur le marché du travail (justifier les interruptions d'activité)
- Poste très spécialisé (mettre en valeur l'adéquation au profil)

**Ne pas inclure de résumé si :**
- Profil débutant avec une expérience limitée
- Progression de carrière linéaire et évidente
- L'espace manque cruellement

### Structure du résumé

**Formule :** [Titre/Identité] + [Années/Expérience] + [Compétences clés] + [Proposition de valeur]

### Par niveau de carrière

**Débutant :**
```
Recent Computer Science graduate from UC Berkeley with internship experience in full-stack development. Skilled in Python, React, and AWS. Seeking to leverage academic projects in machine learning and user-facing application development in a software engineering role.
```

**Milieu de carrière :**
```
Product Manager with 6 years driving B2B SaaS products from concept to scale. Track record of launching products that generated $10M+ ARR through data-driven roadmap prioritization and cross-functional leadership. Expert in API products, developer tools, and enterprise sales motions.
```

**Senior / Dirigeant :**
```
Technology executive with 15+ years building and scaling engineering organizations from 50 to 500+ across global markets. Proven success leading digital transformation initiatives, M&A integration, and platform modernization. P&L ownership of $100M+ with track record of 40%+ efficiency improvements.
```

**Reconversion professionnelle :**
```
Sales professional transitioning to Customer Success, bringing 5 years of consultative selling experience and proven ability to build lasting client relationships. Skilled in needs assessment, solution design, and stakeholder management. Seeking to apply relationship-building expertise to drive customer retention and expansion.
```

### À éviter dans le résumé

- ❌ "À la recherche d'un poste stimulant..."
- ❌ "Travailleur acharné ayant l'esprit d'équipe..."
- ❌ "Professionnel orienté résultats..."
- ❌ La troisième personne ("Jean est un...")
- ❌ Les objectifs personnels (ce que vous voulez vs ce que vous apportez)

## Section Compétences

### Options d'organisation

**Option 1 : Liste simple**
```
SKILLS
Python, JavaScript, SQL, React, Node.js, AWS, Docker, Git, Agile, JIRA
```
Idéal pour : l'optimisation ATS, les contraintes d'espace

**Option 2 : Par catégories**
```
TECHNICAL SKILLS
Languages: Python, JavaScript, TypeScript, SQL
Frameworks: React, Node.js, Django, FastAPI
Cloud: AWS (EC2, S3, Lambda), GCP, Docker, Kubernetes
Tools: Git, JIRA, Confluence, Datadog
```
Idéal pour : les profils techniques, les compétences étendues

**Option 3 : Niveaux de maîtrise** (à utiliser avec précaution)
```
SKILLS
Expert: Python, SQL, Product Management
Advanced: AWS, Data Analysis, Stakeholder Management
Proficient: Machine Learning, Figma, Financial Modeling
```
Idéal pour : les postes exigeant un niveau de maîtrise précis, une représentation honnête

### Ce qu'il faut inclure

**Compétences techniques / Hard Skills :**
- Langages de programmation
- Logiciels et outils
- Méthodologies (Agile, Lean)
- Plateformes (Salesforce, SAP)
- Certifications

**Compétences fonctionnelles :**
- Gestion de projet
- Analyse financière
- Analyse de données
- Études de marché

**Connaissances sectorielles :**
- Expertise métier
- Connaissances réglementaires
- Certifications sectorielles

### Ce qu'il faut exclure

- ❌ Microsoft Office (considéré comme acquis)
- ❌ Compétences "basiques"
- ❌ Compétences dont vous ne pouvez pas parler en entretien
- ❌ Soft skills (à démontrer par les faits, pas à lister)
- ❌ Technologies obsolètes

## Section Expérience

### Format standard

```
COMPANY NAME | City, State
Job Title | Start Date - End Date

• Achievement bullet with metric and impact
• Achievement bullet with metric and impact
• Achievement bullet with metric and impact
```

### Recommandations pour les points (bullets) par niveau de carrière

**Débutant (0-2 ans) :**
- 3 à 5 puces par poste
- Inclure les projets pertinents
- Chiffrer dès que possible
- Montrer l'initiative et la capacité d'apprentissage

**Milieu de carrière (3-10 ans) :**
- 4 à 6 puces pour les postes récents
- 2 à 3 puces pour les postes plus anciens
- Privilégier les réalisations par rapport aux simples tâches
- Des métriques solides d'un bout à l'autre

**Senior (10+ ans) :**
- 5 à 6 puces pour les postes récents
- 2 à 3 puces pour les postes plus anciens
- Mettre l'accent sur le leadership et la stratégie
- Démontrer l'élargissement de son périmètre de responsabilités

### Gérer différentes situations

**Plusieurs postes au sein de la même entreprise :**
```
COMPANY NAME | City, State
Senior Manager | 2021 - Present
• [Bullets for current role]

Manager | 2019 - 2021
• [Bullets for previous role]

Analyst | 2017 - 2019
• [Bullets for earliest role]
```

**Expérience courte :**
- L'inclure s'il s'agit d'une expérience pertinente
- L'articuler autour d'un projet ou d'une réalisation
- Ne pas s'excuser ni justifier la durée dans le CV

**Contrat / Freelance :**
```
Freelance Product Consultant | 2022 - Present
Clients include: Company A, Company B, Company C
• [Achievement with Client A]
• [Achievement with Client B]
```

## Section Formation

### Format standard

```
EDUCATION

Bachelor of Science in Computer Science
University of California, Berkeley | 2020
GPA: 3.8/4.0 | Honors: Magna Cum Laude
```

### Ce qu'il faut inclure par niveau de carrière

**Débutant :**
- Diplôme, spécialité, établissement, année
- Moyenne / GPA (si 3,5/4 ou mention très bien)
- Distinctions et récompenses
- Cours pertinents
- Projets académiques
- Séjours d'études à l'étranger

**Milieu de carrière :**
- Diplôme, spécialité, établissement, année
- Moyenne / mention uniquement si exceptionnelle
- Supprimer les cours suivis (remplacés par l'expérience)

**Senior :**
- Diplôme, établissement
- Possibilité d'omettre l'année (pour éviter la discrimination liée à l'âge)
- La formation continue est plus pertinente

### Diplômes supérieurs

```
MBA, Finance & Strategy
Harvard Business School | 2022
• Leadership Fellow
• Relevant coursework: Corporate Finance, M&A Strategy

M.S. in Computer Science
Stanford University | 2018
• Specialization: Artificial Intelligence
• Thesis: "Title of Thesis"
```

### Certifications

```
CERTIFICATIONS
AWS Solutions Architect Associate | Amazon Web Services | 2023
PMP (Project Management Professional) | PMI | 2022
Google Analytics Certified | Google | 2023
```

## Sections complémentaires

### Quand inclure chaque section

**Section Projets :**
- Profils débutants ayant peu d'expérience professionnelle
- Reconversion professionnelle pour démontrer de nouvelles compétences
- Postes techniques avec des projets personnels

**Section Bénévolat :**
- Expérience bénévole pertinente
- Rôles de leadership
- Permet de combler utilement les interruptions de carrière

**Langues :**
- Si pertinent pour le poste ou l'entreprise
- Préciser le niveau de maîtrise avec exactitude
- Uniquement si supérieur à un niveau de conversation basique

**Publications / Brevets :**
- Postes académiques
- Métiers de la recherche
- Rôles d'expertise et de leadership d'opinion technique

**Prix / Distinctions :**
- Prix sectoriels majeurs
- Reconnaissance à l'échelle de l'entreprise
- Distinctions professionnelles pertinentes

### Exemples de format

**Projets :**
```
PROJECTS
E-commerce Platform | React, Node.js, PostgreSQL | github.com/user/project
• Built full-stack marketplace with 500+ active users
• Implemented payment processing with Stripe integration
```

**Bénévolat :**
```
VOLUNTEER EXPERIENCE
Board Member | Local Nonprofit | 2021 - Present
• Led fundraising committee, increasing annual donations by 40%
```

**Langues :**
```
LANGUAGES
English (Native) | Spanish (Professional) | Mandarin (Conversational)
```

## Ordre des sections selon le type de profil

### Ordre standard
1. Coordonnées
2. Résumé (facultatif)
3. Compétences
4. Expérience
5. Formation
6. Sections complémentaires

### Postes techniques
1. Coordonnées
2. Compétences (priorisées)
3. Expérience
4. Projets
5. Formation
6. Certifications

### Jeune diplômé
1. Coordonnées
2. Formation (priorisée)
3. Compétences
4. Expérience / Stages
5. Projets
6. Activités extra-professionnelles

### Dirigeant / Executive
1. Coordonnées
2. Résumé exécutif
3. Faits marquants de carrière
4. Expérience
5. Rôles aux conseils d'administration
6. Formation

### Reconversion professionnelle
1. Coordonnées
2. Résumé (expliquant la transition)
3. Compétences (transférables)
4. Expérience (recadrée)
5. Expériences de transition
6. Formation

## Format de sortie

Lors de la rédaction de sections de CV :

```markdown
# RESUME SECTION RECOMMENDATIONS

## For: [User's situation/role]

### Recommended Section Order
1. [Section] - [Why]
2. [Section] - [Why]
...

### Section Details

#### Professional Summary
**Recommendation:** [Include/Skip]
**Draft:**
[Written summary if recommended]

#### Skills Section
**Format:** [Simple/Categorized/Proficiency]
**Content:**
[Organized skills list]

#### Experience Section
**Format:** [Standard/Functional/Hybrid]
**Bullets per Role:**
- Recent: [X] bullets
- Older: [X] bullets

#### Education Section
**Include:**
- [Items to include]
**Exclude:**
- [Items to exclude]

#### Additional Sections
**Recommended:** [Section name] because [reason]
**Skip:** [Section name] because [reason]
```

## Liste de contrôle pour la création de sections

- ✅ L'ordre des sections est optimisé pour le poste visé
- ✅ Le résumé est concis et ciblé (s'il est présent)
- ✅ Les compétences sont pertinentes et structurées
- ✅ Les puces de l'expérience sont axées sur les accomplissements
- ✅ La section formation est adaptée au niveau de carrière
- ✅ Les sections complémentaires apportent de la valeur (pas de remplissage)
- ✅ Le formatage est cohérent d'un bout à l'autre
- ✅ Chaque section soutient la candidature pour le poste visé
- ✅ Tout élément hors sujet ou obsolète a été écarté
- ✅ La longueur totale est appropriée (1 à 2 pages)
