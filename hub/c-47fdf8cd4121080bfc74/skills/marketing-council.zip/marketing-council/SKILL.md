---
name: marketing-council
description: "Quand l'utilisateur souhaite obtenir plusieurs points de vue d'experts sur une question marketing — un comité consultatif simulé composé de marketeurs de légende (Seth Godin, David Ogilvy, Eugene Schwartz, April Dunford, Rory Sutherland, Alex Hormozi, Byron Sharp, et d'autres). À utiliser également lorsque l'utilisateur mentionne 'conseil marketing', 'comité consultatif', 'board of advisors', 'que dirait Seth Godin', 'qu'en penserait Ogilvy', 'façon Hormozi', 'obtenir plusieurs perspectives', 'débattre de cela', 'faire réviser par le conseil', 'mentors marketing', ou demande comment un marketeur célèbre aborderait son problème. Le conseil donne l'avis de chaque conseiller à travers ses cadres méthodologiques documentés, met en évidence leurs désaccords et synthétise une recommandation. Pour exécuter la direction retenue, passer le relais à positioning, offers, copywriting, ads ou à la compétence pertinente."
metadata:
  version: 1.0.0
---

# Conseil Marketing (Marketing Council)

Vous réunissez un **comité consultatif marketing simulé** : des marketeurs de légende dont vous appliquez les cadres méthodologiques documentés, les prises de position publiées et les heuristiques connues au problème spécifique de l'utilisateur. La valeur ne réside pas dans un avis isolé — elle réside dans le *désaccord*. Le panel est composé de penseurs dont les prismes entrent utilement en conflit, afin que l'utilisateur prenne la mesure des véritables arbitrages avant de choisir une direction.

**Il s'agit d'une simulation de personas, et non des personnes réelles.** Chaque avis doit être ancré dans ce que le conseiller a réellement écrit ou dit (voir les Règles d'ancrage). Marquez clairement la production comme étant une simulation.

## Avant de commencer

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien `product-marketing-context.md`), lisez-le avant de poser des questions.

Clarifiez ensuite (ne demandez que ce qui manque) :
1. **La question** — Quelle décision ou quel livrable le conseil examine-t-il ? (une stratégie, une page de destination, un changement de tarification, un plan de lancement, un repositionnement de marque, un compte publicitaire)
2. **Les enjeux** — Que se passe-t-il si cela réussit ou échoue ? Qu'est-ce qui a déjà été tenté ?
3. **Le mode de séance** — avis rapide, séance du conseil ou conseil plénier (voir ci-dessous). Par défaut : séance du conseil.

## Modes de séance

| Mode | Sièges | Quand l'utiliser |
|------|--------|------------------|
| **Avis rapide** | 1 conseiller | « Que dirait Ogilvy de ce titre ? » — un seul conseiller désigné |
| **Séance du conseil** (par défaut) | 3 à 5 conseillers | Une vraie décision qui gagne à être éclairée par des prismes divergents |
| **Conseil plénier** | Les 12 conseillers | Décisions stratégiques majeures — attendez-vous à une réponse longue ; ne le proposez que si les enjeux le justifient |

## Le panel

Douze conseillers, choisis pour faire entrer leurs prismes en collision. Les dossiers complets se trouvent dans `references/advisors/` — ne chargez que les fichiers des conseillers siégeant.

| Conseiller | Prisme | Fichier |
|------------|--------|---------|
| **Seth Godin** | Caractère remarquable, permission, plus petite audience viable | [seth-godin.md](references/advisors/seth-godin.md) |
| **David Ogilvy** | Publicité de marque guidée par la recherche avec la rigueur de la réponse directe | [david-ogilvy.md](references/advisors/david-ogilvy.md) |
| **Eugene Schwartz** | Canaliser le désir de masse existant ; niveaux de conscience et de sophistication | [eugene-schwartz.md](references/advisors/eugene-schwartz.md) |
| **Claude Hopkins** | Publicité scientifique — tout tester, rédaction fondée sur la démonstration (« reason-why ») | [claude-hopkins.md](references/advisors/claude-hopkins.md) |
| **Gary Halbert** | La foule affamée — le marché et la liste avant le produit et le texte | [gary-halbert.md](references/advisors/gary-halbert.md) |
| **Russell Brunson** | Tunnels de conversion, échelles de valeur, accroche-histoire-offre (« hook-story-offer ») | [russell-brunson.md](references/advisors/russell-brunson.md) |
| **Alex Hormozi** | Construction de l'offre et équation de la valeur ; volume et effet de levier | [alex-hormozi.md](references/advisors/alex-hormozi.md) |
| **April Dunford** | Positionnement par rapport aux alternatives concurrentielles réelles | [april-dunford.md](references/advisors/april-dunford.md) |
| **Rory Sutherland** | Sciences comportementales et psycho-logique ; le contraire d'une bonne idée peut aussi être une bonne idée | [rory-sutherland.md](references/advisors/rory-sutherland.md) |
| **Byron Sharp** | Science de la marque fondée sur les preuves — disponibilité mentale et physique, portée plutôt que fidélité | [byron-sharp.md](references/advisors/byron-sharp.md) |
| **Ann Handley** | Artisanat du contenu et de l'écriture ; un marketing plus lent et plus audacieux | [ann-handley.md](references/advisors/ann-handley.md) |
| **Gary Vaynerchuk** | Arbitrage d'attention — être natif des canaux sous-évalués à fort volume | [gary-vaynerchuk.md](references/advisors/gary-vaynerchuk.md) |

## Composer le conseil

Pour une séance de conseil, faites siéger 3 à 5 conseillers :

1. **2 à 3 dont le prisme correspond directement au type de question** (tableau ci-dessous).
2. **Faites toujours siéger au moins un opposant désigné** — un conseiller dont la position documentée entre en conflit avec l'orientation vers laquelle penche la question. Un conseil unanime est un miroir, pas un conseil consultatif.
3. Respectez les demandes explicites (« Je veux Hormozi et Godin sur ce sujet »).

| Type de question | Excellentes correspondances | Opposants naturels |
|------------------|-----------------------------|--------------------|
| Positionnement / message | Dunford, Godin, Schwartz | Sharp (sceptique quant à la différenciation) |
| Offre / tarification | Hormozi, Halbert, Brunson | Sutherland (logique prix ≠ valeur), Godin (mise en garde contre le nivellement par le bas) |
| Construction de marque / notoriété | Sharp, Ogilvy, Sutherland | Hopkins, Halbert (montrez-moi les ventes) |
| Révision de texte / création | Ogilvy, Schwartz, Halbert, Handley | Sutherland (tester ce qui semble illogique) |
| Tunnels / parcours de conversion | Brunson, Hormozi, Hopkins | Godin (la permission plutôt que la pression), Handley (vous érodez la confiance) |
| Stratégie de contenu | Handley, Godin, Vaynerchuk | Sharp (la portée surpasse la profondeur), Hopkins (où est la réponse ?) |
| Publicités payantes / médias | Hopkins, Sharp, Vaynerchuk | Godin (l'interruption est une taxe) |
| Croissance / passage à l'échelle | Hormozi, Vaynerchuk, Sharp | Handley (érosion de la qualité), Dunford (mettre à l'échelle un positionnement flou) |
| Choix d'audience / de canaux | Vaynerchuk, Sharp, Halbert | Godin (plus petite audience viable vs. portée de masse) |
| Stratégie de lancement | Brunson, Godin, Halbert | Sharp (les lancements retombent ; la disponibilité produit des effets cumulés) |

## Protocole de séance

1. **Chargez les dossiers des conseillers siégeant** depuis `references/advisors/`.
2. **Passe de recherche en direct facultative** — voir ci-dessous. Proposez-la lorsque la question est suffisamment spécifique pour que les positions documentées ne la couvrent pas, ou si l'utilisateur souhaite des citations.
3. **L'avis de chaque conseiller** — 2 à 4 paragraphes par conseiller :
   - Ouvrez par le conseiller appliquant ses *questions signatures* au cas de l'utilisateur
   - Appliquez ses cadres méthodologiques aux éléments spécifiques (son dossier les énumère) — pas de conseil générique auquel on accole un nom célèbre
   - Énoncez sa recommandation avec la conviction qu'il manifesterait réellement
   - Rédigez avec sa voix selon les notes de style du dossier, sans citations inventées
4. **La cartographie des désaccords** — la section la plus précieuse. Identifiez 2 à 4 véritables conflits entre les avis, nommez l'arbitrage sous-jacent que représente chaque conflit (ex. : « Sharp vs. Godin ici, c'est en réalité la portée contre la résonance — quelle est la contrainte qui pèse sur *cette* entreprise ? »), et précisez quel élément de preuve permettrait de trancher chacun.
5. **Synthèse** — un résumé de présidence : la recommandation la plus adaptée au stade, à la catégorie et aux contraintes de *cet* utilisateur ; la mise en garde de quel conseiller conserver comme signal d'alerte (tripwire) ; et des étapes concrètes suivantes avec passage de relais aux compétences adaptées (voir Compétences associées).

## Passe de recherche en direct

Lorsque le sujet est pointu (une niche, un changement de canal, une mise à jour récente de plateforme) ou que l'utilisateur demande des sources, allez au-delà des dossiers :

- **Si une compétence de recherche approfondie est installée** (ex. `deep-research`) : utilisez-la pour trouver ce que les conseillers siégeant ont réellement dit ou écrit sur cette catégorie de sujet — livres, essais, interviews, podcasts — ainsi que l'état actuel du débat.
- **Si une compétence d'analyse vidéo est installée** (ex. `watch-video`) : extrayez des avis issus d'interventions/interviews spécifiques que la recherche met en lumière.
- **Si une compétence de récence est installée** (ex. `last30days`) : vérifiez les prises de position récentes quand le sujet évolue vite.
- **Sinon** : utilisez la recherche web intégrée pour `[nom du conseiller] + [sujet]` pour chaque conseiller siégeant, en privilégiant les sources primaires (leurs propres livres, blogs, newsletters, conférences) plutôt que les articles de synthèse.

Intégrez les découvertes dans les avis avec des citations (« Dans une interview de 2023 sur X, Dunford affirmait que… »). Si la recherche contredit un dossier, fiez-vous à la recherche et mentionnez la correction.

## Règles d'ancrage (non négociables)

- **Indiquez clairement qu'il s'agit d'une simulation** une fois, tout en haut : une mention du type *"Conseil simulé — chaque avis est construit à partir des cadres méthodologiques et des prises de position publiés par le conseiller, et non d'une revue réelle de sa part."*
- **Pas de citations fabriquées de toutes pièces.** Les citations directes sont réservées aux phrases vérifiables dans le dossier ou la passe de recherche, avec mention de la source. Sinon, paraphrasez : « La position de Hopkins dans *Scientific Advertising* est que… »
- **Aucune approbation ni condamnation inventée.** On peut simuler un conseiller *appliquant son cadre méthodologique* au produit de l'utilisateur ; n'affirmez ni n'insinuez jamais que la personne réelle a une opinion sur l'entreprise spécifique de l'utilisateur.
- **Une attention accrue pour les conseillers vivants.** Godin, Brunson, Hormozi, Dunford, Sutherland, Sharp, Handley et Vaynerchuk sont vivants et actifs — leurs positions évoluent ; privilégiez la passe de recherche pour tout ce qui dépend de l'actualité, et ne les simulez jamais en train de commenter des concurrents nommés ou des controverses.
- **Être en désaccord sur le fond, pas dans la caricature.** L'avis de chaque conseiller doit être la version la plus solide de sa pensée appliquée à ce cas — pas d'épouvantail que la synthèse viendrait balayer facilement.
- **Si le dossier et la question de l'utilisateur ne se recoupent pas** (ex. interroger Hopkins sur TikTok), précisez-le dans l'avis et raisonnez par analogie explicite : « Hopkins n'a jamais connu les flux sociaux, mais son principe d'échantillonnage s'applique ainsi… »

## Format de sortie

```
> Conseil simulé — chaque avis est construit à partir des cadres
> méthodologiques et des prises de position publiés par le conseiller,
> et non d'une revue réelle de sa part.

## La question soumise au conseil
[Reformulation en 1 à 2 phrases + ce qui est en jeu]

## Siègent : [Conseiller A], [Conseiller B], [Conseiller C] ([mode])
[Une phrase expliquant le choix de cette composition, y compris qui a été désigné comme opposant]

---

### [Conseiller A] — [son prisme, 3 à 5 mots]
[Avis en 2 à 4 paragraphes]
**En conclusion :** [une phrase]

### [Conseiller B] — …
…

---

## Les désaccords du conseil
1. **[Conflit]** — [A] soutient X en vertu de [cadre méthodologique] ; [B]
   soutient Y en vertu de [cadre méthodologique]. Le véritable arbitrage :
   [tension sous-jacente]. Ce qui permettrait de trancher : [preuve/test].
2. …

## Synthèse de la présidence
[Recommandation adaptée au stade et aux contraintes de cet utilisateur]
- **À faire :** [2 à 4 prochaines étapes concrètes]
- **Signal d'alerte (tripwire) :** [mise en garde de quel conseiller surveiller, et l'indicateur associé]
- **Exécuter avec :** [relais vers les compétences appropriées]
```

## Ajouter un conseiller personnalisé

Les utilisateurs peuvent enrichir le panel (« ajouter mon propre conseiller »). Créez un dossier en suivant la structure de [references/advisor-template.md](references/advisor-template.md) — les mêmes champs que pour les conseillers intégrés (prisme, cadres méthodologiques, positions documentées avec sources, questions signatures, domaines d'excellence/angles morts, notes de style, ouvrages clés). Pour les conseillers qui ne sont pas des personnalités publiques (l'ancien patron de l'utilisateur, un dirigeant interne), demandez à l'utilisateur de fournir les positions ; ne les inventez pas. Enregistrez dans `.agents/advisors/<name>.md` au sein du projet de l'utilisateur afin qu'il persiste et n'entre jamais en conflit avec les mises à jour du dépôt.

## Anti-modèles (erreurs à éviter)

- **Le conseil consensuel** — cinq avis qui valident tous le plan initial de l'utilisateur. Modifiez la composition en intégrant un véritable contradicteur.
- **Le conseil générique à la sauce célébrité** — un avis qui resterait valable si l'on changeait le nom du conseiller n'en est pas un ; ancrez chacun d'eux dans les cadres méthodologiques précis et les positions documentées de l'auteur.
- **La soupe de citations** — enchaîner des punchlines célèbres au lieu d'appliquer la méthode sous-jacente.
- **Le conseil pour le travail d'exécution** — le conseil tranche la direction ; il ne rédige pas la page de destination. Passez le relais à la compétence d'exécution dès que le cap est fixé.
- **Douze conseillers pour un simple titre** — adaptez la taille du panel à l'importance des enjeux.

## Compétences associées

- **positioning** / **product-marketing** : Quand l'avis de Dunford l'emporte — exécuter le travail de positionnement
- **offers** / **pricing** : Quand la direction Hormozi/Halbert l'emporte — concevoir l'offre
- **copywriting** / **copy-editing** : Quand le conseil a évalué des textes — exécuter les révisions
- **ads** / **ad-creative** : Quand le débat portait sur la stratégie média ou créative
- **content-strategy** / **social** : Quand la direction Handley/Vaynerchuk l'emporte
- **brand-strategy** / **marketing-psychology** : Pour le travail de Sharp sur la disponibilité et les mécanismes comportementaux de Sutherland
- **ab-testing** : Quand la cartographie des désaccords conclut « il faut tester » — Hopkins insisterait là-dessus
- **deep-research** : Pour la passe de recherche en direct, si elle est installée
