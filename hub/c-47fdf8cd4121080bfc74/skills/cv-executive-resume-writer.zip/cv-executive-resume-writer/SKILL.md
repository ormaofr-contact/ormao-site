---
name: executive-resume-writer
description: Créer des CV pour cadres dirigeants (C-suite et VP) mettant en valeur le leadership stratégique
---

# Rédacteur de CV de cadres dirigeants

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Postule à des postes de direction générale (C-suite), de vice-président (VP) ou de directeur
- Possède plus de 15 ans d'expérience au sein de directions générales
- Doit mettre l'accent sur le leadership stratégique plutôt que sur les compétences opérationnelles
- Mentionne : « executive resume », « C-suite », « VP resume », « senior leadership », « board », « executive search »

## Capacités principales

- Rédiger des CV pour des postes de direction générale (C-suite) et de vice-présidence (VP)
- Mettre l'accent sur le leadership stratégique et la transformation d'entreprise
- Valoriser la responsabilité de P&L (compte de résultat) et l'impact organisationnel
- Équilibrer les réalisations et la philosophie de leadership
- Mettre en page pour les chasseurs de têtes et les présentations aux conseils d'administration
- Inclure l'expérience en conseil d'administration et la reconnaissance sectorielle

## Philosophie du CV de dirigeant

**Différences clés par rapport aux CV classiques :**

| CV classique | CV de dirigeant |
|--------------|-----------------|
| Énumère des compétences | Démontre une marque de leadership |
| Montre des tâches | Démontre un impact stratégique |
| Se concentre sur le « quoi » | Se concentre sur le « et alors ? » (l'impact concret) |
| 1 à 2 pages | 2 à 3 pages acceptables |
| Mots-clés pour les ATS | Une histoire pour les décideurs |
| Contributions individuelles | Transformation organisationnelle |

## Structure du CV de dirigeant

### Sections recommandées

```
1. Executive Profile/Summary
2. Core Competencies (Leadership Themes)
3. Career Highlights / Key Achievements
4. Professional Experience
5. Board & Advisory Roles
6. Education & Executive Development
7. Industry Recognition (optional)
```

### Recommandations de longueur
- VP/SVP : 2 pages
- C-Suite : 2-3 pages
- CV pour conseil d'administration : peut être plus long

## Section Profil de dirigeant

Cette section remplace le résumé professionnel standard. Elle doit communiquer votre **marque de leadership**.

### Format
```
[TITLE/FUNCTION] EXECUTIVE

[Leadership brand statement - who you are as a leader]

[2-3 sentences on your track record with scope/scale]

[What you're known for / unique value proposition]
```

### Exemple

```
CHIEF OPERATING OFFICER | P&L LEADERSHIP | OPERATIONAL TRANSFORMATION

Growth-focused operations executive with 20+ years scaling B2B technology companies from $50M to $500M+ in revenue. Known for building high-performance teams, operational excellence, and creating scalable infrastructure that enables rapid growth.

Track record includes 3 successful exits, 2 IPO preparations, and leading organizations of 500+ employees across 6 countries. Expertise in operational strategy, M&A integration, and digital transformation in SaaS and enterprise software environments.

Core philosophy: Build repeatable processes that scale while maintaining the agility that drives innovation.
```

## Section Compétences clés

Présentez-les sous forme de thèmes de leadership plutôt que de simples listes de compétences.

### Exemple
```
LEADERSHIP COMPETENCIES

Strategic Growth        | M&A Integration          | Digital Transformation
P&L Management ($500M+) | Global Team Leadership   | Board Relations
Operational Excellence  | Change Management        | Investor Relations
```

## Section Faits marquants de carrière

Placez vos plus grandes réussites en avant, avant le parcours chronologique.

### Format
```
CAREER HIGHLIGHTS

• [Achievement 1 with metrics]
• [Achievement 2 with metrics]
• [Achievement 3 with metrics]
• [Achievement 4 with metrics]
```

### Exemple
```
CAREER HIGHLIGHTS

• Led operational transformation at TechCorp, improving EBITDA margins from 12% to 28% while growing revenue from $150M to $400M
• Executed 5 acquisitions totaling $200M+ and successfully integrated 3 companies with 95% employee retention
• Built global operations team from 50 to 500+ employees across US, EMEA, and APAC regions
• Prepared company for successful IPO, implementing SOX compliance and investor-ready reporting
```

## Section Expérience pour cadres dirigeants

### La formule des puces pour dirigeants

**[Action de leadership] + [Initiative stratégique] + [Résultat économique à grande échelle]**

### Exemple de poste

```
CHIEF OPERATING OFFICER
TechCorp Inc. | San Francisco, CA | 2019 - Present
$400M B2B SaaS company | 1,200 employees | Series D - IPO track

Recruited by CEO to transform operations and prepare company for IPO. Direct reports include VP Engineering, VP Customer Success, VP Operations, and CIO. Full P&L ownership for services business ($150M).

Strategic Initiatives & Results:

• Operational Transformation: Redesigned end-to-end operations, improving gross margins from 62% to 78% and reducing customer onboarding time from 90 to 30 days

• Scale & Growth: Built infrastructure to support growth from $150M to $400M revenue, including implementation of ERP, expansion to 3 new geographies, and establishment of 24/7 global support

• M&A Leadership: Served as operational lead for 3 acquisitions totaling $75M, achieving full integration within 6 months and 95% talent retention

• Team Development: Expanded operations organization from 200 to 600 employees, established leadership development program that promoted 15 internal candidates to VP/Director roles

• IPO Preparation: Led SOX compliance implementation, established audit committee reporting, and built investor-ready operational metrics and forecasting capabilities
```

### Éléments clés pour l'expérience de dirigeant

**À inclure systématiquement :**
- Contexte de l'entreprise (chiffre d'affaires, effectifs, stade de développement)
- Structure hiérarchique / périmètre de responsabilité (span of control)
- Responsabilité de P&L ou de budget
- Envergure stratégique

**Indicateurs à mettre en avant :**
- Croissance du chiffre d'affaires (en valeur et en %)
- Amélioration de la rentabilité (marges, EBITDA)
- Réduction des coûts
- Taille de l'équipe et développement des talents
- Expansion géographique
- Activité de fusions-acquisitions (M&A)
- Résultats de sorties (exits)

## Section Conseil d'administration et rôles consultatifs

```
BOARD & ADVISORY POSITIONS

Board of Directors | TechStartup Inc. | 2022 - Present
$50M ARR B2B SaaS company. Chair of Compensation Committee.

Advisory Board | VentureStudio | 2020 - Present
Supporting portfolio companies with operational strategy and GTM execution.

Board Observer | AcquiredCo (acquired by BigTech, 2023) | 2021 - 2023
Provided operational guidance through $200M acquisition process.
```

## Considérations spécifiques aux dirigeants

### Mettre l'accent sur la transformation

Les dirigeants sont recrutés pour **transformer**, non pour maintenir. Montrez :
- Ce qui a changé grâce à vous
- La situation avant / après
- L'ampleur de l'impact

**Formule du récit de transformation :**
« A hérité de [situation]. A mis en œuvre [changement stratégique]. A obtenu [résultat]. »

### Révéler la philosophie de leadership

Contrairement aux CV de contributeurs individuels, le CV d'un dirigeant doit suggérer **comment** vous dirigez.

**Exemples :**
- « Réputé pour bâtir le consensus auprès de parties prenantes diverses »
- « Dirige en s'appuyant sur des décisions guidées par les données tout en conservant une agilité stratégique »
- « Promeut l'innovation tout en maintenant une discipline opérationnelle »

### Gérer la durée des postes avec soin

**Postes courts :** Formulez-les autour de missions spécifiques
- « Recruté pour mener l'intégration post-fusion »
- « Embauché pour un redressement d'entreprise ; mené à bien en 18 mois »
- « A rejoint l'entreprise pour la préparer à son acquisition »

**Postes longs :** Montrez la progression et la réinvention
- « Promotion à travers 4 postes successifs sur 12 ans »
- « A mené plusieurs transformations au fur et à mesure que l'entreprise est passée de 50 M$ à 500 M$ »

### Informations confidentielles

**À faire :**
- Utiliser des pourcentages d'amélioration lorsque les valeurs absolues sont confidentielles
- Utiliser des fourchettes pour le chiffre d'affaires et les effectifs
- Exprimer l'impact en termes relatifs

**À ne pas faire :**
- Partager des stratégies propriétaires
- Nommer des cibles d'acquisition confidentielles
- Révéler des informations financières non publiques

## Ton du CV de dirigeant

### Vocabulaire d'impact pour les dirigeants

**Verbes d'action stratégiques :**
- A piloté, A orchestré, A promu, A guidé
- A transformé, A révolutionné, A été le pionnier de
- A conçu, A structuré (sur le plan stratégique)
- A impulsé, A accéléré, A catalysé

**Formulations de leadership :**
- « A dirigé l'organisation à travers... »
- « A bâti et développé à grande échelle... »
- « A défini la vision pour... »
- « A négocié et sécurisé... »
- « A porté la transformation... »

### Ce qu'il faut éviter

- ❌ Le vocabulaire tactique/opérationnel (a géré, a traité, a assisté)
- ❌ Les pronoms à la première personne (je, mon, me)
- ❌ Le jargon dénué de contexte
- ❌ Les affirmations génériques sans preuves
- ❌ L'excès d'humilité (attribuez-vous le mérite de manière appropriée)

## Format de sortie

Lors de la rédaction d'un CV de dirigeant :

```markdown
# EXECUTIVE RESUME

## Executive Profile
[Full executive profile section]

## Core Competencies
[Formatted competency grid]

## Career Highlights
[4-6 top achievements with metrics]

## Professional Experience

### [Most Recent Role]
[Full executive role writeup]

### [Previous Role]
[Full executive role writeup]

## Board & Advisory
[Board positions]

## Education & Development
[Degrees and executive education]

---

## Positioning Notes
- Key narrative theme: [The story your resume tells]
- Leadership brand: [What you're known for]
- Differentiator: [What sets you apart]
```

## Considérations pour la chasse de têtes (Executive Search)

**Votre CV est susceptible d'être lu par :**
- Des chasseurs de têtes pour cadres dirigeants
- Des membres de conseils d'administration
- Des associés en capital-investissement (PE) ou capital-risque (VC)
- Des directeurs généraux (CEO) et directeurs des ressources humaines (CHRO)

**Optimisez pour :**
- Une lecture rapide par des dirigeants occupés
- Un fil conducteur clair de la progression de carrière
- Une marque de leadership évidente
- Des réalisations crédibles et vérifiables

**Rappelez-vous :**
- Les recrutements de dirigeants impliquent souvent des prises de références avant même les entretiens
- Les informations de votre CV seront vérifiées
- Les relations et la réputation sont déterminantes
- Le CV ouvre les portes ; le relationnel conclut les opportunités
