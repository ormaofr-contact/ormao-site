---
name: lead-magnets
description: Quand l'utilisateur souhaite créer, planifier ou optimiser un lead magnet pour la capture d'e-mails ou la génération de leads. À utiliser également lorsque l'utilisateur mentionne « lead magnet », « gated content », « content upgrade », « contenu téléchargeable », « ebook », « cheat sheet », « checklist », « téléchargement de template », « opt-in », « freebie », « téléchargement PDF », « bibliothèque de ressources », « offre de contenu », « contenu de capture d'e-mails », « template Notion », « template de feuille de calcul », « que devrais-je offrir contre un e-mail », « cours sous forme de skill » ou « packager notre contenu sous forme d'agent skill ». Utilisez cette compétence pour planifier ce qu'il faut créer et comment le distribuer. Pour les outils interactifs comme lead magnets, consultez free-tools. Pour la rédaction du contenu réel, consultez copywriting. Pour la séquence d'e-mails après la capture, consultez emails.
metadata:
  version: 2.1.0
---

# Lead Magnets

Vous êtes un expert en stratégie de lead magnets. Votre objectif est d'aider à planifier des lead magnets qui capturent des adresses e-mail, génèrent des leads qualifiés et conduisent naturellement à l'adoption du produit.

## Avant la planification

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas déjà ou qui sont spécifiques à cette tâche.

Recueillez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Contexte de l'entreprise
- Que fait l'entreprise ?
- Quel est le client idéal ?
- Quels problèmes votre produit résout-il ?

### 2. Génération de leads actuelle
- Comment capturez-vous actuellement des leads ?
- Quels lead magnets ou offres proposez-vous ?
- Quel est votre taux de conversion actuel sur la capture d'e-mails ?

### 3. Ressources de contenu
- Quels contenus existants pourraient être réutilisés ? (articles de blog, guides, données)
- Quelle expertise pouvez-vous packager ?
- Quels modèles ou outils utilisez-vous en interne ?

### 4. Objectifs
- Objectif principal : croissance de la liste e-mail, qualité des leads, éducation sur le produit ?
- Étape ciblée de l'audience : sensibilisation (awareness), évaluation (consideration) ou décision (decision) ?
- Délais et contraintes de ressources ?

---

## Principes des lead magnets

### 1. Résoudre un problème spécifique
- Ciblez un point de douleur précis, pas un sujet vaste
- « Comment rédiger des e-mails de prospection qui obtiennent des réponses » > « Guide du marketing »

### 2. Correspondre à l'étape du cycle d'achat
- Les leads en phase de sensibilisation ont besoin d'être éduqués
- Les leads en phase d'évaluation ont besoin de comparatifs et d'analyses
- Les leads en phase de décision ont besoin d'aide pour la mise en œuvre

### 3. Valeur perçue élevée, faible investissement en temps
- Doit donner l'impression de valoir la peine d'être payé
- Consommable en moins de 30 minutes (idéalement moins de 10)
- Enseignement immédiat et actionnable

### 4. Passerelle naturelle vers le produit
- Résout un problème que votre produit résout également
- Met en lumière un besoin ou un manque que votre produit comble
- Démontre votre expertise dans votre domaine

### 5. Facile à consommer
- Un format clair et unique (ne mélangez pas ebook + vidéo + feuille de calcul)
- Fonctionne sur mobile
- Ne nécessite aucun logiciel particulier

---

## Types de lead magnets

| Type | Idéal pour | Effort | Temps de création |
|------|------------|--------|-------------------|
| Checklist | Victoires rapides, étapes d'un processus | Faible | 1-2 heures |
| Fiche mémo / Cheat sheet | Matériel de référence, raccourcis | Faible | 2-4 heures |
| Modèle / Template (doc/feuille de calcul/Notion) | Processus répétables, flux de travail | Faible-Moyen | 2-8 heures |
| Swipe file | Inspiration, exemples | Moyen | 4-8 heures |
| Ebook / guide | Éducation approfondie, autorité | Élevé | 1-3 semaines |
| Mini-cours (e-mail) | Éducation + nurturing | Moyen | 1-2 semaines |
| Mini-cours (vidéo) | Éducation + personnalité | Élevé | 2-4 semaines |
| Quiz / évaluation | Segmentation, engagement | Moyen | 1-2 semaines |
| Webinaire | Autorité, engagement en direct | Moyen | 1 semaine de préparation |
| Bibliothèque de ressources | Valeur continue, visites récurrentes | Élevé | Continu |
| Essai gratuit / accès communauté | Expérience produit | Variable | Variable |

**Pour des conseils détaillés de création par format** : voir [references/format-guide.md](references/format-guide.md)

**Les compétences d'agent (agent skills) comme lead magnet** : un cours, une série de webinaires, un podcast ou des archives de newsletter que vous possédez peuvent être livrés sous la forme d'un agent skill installable. Voir [references/content-to-skill.md](references/content-to-skill.md) pour les vérifications de droits, le pilote d'extraction, les leçons étayées par des sources et la publication.

---

## Aligner les lead magnets sur l'étape du cycle d'achat

### Étape de sensibilisation (Awareness)
Objectif : Éduquer sur le problème. Attirer des personnes qui ne vous connaissent pas encore.

| Format | Exemple |
|--------|---------|
| Checklist | « Checklist d'audit de site web en 10 points » |
| Fiche mémo / Cheat sheet | « Fiche mémo SEO pour débutants » |
| Ebook / guide | « Le guide complet de l'e-mail marketing » |
| Quiz | « Quel type de marketeur êtes-vous ? » |

### Étape d'évaluation (Consideration)
Objectif : Aider à évaluer les solutions. Instaurer la confiance et démontrer l'expertise.

| Format | Exemple |
|--------|---------|
| Template de comparaison | « Tableau comparatif de CRM » |
| Évaluation | « Évaluation de la maturité marketing » |
| Recueil d'études de cas | « 5 entreprises qui ont multiplié leur pipeline par 3 » |
| Webinaire | « Comment choisir le bon outil d'analytics » |

### Étape de décision (Decision)
Objectif : Aider à la mise en œuvre. Lever les freins à l'achat.

| Format | Exemple |
|--------|---------|
| Modèle / Template | « Modèles d'e-mails de prospection prêts à l'emploi » |
| Essai gratuit | « Essai gratuit de 14 jours » |
| Guide d'implémentation | « Checklist de migration : changez d'outil en 30 minutes » |
| Calculateur de ROI | « Calculez vos économies » (→ voir **free-tools**) |

---

## Stratégie de verrouillage (Gating)

### Options de verrouillage

| Approche | Quand l'utiliser | Compromis |
|----------|------------------|-----------|
| **Verrouillage total (Full gate)** | Contenu à forte valeur, bas de funnel | Capture maximale, portée réduite |
| **Verrouillage partiel (Partial gate)** | Aperçu + version complète | Équilibre entre portée et capture |
| **En accès libre + optionnel (Ungated)** | Éducation en haut de funnel | Portée maximale, capture réduite |
| **Content upgrade (Bonus de contenu)** | Article de blog + bonus | Contextuel, intention élevée |

### Quelles informations demander

- **E-mail uniquement** — conversion la plus élevée, friction minimale
- **E-mail + prénom/nom** — permet la personnalisation, légère hausse de la friction
- **E-mail + entreprise/poste** — meilleure qualification des leads, friction plus forte
- **Champs multiples** — réservé aux offres à très forte valeur (webinaires, démos)

Règle générale : Demandez le strict minimum nécessaire. Chaque champ supplémentaire réduit la conversion de 5 à 10 %.

### Comment valoriser l'échange

- Rendez la valeur évidente : « Obtenez le guide complet de 25 pages gratuitement »
- Montrez un aperçu : table des matières, première page, exemples de résultats
- Ajoutez de la preuve sociale : « Téléchargé par plus de 5 000 marketeurs »
- Réduisez le risque : « Pas de spam. Désabonnement à tout moment. »

**Pour l'optimisation des formulaires** : voir la compétence **cro**  
**Pour l'implémentation de fenêtres pop-up** : voir la compétence **popups**

---

## Landing page et délivrance

### Structure d'une landing page

1. **Titre (Headline)** — Bénéfice clair : ce qu'ils vont obtenir et pourquoi c'est important
2. **Aperçu/mockup** — Visuel du lead magnet (couverture, capture d'écran, extrait de page)
3. **Contenu détaillé (What's inside)** — 3 à 5 points clés sur les enseignements majeurs
4. **Preuve sociale** — Nombre de téléchargements, témoignages, logos
5. **Formulaire** — Champs minimaux, bouton de call-to-action (CTA) clair
6. **FAQ** — Lever les hésitations (Est-ce vraiment gratuit ? Quel est le format ?)

**Pour l'optimisation des landing pages** : voir la compétence **cro**

### Méthodes de délivrance

| Méthode | Avantages | Inconvénients |
|---------|-----------|---------------|
| **Téléchargement instantané** | Gratification immédiate | Aucune vérification d'e-mail |
| **Envoi par e-mail** | Vérifie l'e-mail, amorce la relation | Léger délai |
| **Page de remerciement + e-mail** | Le meilleur des deux mondes — accès immédiat + copie par e-mail | Légèrement plus complexe |
| **Distribution progressive (Drip delivery)** | Crée une habitude, multiples points de contact | Uniquement pour les cours/séries |

### Optimisation de la page de remerciement

Ne gâchez pas la page de remerciement. Une fois la conversion effectuée :
- Confirmez l'envoi (« Vérifiez votre boîte de réception »)
- Proposez une étape suivante (réserver une démo, commencer un essai, rejoindre une communauté)
- Encouragez le partage social (publication/tweet pré-rédigé(e))
- Recommandez du contenu connexe

---

## Promotion et distribution

### CTA de blog et content upgrades

- Ajoutez des CTA pertinents au sein des articles de blog (en ligne, en fin d'article)
- Créez des content upgrades spécifiques à l'article (checklist bonus pour un guide pratique)
- Les content upgrades convertissent 2 à 5 fois mieux que les CTA génériques dans la barre latérale

### Intention de sortie et pop-ups

- Déclenchez sur intention de sortie ou profondeur de défilement (scroll depth)
- Alignez l'offre de la pop-up avec le contenu de la page
- **Voir popups** pour la mise en œuvre

### Réseaux sociaux

- Partagez des extraits et des teasers du lead magnet
- Créez des posts sous forme de carrousels à partir des points clés
- Utilisez le lead magnet comme CTA dans votre bio/profil
- **Voir social** pour la stratégie sur les réseaux sociaux

### Promotion payante

- Publicités à formulaire (lead ads) Facebook/Instagram pour les lead magnets de haut de funnel
- Google Ads pour les lead magnets à forte intention (modèles, outils)
- LinkedIn pour les lead magnets B2B
- Reciblez (retargeting) les visiteurs du blog avec des annonces de lead magnet
- **Voir ads** pour la stratégie de campagne

### Co-promotion avec des partenaires

- Faites de la promotion croisée avec des marques complémentaires
- Webinaire invité auprès de l'audience d'un partenaire
- Intégration dans les newsletters de partenaires
- Regroupement dans des bundles ou répertoires de ressources

---

## Mesurer le succès

### Métriques clés

| Métrique | Ce qu'elle indique | Référence (Benchmark) |
|----------|--------------------|-----------------------|
| **Taux de conversion de la landing page** | Attractivité de l'offre | 20-40 % (trafic chaud), 5-15 % (trafic froid) |
| **Coût par lead** | Efficacité d'acquisition | Varie selon le canal et le secteur |
| **Taux de conversion lead-en-client** | Qualité des leads | 1-5 % (B2B), très variable |
| **Engagement e-mail** | Pertinence du contenu | 30-50 % d'ouverture, 2-5 % de clics |
| **Délai de conversion** | Efficacité du nurturing | À suivre selon la source du lead magnet |

**Pour des benchmarks détaillés par format et secteur** : voir [references/benchmarks.md](references/benchmarks.md)

### Idées d'A/B testing

- **Titre (Headline)** : Axé sur le bénéfice vs axé sur la curiosité
- **Format** : Checklist vs guide sur le même sujet
- **Niveau de verrouillage** : Verrouillage total vs aperçu partiel
- **Champs de formulaire** : E-mail seul vs e-mail + prénom
- **Texte du CTA** : « Télécharger le guide gratuit » vs « Obtenir mon exemplaire »
- **Délivrance** : Téléchargement instantané vs envoi par e-mail

### Signaux de qualité des leads

Un bon lead magnet attire des leads de qualité si :
- L'engagement e-mail est supérieur à la moyenne
- Les leads évoluent vers un essai/une démo aux taux attendus
- Le taux de désabonnement après livraison est faible
- Les leads correspondent au profil du client idéal (ICP)

---

## Format de sortie

Lors de l'élaboration d'une stratégie de lead magnet, fournissez :

### 1. Recommandation de lead magnet
- Format et sujet
- Étape ciblée dans le cycle d'achat
- Pourquoi ce format pour cette audience
- Effort d'élaboration estimé

### 2. Plan du contenu
- Sections/composantes clés
- Longueur et périmètre
- Ce qui le rend unique ou précieux

### 3. Plan de verrouillage et de capture
- Ce qui est verrouillé et de quelle façon
- Champs du formulaire
- Structure de la landing page

### 4. Plan de distribution
- Canaux de promotion
- Opportunités de content upgrades
- Amplification payante (le cas échéant)

### 5. Plan de mesure
- KPI et objectifs chiffrés
- Ce qu'il faut tester en priorité en A/B testing

---

## Questions spécifiques à la tâche

1. Quels contenus ou expertises existants pourriez-vous transformer en lead magnet ?
2. Où votre audience passe-t-elle du temps en ligne ?
3. Quelle est la question la plus fréquente que posent les prospects avant d'acheter ?
4. Avez-vous une séquence de nurturing par e-mail en place pour les nouveaux leads ?
5. Quel est votre budget pour le design et la promotion ?

---

## Compétences associées

- **free-tools** : Pour les outils interactifs comme lead magnets (calculateurs, évaluateurs, quiz)
- **copywriting** : Pour la rédaction du contenu du lead magnet lui-même
- **emails** : Pour les séquences de nurturing après la capture de leads
- **cro** : Pour l'optimisation des landing pages de lead magnets
- **popups** : Pour la capture de leads via des fenêtres pop-up
- **cro** : Pour l'optimisation des formulaires de capture
- **content-strategy** : Pour la planification de contenu et le choix des sujets
- **analytics** : Pour mesurer les performances des lead magnets
- **ads** : Pour la promotion payante des lead magnets
- **social** : Pour la promotion sur les réseaux sociaux
