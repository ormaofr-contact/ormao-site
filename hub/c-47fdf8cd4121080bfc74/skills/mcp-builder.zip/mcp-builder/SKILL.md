---
name: mcp-builder
description: Guide pour créer des serveurs MCP (Model Context Protocol) de haute qualité permettant aux LLM d'interagir avec des services externes via des outils bien conçus. À utiliser lors de la création de serveurs MCP pour intégrer des API ou des services externes, que ce soit en Python (FastMCP) ou en Node/TypeScript (MCP SDK).
license: Complete terms in LICENSE.txt
---

# Guide de développement de serveurs MCP

## Vue d'ensemble

Créez des serveurs MCP (Model Context Protocol) qui permettent aux LLM d'interagir avec des services externes grâce à des outils bien conçus. La qualité d'un serveur MCP se mesure à sa capacité à permettre aux LLM d'accomplir des tâches du monde réel.

---

# Processus

## 🚀 Flux de travail global

La création d'un serveur MCP de haute qualité comporte quatre phases principales :

### Phase 1 : Recherche approfondie et planification

#### 1.1 Comprendre la conception moderne de MCP

**Couverture d'API vs outils de workflow :**
Trouvez le juste équilibre entre une couverture complète des points de terminaison de l'API et des outils de workflow spécialisés. Les outils de workflow peuvent être plus pratiques pour des tâches spécifiques, tandis qu'une couverture complète offre aux agents la flexibilité nécessaire pour composer des opérations. Les performances varient selon le client : certains clients tirent parti de l'exécution de code combinant des outils de base, tandis que d'autres fonctionnent mieux avec des workflows de plus haut niveau. En cas de doute, donnez la priorité à une couverture d'API exhaustive.

**Nommage et découvrabilité des outils :**
Des noms d'outils clairs et descriptifs aident les agents à trouver rapidement les bons outils. Utilisez des préfixes cohérents (par ex., `github_create_issue`, `github_list_repos`) et un nommage orienté action.

**Gestion du contexte :**
Les agents bénéficient de descriptions d'outils concises et de la possibilité de filtrer/paginer les résultats. Concevez des outils qui renvoient des données ciblées et pertinentes. Certains clients prennent en charge l'exécution de code, ce qui peut aider les agents à filtrer et traiter les données efficacement.

**Messages d'erreur actionnables :**
Les messages d'erreur doivent orienter les agents vers des solutions avec des suggestions spécifiques et les étapes suivantes à suivre.

#### 1.2 Étudier la documentation du protocole MCP

**Parcourir la spécification MCP :**

Commencez par le sitemap pour trouver les pages pertinentes : `https://modelcontextprotocol.io/sitemap.xml`

Récupérez ensuite les pages spécifiques avec le suffixe `.md` pour obtenir le format Markdown (par ex., `https://modelcontextprotocol.io/specification/draft.md`).

Pages clés à consulter :
- Vue d'ensemble de la spécification et architecture
- Mécanismes de transport (streamable HTTP, stdio)
- Définitions des outils (tools), ressources (resources) et prompts

#### 1.3 Étudier la documentation des frameworks

**Stack recommandée :**
- **Langage** : TypeScript (support du SDK de haute qualité et bonne compatibilité dans de nombreux environnements d'exécution, par ex. MCPB. De plus, les modèles d'IA génèrent très bien le code TypeScript, profitant de sa large utilisation, de son typage statique et de ses bons outils de linting)
- **Transport** : Streamable HTTP pour les serveurs distants, en utilisant du JSON sans état (plus simple à mettre à l'échelle et à maintenir, par opposition aux sessions avec état et aux réponses en streaming). stdio pour les serveurs locaux.

**Charger la documentation des frameworks :**

- **Bonnes pratiques MCP** : [📋 Consulter les bonnes pratiques](./reference/mcp_best_practices.md) - Directives fondamentales

**Pour TypeScript (recommandé) :**
- **SDK TypeScript** : Utilisez WebFetch pour charger `https://raw.githubusercontent.com/modelcontextprotocol/typescript-sdk/main/README.md`
- [⚡ Guide TypeScript](./reference/node_mcp_server.md) - Motifs et exemples TypeScript

**Pour Python :**
- **SDK Python** : Utilisez WebFetch pour charger `https://raw.githubusercontent.com/modelcontextprotocol/python-sdk/main/README.md`
- [🐍 Guide Python](./reference/python_mcp_server.md) - Motifs et exemples Python

#### 1.4 Planifier votre implémentation

**Comprendre l'API :**
Examinez la documentation de l'API du service pour identifier les points de terminaison clés, les exigences d'authentification et les modèles de données. Utilisez la recherche web et WebFetch selon vos besoins.

**Sélection des outils :**
Donnez la priorité à une couverture d'API exhaustive. Listez les points de terminaison à implémenter, en commençant par les opérations les plus courantes.

---

### Phase 2 : Implémentation

#### 2.1 Configurer la structure du projet

Consultez les guides spécifiques à chaque langage pour la configuration du projet :
- [⚡ Guide TypeScript](./reference/node_mcp_server.md) - Structure de projet, package.json, tsconfig.json
- [🐍 Guide Python](./reference/python_mcp_server.md) - Organisation des modules, dépendances

#### 2.2 Implémenter l'infrastructure centrale

Créez les utilitaires partagés :
- Client API avec authentification
- Fonctions d'aide pour la gestion des erreurs
- Formatage des réponses (JSON/Markdown)
- Prise en charge de la pagination

#### 2.3 Implémenter les outils

Pour chaque outil :

**Schéma d'entrée (Input Schema) :**
- Utilisez Zod (TypeScript) ou Pydantic (Python)
- Incluez des contraintes et des descriptions claires
- Ajoutez des exemples dans les descriptions de champs

**Schéma de sortie (Output Schema) :**
- Définissez `outputSchema` lorsque c'est possible pour les données structurées
- Utilisez `structuredContent` dans les réponses d'outils (fonctionnalité du SDK TypeScript)
- Aide les clients à comprendre et traiter les sorties d'outils

**Description de l'outil :**
- Résumé concis de la fonctionnalité
- Descriptions des paramètres
- Schéma du type de retour

**Implémentation :**
- Async/await pour les opérations d'E/S
- Gestion appropriée des erreurs avec des messages actionnables
- Prise en charge de la pagination le cas échéant
- Renvoi à la fois de contenu texte et de données structurées lors de l'utilisation de SDK récents

**Annotations :**
- `readOnlyHint`: true/false
- `destructiveHint`: true/false
- `idempotentHint`: true/false
- `openWorldHint`: true/false

---

### Phase 3 : Revue et tests

#### 3.1 Qualité du code

Vérifiez les points suivants :
- Pas de duplication de code (principe DRY)
- Gestion des erreurs cohérente
- Couverture complète des types
- Descriptions d'outils claires

#### 3.2 Compilation et tests

**TypeScript :**
- Exécutez `npm run build` pour vérifier la compilation
- Testez avec MCP Inspector : `npx @modelcontextprotocol/inspector`

**Python :**
- Vérifiez la syntaxe : `python -m py_compile your_server.py`
- Testez avec MCP Inspector

Consultez les guides spécifiques au langage pour les approches de test détaillées et les listes de contrôle qualité.

---

### Phase 4 : Créer des évaluations

Après avoir implémenté votre serveur MCP, créez des évaluations complètes pour tester son efficacité.

**Chargez le [✅ Guide d'évaluation](./reference/evaluation.md) pour obtenir l'intégralité des directives d'évaluation.**

#### 4.1 Comprendre l'objectif des évaluations

Utilisez les évaluations pour vérifier si les LLM peuvent utiliser efficacement votre serveur MCP pour répondre à des questions réalistes et complexes.

#### 4.2 Créer 10 questions d'évaluation

Pour créer des évaluations efficaces, suivez le processus décrit dans le guide d'évaluation :

1. **Inspection des outils** : Listez les outils disponibles et comprenez leurs capacités
2. **Exploration du contenu** : Utilisez des opérations en LECTURE SEULE pour explorer les données disponibles
3. **Génération de questions** : Créez 10 questions complexes et réalistes
4. **Vérification des réponses** : Résolvez chaque question vous-même pour vérifier les réponses

#### 4.3 Exigences des évaluations

Assurez-vous que chaque question est :
- **Indépendante** : Ne dépend pas d'autres questions
- **En lecture seule** : Seules des opérations non destructives sont nécessaires
- **Complexe** : Nécessite plusieurs appels d'outils et une exploration approfondie
- **Réaliste** : Basée sur des cas d'usage réels qui intéressent les humains
- **Vérifiable** : Réponse unique et claire qui peut être vérifiée par comparaison de chaînes
- **Stable** : La réponse ne change pas au fil du temps

#### 4.4 Format de sortie

Créez un fichier XML avec cette structure :

```xml
<evaluation>
  <qa_pair>
    <question>Find discussions about AI model launches with animal codenames. One model needed a specific safety designation that uses the format ASL-X. What number X was being determined for the model named after a spotted wild cat?</question>
    <answer>3</answer>
  </qa_pair>
<!-- More qa_pairs... -->
</evaluation>
```

---

# Fichiers de référence

## 📚 Bibliothèque de documentation

Chargez ces ressources selon vos besoins pendant le développement :

### Documentation centrale de MCP (À charger en premier)
- **Protocole MCP** : Commencez par le sitemap à `https://modelcontextprotocol.io/sitemap.xml`, puis récupérez les pages spécifiques avec le suffixe `.md`
- [📋 Bonnes pratiques MCP](./reference/mcp_best_practices.md) - Directives universelles MCP incluant :
  - Conventions de nommage des serveurs et des outils
  - Directives sur le format des réponses (JSON vs Markdown)
  - Bonnes pratiques de pagination
  - Sélection du transport (streamable HTTP vs stdio)
  - Normes de sécurité et de gestion des erreurs

### Documentation des SDK (À charger pendant la phase 1/2)
- **SDK Python** : Récupérer depuis `https://raw.githubusercontent.com/modelcontextprotocol/python-sdk/main/README.md`
- **SDK TypeScript** : Récupérer depuis `https://raw.githubusercontent.com/modelcontextprotocol/typescript-sdk/main/README.md`

### Guides d'implémentation par langage (À charger pendant la phase 2)
- [🐍 Guide d'implémentation Python](./reference/python_mcp_server.md) - Guide complet Python/FastMCP avec :
  - Motifs d'initialisation du serveur
  - Exemples de modèles Pydantic
  - Enregistrement des outils avec `@mcp.tool`
  - Exemples complets et fonctionnels
  - Liste de contrôle qualité

- [⚡ Guide d'implémentation TypeScript](./reference/node_mcp_server.md) - Guide complet TypeScript avec :
  - Structure de projet
  - Motifs de schémas Zod
  - Enregistrement des outils avec `server.registerTool`
  - Exemples complets et fonctionnels
  - Liste de contrôle qualité

### Guide d'évaluation (À charger pendant la phase 4)
- [✅ Guide d'évaluation](./reference/evaluation.md) - Guide complet de création d'évaluations avec :
  - Directives de création de questions
  - Stratégies de vérification des réponses
  - Spécifications du format XML
  - Exemples de questions et réponses
  - Exécution d'une évaluation avec les scripts fournis
