---
name: ig-plan
description: >-
  Planifier la semaine sur Instagram - quoi publier, sous quel format, quand et
  avec qui interagir. À utiliser lorsque l'utilisateur dit « planifie ma semaine »,
  « que devrais-je publier », « calendrier de contenu », « je n'ai rien à publier »,
  ou souhaite un planning de publication et une liste d'engagement.
---

# ig-plan

La tour de contrôle. Tout le reste dans ce pack exécute ; ceci décide de ce qui
est exécuté. Lancez-le une fois par semaine, le même jour.

## Entrée

Si `~/.claude/instagram/voice.md`, `swipe.md` et `log.md` existent, lisez-les.
Le fichier swipe correspond aux propres observations de l'utilisateur issues de
`/ig-viral` concernant les formules qui fonctionnent dans sa niche en ce moment,
et il prévaut sur tout le reste dans ce fichier. Le journal de bord (log) évite
que le plan ne répète un thème de la dernière quinzaine.

S'ils n'existent pas, demandez quatre éléments et notez-les :

1. Ce que vend l'utilisateur, et à qui.
2. Les trois ou quatre thèmes pour lesquels il souhaite être reconnu.
3. Ce qui s'est réellement passé cette semaine : un appel client, un chiffre,
   une erreur, quelque chose qu'il a conçu, un débat qu'il a eu. C'est de là
   que viennent les publications.
4. Dix comptes auprès desquels il est pertinent d'être visible.

## Que publier

Quatre à cinq publications par semaine, dont au moins trois Reels. Les Reels sont
le seul format sur Instagram qui permet d'atteindre de manière fiable des personnes
qui ne suivent pas le compte. Les carrousels approfondissent la relation avec
ceux qui le suivent déjà. Les Stories sont quotidiennes et se planifient séparément.

Variez au cours de la semaine, jamais deux du même type consécutivement :

| type | répartition | rôle |
| --- | --- | --- |
| **Proof** | 1 par semaine | quelque chose qui s'est produit, avec un chiffre. Reel. |
| **Teach** | 1 à 2 par semaine | une chose que le spectateur peut appliquer aujourd'hui. Reel ou carrousel. |
| **Opinion** | 1 par semaine | une prise de position qui pourrait vous faire perdre des abonnés. Reel. |
| **Story** | 1 tous les 15 jours | une scène avec un coût réel. Reel. |
| **Offer** | 1 tous les 15 jours | ce que vous vendez, formulé simplement, sans détour. Carrousel ou stories. |

Pour chaque créneau, indiquez : le thème, l'angle précis tiré des événements réels
de cette semaine, le format, ainsi que le numéro de la formule d'accroche provenant
de `ig-reel/hooks.json`. Pas un sujet vague, un angle précis. « L'IA » n'est pas
un plan. « La proposition commerciale perdue à cause d'un tiret cadratin dans le
brouillon » est un Reel.

## Quand publier

Publiez lorsque l'audience de l'utilisateur est réveillée et n'est pas au travail.
Pour la plupart des audiences grand public, cela correspond au début de soirée,
heure locale ; pour une audience professionnelle, tôt le matin.

Mais formulez-le clairement : **l'heure compte beaucoup moins que les deux premières
secondes.** Instagram continuera de montrer un Reel pendant des jours s'il est
performant, et enterrera un Reel publié au moment idéal s'il ne l'est pas. Si
l'utilisateur cherche à optimiser ses heures de publication avant que ses accroches
ne fonctionnent, il ne concentre pas ses efforts au bon endroit, et vous devez le
lui faire savoir.

Ajustez les heures en fonction du fuseau horaire de l'audience, et non de celui
de l'utilisateur, s'ils sont différents.

## La session d'engagement, qui n'est pas facultative

20 minutes par jour, avant de publier, et non après. Constituez une liste de 10 :

- **5 visibilité** - des comptes dont l'audience intéresse l'utilisateur, où un
  bon commentaire sera remarqué. Commentez tôt, avant que le fil n'atteigne 200
  réponses.
- **3 pairs** - même taille de compte, même domaine. C'est le groupe qui rend
  la pareille.
- **2 acheteurs** - des personnes susceptibles d'acheter. Commentez pendant des
  semaines avant tout message privé, et ne pitchez jamais dans un commentaire.

Transmettez la liste à `/ig-comment`.

## Sortie

```
WEEK OF SEP 15

MON  engage only  (20 min, list below)
TUE  7:30pm  REEL      PROOF    #5  Time Collapse   - 5hr proposal to 20 min
WED  stories only + engage
THU  7:00pm  CAROUSEL  TEACH    Job B caption       - the 4-slide clause breakdown
FRI  7:30pm  REEL      OPINION  #2  Negative Command - stop doing discovery calls
SAT  -
SUN  6:00pm  REEL      STORY    #21 Mid-Sentence    - the refund email

STORIES  every day, 3 to 5 frames, question box on Thursday.

ENGAGE  (5 reach / 3 peers / 2 buyers)
  ...

Say "write Tuesday" and I will draft it.
```

Écrivez le plan dans `~/.claude/instagram/plan.md` pour que les autres compétences
puissent le lire. Rien n'est programmé ni publié nulle part. Il s'agit d'un plan,
et c'est l'utilisateur qui l'exécute.
