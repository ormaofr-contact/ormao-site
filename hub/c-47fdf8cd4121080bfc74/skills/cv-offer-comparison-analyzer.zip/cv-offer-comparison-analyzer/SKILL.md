---
name: offer-comparison-analyzer
description: Comparez plusieurs offres d'emploi côte à côte avec une analyse de la rémunération globale
---

# Analyseur de comparaison d'offres

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A plusieurs offres d'emploi à comparer
- Doit évaluer la rémunération globale
- Veut prendre une décision professionnelle fondée sur des données
- Pèse différentes opportunités
- Mentionne : "compare offers", "multiple offers", "which job", "offer comparison", "deciding between jobs"

## Capacités principales

- Comparer la rémunération globale entre plusieurs offres
- Évaluer les facteurs non financiers
- Créer des grilles de décision pondérées
- Calculer la valeur réelle d'une offre
- Identifier les coûts et avantages cachés
- Guider le processus de prise de décision

## Le défi de la comparaison

**Le problème :** 
Comparer des offres est difficile en raison de :
- Structures de rémunération différentes
- Importance des facteurs non financiers
- Avantages et coûts cachés
- Facteurs émotionnels qui altèrent le jugement
- Asymétrie d'information

**La solution :**
Un cadre de comparaison systématique qui prend en compte :
- La rémunération globale (pas seulement le salaire)
- Le potentiel d'évolution de carrière
- Les facteurs d'équilibre vie professionnelle/vie personnelle
- L'évaluation des risques
- L'alignement avec les valeurs personnelles

## Calculateur de rémunération globale

### Éléments à inclure

**Rémunération en espèces :**
- Salaire de base
- Prime à la signature (prime unique)
- Prime annuelle (% cible)
- Commissions (pour les postes commerciaux)
- Aide à la réinstallation

**Rémunération en actions :**
- Stock-options (valeur = cours actuel - prix d'exercice)
- Actions gratuites / RSU (valeur = cours actuel × actions)
- Calendrier d'acquisition (vesting schedule)
- Perspectives de réattribution (refresh grants)

**Valeur des avantages sociaux :**
- Assurance santé (contribution de l'employeur)
- Abondement 401(k) / plan d'épargne retraite
- Cotisations HSA/FSA
- Assurance vie/invalidité
- Autres couvertures d'assurance

**Valeur des avantages annexes :**
- Jours de congés payés (possibilité d'attribuer une valeur financière)
- Télétravail (économies sur les coûts de transport)
- Budget de développement professionnel
- Indemnité pour l'équipement/le bureau
- Repas, salle de sport, etc.

### Calculation Template

```
OFFER A - TOTAL COMPENSATION

CASH
Base Salary:                    $150,000
Signing Bonus (year 1 only):     $25,000
Target Bonus (15%):              $22,500
--------------------------------
Cash Compensation:              $197,500 (year 1)
                               $172,500 (ongoing)

EQUITY
RSU Grant: $200,000 over 4 years
Annual Value:                    $50,000
--------------------------------
Equity Compensation:             $50,000/year

BENEFITS
401(k) Match (4%):               $6,000
Health Insurance:                $15,000 (employer portion)
HSA Contribution:                 $1,000
--------------------------------
Benefits Value:                  $22,000/year

PERKS
Vacation: 20 days (vs 10 standard)
  Extra 10 days × ~$575/day:      $5,750 value
Remote Work Savings:              $3,000 (commute, lunch)
Professional Dev:                 $2,000 budget
--------------------------------
Perks Value:                     $10,750/year

TOTAL YEAR 1:        $280,250
TOTAL ONGOING:       $255,250/year
```

## Modèle de comparaison côte à côte

```markdown
# OFFER COMPARISON

|                          | Company A | Company B | Notes |
|--------------------------|-----------|-----------|-------|
| **CASH**                 |           |           |       |
| Base Salary              | $150,000  | $160,000  | B +$10K |
| Signing Bonus            | $25,000   | $10,000   | A +$15K |
| Target Bonus             | 15%       | 10%       | A +$6.5K |
| **Cash Total (Yr 1)**    | $197,500  | $186,000  | A +$11.5K |
|                          |           |           |       |
| **EQUITY**               |           |           |       |
| Grant Value (4yr)        | $200,000  | $300,000  | B +$100K |
| Annual Equity            | $50,000   | $75,000   | B +$25K |
|                          |           |           |       |
| **BENEFITS**             |           |           |       |
| 401(k) Match             | 4%        | 6%        | B +$3.2K |
| Health Insurance         | Good      | Premium   | B better |
| PTO                      | 20 days   | Unlimited | Varies |
|                          |           |           |       |
| **TOTAL COMP (Yr 1)**    | $280,250  | $285,000  | B +$4.7K |
| **TOTAL COMP (Ongoing)** | $255,250  | $275,000  | B +$19.7K |
```

## Cadre d'évaluation des facteurs non financiers

### Évolution de carrière (Poids : Élevé)

**Questions à considérer :**
- Quel poste offre le plus d'opportunités d'apprentissage ?
- Quelle entreprise/marque valorisera le plus vos futures recherches d'emploi ?
- Laquelle offre les meilleures perspectives de promotion ?
- Laquelle propose le plus de responsabilités/d'envergure ?
- Quel manager vous fera le plus progresser ?

**Notation :**
```
Company A: Growth Score
- Learning opportunity: 8/10
- Brand/resume value: 7/10
- Promotion potential: 6/10
- Scope: 8/10
Average: 7.25/10

Company B: Growth Score
- Learning opportunity: 7/10
- Brand/resume value: 9/10
- Promotion potential: 8/10
- Scope: 7/10
Average: 7.75/10
```

### Équilibre vie professionnelle/vie personnelle (Poids : Personnel)

**Facteurs :**
- Volume horaire attendu
- Flexibilité télétravail/hybride
- Culture relative à la prise effective des congés
- Exigences d'astreinte
- Déplacements requis
- Temps de trajet

### Équipe et culture (Poids : Élevé)

**Facteurs :**
- Qualité du manager (crucial !)
- Santé et dynamique de l'équipe
- Adéquation avec la culture d'entreprise
- Considérations de DEI (diversité, équité, inclusion)
- Stabilité et croissance de l'entreprise
- Alignement des valeurs

### Évaluation des risques (Poids : Moyen)

**Startup vs Entreprise établie :**
- Visibilité financière restante (runway)
- Position sur le marché
- Trajectoire de l'entreprise
- Risque lié aux actions (peuvent valoir 0 $)

**Questions :**
- Que se passe-t-il si l'entreprise rencontre des difficultés ?
- À quel point ce poste est-il stable ?
- Quelle est la politique d'indemnités de départ ?

## Matrice de décision pondérée

### Étape 1 : Définissez vos priorités

```
Factor                  Weight
------------------------------------
Total Compensation       25%
Career Growth            25%
Work-Life Balance        20%
Team & Culture           20%
Location/Commute         10%
------------------------------------
Total:                   100%
```

### Étape 2 : Notez chaque facteur

```
                    Company A   Company B
Factor              Score (1-10)
------------------------------------
Compensation        7           8
Career Growth       7           8
Work-Life           8           6
Team & Culture      9           7
Location            8           5
```

### Étape 3 : Calculez le score pondéré

```
Company A:
(7 × 0.25) + (7 × 0.25) + (8 × 0.20) + (9 × 0.20) + (8 × 0.10)
= 1.75 + 1.75 + 1.60 + 1.80 + 0.80
= 7.70

Company B:
(8 × 0.25) + (8 × 0.25) + (6 × 0.20) + (7 × 0.20) + (5 × 0.10)
= 2.00 + 2.00 + 1.20 + 1.40 + 0.50
= 7.10

Result: Company A scores higher (7.70 vs 7.10)
```

## Signaux d'alarme à surveiller

### Dans l'offre

- ❌ Formulation vague sur les primes (« jusqu'à 20 % »)
- ❌ Actions sans perspective de liquidité
- ❌ Salaire de base élevé mais pas d'actions (en startup)
- ❌ Période d'acquisition initiale (cliff) supérieure à 1 an
- ❌ Absence d'accélération d'acquisition (vesting acceleration)
- ❌ Clauses de non-concurrence restrictives
- ❌ Promesses verbales non confirmées par écrit

### Concernant l'entreprise

- ❌ Rotation élevée du personnel (à vérifier sur LinkedIn)
- ❌ Licenciements ou réorganisations récents
- ❌ Manager qui semble désengagé
- ❌ Schémas récurrents d'avis négatifs sur Glassdoor
- ❌ Inquiétudes sur le financement
- ❌ Absence de trajectoire claire vers la rentabilité

### Concernant le poste

- ❌ Responsabilités vagues
- ❌ Le poste semble changer au fil des entretiens
- ❌ Signaux d'alerte sur la raison pour laquelle le poste est vacant
- ❌ Aucune perspective d'évolution abordée
- ❌ Attentes irréalistes fixées

## Questions à se poser

### Le test de l'intuition
- Quelle offre m'enthousiasme le plus ?
- Laquelle regretterais-je de ne pas avoir choisie ?
- Laquelle correspond à mes objectifs à 5 ans ?
- De laquelle parlerais-je avec fierté à mes amis ?

### Le test du lundi matin
- Pour quel travail ai-je envie de me lever ?
- Avec quelle équipe ai-je envie de collaborer ?
- Quels problèmes ai-je envie de résoudre ?

### Le test de l'apprentissage
- Où vais-je le plus progresser ?
- Quelles compétences vais-je développer ?
- Qu'est-ce qui sera le plus valorisant sur mon CV dans 3 ans ?

### Le test du risque
- Quels sont les inconvénients de chaque option ?
- Quel échec regretterais-je le plus ?
- Quel est mon plan B pour chacune ?

## Format de sortie

Lors de la comparaison d'offres :

```markdown
# JOB OFFER COMPARISON

## Offers Being Compared
- **Offer A:** [Role] at [Company]
- **Offer B:** [Role] at [Company]

## Total Compensation Comparison

| Component | Offer A | Offer B | Difference |
|-----------|---------|---------|------------|
| Base | $X | $X | |
| Bonus | $X | $X | |
| Equity (annual) | $X | $X | |
| Benefits | $X | $X | |
| **Year 1 Total** | $X | $X | |
| **Ongoing Total** | $X | $X | |

## Non-Monetary Comparison

| Factor | Offer A | Offer B | Notes |
|--------|---------|---------|-------|
| Career Growth | X/10 | X/10 | |
| Work-Life | X/10 | X/10 | |
| Team/Culture | X/10 | X/10 | |
| Risk Level | X/10 | X/10 | |

## Weighted Analysis

Using your priorities:
- Offer A Score: X.XX
- Offer B Score: X.XX

## Key Differences
1. [Key difference 1]
2. [Key difference 2]
3. [Key difference 3]

## Recommendation

Based on your stated priorities of [X, Y, Z], **Offer [A/B]** appears to be the stronger choice because:
- [Reason 1]
- [Reason 2]
- [Reason 3]

## Things to Clarify Before Deciding
- [ ] [Question for Company A]
- [ ] [Question for Company B]

## Negotiation Opportunities
- [Opportunity 1]
- [Opportunity 2]
```

## Liste de contrôle pour la comparaison

- ✅ Calcul de la rémunération globale (pas seulement le salaire de base)
- ✅ Intégration des actions avec une valorisation réaliste
- ✅ Prise en compte de la valeur des avantages sociaux
- ✅ Évaluation des implications fiscales
- ✅ Pondération des facteurs non financiers
- ✅ Évaluation du potentiel d'évolution de carrière
- ✅ Évaluation de la qualité de l'équipe et du manager
- ✅ Vérification de la stabilité et des risques de l'entreprise
- ✅ Alignement avec les priorités personnelles
- ✅ Validation par l'intuition
