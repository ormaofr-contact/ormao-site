---
name: resume-quantifier
description: Identifier les opportunités d'ajouter des métriques et estimer des chiffres lorsque les données exactes ne sont pas disponibles
---

# Quantificateur de CV

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- A besoin d'ajouter des métriques et des chiffres à son CV
- A des puces sans résultats quantifiables
- Ne sait pas quels chiffres inclure
- Dit qu'il « n'a pas de métriques » ou « ne peut pas mesurer l'impact »
- Mentionne : « ajouter des métriques », « quantifier », « ajouter des chiffres », « mesurer l'impact », « pas de données »

## Capacités principales

- Trouver des métriques cachées dans n'importe quelle expérience
- Estimer des chiffres lorsque les données exactes ne sont pas disponibles
- Créer des comparaisons avant/après
- Identifier des points d'impact mesurables
- Transformer des affirmations vagues en réalisations quantifiées
- Guider les utilisateurs pour découvrir leurs métriques

## Pourquoi la quantification est importante

**Le problème :**
- « Gestion de projets » vs « Gestion de 12 projets d'une valeur de 2 M$ »
- « Amélioration des processus » vs « Réduction du temps de cycle de 40 % »
- « Assistance aux clients » vs « Résolution de plus de 50 tickets par jour avec un taux de satisfaction de 98 % »

**Les études montrent que :**
- Les CV contenant des chiffres retiennent 30 % d'attention en plus
- Les puces quantifiées sont 40 % plus mémorables
- Les chiffres apportent de la crédibilité et donnent une idée de l'échelle

## Le cadre de quantification

### Catégories de métriques

**1. Argent**
- Chiffre d'affaires généré
- Coûts réduits / économisés
- Budget géré
- Montant des transactions conclues
- Marges bénéficiaires améliorées

**2. Temps**
- Heures économisées
- Temps de cycle réduit
- Durée du projet
- Délais de réponse
- Délai de mise sur le marché

**3. Pourcentages**
- Taux de croissance
- Pourcentages d'amélioration
- Gains d'efficacité
- Réduction des erreurs
- Taux de conversion

**4. Volume / Échelle**
- Nombre de clients / utilisateurs
- Projets gérés
- Taille de l'équipe
- Transactions traitées
- Articles produits

**5. Qualité**
- Scores de satisfaction
- Taux d'erreur
- Taux d'exactitude
- Taux de conformité
- Respect des SLA

**6. Fréquence**
- Par jour / semaine / mois
- Totaux annuels
- Fréquence des réunions
- Cycles de reporting

## Trouver des métriques cachées

### Les questions d'exploration

Pour chaque expérience, demandez :

**Questions relatives à l'échelle :**
- Combien de personnes / projets / clients ?
- Quel était le budget / chiffre d'affaires concerné ?
- Quelle était la taille de l'équipe ?
- Combien de sites / régions ?

**Questions relatives à l'impact :**
- Qu'est-ce qui a changé grâce à votre travail ?
- Que se serait-il passé sans vous ?
- Quels problèmes avez-vous résolus ?
- Qu'est-ce qui est devenu meilleur / plus rapide / moins cher ?

**Questions relatives aux comparaisons :**
- Comment était la situation avant vs après ?
- Comment vous situiez-vous par rapport aux autres / aux résultats précédents ?
- Quel était le point de référence que vous avez amélioré ?

### Exploration des métriques par fonction

**Ventes :**
- Pourcentage d'atteinte des objectifs
- Chiffre d'affaires généré
- Nombre de contrats conclus
- Montant moyen des transactions
- Pipeline généré
- Nouveaux comptes acquis
- Taux de rétention

**Marketing :**
- Pistes (leads) générées
- ROI des campagnes
- Taux d'engagement
- Croissance du nombre d'abonnés
- Augmentation du trafic sur le site web
- Taux de conversion
- Métriques de notoriété de la marque

**Service client :**
- Tickets résolus par jour
- Score de satisfaction client
- Temps de réponse moyen
- Taux de résolution au premier contact
- Contribution au score NPS

**Opérations :**
- Améliorations de l'efficacité
- Réductions de coûts
- Temps de cycle des processus
- Réductions du taux d'erreur
- Augmentations du débit / volume traité

**Ingénierie :**
- Disponibilité du système (uptime)
- Améliorations des performances
- Taux de résolution des bugs
- Fréquence des déploiements
- Couverture du code

**Gestion de projet :**
- Nombre de projets
- Tailles des budgets
- Tailles des équipes
- Taux de livraison dans les délais
- Parties prenantes gérées

**RH / Administration :**
- Nombre de recrutements
- Délai de recrutement
- Scores de satisfaction des employés
- Taux de complétion des formations
- Efficacité de l'intégration (onboarding)

## Techniques d'estimation

Lorsque vous ne disposez pas de chiffres exacts :

### Estimation prudente

**Principe :** Estimer à la baisse pour préserver la crédibilité

**Exemple :**
- Vous pensez avoir économisé 100 heures/mois → indiquez « plus de 75 heures »
- Vous pensez que la croissance a été de 50 % → indiquez « ~40 % »
- Vous pensez avoir servi 500 clients → indiquez « plus de 400 »

### Estimation par fourchette

**Format :** « X-Y » ou « de X à Y »

**Exemples :**
- « Encadrement d'une équipe de 8 à 12 personnes »
- « Génération de 100 k$ à 150 k$ de chiffre d'affaires »
- « Économie de 20 à 30 heures par semaine »

### Seuil minimal

**Format :** « X+ » ou « au moins X »

**Exemples :**
- « Plus de 100 clients servis quotidiennement »
- « Gestion d'au moins 15 projets simultanés »
- « Génération de plus de 500 k$ de chiffre d'affaires annuel »

### Pourcentage d'activité

**Format :** Calculer à partir de totaux connus

**Exemple :**
- L'entreprise comptait 1 000 clients → Vous en gériez 20 % → « Gestion de 200 comptes clients »
- L'équipe comptait 10 personnes → Vous en supervisiez 4 → « Supervision de 40 % de l'équipe »

### Calcul basé sur le temps

**Format :** Partir de la fréquence pour reconstituer le total

**Exemple :**
- Rendez-vous avec 5 clients/semaine × 50 semaines = « Conseil auprès de plus de 250 clients par an »
- Traitement de 30 factures/jour × 250 jours = « Traitement de plus de 7 500 factures par an »

## Modèles de quantification

### Modèle Avant et Après
```
"Improved [X] from [before number] to [after number], resulting in [Y]% improvement"

Example:
"Improved page load time from 8 seconds to 2 seconds, resulting in 75% reduction and 20% increase in user engagement"
```

### Modèle Échelle
```
"[Verb] [number] [things], resulting in [impact]"

Example:
"Managed 25 concurrent projects worth $3M, delivering 95% on-time with zero budget overruns"
```

### Modèle Volume + Impact
```
"Processed [number] [items] per [time period], achieving [quality metric]"

Example:
"Resolved 50+ customer tickets daily, maintaining 98% satisfaction rating and 4-hour average response time"
```

### Modèle Comparaison
```
"Ranked #[X] out of [Y] in [metric], [context]"

Example:
"Ranked #2 out of 45 sales representatives nationally, generating $3.2M in annual revenue"
```

## Situations courantes : « Je n'ai aucun chiffre »

### Situation 1 : « Je n'étais qu'un membre parmi d'autres dans une équipe »

**Solution :** Concentrez-vous sur VOTRE contribution

**Exemple :**
- « Membre de l'équipe qui a lancé le produit » →
- « Contribution à hauteur de 40 % du code front-end pour le lancement d'un produit ayant atteint 100 000 utilisateurs »

### Situation 2 : « Je n'ai pas accès aux métriques de l'entreprise »

**Solution :** Quantifiez les activités et les contributions directes

**Exemple :**
- « Soutien à l'équipe commerciale » →
- « Création de plus de 50 présentations commerciales et gestion d'un pipeline de plus de 200 prospects dans Salesforce »

### Situation 3 : « Mon poste ne produisait pas de résultats mesurables »

**Solution :** Mesurez le travail en lui-même

**Exemple :**
- « Rédaction de documentation » →
- « Production d'une documentation technique de 75 pages réduisant le temps d'intégration des nouvelles recrues de 2 semaines »

### Situation 4 : « Les résultats étaient confidentiels »

**Solution :** Utilisez des pourcentages ou des fourchettes

**Exemple :**
- « Augmentation du chiffre d'affaires » →
- « Croissance du chiffre d'affaires de plus de 40 % d'une année sur l'autre » ou « Contribution à une croissance de X à Y millions de dollars »

### Situation 5 : « J'occupais un poste débutant avec un impact limité »

**Solution :** Quantifiez l'apprentissage, le débit de traitement, la précision

**Exemple :**
- « Saisie de données » →
- « Traitement de plus de 200 dossiers par jour avec un taux d'exactitude de 99,5 %, dépassant la moyenne de l'équipe de 15 % »

## Format de sortie

Lors de la quantification d'un CV :

```markdown
# RESUME QUANTIFICATION

## Analysis Summary
**Bullets without numbers:** X
**Bullets with numbers:** Y
**Target:** 100% of bullets should have at least one metric

## Quantified Bullets

### Original Bullet #1:
"Managed customer accounts"

### Questions to Find Metrics:
- How many accounts? → [User answer: ~40]
- What was the revenue? → [User answer: ~$2M]
- What results did you achieve? → [User answer: retained most]

### Quantified Version:
"Managed portfolio of 40 enterprise accounts representing $2M ARR, achieving 95% retention rate"

### Metrics Added:
- Account count: 40
- Revenue: $2M ARR
- Retention: 95%

---

### Original Bullet #2:
[Continue for each bullet]

## Estimation Notes
- [Metric]: Estimated based on [reasoning]
- [Metric]: Conservative estimate using [method]

## Remaining Questions
- [Questions to ask user for missing information]
```

## Liste de contrôle de la qualité de la quantification

Pour chaque puce :
- ✅ Comporte au moins UN chiffre
- ✅ Le chiffre est pertinent (pas n'importe quel chiffre)
- ✅ L'échelle est claire (que signifie ce chiffre ?)
- ✅ L'estimation est prudente et défendable
- ✅ Le chiffre renforce la crédibilité, sans créer de confusion
- ✅ Vous êtes capable d'expliquer ce chiffre lors d'un entretien

## Chiffres à éviter

- ❌ Les chiffres qui vous mettent en défaut
- ❌ Les chiffres que vous ne pouvez pas expliquer ou défendre
- ❌ Les chiffres qui révèlent des informations confidentielles
- ❌ Les chiffres exagérés ou gonflés
- ❌ Les chiffres sans contexte (ex. : « augmenté de 300 % » sans base de référence)
- ❌ Trop de chiffres dans une seule puce (2 à 3 maximum)

## Principe clé

**Chaque puce peut être quantifiée.** Si vous pensez que votre travail ne peut pas être mesuré, c'est simplement que vous n'avez pas encore posé les bonnes questions.

Le but n'est pas d'afficher des chiffres impressionnants, mais d'avoir des chiffres PRÉCIS qui illustrent l'étendue et l'impact de votre travail.
