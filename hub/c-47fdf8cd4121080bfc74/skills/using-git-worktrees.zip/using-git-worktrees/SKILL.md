---
name: using-git-worktrees
description: À utiliser lors du démarrage d'une fonctionnalité nécessitant une isolation de l'espace de travail actuel ou avant d'exécuter des plans d'implémentation - garantit l'existence d'un espace de travail isolé via des outils natifs ou la solution de repli git worktree
---

# Utilisation des Git Worktrees

## Aperçu

Assurez-vous que le travail se déroule dans un espace de travail isolé. Privilégiez les outils de worktree natifs de votre plateforme. Ne recourez aux worktrees git manuels que si aucun outil natif n'est disponible.

**Principe fondamental :** Détectez d'abord une isolation existante. Utilisez ensuite les outils natifs. Puis rabattez-vous sur git. Ne luttez jamais contre le harness.

**Annoncez au démarrage :** "J'utilise la compétence using-git-worktrees pour configurer un espace de travail isolé."

## Étape 0 : Détecter l'isolation existante

**Avant de créer quoi que ce soit, vérifiez si vous êtes déjà dans un espace de travail isolé.**

```bash
GIT_DIR=$(cd "$(git rev-parse --git-dir)" 2>/dev/null && pwd -P)
GIT_COMMON=$(cd "$(git rev-parse --git-common-dir)" 2>/dev/null && pwd -P)
BRANCH=$(git branch --show-current)
```

**Garde-fou pour les sous-modules :** `GIT_DIR != GIT_COMMON` est également vrai à l'intérieur des sous-modules git. Avant de conclure que vous êtes « déjà dans un worktree », vérifiez que vous n'êtes pas dans un sous-module :

```bash
# Si ceci renvoie un chemin, vous êtes dans un sous-module, pas un worktree — traitez comme un dépôt normal
git rev-parse --show-superproject-working-tree 2>/dev/null
```

**Si `GIT_DIR != GIT_COMMON` (et pas un sous-module) :** Vous êtes déjà dans un worktree lié. Passez directement à l'Étape 2 (Configuration du projet). Ne créez PAS un autre worktree.

Indiquez l'état de la branche :
- Sur une branche : "Déjà dans un espace de travail isolé à `<path>` sur la branche `<name>`."
- HEAD détachée : "Déjà dans un espace de travail isolé à `<path>` (HEAD détachée, gérée en externe). Création de branche requise au moment de finaliser."

**Si `GIT_DIR == GIT_COMMON` (ou dans un sous-module) :** Vous êtes dans un clone de dépôt normal.

L'utilisateur a-t-il déjà indiqué sa préférence de worktree dans vos instructions ? Si ce n'est pas le cas, demandez son consentement avant de créer un worktree :

> "Souhaitez-vous que je configure un worktree isolé ? Cela protège votre branche actuelle contre les modifications."

Respectez toute préférence déjà déclarée sans poser la question. Si l'utilisateur refuse son consentement, travaillez sur place et passez à l'Étape 2.

## Étape 1 : Créer un espace de travail isolé

**Vous disposez de deux mécanismes. Essayez-les dans cet ordre.**

### 1a. Outils de worktree natifs (recommandé)

L'utilisateur a demandé un espace de travail isolé (consentement de l'Étape 0). Disposez-vous déjà d'un moyen pour créer un worktree ? Il peut s'agir d'un outil nommé `EnterWorktree`, `WorktreeCreate`, d'une commande `/worktree` ou d'un drapeau `--worktree`. Si oui, utilisez-le et passez à l'Étape 2.

Les outils natifs gèrent automatiquement le placement du répertoire, la création de la branche et le nettoyage. Utiliser `git worktree add` alors que vous disposez d'un outil natif génère un état fantôme que votre harness ne peut ni voir ni gérer.

Ne passez à l'Étape 1b que si vous ne disposez d'aucun outil de worktree natif.

### 1b. Solution de repli : Git Worktree

**N'utilisez cette option que si l'Étape 1a ne s'applique pas** — aucun outil de worktree natif n'est disponible. Créez un worktree manuellement en utilisant git.

#### Sélection du répertoire

Suivez cet ordre de priorité. La préférence explicite de l'utilisateur l'emporte toujours sur l'état observé du système de fichiers.

1. **Vérifiez vos instructions pour une préférence de répertoire de worktree déclarée.** Si l'utilisateur en a déjà spécifié un, utilisez-le sans demander.

2. **Vérifiez la présence d'un répertoire de worktree local au projet existant :**
   ```bash
   ls -d .worktrees 2>/dev/null     # Préféré (masqué)
   ls -d worktrees 2>/dev/null      # Alternative
   ```
   S'il existe, utilisez-le. Si les deux existent, `.worktrees` l'emporte.

3. **En l'absence de toute autre consigne**, utilisez par défaut `.worktrees/` à la racine du projet.

#### Vérification de sécurité (répertoires locaux au projet uniquement)

**Vous DEVEZ vérifier que le répertoire est ignoré avant de créer le worktree :**

```bash
git check-ignore -q .worktrees 2>/dev/null || git check-ignore -q worktrees 2>/dev/null
```

**S'il n'est PAS ignoré :** Ajoutez-le à .gitignore, validez le changement (commit), puis poursuivez.

**Pourquoi c'est essentiel :** Empêche d'ajouter accidentellement le contenu du worktree au dépôt par un commit.

#### Créer le worktree

```bash
# Déterminer le chemin en fonction de l'emplacement choisi
path="$LOCATION/$BRANCH_NAME"

git worktree add "$path" -b "$BRANCH_NAME"
cd "$path"
```

**Repli en cas de sandbox :** Si `git worktree add` échoue avec une erreur de permission (refus du sandbox), informez l'utilisateur que le sandbox a bloqué la création du worktree et que vous travaillez dans le répertoire courant à la place. Exécutez ensuite la configuration et les tests de référence sur place.

## Étape 2 : Configuration du projet

Détectez automatiquement et exécutez la configuration appropriée :

```bash
# Node.js
if [ -f package.json ]; then npm install; fi

# Rust
if [ -f Cargo.toml ]; then cargo build; fi

# Python
if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
if [ -f pyproject.toml ]; then poetry install; fi

# Go
if [ -f go.mod ]; then go mod download; fi
```

## Étape 3 : Vérifier l'état de référence propre

Exécutez les tests pour vous assurer que l'espace de travail démarre sur une base saine :

```bash
# Utilisez la commande appropriée au projet
npm test / cargo test / pytest / go test ./...
```

**Si les tests échouent :** Signalez les échecs, demandez s'il faut continuer ou investiguer.

**Si les tests réussissent :** Signalez que vous êtes prêt.

### Rapport

```
Worktree ready at <full-path>
Tests passing (<N> tests, 0 failures)
Ready to implement <feature-name>
```

## Référence rapide

| Situation | Action |
|-----------|--------|
| Déjà dans un worktree lié | Sauter la création (Étape 0) |
| Dans un sous-module | Traiter comme un dépôt normal (garde-fou Étape 0) |
| Outil de worktree natif disponible | L'utiliser (Étape 1a) |
| Aucun outil natif | Repli sur git worktree (Étape 1b) |
| `.worktrees/` existe | L'utiliser (vérifier qu'il est ignoré) |
| `worktrees/` existe | L'utiliser (vérifier qu'il est ignoré) |
| Les deux existent | Utiliser `.worktrees/` |
| Aucun des deux n'existe | Vérifier le fichier d'instructions, sinon `.worktrees/` par défaut |
| Répertoire non ignoré | Ajouter à .gitignore + commit |
| Erreur de permission à la création | Repli sandbox, travailler sur place |
| Échec des tests lors de la vérification de référence | Signaler les échecs + demander |
| Pas de package.json/Cargo.toml | Sauter l'installation des dépendances |

## Rationalisations courantes

| Excuse | Réalité |
|--------|---------|
| "Je ne suis manifestement pas dans un worktree — inutile de vérifier" | Exécutez l'Étape 0. L'isolation créée par un harness et les sous-modules peuvent tous deux tromper une estimation visuelle ; les commandes de détection tranchent la question. |
| "`git worktree add` est plus rapide que de chercher un outil natif" | Un outil natif (ex. `EnterWorktree`) gère le placement, le branchage et le nettoyage. Le contourner est l'erreur n°1 — cela génère un état fantôme que votre harness ne peut ni voir ni gérer. |
| "Le répertoire de worktree est sûrement déjà ignoré" | Exécutez `git check-ignore`. Un répertoire de worktree non ignoré commit l'arborescence entière dans le dépôt. |
| "N'importe quel nom de répertoire convient" | Les instructions explicites l'emportent sur un répertoire local au projet existant, qui l'emporte sur le défaut `.worktrees/`. |
| "L'espace de travail est tout neuf — les tests de référence peuvent attendre" | Une référence initiale corrompue rend chaque échec ultérieur ambigu. Exécutez les tests maintenant ; passer outre les échecs relève de la décision de votre partenaire humain. |
