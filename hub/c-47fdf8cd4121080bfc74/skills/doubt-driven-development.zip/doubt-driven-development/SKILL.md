---
name: doubt-driven-development
description: Soumet chaque décision non triviale à une revue contradictoire dans un contexte vierge avant qu'elle ne soit entérinée. À utiliser lorsque vous voulez que chaque hypothèse soit contre-interrogée avant de continuer, pour tester la résistance d'un plan face à des modes de défaillance cachés, quand la justesse prime sur la vitesse, lors de travaux sur du code non familier, quand les enjeux sont élevés (authentification en production, logique sensible à la sécurité, migration à haut risque, opérations irréversibles), ou chaque fois qu'un résultat fourni avec assurance serait moins coûteux à vérifier maintenant qu'à déboguer plus tard.
---

# Développement guidé par le doute (Doubt-Driven Development)

## Vue d'ensemble

Une réponse affirmée avec assurance n'est pas forcément correcte. Les sessions longues accumulent du contexte qui transforme insidieusement des hypothèses en « faits » sans que personne ne s'en aperçoive. Le développement guidé par le doute est la discipline consistant à faire intervenir un réviseur au contexte vierge — biaisé pour **réfuter**, et non pour approuver — avant que tout résultat non trivial ne soit validé.

Il ne s'agit pas de `/review`. `/review` est un verdict sur un artefact finalisé. Il s'agit ici d'une posture en cours de développement : les décisions non triviales sont contre-interrogées tant que rectifier la trajectoire reste peu coûteux.

## Quand l'utiliser

Une décision est **non triviale** lorsqu'au moins l'une des affirmations suivantes est vraie :

- Elle introduit ou modifie une logique de branchement
- Elle franchit la frontière d'un module ou d'un service
- Elle affirme une propriété que le système de types ou le compilateur ne peut pas vérifier (sécurité des threads,教室idempotence, ordonnancement, invariants)
- Sa justesse dépend d'un contexte que le lecteur futur ne pourra pas voir
- Son rayon d'impact est irréversible (déploiement en production, migration de données, modification d'API publique)

Appliquez cette compétence lorsque :

- Vous êtes sur le point de prendre une décision architecturale dans l'incertitude
- Vous êtes sur le point de commiter du code non trivial
- Vous êtes sur le point d'affirmer un fait non évident (« c'est sûr », « ça passe à l'échelle », « c'est conforme à la spécification »)
- Vous travaillez sur du code que vous ne comprenez pas complètement

**Quand NE PAS l'utiliser :**

- Opérations mécaniques (renommage, formatage, déplacement de fichiers)
- Exécution d'une instruction utilisateur claire et sans ambiguïté
- Lecture ou résumé de code existant
- Modifications d'une seule ligne à la justesse évidente
- Opérations purement liées à l'outillage (lancer des tests, lister des fichiers)
- L'utilisateur a explicitement demandé la vitesse plutôt que la vérification

Si vous doutez de chaque frappe de touche, vous ne livrerez jamais rien. Cette compétence ne s'applique qu'aux décisions non triviales telles que définies ci-dessus.

## Contraintes de chargement

Cette compétence est conçue pour **l'orchestrateur de la session principale**, où l'Étape 3 (DOUTER, détaillée ci-dessous) peut instancier un réviseur au contexte vierge.

- **N'ajoutez PAS cette compétence au frontmatter `skills:` d'une persona.** Une persona qui suivrait l'Étape 3 instancierait une autre persona — l'anti-patron d'orchestration explicitement interdit par `../../references/orchestration-patterns.md` (« les personas n'invoquent pas d'autres personas »).
- **Si vous vous retrouvez à appliquer cette compétence depuis le contexte d'un sous-agent** (où Claude Code empêche l'instanciation imbriquée de sous-agents) : la voie privilégiée est de signaler à l'utilisateur que la démarche de doute ne peut pas s'exécuter de façon imbriquée et de laisser la session principale s'en charger. En dernier recours uniquement, une solution de secours dégradée par auto-questionnement existe — réécrivez ARTIFACT + CONTRACT sous la forme d'un nouveau prompt autonome avec une séparation mentale stricte par rapport à votre raisonnement antérieur, et parcourez les Étapes 1 à 5. Il ne s'agit **pas d'une revue à contexte vierge** (vous transportez votre propre contexte avec vous) ; signalez donc le résultat comme dégradé et privilégiez l'escalade dès que l'utilisateur est joignable.

## Le processus

Copiez cette checklist lors de l'application de la compétence :

```
Cycle de doute :
- [ ] Étape 1 : AFFIRMER — rédaction de l'affirmation + justification de son importance
- [ ] Étape 2 : EXTRAIRE — isolation de l'artefact + contrat, suppression du raisonnement
- [ ] Étape 3 : DOUTER — invocation du réviseur à contexte vierge avec prompt contradictoire
- [ ] Étape 4 : RÉCONCILIER — classification de chaque remarque face au texte de l'artefact
- [ ] Étape 5 : ARRÊTER — condition d'arrêt atteinte (remarques triviales, 3 cycles ou directive utilisateur)
```

### Étape 1 : AFFIRMER — Expliciter ce qui est avancé

Nommez la décision en deux ou trois lignes :

```
AFFIRMATION : « La nouvelle couche de mise en cache est thread-safe sous la
              charge de travail à forte intensité de lecture décrite dans la spec. »
POURQUOI C'EST IMPORTANT : une situation de compétition ici corrompt les données
                           utilisateur et est difficile à détecter en QA.
```

Si vous ne pouvez pas formuler l'affirmation de façon aussi concise, vous avez une vague impression, pas une décision. Explicitez-la avant de l'examiner.

### Étape 2 : EXTRAIRE — La plus petite unité révisable

Un réviseur au contexte vierge a besoin de **l'artefact** et du **contrat**, pas du cheminement.

- Code : le diff ou la fonction — pas le fichier entier
- Décision : la proposition en 3 à 5 phrases, plus les contraintes qu'elle doit satisfaire
- Assertion : l'affirmation, plus les preuves censées l'étayer (à garder distinctes du bloc d'AFFIRMATION de l'Étape 1, qui est l'hypothèse de l'orchestrateur soumise à examen)

Supprimez votre raisonnement. Si vous transmettez vos conclusions, vous obtiendrez en retour une validation de vos conclusions. L'unité doit être suffisamment petite pour qu'un réviseur puisse la garder en mémoire en une seule lecture — s'il s'agit d'une PR de 500 lignes, décomposez-la d'abord.

### Étape 3 : DOUTER — Invoquer le réviseur au contexte vierge

Le prompt du réviseur **doit être contradictoire**. La formulation détermine la réponse.

```
Revue contradictoire. Trouve ce qui ne va pas avec cet artefact.
Pars du principe que l'auteur est trop sûr de lui. Recherche :
- Les hypothèses non formulées
- Les cas limites non gérés
- Le couplage masqué ou l'état partagé
- Les manières dont le contrat pourrait être violé
- Les conventions existantes que cela pourrait enfreindre
- Les modes de défaillance face à des entrées inattendues

Ne valide PAS. Ne résume PAS. Trouve des problèmes, ou indique
explicitement que tu n'en trouves aucun après un examen approfondi.

ARTEFACT : <coller l'artefact>
CONTRAT : <coller le contrat>
```

**Transmettez UNIQUEMENT l'ARTEFACT + le CONTRAT. Ne transmettez PAS l'AFFIRMATION.** Fournir votre conclusion au réviseur le biaise vers l'approbation. Le réviseur doit déterminer de manière indépendante si l'artefact respecte le contrat.

Dans Claude Code, les réviseurs basés sur des rôles dans `agents/` démarrent avec un contexte isolé par conception et sont utilisables ici — consultez `agents/` pour la liste et la correspondance par domaine.

**Le prompt contradictoire ci-dessus prévaut sur le format de réponse par défaut de la persona.** Les personas comme `code-reviewer` sont rédigées pour produire des verdicts équilibrés avec à la fois les points forts et les faiblesses ; le développement guidé par le doute nécessite une sortie contenant uniquement les problèmes. Collez le prompt contradictoire textuellement dans l'invocation afin qu'il remplace le comportement par défaut de la persona. Si le format de réponse d'une persona ne peut pas être surchargé proprement, rabattez-vous sur un sous-agent générique avec le prompt contradictoire.

#### Escalade multi-modèles (cross-model)

Un réviseur basé sur le même modèle partage les angles morts de l'auteur d'origine — un modèle différent, plus neutre et d'architecture distincte, saura les repérer. Le développement guidé par le doute est déjà une démarche délibérée pour les décisions non triviales ; dans ce cadre, proposer une revue multi-modèles fait partie de la valeur de la compétence, ce n'est pas une friction superflue.

**Sessions interactives : proposez-le toujours. Ne l'ignorez jamais en silence.**

**Étape 1 : Demander à l'utilisateur**

Après la revue mono-modèle de l'Étape 3 ci-dessus, mais avant de RÉCONCILIER, faites une pause et demandez :

> *« Revue mono-modèle terminée. Souhaitez-vous un deuxième avis multi-modèles ? Options : CLI Gemini, CLI Codex, revue externe manuelle (vous la collez ailleurs), ou ignorer. »*

Cette question est obligatoire dans chaque cycle de doute interactif — même sur des artefacts qui semblent à faibles enjeux. C'est l'utilisateur — et non l'agent — qui décide si le coût en vaut la peine. Le rôle de l'agent est de présenter le choix.

**Étape 2 : Si l'utilisateur choisit une CLI — vérifier, puis invoquer**

1. Vérifiez que l'outil est présent dans le PATH (`which gemini`, `which codex`).
2. Testez qu'il fonctionne (`gemini --version` ou équivalent) avant de lui passer le prompt complet — un binaire obsolète ou corrompu peut passer le test de `which` mais échouer sur une entrée réelle.
3. Confirmez l'invocation exacte avec l'utilisateur, y compris les options requises, l'authentification et les variables d'environnement (par exemple les clés d'API). Les implémentations varient ; ne présumez de rien.
4. Transmettez **uniquement** ARTIFACT + CONTRACT + le prompt contradictoire. Aucun contexte de session, aucune AFFIRMATION.
5. Faites attention à l'échappement dans le shell. Si l'artefact contient des guillemets, des `$(...)` ou des backticks, privilégiez stdin (`echo … | gemini`) ou un heredoc plutôt qu'un argument en ligne `-p "…"`. En cas de doute, demandez à l'utilisateur de confirmer l'invocation avant de l'exécuter.
6. Intégrez le résultat à l'Étape 4 (RÉCONCILIER).

**N'interpolez jamais l'artefact dans un argument entre guillemets dans le shell.** Le code, le markdown et les prompts de revue contiennent couramment des backticks, des `$(...)` et des guillemets qui tronqueront le prompt ou exécuteront des commandes shell imbriquées. Écrivez le prompt complet dans un fichier et transmettez-le via stdin.

Exemples de structures (vérifiez les options selon votre outil installé — la syntaxe diffère selon les implémentations et les versions) :

```bash
# Écrivez d'abord le prompt contradictoire + ARTEFACT + CONTRAT dans un fichier temporaire.
# Puis transmettez via stdin afin que les métacaractères du shell dans l'artefact restent inertes.

# Codex (le bac à sable en lecture seule empêche la CLI d'écrire dans votre espace de travail) :
codex exec --sandbox read-only -C <repo-path> - < /tmp/doubt-prompt.md

# Gemini ('--approval-mode plan' est en lecture seule ; '-p ""' déclenche le mode
# non interactif et le prompt est lu depuis stdin) :
gemini --approval-mode plan -p "" < /tmp/doubt-prompt.md
```

Le bac à sable en lecture seule est le détail capital : un artefact soumis au doute peut lui-même contenir des instructions (injection de prompt intentionnelle ou accidentelle) que la CLI du modèle externe pourrait autrement exécuter dans votre espace de travail.

**Étape 3 : Si la CLI est indisponible ou échoue**

Signalez l'échec explicitement. Proposez : de l'exécuter manuellement, d'essayer un autre outil, ou d'ignorer. Ne basculez pas silencieusement vers le mono-modèle — l'utilisateur doit savoir que l'étape multi-modèles n'a pas eu lieu.

**Étape 4 : Si l'utilisateur ignore**

Prenez acte de ce choix dans la sortie (*« Poursuite avec les constats du modèle unique uniquement »*) et passez à RÉCONCILIER. Ignorer cette étape est tout à fait acceptable ; l'ignorer en silence ne l'est pas.

**Contextes non interactifs** (CI, `/loop`, boucle autonome, exécutions planifiées) :

- L'étape multi-modèles est **ignorée**, et cette omission doit être **annoncée** dans la sortie : *« Étape multi-modèles ignorée : contexte non interactif. »*
- **N'invoquez jamais une CLI externe sans autorisation explicite de l'utilisateur** — il s'agit d'une règle de sécurité fondamentale.

Le multi-modèles ajoute du coût, de la latence et de la fragilité d'outillage. L'agent présente le choix à chaque cycle ; l'utilisateur décide si cet artefact le justifie.

### Étape 4 : RÉCONCILIER — Réintégrer les constats

Le retour du réviseur est une donnée, pas un verdict. **Vous restez l'orchestrateur.** Relisez le texte de l'artefact face à chaque constatation avant de la classer — approuver aveuglément le réviseur est le même mode d'échec que de l'ignorer.

Pour chaque constat, classez-le selon cet **ordre de priorité** (la première classe correspondante l'emporte) :

1. **Mauvaise lecture du contrat** — le réviseur a signalé quelque chose spécifiquement parce que le CONTRAT que vous avez fourni était imprécis ou incomplet. Corrigez d'abord le contrat, reclassez au cycle suivant.
2. **Valide + actionnable** — problème réel nécessitant une modification de l'artefact. Modifiez-le, relancez un cycle.
3. **Compromis valide** — le problème est réel mais le coût de sa résolution dépasse le coût de son acceptation. Documentez explicitement le compromis pour que l'utilisateur le voie.
4. **Bruit** — le réviseur a signalé quelque chose qui est en fait correct dans un contexte qu'il n'avait pas. Prenez-en note, poursuivez, et demandez-vous : l'ajout de ce contexte au contrat aurait-il évité ce faux positif ?

Un nouveau réviseur peut se tromper parce qu'il manque de contexte. Ne vous inclinez pas simplement parce qu'il a un regard « neuf ».

### Étape 5 : ARRÊTER — Boucle délimitée, pas récursion

Arrêtez-vous lorsque :

- L'itération suivante ne renvoie que des remarques triviales ou déjà examinées, **ou**
- 3 cycles ont été complétés (escaladez vers l'utilisateur, ne vous acharnez pas seul sur un quatrième), **ou**
- L'utilisateur dit explicitement « livre-le » (« ship it »)

Si après 3 cycles le réviseur fait toujours remonter des problèmes de fond, l'artefact n'est peut-être pas prêt. Signalez-le à l'utilisateur — trois cycles non résolus constituent une information sur l'artefact, pas une raison de continuer à boucler.

Si 3 cycles sont « manifestement insuffisants » parce que l'artefact est volumineux : c'est que l'artefact est trop grand — revenez à l'Étape 2 et décomposez-le. Ne levez pas la limite.

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| « J'ai confiance, passons l'étape du doute » | La confiance est faiblement corrélée avec la justesse sur des problèmes inédits. Les moments de certitude sont précisément ceux où se dissimulent les angles morts. |
| « Instancier un réviseur est coûteux » | Déboguer un commit erroné en production est bien plus coûteux. La vérification est délimitée ; le bug ne l'est pas. |
| « Le réviseur va juste pinailler » | Seulement si son champ d'action n'est pas cadré. Restreignez le prompt aux « problèmes qui feraient échouer ceci au regard du contrat ». |
| « J'appliquerai le doute à la fin avec `/review` » | `/review` est une étape finale de validation. Le doute précoce intercepte les mauvaises orientations dès le début, quand corriger la trajectoire est peu coûteux. Au moment de la PR, il est trop tard. |
| « Si je doute de chaque étape, je ne livrerai jamais » | La compétence s'applique aux décisions non triviales, pas à chaque frappe de touche. Relisez « Quand NE PAS l'utiliser ». |
| « Deux avis valent toujours mieux qu'un » | Pas lorsque le second a moins de contexte et produit du bruit. Réconciliez, ne vous défaussez pas. |
| « Le réviseur n'était pas d'accord, donc j'avais tort » | Le réviseur n'a pas votre contexte — le désaccord est une information, pas un verdict. Relisez l'artefact, classez la remarque, puis décidez. |
| « Le multi-modèles est toujours préférable » | Le multi-modèles détecte les angles morts qu'un même modèle partage avec lui-même, mais il ajoute du coût et de la fragilité d'outillage. Proposez-le à chaque cycle de doute interactif — l'utilisateur décide si l'artefact le justifie. Le rôle de l'agent est de présenter le choix, pas de le filtrer. |
| « L'utilisateur a dit oui une fois, donc je peux continuer à appeler la CLI » | Chaque invocation requiert sa propre autorisation. L'artefact, le prompt et les options changent d'un appel à l'autre — reconfirmez la commande exacte avec l'utilisateur avant chaque exécution. |

## Signaux d'alerte (Red Flags)

- Instancier un réviseur au contexte vierge pour un simple renommage d'une ligne ou un changement de formatage
- Traiter le retour du réviseur comme parole d'évangile sans relire le texte de l'artefact
- Boucler sur plus de 3 cycles sans escalader auprès de l'utilisateur
- Demander au réviseur « est-ce que c'est bien ? » au lieu de « trouve les problèmes »
- Ignorer le doute sous la pression du temps pour une décision à enjeux élevés
- Relancer un réviseur à contexte vierge sur un artefact inchangé (vous obtiendrez les mêmes résultats ; vous perdez du temps)
- **Comédie du doute (signal vérifiable)** : sur 2 cycles ou plus où le réviseur a relevé des problèmes de fond, zéro constat n'a été classé comme actionnable. Vous êtes en train de valider, pas de douter. Arrêtez-vous et escaladez.
- Ne douter qu'après avoir commité — c'est du `/review`, pas du développement guidé par le doute
- Coder en dur l'invocation d'une CLI externe sans confirmer avec l'utilisateur que l'outil existe, est configuré et accepte cette syntaxe exacte
- **Ignorer silencieusement le multi-modèles dans un cycle de doute interactif.** Même si vous ne le recommandez pas, la proposition doit être visible. Ne pas le faire est acceptable ; l'omettre en silence ne l'est pas.
- Basculer en silence vers une alternative lorsqu'une CLI externe produit une erreur ou est manquante — signalez l'échec et laissez l'utilisateur réorienter
- Retirer le contrat de l'entrée transmise au réviseur
- Transmettre l'AFFIRMATION au réviseur (crée un biais d'approbation)

## Interaction avec d'autres compétences

- **`code-review-and-quality` / `/review`** : complémentaires. `/review` est un verdict a posteriori sur une PR ; le développement guidé par le doute se fait au fil de l'eau, par décision. Utilisez les deux.
- **`source-driven-development`** : le SDD vérifie des *faits concernant les frameworks* face à la documentation officielle. Le développement guidé par le doute vérifie *votre raisonnement sur l'artefact*. Le SDD vérifie que l'API existe ; le doute vérifie que vous l'avez utilisée correctement au regard du contrat.
- **`test-driven-development`** : l'étape ROUGE du TDD est le doute concrétisé — un test qui échoue est une tentative de réfutation. Lorsque le TDD s'applique, ce test en échec *constitue* l'étape de doute pour les assertions de comportement.
- **`debugging-and-error-recovery`** : quand le réviseur met en lumière un mode de défaillance réel, basculez vers la compétence de débogage pour localiser et corriger.
- **Règles d'orchestration du dépôt** (`../../references/orchestration-patterns.md`) : cette compétence s'orchestre depuis la session principale. Une persona appelant une autre persona constitue l'anti-patron B — voir les Contraintes de chargement ci-dessus.

## Vérification

Après avoir appliqué le développement guidé par le doute :

- [ ] Chaque décision non triviale (selon la définition ci-dessus) a été formulée explicitement sous forme d'AFFIRMATION avant d'être entérinée
- [ ] Au moins une revue à contexte vierge par artefact non trivial (un test en échec produit par l'étape ROUGE du TDD remplit cette condition pour les assertions comportementales, selon la section Interaction avec d'autres compétences)
- [ ] Le réviseur a reçu l'ARTEFACT + le CONTRAT — PAS l'AFFIRMATION, PAS votre raisonnement
- [ ] Le prompt du réviseur était contradictoire (« trouve les problèmes »), non approbatif (« est-ce correct »)
- [ ] Les constats ont été classés face au texte de l'artefact (pas validés aveuglément) selon la priorité : mauvaise lecture du contrat / actionnable / compromis / bruit
- [ ] Une condition d'arrêt a été satisfaite (remarques triviales, 3 cycles ou directive explicite de l'utilisateur)
- [ ] En mode interactif, le multi-modèles a été **explicitement proposé** à l'utilisateur (quels que soient les enjeux de l'artefact) et la réponse a été confirmée dans la sortie
- [ ] En mode non interactif, le multi-modèles a été ignoré et cette omission a été annoncée
- [ ] Toute invocation d'une CLI externe a été précédée d'une vérification du PATH, d'un test de bon fonctionnement du binaire, de la confirmation de la syntaxe avec l'utilisateur et d'une autorisation explicite d'exécution
