---
name: verification-before-completion
description: À utiliser avant d'affirmer qu'un travail est terminé, corrigé ou validé, avant de commiter ou de créer des PR - nécessite d'exécuter les commandes de vérification et de confirmer le résultat avant toute affirmation de succès ; les preuves avant les déclarations, toujours
---

# Vérification avant finalisation

## Vue d'ensemble

**Principe fondamental :** Des preuves avant les affirmations, toujours.

**Enfreindre la lettre de cette règle, c'est en enfreindre l'esprit.**

## La loi d'airain

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

Si vous n'avez pas exécuté la commande de vérification dans ce message, vous ne pouvez pas affirmer que c'est validé.

## La fonction de contrôle

```
BEFORE claiming any status or expressing satisfaction:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute the FULL command (fresh, complete)
3. READ: Full output, check exit code, count failures
4. VERIFY: Does output confirm the claim?
   - If NO: State actual status with evidence
   - If YES: State claim WITH evidence
5. ONLY THEN: Make the claim

Skip any step = lying, not verifying
```

## Échecs fréquents

| Affirmation | Exige | Insuffisant |
|-------------|-------|-------------|
| Les tests passent | Résultat de la commande de test : 0 échec | Exécution précédente, « devrait passer » |
| Linter sans erreur | Résultat du linter : 0 erreur | Vérification partielle, extrapolation |
| Le build réussit | Commande de build : exit 0 | Linter validé, les logs semblent corrects |
| Bug corrigé | Tester le symptôme d'origine : passe | Code modifié, supposé corrigé |
| Le test de régression fonctionne | Cycle rouge-vert vérifié | Le test passe une fois |
| Agent terminé | Le diff VCS montre les modifications | L'agent signale un « succès » |
| Exigences satisfaites | Checklist ligne par ligne | Tests qui passent |

## Signaux d'alerte - ARRÊT

- Utiliser « devrait », « probablement », « semble »
- Exprimer de la satisfaction avant vérification (« Super ! », « Parfait ! », « Terminé ! », etc.)
- Être sur le point de commiter/pusher/créer une PR sans vérification
- Faire confiance aux rapports de succès des agents
- Se fier à une vérification partielle
- Se dire « juste pour cette fois »
- Être fatigué et vouloir en finir avec le travail
- **TOUTE formulation sous-entendant le succès sans avoir exécuté la vérification**

## Prévention des rationalisations

| Prétexte | Réalité |
|----------|---------|
| « Ça devrait fonctionner maintenant » | EXÉCUTER la vérification |
| « J'ai confiance » | Confiance ≠ preuve |
| « Juste pour cette fois » | Aucune exception |
| « Le linter est passé » | Linter ≠ compilateur |
| « L'agent a indiqué succès » | Vérifier de manière indépendante |
| « Je suis fatigué » | Épuisement ≠ excuse |
| « Une vérification partielle suffit » | Une vérification partielle ne prouve rien |
| « Formulation différente donc la règle ne s'applique pas » | L'esprit plutôt que la lettre |

## Modèles clés

**Tests :**
```
✅ [Run test command] [See: 34/34 pass] "All tests pass"
❌ "Should pass now" / "Looks correct"
```

**Tests de régression (TDD Rouge-Vert) :**
```
✅ Write → Run (pass) → Revert fix → Run (MUST FAIL) → Restore → Run (pass)
❌ "I've written a regression test" (without red-green verification)
```

**Build :**
```
✅ [Run build] [See: exit 0] "Build passes"
❌ "Linter passed" (linter doesn't check compilation)
```

**Exigences :**
```
✅ Re-read plan → Create checklist → Verify each → Report gaps or completion
❌ "Tests pass, phase complete"
```

**Délégation d'agent :**
```
✅ Agent reports success → Check VCS diff → Verify changes → Report actual state
❌ Trust agent report
```

## Quand l'appliquer

**TOUJOURS avant :**
- TOUTE variante d'affirmation de succès/finalisation
- TOUTE expression de satisfaction
- TOUTE déclaration positive sur l'état du travail
- Commiter, créer une PR, achever une tâche
- Passer à la tâche suivante
- Déléguer à des agents

**La règle s'applique à :**
- Des formulations exactes
- Des paraphrases et synonymes
- Des sous-entendus de succès
- TOUTE communication suggérant la finalisation/l'exactitude
