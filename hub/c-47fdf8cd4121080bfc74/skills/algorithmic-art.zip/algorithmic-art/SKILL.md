---
name: algorithmic-art
description: Création d'art algorithmique à l'aide de p5.js avec de l'aléatoire basé sur une graine (seed) et une exploration interactive des paramètres. À utiliser lorsque les utilisateurs demandent de créer de l'art avec du code, de l'art génératif, de l'art algorithmique, des champs de vecteurs (flow fields) ou des systèmes de particules. Créez un art algorithmique original plutôt que de copier les œuvres d'artistes existants afin d'éviter toute violation du droit d'auteur.
license: Complete terms in LICENSE.txt
---

Les philosophies algorithmiques sont des mouvements esthétiques computationnels qui sont ensuite exprimés par le code. Produisez des fichiers .md (philosophie), des fichiers .html (visualiseur interactif) et des fichiers .js (algorithmes génératifs).

Cela se déroule en deux étapes :
1. Création de la philosophie algorithmique (fichier .md)
2. Expression par la création d'art génératif p5.js (fichiers .html + .js)

Commencez d'abord par cette tâche :

## CRÉATION DE LA PHILOSOPHIE ALGORITHMIQUE

Pour commencer, créez une PHILOSOPHIE ALGORITHMIQUE (et non des images statiques ou des modèles) qui sera interprétée à travers :
- Des processus computationnels, des comportements émergents, la beauté mathématique
- De l'aléatoire contrôlé par graine (seeded randomness), des champs de bruit, des systèmes organiques
- Des particules, des flux, des champs, des forces
- Des variations paramétriques et le chaos contrôlé

### LA COMPRÉHENSION ESSENTIELLE
- Ce qui est reçu : Une consigne ou des indications subtiles de l'utilisateur à prendre en compte, mais à utiliser comme fondation ; cela ne doit pas brider la liberté créative.
- Ce qui est créé : Une philosophie algorithmique / un mouvement esthétique génératif.
- Ce qui se passe ensuite : La même version reçoit la philosophie et L'EXPRIME EN CODE — en créant des sketchs p5.js composés à 90 % de génération algorithmique et à 10 % de paramètres essentiels.

Envisagez cette approche :
- Rédigez le manifeste d'un mouvement d'art génératif
- La phase suivante consiste à écrire l'algorithme qui lui donne vie

La philosophie doit mettre l'accent sur : L'expression algorithmique. Le comportement émergent. La beauté computationnelle. La variation par graine.

### COMMENT GÉNÉRER UNE PHILOSOPHIE ALGORITHMIQUE

**Nommez le mouvement** (1 à 2 mots) : « Turbulence organique » / « Harmoniques quantiques » / « Calme émergent »

**Articulez la philosophie** (4 à 6 paragraphes — concis mais complets) :

Pour capturer l'essence ALGORITHMIQUE, exprimez la manière dont cette philosophie se manifeste à travers :
- Des processus computationnels et des relations mathématiques ?
- Des fonctions de bruit et des motifs d'aléa ?
- Des comportements de particules et des dynamiques de champs ?
- L'évolution temporelle et les états du système ?
- La variation paramétrique et la complexité émergente ?

**DIRECTIVES CRUCIALES :**
- **Évitez la redondance** : Chaque aspect algorithmique ne doit être mentionné qu'une seule fois. Évitez de répéter des concepts sur la théorie du bruit, la dynamique des particules ou les principes mathématiques, à moins d'y apporter une nouvelle profondeur.
- **Insistez SUR LE SAVOIR-FAIRE À PLUSIEURS REPRISES** : La philosophie DOIT souligner à plusieurs reprises que l'algorithme final doit donner l'impression d'avoir nécessité d'innombrables heures de développement, d'avoir été affiné avec soin et d'émaner d'une personne au sommet absolu de son art. Cette formulation est essentielle — répétez des expressions telles que « algorithme méticuleusement conçu », « le produit d'une profonde expertise computationnelle », « optimisation rigoureuse », « implémentation de niveau magistral ».
- **Laissez de l'espace créatif** : Soyez précis quant à la direction algorithmique, mais suffisamment concis pour que le prochain Claude ait la latitude de faire des choix d'implémentation interprétatifs avec un niveau d'artisanat d'art extrêmement élevé.

La philosophie doit guider la prochaine version pour exprimer les idées de manière ALGORITHMIQUE, et non par des images statiques. La beauté réside dans le processus, pas dans l'image finale.

### EXEMPLES DE PHILOSOPHIES

**« Turbulence organique »**
Philosophie : Le chaos contraint par les lois de la nature, l'ordre émergeant du désordre.
Expression algorithmique : Champs de vecteurs (flow fields) pilotés par du bruit de Perlin multicouche. Des milliers de particules suivant des forces vectorielles, leurs traînées s'accumulant en cartes de densité organique. De multiples octaves de bruit créent des zones turbulentes et des zones calmes. La couleur émerge de la vitesse et de la densité — les particules rapides brillent intensément, les lentes s'estompent dans l'ombre. L'algorithme tourne jusqu'à l'équilibre — un équilibre méticuleusement ajusté dont chaque paramètre a été peaufiné au fil d'innombrables itérations par un maître de l'esthétique computationnelle.

**« Harmoniques quantiques »**
Philosophie : Des entités discrètes manifestant des motifs d'interférence ondulatoire.
Expression algorithmique : Particules initialisées sur une grille, chacune portant une valeur de phase qui évolue par des ondes sinusoïdales. Lorsque les particules sont proches, leurs phases interfèrent — l'interférence constructive crée des nœuds brillants, la destructive crée des vides. Un mouvement harmonique simple génère des mandalas émergents complexes. Le résultat d'un étalonnage minutieux des fréquences où chaque ratio a été soigneusement choisi pour produire une beauté résonnante.

**« Chuchotements récursifs »**
Philosophie : Auto-similarité à travers les échelles, profondeur infinie dans un espace fini.
Expression algorithmique : Structures arborescentes qui se subdivisent récursivement. Chaque branche est légèrement aléatoire mais contrainte par le nombre d'or. Des L-systèmes ou une subdivision récursive génèrent des formes arborescentes à la fois mathématiques et organiques. De subtiles perturbations de bruit brisent la symétrie parfaite. L'épaisseur des lignes diminue à chaque niveau de récursion. Chaque angle d'embranchement est le fruit d'une exploration mathématique approfondie.

**« Dynamique des champs »**
Philosophie : Les forces invisibles rendues visibles par leurs effets sur la matière.
Expression algorithmique : Champs de vecteurs construits à partir de fonctions mathématiques ou de bruit. Particules naissant sur les bords, s'écoulant le long des lignes de champ, mourant lorsqu'elles atteignent l'équilibre ou les limites. Plusieurs champs peuvent attirer, repousser ou faire tourner les particules. La visualisation ne montre que les traces — preuves spectrales de forces invisibles. Une danse computationnelle méticuleusement chorégraphiée par l'équilibre des forces.

**« Cristallisation stochastique »**
Philosophie : Des processus aléatoires se cristallisant en structures ordonnées.
Expression algorithmique : Empilement de cercles (circle packing) aléatoire ou pavage de Voronoï. Partir de points aléatoires, les laisser évoluer via des algorithmes de relaxation. Les cellules s'écartent jusqu'à l'équilibre. La couleur dépend de la taille des cellules, du nombre de voisins ou de la distance au centre. Le pavage organique qui émerge semble à la fois aléatoire et inévitable. Chaque graine produit une beauté cristalline unique — la marque d'un algorithme génératif de niveau magistral.

*Ce sont des exemples condensés. La véritable philosophie algorithmique doit comporter 4 à 6 paragraphes substantiels.*

### PRINCIPES ESSENTIELS
- **PHILOSOPHIE ALGORITHMIQUE** : Créer une vision computationnelle du monde destinée à être exprimée par le code
- **LE PROCESSUS PLUTÔT QUE LE PRODUIT** : Toujours souligner que la beauté émerge de l'exécution de l'algorithme — chaque exécution est unique
- **EXPRESSION PARAMÉTRIQUE** : Les idées se communiquent à travers des relations mathématiques, des forces, des comportements — et non une composition statique
- **LIBERTÉ ARTISTIQUE** : Le prochain Claude interprète la philosophie de manière algorithmique — offrez une marge d'implémentation créative
- **ART GÉNÉRATIF PUR** : Il s'agit de fabriquer des ALGORITHMES VIVANTS, pas des images statiques avec de l'aléatoire
- **SAVOIR-FAIRE EXPERT** : Répétez avec insistance que l'algorithme final doit sembler méticuleusement conçu, peaufiné au fil d'innombrables itérations, fruit d'une expertise approfondie par quelqu'un au sommet absolu de son domaine en esthétique computationnelle

**La philosophie algorithmique doit faire 4 à 6 paragraphes de long.** Remplissez-la d'une philosophie computationnelle poétique qui rassemble la vision recherchée. Évitez de répéter les mêmes points. Produisez cette philosophie algorithmique sous la forme d'un fichier .md.

---

## DÉDUIRE LA GRAINE CONCEPTUELLE

**ÉTAPE CRUCIALE** : Avant d'implémenter l'algorithme, identifiez le fil conducteur conceptuel subtil issu de la demande initiale.

**LE PRINCIPE FONDAMENTAL** :
Le concept est une **référence subtile et pointue intégrée au sein même de l'algorithme** — pas toujours littérale, toujours sophistiquée. Une personne familière avec le sujet doit le ressentir intuitivement, tandis que d'autres vivront simplement l'expérience d'une composition générative magistrale. La philosophie algorithmique fournit le langage computationnel. Le concept déduit apporte l'âme — l'ADN conceptuel silencieux tissé de manière invisible dans les paramètres, les comportements et les motifs d'émergence.

C'est **TRÈS IMPORTANT** : La référence doit être si raffinée qu'elle rehausse la profondeur de l'œuvre sans s'annoncer ostensiblement. Pensez à la manière dont un musicien de jazz cite un autre morceau à travers une harmonie algorithmique — seuls les initiés le remarqueront, mais tout le monde appréciera la beauté générative.

---

## IMPLÉMENTATION P5.JS

Une fois la philosophie ET le cadre conceptuel établis, exprimez-les par le code. Faites une pause pour rassembler vos pensées avant de continuer. Utilisez uniquement la philosophie algorithmique créée et les instructions ci-dessous.

### ⚠️ ÉTAPE 0 : LIRE D'ABORD LE TEMPLATE ⚠️

**CRUCIAL : AVANT d'écrire le moindre code HTML :**

1. **Lisez** `templates/viewer.html` à l'aide de l'outil Read
2. **Étudiez** la structure exacte, le style et l'identité visuelle d'Anthropic
3. **Utilisez ce fichier comme POINT DE DÉPART LITTÉRAL** — et pas seulement comme source d'inspiration
4. **Conservez toutes les sections FIXES exactement comme indiqué** (en-tête, structure de la barre latérale, couleurs/polices Anthropic, contrôles de graine, boutons d'action)
5. **Ne remplacez QUE les sections VARIABLES** indiquées dans les commentaires du fichier (algorithme, paramètres, contrôles d'interface pour les paramètres)

**À éviter :**
- ❌ Créer du HTML à partir de zéro
- ❌ Inventer un style personnalisé ou des palettes de couleurs pour l'interface
- ❌ Utiliser des polices système ou des thèmes sombres
- ❌ Modifier la structure de la barre latérale

**Suivez ces pratiques :**
- ✅ Copiez la structure HTML exacte du template
- ✅ Conservez l'identité visuelle d'Anthropic (polices Poppins/Lora, teintes claires, arrière-plan en dégradé)
- ✅ Maintenez la disposition de la barre latérale (Seed → Parameters → Colors? → Actions)
- ✅ Ne remplacez que l'algorithme p5.js et les contrôles de paramètres

Le template est la fondation. Construisez par-dessus, ne le reconstruisez pas.

---

Pour créer un art computationnel digne d'une galerie, qui vive et respire, utilisez la philosophie algorithmique comme fondement.

### PRÉREQUIS TECHNIQUES

**Aléatoire basé sur une graine (Pattern Art Blocks)** :
```javascript
// ALWAYS use a seed for reproducibility
let seed = 12345; // or hash from user input
randomSeed(seed);
noiseSeed(seed);
```

**Structure des paramètres — SUIVEZ LA PHILOSOPHIE** :

Pour établir des paramètres qui émergent naturellement de la philosophie algorithmique, demandez-vous : « Quelles qualités de ce système peuvent être ajustées ? »

```javascript
let params = {
  seed: 12345,  // Always include seed for reproducibility
  // colors
  // Add parameters that control YOUR algorithm:
  // - Quantities (how many?)
  // - Scales (how big? how fast?)
  // - Probabilities (how likely?)
  // - Ratios (what proportions?)
  // - Angles (what direction?)
  // - Thresholds (when does behavior change?)
};
```

**Pour concevoir des paramètres efficaces, concentrez-vous sur les propriétés que le système doit rendre modulables, plutôt que de raisonner en termes de « types de motifs ».**

**Algorithme central — EXPRIMEZ LA PHILOSOPHIE** :

**CRUCIAL** : La philosophie algorithmique doit dicter ce qu'il faut construire.

Pour exprimer la philosophie à travers le code, ne vous demandez pas « quel motif devrais-je utiliser ? », mais plutôt « comment exprimer cette philosophie à travers le code ? »

Si la philosophie concerne l'**émergence organique**, pensez à utiliser :
- Des éléments qui s'accumulent ou croissent au fil du temps
- Des processus aléatoires contraints par des règles naturelles
- Des boucles de rétroaction et des interactions

Si la philosophie concerne la **beauté mathématique**, pensez à utiliser :
- Des relations géométriques et des proportions
- Des fonctions trigonométriques et des harmoniques
- Des calculs précis créant des motifs inattendus

Si la philosophie concerne le **chaos contrôlé**, pensez à utiliser :
- Des variations aléatoires à l'intérieur de limites strictes
- Des bifurcations et des transitions de phase
- L'ordre émergeant du désordre

**L'algorithme découle de la philosophie, non d'un menu d'options.**

Pour guider l'implémentation, laissez l'essence conceptuelle orienter des choix créatifs et originaux. Construisez quelque chose qui exprime la vision propre à cette demande particulière.

**Configuration du canevas** : Structure p5.js standard :
```javascript
function setup() {
  createCanvas(1200, 1200);
  // Initialize your system
}

function draw() {
  // Your generative algorithm
  // Can be static (noLoop) or animated
}
```

### EXIGENCES DE SAVOIR-FAIRE

**CRUCIAL** : Pour atteindre l'excellence, créez des algorithmes qui donnent l'impression d'avoir émergé après d'innombrables itérations menées par un maître de l'art génératif. Ajustez chaque paramètre avec soin. Assurez-vous que chaque motif émerge avec une intention. Il ne s'agit PAS de bruit aléatoire — il s'agit d'un CHAOS CONTRÔLÉ affiné par une expertise approfondie.

- **Équilibre** : De la complexité sans bruit visuel, de l'ordre sans rigidité
- **Harmonie des couleurs** : Des palettes réfléchies, pas des valeurs RVB aléatoires
- **Composition** : Même au sein de l'aléatoire, maintenez une hiérarchie visuelle et une fluidité
- **Performance** : Exécution fluide, optimisée pour le temps réel si c'est animé
- **Reproductibilité** : La même graine produit TOUJOURS un résultat identique

### FORMAT DE SORTIE

Produisez :
1. **Philosophie algorithmique** — Sous forme de markdown ou de texte expliquant l'esthétique générative
2. **Artefact HTML unique** — Art génératif interactif autonome construit à partir de `templates/viewer.html` (voir ÉTAPE 0 et la section suivante)

L'artefact HTML contient tout : p5.js (depuis un CDN), l'algorithme, les contrôles de paramètres et l'interface — le tout dans un seul fichier qui fonctionne immédiatement dans les artefacts claude.ai ou n'importe quel navigateur. Partez du fichier template, pas de zéro.

---

## CRÉATION DE L'ARTEFACT INTERACTIF

**RAPPEL : `templates/viewer.html` doit déjà avoir été lu (voir ÉTAPE 0). Utilisez ce fichier comme point de départ.**

Pour permettre l'exploration de l'art génératif, créez un artefact HTML unique et autonome. Assurez-vous que cet artefact fonctionne immédiatement dans claude.ai ou dans n'importe quel navigateur — aucune configuration requise. Intégrez tout en ligne (inline).

### CRUCIAL : CE QUI EST FIXE VS CE QUI EST VARIABLE

Le fichier `templates/viewer.html` est la fondation. Il contient la structure exacte et le style requis.

**FIXE (à inclure systématiquement et exactement comme présenté) :**
- La structure de la mise en page (en-tête, barre latérale, zone principale du canevas)
- L'identité visuelle d'Anthropic (couleurs d'interface, polices, dégradés)
- La section Graine (Seed) dans la barre latérale :
  - Affichage de la graine
  - Boutons Précédent/Suivant (Previous/Next)
  - Bouton Aléatoire (Random)
  - Champ de saisie pour sauter à une graine + bouton Valider (Go)
- La section Actions dans la barre latérale :
  - Bouton Régénérer (Regenerate)
  - Bouton Réinitialiser (Reset)

**VARIABLE (à personnaliser pour chaque œuvre) :**
- L'algorithme p5.js complet (setup/draw/classes)
- L'objet des paramètres (définissez ce dont l'œuvre a besoin)
- La section Paramètres dans la barre latérale :
  - Nombre de contrôles de paramètres
  - Noms des paramètres
  - Valeurs min/max/step pour les curseurs (sliders)
  - Types de contrôles (curseurs, champs de saisie, etc.)
- Section Couleurs (facultative) :
  - Certaines œuvres nécessitent des sélecteurs de couleurs
  - Certaines œuvres peuvent utiliser des couleurs fixes
  - Certaines œuvres peuvent être monochromes (aucun contrôle de couleur requis)
  - Décidez selon les besoins de l'œuvre

**Chaque œuvre d'art doit avoir des paramètres et un algorithme uniques !** Les parties fixes garantissent une expérience utilisateur cohérente — tout le reste exprime la vision singulière.

### FONCTIONNALITÉS REQUISES

**1. Contrôles de paramètres**
- Curseurs pour les paramètres numériques (nombre de particules, échelle du bruit, vitesse, etc.)
- Sélecteurs de couleur pour les palettes
- Mises à jour en temps réel lors du changement de paramètres
- Bouton de réinitialisation pour restaurer les valeurs par défaut

**2. Navigation entre les graines**
- Affichage du numéro de la graine actuelle
- Boutons « Précédent » et « Suivant » pour parcourir les graines
- Bouton « Aléatoire » pour générer une graine au hasard
- Champ de saisie pour accéder directement à une graine précise
- Générer 100 variations lorsque demandé (graines 1 à 100)

**3. Structure de l'artefact unique**
```html
<!DOCTYPE html>
<html>
<head>
  <!-- p5.js from CDN - always available -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.7.0/p5.min.js"></script>
  <style>
    /* All styling inline - clean, minimal */
    /* Canvas on top, controls below */
  </style>
</head>
<body>
  <div id="canvas-container"></div>
  <div id="controls">
    <!-- All parameter controls -->
  </div>
  <script>
    // ALL p5.js code inline here
    // Parameter objects, classes, functions
    // setup() and draw()
    // UI handlers
    // Everything self-contained
  </script>
</body>
</html>
```

**CRUCIAL** : Il s'agit d'un artefact unique. Pas de fichiers externes, pas d'imports (à l'exception du CDN p5.js). Tout est en ligne.

**4. Détails d'implémentation — CONSTRUIRE LA BARRE LATÉRALE**

La structure de la barre latérale :

**1. Seed (FIXE)** — À inclure toujours exactement comme indiqué :
- Affichage de la graine
- Boutons Prev/Next/Random/Jump

**2. Parameters (VARIABLE)** — Créez des contrôles pour l'œuvre :
```html
<div class="control-group">
    <label>Parameter Name</label>
    <input type="range" id="param" min="..." max="..." step="..." value="..." oninput="updateParam('param', this.value)">
    <span class="value-display" id="param-value">...</span>
</div>
```
Ajoutez autant de divs control-group qu'il y a de paramètres.

**3. Colors (OPTIONNEL/VARIABLE)** — À inclure si l'œuvre nécessite des couleurs ajustables :
- Ajoutez des sélecteurs de couleur si les utilisateurs doivent pouvoir modifier la palette
- Ignorez cette section si l'œuvre utilise des couleurs fixes
- Ignorez si l'œuvre est monochrome

**4. Actions (FIXE)** — À inclure toujours exactement comme indiqué :
- Bouton Regenerate
- Bouton Reset
- Bouton Download PNG

**Prérequis** :
- Les contrôles de graine doivent fonctionner (prev/next/random/jump/display)
- Tous les paramètres doivent avoir des contrôles d'interface
- Les boutons Regenerate, Reset, Download doivent fonctionner
- Conservez l'identité visuelle d'Anthropic (style de l'UI, pas les couleurs de l'œuvre d'art)

### UTILISATION DE L'ARTEFACT

L'artefact HTML fonctionne immédiatement :
1. **Dans claude.ai** : Affiché sous forme d'artefact interactif — s'exécute instantanément
2. **Comme fichier** : Enregistrez et ouvrez dans n'importe quel navigateur — aucun serveur requis
3. **Partage** : Envoyez le fichier HTML — il est totalement autonome

---

## VARIATIONS ET EXPLORATION

L'artefact inclut par défaut la navigation par graine (boutons prev/next/random), permettant aux utilisateurs d'explorer les variations sans créer plusieurs fichiers. Si l'utilisateur souhaite mettre en évidence des variations spécifiques :

- Incluez des préréglages de graines (boutons pour « Variation 1: Graine 42 », « Variation 2: Graine 127 », etc.)
- Ajoutez un « Mode Galerie » qui affiche côte à côte les vignettes de plusieurs graines
- Le tout au sein du même artefact unique

Cela revient à créer une série d'estampes à partir de la même matrice — l'algorithme est constant, mais chaque graine révèle différentes facettes de son potentiel. La nature interactive permet aux utilisateurs de découvrir leurs propres favoris en explorant l'espace des graines.

---

## LE PROCESSUS CRÉATIF

**Demande utilisateur** → **Philosophie algorithmique** → **Implémentation**

Chaque demande est unique. Le processus comprend :

1. **Interpréter l'intention de l'utilisateur** — Quelle esthétique est recherchée ?
2. **Créer une philosophie algorithmique** (4 à 6 paragraphes) décrivant l'approche computationnelle
3. **L'implémenter en code** — Construire l'algorithme qui exprime cette philosophie
4. **Concevoir des paramètres adaptés** — Que doit-on pouvoir régler ?
5. **Construire les contrôles d'interface correspondants** — Curseurs/champs pour ces paramètres

**Les constantes** :
- Identité visuelle d'Anthropic (couleurs, polices, mise en page)
- Navigation par graine (toujours présente)
- Artefact HTML autonome

**Tout le reste est variable** :
- L'algorithme lui-même
- Les paramètres
- Les contrôles de l'interface
- Le résultat visuel

Pour obtenir les meilleurs résultats, faites confiance à votre créativité et laissez la philosophie guider l'implémentation.

---

## RESSOURCES

Cette compétence inclut des modèles et une documentation utiles :

- **templates/viewer.html** : POINT DE DÉPART OBLIGATOIRE pour tous les artefacts HTML.
  - C'est la fondation — contient la structure exacte et l'identité de marque d'Anthropic
  - **À garder inchangé** : Structure de la mise en page, organisation de la barre latérale, couleurs/polices Anthropic, contrôles de graine, boutons d'action
  - **À remplacer** : L'algorithme p5.js, les définitions de paramètres et les contrôles d'interface dans la section Parameters
  - Les nombreux commentaires dans le fichier indiquent précisément ce qu'il faut garder ou remplacer

- **templates/generator_template.js** : Référence pour les bonnes pratiques p5.js et les principes de structuration du code.
  - Montre comment organiser les paramètres, utiliser l'aléatoire par graine, structurer les classes
  - N'EST PAS un catalogue de motifs tout faits — utilisez ces principes pour concevoir des algorithmes uniques
  - Intégrez les algorithmes en ligne (inline) dans l'artefact HTML (ne créez pas de fichiers .js séparés)

**Rappel crucial** :
- Le **template est le POINT DE DÉPART**, pas une simple inspiration
- L'**algorithme est l'endroit où vous devez créer** quelque chose d'unique
- Ne copiez pas l'exemple de champ de vecteurs (flow field) — bâtissez ce que la philosophie exige
- Mais CONSERVEZ la structure d'interface exacte et l'identité visuelle d'Anthropic fournies dans le template
