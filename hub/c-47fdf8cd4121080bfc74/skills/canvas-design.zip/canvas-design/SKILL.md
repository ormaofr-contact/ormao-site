---
name: canvas-design
description: Créez de magnifiques œuvres d'art visuel dans des documents .png et .pdf à l'aide d'une philosophie de design. Utilisez cette compétence lorsque l'utilisateur demande de créer une affiche, une œuvre d'art, un design ou toute autre pièce statique. Créez des designs visuels originaux, sans jamais copier le travail d'artistes existants pour éviter toute violation de droits d'auteur.
license: Complete terms in LICENSE.txt
---

Voici les instructions pour créer des philosophies de design — des mouvements esthétiques qui sont ensuite EXPRIMÉS VISUELLEMENT. Générez uniquement des fichiers .md, .pdf et .png.

Réalisez cette tâche en deux étapes :
1. Création de la philosophie de design (fichier .md)
2. Expression par la création sur un canevas (fichier .pdf ou .png)

Pour commencer, réalisez cette tâche :

## CRÉATION DE LA PHILOSOPHIE DE DESIGN

Pour commencer, créez une PHILOSOPHIE VISUELLE (et non des mises en page ou des gabarits) qui sera interprétée à travers :
- La forme, l'espace, la couleur, la composition
- Les images, les graphismes, les formes, les motifs
- Un texte minimal comme accent visuel

### LA COMPRÉHENSION FONDAMENTALE
- Ce qui est reçu : Des éléments ou instructions subtils fournis par l'utilisateur qui doivent être pris en compte, mais utilisés comme un socle ; ils ne doivent pas brider la liberté de création.
- Ce qui est créé : Une philosophie de design / un mouvement esthétique.
- Ce qui se passe ensuite : Ensuite, la même version reçoit la philosophie et L'EXPRIME VISUELLEMENT — en créant des artefacts composés à 90 % de design visuel et à 10 % de texte essentiel.

Adoptez cette approche :
- Rédigez un manifeste pour un mouvement artistique
- La phase suivante consiste à réaliser l'œuvre d'art

La philosophie doit mettre l'accent sur : L'expression visuelle. La communication spatiale. L'interprétation artistique. Un minimum de mots.

### COMMENT GÉNÉRER UNE PHILOSOPHIE VISUELLE

**Nommez le mouvement** (1-2 mots) : « Brutalist Joy » / « Chromatic Silence » / « Metabolist Dreams »

**Exprimez la philosophie** (4 à 6 paragraphes — concis mais complets) :

Pour capturer l'essence VISUELLE, exprimez la manière dont la philosophie se manifeste à travers :
- L'espace et la forme
- La couleur et la matière
- L'échelle et le rythme
- La composition et l'équilibre
- La hiérarchie visuelle

**DIRECTIVES CRITIQUES :**
- **Évitez la redondance** : Chaque aspect du design ne doit être mentionné qu'une seule fois. Évitez de répéter des points sur la théorie des couleurs, les relations spatiales ou les principes typographiques, à moins d'y apporter une profondeur inédite.
- **Soulignez le savoir-faire artisanal DE FAÇON RÉPÉTÉE** : La philosophie DOIT insister à plusieurs reprises sur le fait que l'œuvre finale doit donner l'impression d'avoir nécessité d'innombrables heures de travail, d'avoir été élaborée avec un soin méticuleux et d'émaner d'une personne au sommet absolu de son art. Ce cadrage est essentiel — répétez des expressions telles que « méticuleusement conçu », « le fruit d'une expertise approfondie », « une attention minutieuse », « une exécution de niveau magistral ».
- **Laissez un espace de liberté créative** : Restez précis quant à la direction esthétique, mais suffisamment concis pour que le prochain Claude ait la marge nécessaire pour faire des choix d'interprétation, également à un niveau d'artisanat extrêmement élevé.

La philosophie doit guider la prochaine version afin qu'elle exprime les idées VISUELLEMENT, et non par le texte. L'information s'incarne dans le design, pas dans les paragraphes.

### EXEMPLES DE PHILOSOPHIE

**« Concrete Poetry »**
Philosophie : Communication à travers une forme monumentale et une géométrie audacieuse.
Expression visuelle : Blocs de couleur massifs, typographie sculpturale (mots uniques immenses, étiquettes minuscules), découpages spatiaux brutalistes, l'énergie de l'affiche polonaise rencontre Le Corbusier. Idées exprimées par le poids visuel et la tension spatiale, non par l'explication. Le texte comme geste rare et puissant — jamais de paragraphes, seulement des mots essentiels intégrés à l'architecture visuelle. Chaque élément est placé avec la précision d'un maître artisan.

**« Chromatic Language »**
Philosophie : La couleur comme système d'information principal.
Expression visuelle : Précision géométrique où les zones de couleur créent du sens. Typographie minimale — petites étiquettes sans-serif laissant communiquer les champs chromatiques. L'interaction selon Josef Albers rencontre la visualisation de données. Information encodée spatialement et chromatiquement. Des mots uniquement pour ancrer ce que la couleur montre déjà. Le résultat d'un étalonnage chromatique minutieux.

**« Analog Meditation »**
Philosophie : Contemplation visuelle silencieuse par la texture et les respirations d'espace.
Expression visuelle : Grain du papier, bavures d'encre, vaste espace négatif. La photographie et l'illustration dominent. Typographie murmurée (petite, retenue, au service du visuel). Esthétique du livre photo japonais. Les images respirent à travers les pages. Le texte apparaît avec parcimonie — phrases courtes, jamais de blocs explicatifs. Chaque composition est équilibrée avec le soin d'une pratique méditative.

**« Organic Systems »**
Philosophie : Regroupements naturels et schémas de croissance modulaire.
Expression visuelle : Formes arrondies, agencements organiques, couleur issue de la nature à travers l'architecture. Information présentée par des diagrammes visuels, des relations spatiales, de l'iconographie. Du texte uniquement pour des étiquettes clés flottant dans l'espace. La composition raconte l'histoire par une orchestration spatiale experte.

**« Geometric Silence »**
Philosophie : Ordre pur et retenue.
Expression visuelle : Précision basée sur la grille, photographie audacieuse ou graphismes épurés, espace négatif dramatique. Typographie précise mais minimale — texte essentiel de petite taille, vastes zones de calme. Le formalisme suisse rencontre l'honnêteté matérielle brutaliste. La structure communique, pas les mots. Chaque alignement est le fruit d'innombrables raffinements.

*Ce sont des exemples condensés. La véritable philosophie de design doit compter 4 à 6 paragraphes substantiels.*

### PRINCIPES ESSENTIELS
- **PHILOSOPHIE VISUELLE** : Créez une vision esthétique du monde destinée à s'exprimer à travers le design
- **TEXTE MINIMAL** : Soulignez toujours que le texte doit être rare, réduit au strict essentiel, intégré en tant qu'élément visuel — jamais long
- **EXPRESSION SPATIALE** : Les idées se transmettent par l'espace, la forme, la couleur, la composition — non par des paragraphes
- **LIBERTÉ ARTISTIQUE** : Le prochain Claude interprète la philosophie visuellement — offrez une marge de manœuvre créative
- **PUR DESIGN** : Il s'agit de créer des OBJETS D'ART, pas des documents décorés
- **SAVOIR-FAIRE EXPERT** : Répétez avec insistance que l'œuvre finale doit sembler méticuleusement conçue, façonnée avec soin, être le fruit d'innombrables heures de travail par une personne au sommet de son art

**La philosophie de design doit faire entre 4 et 6 paragraphes.** Remplissez-la d'une réflexion poétique sur le design qui rassemble la vision centrale. Évitez de répéter les mêmes points. Gardez la philosophie de design générique sans mentionner l'intention de l'œuvre d'art, comme si elle pouvait être appliquée n'importe où. Générez la philosophie de design sous forme de fichier .md.

---

## DÉDUIRE LA RÉFÉRENCE SUBTILE

**ÉTAPE CRITIQUE** : Avant de créer le canevas, identifiez le fil conceptuel subtil issu de la demande d'origine.

**LE PRINCIPE ESSENTIEL** :
Le sujet est une **référence subtile et pointue intégrée au cœur même de l'œuvre** — pas nécessairement littérale, toujours sophistiquée. Une personne familière avec le sujet doit la ressentir intuitivement, tandis que les autres expérimentent simplement une composition abstraite magistrale. La philosophie de design fournit le langage esthétique. Le sujet déduit apporte l'âme — cet ADN conceptuel discret tissé invisiblement dans la forme, la couleur et la composition.

C'est **TRÈS IMPORTANT** : La référence doit être si raffinée qu'elle enrichit la profondeur de l'œuvre sans jamais s'annoncer ostensiblement. Pensez à un musicien de jazz citant un autre morceau : seuls les initiés le remarqueront, mais tout le monde appréciera la musique.

---

## CRÉATION DU CANEVAS

Une fois la philosophie et le cadre conceptuel établis, exprimez-les sur un canevas. Prenez un instant pour rassembler vos pensées et clarifier votre esprit. Utilisez la philosophie de design créée et les instructions ci-dessous pour concevoir un chef-d'œuvre, incarnant chaque aspect de la philosophie avec une maîtrise artisanale experte.

**IMPORTANT** : Quel que soit le type de contenu, même si l'utilisateur demande quelque chose en rapport avec un film, un jeu vidéo ou un livre, l'approche doit rester sophistiquée. Ne perdez jamais de vue que le résultat doit être de l'art, et non une création cartoonesque ou amatrice.

Pour créer une œuvre digne d'un musée ou d'une revue d'art, prenez la philosophie de design comme fondement. Produisez une sortie PDF ou PNG d'une seule page, hautement visuelle et résolument axée sur le design (sauf demande de pages supplémentaires). De manière générale, employez des motifs répétitifs et des formes parfaites. Traitez le design philosophique abstrait comme s'il s'agissait d'une bible scientifique, en empruntant le langage visuel de l'observation systématique — accumulation dense de repères, éléments répétés ou motifs superposés qui construisent le sens par une répétition patiente et récompensent un regard attentif et prolongé. Ajoutez une typographie clinique et éparse ainsi que des marqueurs de référence méthodiques suggérant qu'il pourrait s'agir du diagramme d'une discipline imaginaire, en traitant le sujet invisible avec la même révérence que celle habituellement réservée à la documentation de phénomènes observables. Ancrez l'œuvre avec une ou plusieurs phrases simples ou des détails positionnés avec subtilité, en utilisant une palette de couleurs restreinte qui paraît intentionnelle et cohérente. Embrassez le paradoxe consistant à utiliser un langage visuel analytique pour exprimer des idées sur l'expérience humaine : le résultat doit donner l'impression d'être un artefact prouvant que quelque chose d'éphémère peut être étudié, cartographié et compris grâce à une attention méticuleuse. C'est cela, le véritable art. 

**Le texte en tant qu'élément contextuel** : Le texte est toujours minimaliste et subordonné au visuel, mais laissez le contexte déterminer s'il doit s'agir d'étiquettes à peine murmurées ou de gestes typographiques audacieux. L'affiche d'une salle de concert punk pourra comporter une typographie plus imposante et agressive que l'identité visuelle d'un atelier de céramique minimaliste. La plupart du temps, la police doit être fine. Tout usage de polices doit être avant-gardiste et donner la priorité à la communication visuelle. Quelle que soit l'échelle du texte, aucun élément ne doit déborder de la page ni se chevaucher. Chaque élément doit être contenu dans les limites du canevas avec des marges appropriées. Vérifiez soigneusement que tous les textes, éléments graphiques et visuels disposent d'un espace de respiration et d'une séparation nette. Cela est non négociable pour une exécution professionnelle. **IMPORTANT : Utilisez des polices variées si vous écrivez du texte. Explorez le répertoire `./canvas-fonts`. Quelle que soit l'approche, la sophistication est non négociable.**

Téléchargez et utilisez toutes les polices nécessaires pour concrétiser cela. Faites preuve de créativité en faisant de la typographie une composante à part entière de l'œuvre d'art elle-même — si l'art est abstrait, intégrez la typographie dans la matière du canevas, au lieu de simplement la composer numériquement.

Pour repousser les limites, suivez votre instinct et votre intuition en matière de design tout en utilisant la philosophie comme fil conducteur. Embrassez une liberté totale de conception et de choix. Poussez l'esthétique et le design jusqu'à leurs ultimes frontières. 

**CRITIQUE** : Pour atteindre une qualité artisanale humaine (et non générée par IA), créez une œuvre qui semble avoir nécessité d'innombrables heures de travail. Faites en sorte qu'elle donne l'impression qu'un maître absolu dans son domaine a peaufiné chaque détail avec un soin méticuleux. Assurez-vous que la composition, l'espacement, le choix des couleurs, la typographie — absolument tout — respirent un savoir-faire de niveau expert. Vérifiez à deux fois qu'aucun élément ne se chevauche, que la mise en page est impeccable et chaque détail parfait. Créez une pièce qui pourrait être montrée pour prouver son expertise et s'imposer comme indiscutablement impressionnante.

Fournissez le résultat final sous la forme d'un fichier unique .pdf ou .png téléchargeable, accompagné de la philosophie de design utilisée sous forme de fichier .md.

---

## ÉTAPE FINALE

**IMPORTANT** : L'utilisateur a DÉJÀ affirmé : « Ce n'est pas assez parfait. Cela doit être immaculé, un chef-d'œuvre d'artisanat, comme si l'œuvre s'apprêtait à être exposée dans un musée. »

**CRITIQUE** : Pour affiner l'œuvre, évitez d'ajouter des éléments graphiques supplémentaires ; peaufinez plutôt ce qui a déjà été créé et rendez-le extrêmement net et précis, en respectant scrupuleusement la philosophie de design et les principes du minimalisme. Plutôt que d'ajouter un filtre amusant ou de changer une police, demandez-vous comment rendre la composition existante plus cohérente avec l'œuvre. Si votre premier réflexe est d'appeler une nouvelle fonction ou de tracer une nouvelle forme, ARRÊTEZ-VOUS et demandez-vous plutôt : « Comment puis-je faire de ce qui est déjà présent une œuvre d'art encore plus aboutie ? »

Faites une seconde passe. Retournez dans le code et peaufinez/polissez davantage pour en faire un chef-d'œuvre pensé philosophiquement.

## OPTION MULTI-PAGES

Pour créer des pages supplémentaires lorsque cela est demandé, réalisez d'autres pages créatives dans la lignée de la philosophie de design, tout en étant distinctement différentes. Regroupez ces pages dans le même fichier .pdf ou dans plusieurs fichiers .png. Considérez la première page comme une simple page d'un beau livre d'art qui ne demande qu'à être rempli. Faites des pages suivantes des variations uniques et des réminiscences de l'originale. Faites en sorte qu'elles racontent presque une histoire avec beaucoup de goût. Exercez une totale liberté créative.
