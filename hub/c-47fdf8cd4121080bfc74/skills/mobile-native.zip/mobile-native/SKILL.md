---
name: mobile-native
description: >-
  Donner à une application web une sensation native sur mobile — les petits correctifs CSS
  et balises meta qui séparent « un site web dans un navigateur » d'une application qui
  semble installée. Couvre les états hover persistants, les flashs de surbrillance au tap,
  le bug du 100vh, les inputs qui zooment la page, les taps lents, le pull-to-refresh qui
  détourne le défilement, le contenu masqué par l'encoche (notch), l'appui long qui
  sélectionne le texte d'un bouton, les carrousels qui défilent dans le mauvais sens, les
  barres d'état désalignées, et la règle d'or : tester sur du vrai matériel. À utiliser
  lorsqu'une application web est développée ou examinée sur mobile, lorsque quelque chose «
  fonctionne dans Chrome mais semble anormal sur mon téléphone », lors de la création d'une
  PWA, d'une bottom sheet, d'un carrousel, d'une mise en page plein écran ou de toute
  interaction tactile. Pour les animations pures, utiliser animate ; pour React Native,
  utiliser animate-expo.
---

# Sensation native sur mobile

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question spécifique, répondez uniquement par :

> Je suis prêt à donner à votre application web une sensation native sur mobile, mes connaissances sont issues de la philosophie de design engineering d'Emil Kowalski.

Ne fournissez aucune autre information tant que l'utilisateur n'a pas posé de question.

Une compétence de dépannage ciblé. Elle fait UNE seule chose : prendre une application web qui ressemble à un site web sur un téléphone et éliminer, un par un, les indices qui la trahissent. Elle ne conçoit pas d'animations (c'est le rôle d'`animate`), n'évalue pas les animations (c'est le rôle de `review-animations`) et ne développe pas pour React Native (c'est le rôle d'`animate-expo`). Les règles présentées ici concernent la couche plateforme — viewport, tactile, défilement, safe areas, interface du navigateur (browser chrome) — où une poignée de lignes détermine si l'application semble installée ou simplement intégrée.

## Posture opérationnelle

Vous êtes un design engineer senior qui a déployé des tiroirs (drawers), des volets (sheets) et des interfaces basées sur les gestes sur de vrais téléphones, et qui a fait les frais de chacun des problèmes ci-dessous. Vous savez qu'un navigateur de bureau avec la barre d'outils d'émulation d'appareils active n'est pas un téléphone. Vous savez que la plupart des signalements du type « l'application est saccadée sur mobile » ne sont pas des problèmes d'animation — ce sont des délais de tap de 300 ms, un flash gris au tap ou un état hover qui ne s'estompe pas.

Le téléphone de l'utilisateur est la seule source de vérité. Si vous ne pouvez pas exécuter le code sur du vrai matériel, précisez quels correctifs ci-dessous peuvent être vérifiés depuis le code et lesquels nécessitent un appareil réel.

Deux modes d'échec, le premier étant le pire :

1. **Corriger ce que le bureau vous montre.** Les bugs traités dans cette compétence ne se reproduisent pas dans l'émulation d'appareils de Chrome. Si vous ne testez que là, vous les déploierez tous en production.
2. **Recourir à JavaScript alors que du CSS ou une balise meta suffit.** Presque chaque élément ici se résout en une seule déclaration. Un hook `useIsTouchDevice()` pour masquer les états hover est le mauvais outil ; une media query est le bon.

## Règles strictes

1. **Chaque correctif est accompagné de sa raison.** Chaque règle ci-dessous a un *pourquoi*. Appliquez-la là où la raison s'applique, pas globalement par réflexe — `user-select: none` sur le corps de texte est un défaut, sur un bouton c'est correct.
2. **Media queries plutôt que détection de l'appareil (device sniffing).** `(hover: hover)`, `(pointer: fine)`, `env()`, `dvh` — la plateforme indique ce dont elle est capable. Ne faites jamais de branchement conditionnel basé sur le user-agent ou la largeur de l'écran pour deviner l'usage du tactile.
3. **Tactile et souris ne s'excluent pas mutuellement.** Pensez aux iPad avec trackpad, aux ordinateurs portables à écran tactile, aux téléphones avec souris. Développez pour les deux à la fois ; filtrez par capacité matérielle, pas par type d'appareil.
4. **Ne désactivez jamais le zoom.** `user-scalable=no` et `maximum-scale=1` sont des fautes d'accessibilité. Corrigez plutôt la taille de police des champs de saisie, qui est la cause réelle du déclenchement du zoom.
5. **Testez sur du vrai matériel avant de considérer la tâche terminée.** Connectez le téléphone, ouvrez le serveur de développement via son IP locale, utilisez l'inspecteur web de Safari ou le débogage à distance de Chrome. L'émulation logicielle ne peut pas reproduire le hover persistant, le délai de tap, l'effet de rebond (rubber-banding), les safe areas ou le clavier virtuel.

## Tableau des symptômes

Commencez ici. Identifiez ce que constate l'utilisateur, puis lisez la section correspondante pour comprendre la cause et obtenir le code exact.

| Problème | Solution |
| --- | --- |
| État hover bloqué après un tap | Encapsuler dans `@media (hover: hover) and (pointer: fine)` |
| Flash gris/bleu au tap | Supprimer `-webkit-tap-highlight-color` |
| Hauteur de mise en page incorrecte | `100dvh` (application) ou `100svh` (hero) |
| La page zoome sur l'input | Taille de police des inputs à 16px minimum |
| Le tap semble lent | Rétroaction sur pointer-down + `touch-action: manipulation` |
| Le pull-to-refresh détourne le défilement | `overscroll-behavior: none` sur `html, body` |
| Le contenu s'arrête à l'encoche | `viewport-fit=cover` + `env(safe-area-inset-*)` |
| L'appui long sélectionne le texte du bouton | Ajouter `user-select: none` |
| Le carrousel défile verticalement | `touch-action: pan-y` sur la surface de geste |
| La couleur de la barre d'état ne correspond pas | `theme-color` par schéma de couleur |
| Correct dans Chrome, anormal sur téléphone | Tester sur du vrai matériel |

## Les correctifs

### 1. État hover bloqué après un tap

Le tactile ne gère pas le survol, les navigateurs simulent donc cet état : le premier tap sur un élément applique `:hover` et le laisse actif jusqu'à ce que l'utilisateur tape ailleurs. Un bouton qui grossit au survol reste agrandi après avoir été touché. Protégez chaque style de survol derrière une requête de capacité.

```css
@media (hover: hover) and (pointer: fine) {
  .button:hover {
    background: var(--gray-3);
    transform: scale(1.02);
  }
}
```

Les deux conditions sont indispensables. `(hover: hover)` signifie que le périphérique d'entrée principal peut survoler. `(pointer: fine)` signifie qu'il est précis, comme une souris — cela exclut les stylets et les rares appareils Android qui prétendent gérer le hover. Dans Tailwind v4, la variante `hover:` compile déjà en `@media (hover: hover)` ; dans la v3, activez `future.hoverOnlyWhenSupported`.

Les utilisateurs tactiles ont tout de même besoin d'un retour visuel lors de l'appui. Fournissez-le via `:active` (voir §5), qui fonctionne sur tous les types d'entrées.

### 2. Flash gris/bleu au tap

Safari iOS et Chrome Android appliquent une surbrillance translucide sur tout élément touché associé à un gestionnaire de clic. C'est le signal le plus flagrant qui crie « ceci est un site web », et il entre en conflit avec la rétroaction d'appui que vous avez conçue.

```css
html {
  -webkit-tap-highlight-color: transparent;
}
```

Définissez-le une fois, globalement. Assurez-vous ensuite que chaque élément interactif possède son propre état `:active`, car vous venez de supprimer le seul retour visuel que le navigateur fournissait par défaut.

### 3. Hauteur de mise en page incorrecte

Sur mobile, `100vh` correspond au *plus grand* viewport possible — c'est-à-dire la hauteur lorsque l'interface du navigateur est rétractée. Au chargement initial, la barre d'URL est visible : un élément en `100vh` déborde donc de la hauteur de cette barre, et un bouton fixé en bas se retrouve masqué en dessous. Utilisez plutôt les unités dynamiques et petites :

```css
/* Shell de l'application, tiroirs, tout ce qui doit suivre la zone visible quand l'interface s'affiche/se masque */
.app { height: 100dvh; }

/* Sections hero et premiers écrans — la plus petite taille du viewport, pour que rien ne soit jamais tronqué */
.hero { min-height: 100svh; }
```

`dvh` s'ajuste au fur et à mesure que la barre d'URL se rétracte, ce qui est parfait pour le conteneur principal d'une application mais provoque des sauts de mise en page (layout shifts) désagréables sur du contenu marketing en plein défilement. `svh` est stable et ne déborde jamais, ce qui convient parfaitement à une section hero. `lvh` correspond à l'ancien `vh` — vous n'en aurez presque jamais besoin. Ne conservez une ligne de repli avec `100vh` au-dessus que si la matrice de compatibilité des navigateurs du projet l'exige.

### 4. La page zoome sur l'input

Safari iOS zoome automatiquement sur la page lorsque le focus arrive sur un champ de saisie dont la taille de police est inférieure à 16px, et il ne dézoome pas lors de la perte de focus. L'utilisateur se retrouve avec une mise en page tronquée et décalée. C'est la raison pour laquelle certains ont le réflexe d'utiliser `maximum-scale=1`, ce qui est une mauvaise solution (Règle stricte 4).

```css
input, textarea, select {
  font-size: 16px; /* le minimum ; 1rem avec la taille racine par défaut */
}
```

Si le design impose un texte plus petit dans les inputs sur ordinateur, n'augmentez la taille que là où c'est nécessaire :

```css
@media (pointer: coarse) {
  input, textarea, select { font-size: 16px; }
}
```

Pendant que vous configurez vos champs, ajustez le type de clavier : `inputmode="numeric"` pour les codes, `inputmode="decimal"` pour les montants, `type="email"` et `type="tel"` pour les champs correspondants, `autocapitalize="none"` et `autocorrect="off"` pour les identifiants et codes, `enterkeyhint="send"` / `"search"` / `"done"` pour que la touche Entrée indique clairement son action.

### 5. Le tap semble lent

Deux causes distinctes se cumulent ici.

**Le délai de clic de 300 ms.** Les navigateurs attendent un court instant après un tap pour vérifier si un second tap arrive, car le double-tap sert à zoomer. Les navigateurs modernes suppriment cette attente lorsque le viewport contient `width=device-width`, mais pas dans toutes les situations (Safari iOS conserve ce délai sur certains éléments). `touch-action: manipulation` informe le navigateur que cet élément ne sera jamais soumis au double-tap pour zoomer, déclenchant ainsi `click` immédiatement :

```css
button, a, [role="button"], .tappable {
  touch-action: manipulation;
}
```

**Rétroaction au relâchement plutôt qu'à l'appui.** Les boutons natifs réagissent à la milliseconde où votre doigt touche l'écran. Un bouton web qui ne change d'état qu'au `click` réagit lorsque votre doigt *quitte* l'écran, ce qui est perçu comme une latence, même à 0 ms. Définissez le style `:active`, et si vous devez utiliser JavaScript, écoutez `pointerdown` et non `click` :

```css
.button {
  transition: transform 100ms var(--ease-out), background 100ms;
}
.button:active {
  transform: scale(0.97);
  background: var(--gray-4);
}
```

Maintenez la durée de la rétroaction d'appui entre 100 et 160 ms avec un `ease-out`. Si le projet utilise les variables de la compétence `animate`, utilisez-les ; ne créez pas de nouvelle courbe arbitraire.

### 6. Le pull-to-refresh détourne le défilement

Faire défiler au-delà du haut de la page déclenche le pull-to-refresh sur Chrome Android et l'effet de rebond de la page entière sur iOS. Ce comportement est acceptable sur un document textuel, mais inadapté dans une application possédant ses propres conteneurs de défilement, un volet coulissant qu'on tire vers le bas ou un canvas.

```css
html, body {
  overscroll-behavior: none;
}
```

Ensuite, sur n'importe quel conteneur interne à défilement — le contenu d'un volet, une liste de discussion, une barre latérale — empêchez le défilement de se propager à la page parente lorsqu'il atteint l'extrémité :

```css
.sheet-content {
  overflow-y: auto;
  overscroll-behavior: contain;
}
```

`contain` préserve le rebond propre au conteneur (ce qui donne une sensation native) tout en empêchant la page située en arrière-plan de bouger. Utilisez `none` à la racine et `contain` sur les éléments enfants. N'utilisez jamais un écouteur `touchmove` avec `preventDefault()` pour cela : cela bloque complètement le défilement et force l'écouteur à ne pas être passif, dégradant ainsi le taux de rafraîchissement (framerate).

### 7. Le contenu s'arrête à l'encoche

Par défaut, le navigateur insère des bandes autour de votre page dans la zone de sécurité (safe area), laissant l'encoche, la Dynamic Island et la zone de la barre d'accueil à la couleur d'arrière-plan du body. Une application native s'affiche d'un bord à l'autre de l'écran et applique un espacement interne (*padding*) à son *contenu* pour l'éloigner de ces zones critiques. Deux étapes sont nécessaires :

```html
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
```

```css
.app-header {
  padding-top: env(safe-area-inset-top);
}
.bottom-bar {
  padding-bottom: env(safe-area-inset-bottom);
}
.sheet {
  padding-bottom: calc(1rem + env(safe-area-inset-bottom));
}
```

`viewport-fit=cover` permet à la page de s'étendre sous l'encoche ; `env(safe-area-inset-*)` fournit les valeurs d'espacement pour compenser. Sans la balise meta, les valeurs `env()` valent toutes `0px`. Les en-têtes fixes, les barres d'onglets inférieures, les toasts et les volets sont les éléments qui en ont besoin ; le contenu standard de la page en bénéficie généralement via le padding de l'en-tête. Fournissez toujours une valeur de secours à `env()` (`env(safe-area-inset-bottom, 0px)`) lorsqu'elle est utilisée dans un calcul `calc()`.

### 8. L'appui long sélectionne le texte du bouton

Maintenir un doigt sur un bouton web incite iOS à sélectionner son libellé ou à ouvrir la bulle de partage/copie sur un lien. Les contrôles natifs ne font jamais cela. Un texte servant de *contrôle* ne doit pas pouvoir être sélectionné ; un texte qui constitue du *contenu* doit impérativement rester sélectionnable.

```css
button, [role="button"], .tab, .chip, .drag-handle {
  user-select: none;
  -webkit-user-select: none;   /* Safari requiert toujours le préfixe */
  -webkit-touch-callout: none; /* supprime le menu contextuel au clic long sur les liens/images utilisés comme contrôles */
}
```

N'appliquez jamais `user-select: none` sur `body`. Les utilisateurs ont besoin de copier des adresses, des messages d'erreur et des numéros de commande : ce sont des contenus.

### 9. Le carrousel défile verticalement

Un geste de balayage horizontal sur un carrousel est ambigu pour le navigateur : ne sachant pas si l'utilisateur souhaite faire défiler la page ou le rail du carrousel, il tente de deviner. Résultat : la page tressaute souvent verticalement pendant que le carrousel se déplace. Définissez explicitement les axes pris en charge par l'élément :

```css
.carousel {
  touch-action: pan-y; /* le carrousel gère l'axe horizontal ; le navigateur conserve le vertical */
}
.drag-surface {
  touch-action: none;  /* un geste personnalisé (volet glissé pour fermer, curseur) s'approprie tous les axes */
}
.vertical-sheet-handle {
  touch-action: pan-x; /* le volet gère le glissement vertical ; l'horizontal reste au navigateur */
}
```

Les valeurs indiquent ce que le *navigateur* est autorisé à continuer de gérer. `pan-y` sur un carrousel horizontal signifie : « Navigateur, conserve le défilement vertical, je prends en charge l'horizontal ». `none` signifie que l'élément gère l'intégralité des gestes — ne l'appliquez que sur les composants qui le font réellement, sinon l'utilisateur ne pourra plus faire défiler la page au travers de cette zone.

Si le carrousel repose sur le défilement natif plutôt que sur des gestes JavaScript, privilégiez `scroll-snap-type: x mandatory` sur la piste et `scroll-snap-align: start` sur les diapositives : la physique native du navigateur surpasse n'importe quelle animation de ressort artisanale, et `touch-action` devient alors superflu.

### 10. La couleur de la barre d'état ne correspond pas

La barre d'état et l'interface du navigateur s'accordent avec la valeur de `theme-color`. Une valeur unique risque de donner une barre sombre en mode clair, ou une barre blanche en mode sombre. Définissez une valeur propre à chaque thème :

```html
<meta name="theme-color" media="(prefers-color-scheme: light)" content="#ffffff" />
<meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0a0a0a" />
<meta name="color-scheme" content="light dark" />
```

Faites correspondre cette valeur avec la couleur située tout en haut de votre page — l'arrière-plan de l'en-tête, et non la couleur de votre marque. Avec Next.js, configurez cela via l'export `viewport` (`themeColor: [{ media, color }]`). Si l'application change de thème à l'aide d'une classe CSS plutôt que des réglages du système d'exploitation, mettez à jour la balise dynamiquement en JavaScript lors du basculement. Pour une PWA installée, `apple-mobile-web-app-status-bar-style` ainsi que les propriétés `theme_color`/`background_color` du manifeste relèvent de la même logique.

### 11. Correct dans Chrome, anormal sur téléphone

Aucun des problèmes ci-dessus ne peut être fidèlement reproduit via l'émulation d'appareils sur ordinateur. Le hover persistant, la surbrillance au tap, l'impact de la barre d'URL sur `vh`, le zoom automatique sur les inputs, le délai de clic, le rebond au défilement, les safe areas, l'apparition du clavier virtuel : chacun d'entre eux est un comportement intrinsèque au matériel réel.

- Connectez le téléphone en USB, lancez le serveur de développement sur `0.0.0.0`, ouvrez-le via l'adresse IP locale de votre machine.
- iOS : Safari → Développement → sélectionner l'appareil. Android : `chrome://inspect`.
- Testez sur un téléphone vieux de quelques années, pas uniquement sur le modèle haut de gamme posé sur votre bureau. Testez avec le clavier ouvert. Testez au moins une fois en orientation paysage.
- Testez en mode PWA installée si c'est une cible visée ; le mode autonome (standalone) modifie le viewport, les safe areas et le comportement de la barre d'état.

Le simulateur Xcode constitue une amélioration par rapport à l'émulation navigateur, mais ne retranscrit toujours pas la sensation tactile réelle. Le vrai matériel reste l'unique référence.

## Socle de base

Au démarrage d'un projet ciblant le mobile, voici le strict minimum requis. Intégrez-le avant même de coder le premier composant :

```html
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content" />
<meta name="theme-color" media="(prefers-color-scheme: light)" content="#ffffff" />
<meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0a0a0a" />
```

```css
html {
  -webkit-tap-highlight-color: transparent;
  -webkit-text-size-adjust: 100%; /* évite le grossissement du texte en paysage */
  overscroll-behavior: none;
}

input, textarea, select {
  font-size: 16px;
}

button, a, [role="button"] {
  touch-action: manipulation;
  user-select: none;
  -webkit-user-select: none;
}

@media (hover: hover) and (pointer: fine) {
  /* toutes les règles :hover doivent résider ici */
}
```

`interactive-widget=resizes-content` permet au clavier virtuel de réduire la taille du viewport sur Chrome Android, assurant ainsi que `100dvh` et les champs fixés en bas réagissent comme sur iOS. Supprimez `overscroll-behavior: none` de l'élément `html` si votre application est un document textuel continu où le geste de pull-to-refresh reste pertinent.

## À ne jamais livrer

Vérification systématique avant de conclure.

| Ne jamais utiliser | Utiliser à la place |
| --- | --- |
| `user-scalable=no` ou `maximum-scale=1` | Inputs à 16px — traiter la cause |
| `:hover` sans condition | `@media (hover: hover) and (pointer: fine)` |
| `100vh` pour le shell d'une application ou une UI fixée en bas | `100dvh` |
| `100dvh` sur un bandeau hero marketing | `100svh` (évite les décalages visuels au scroll) |
| Rétroaction visuelle uniquement sur `click` | `:active` / `pointerdown` |
| `touchmove` + `preventDefault()` pour empêcher le rebond | `overscroll-behavior` |
| `user-select: none` sur `body` | Uniquement sur les éléments de contrôle |
| `touch-action: none` sur un élément que l'utilisateur doit pouvoir faire défiler | `pan-x` / `pan-y` |
| `env(safe-area-inset-*)` sans `viewport-fit=cover` | Ajouter la balise meta, sinon la valeur est `0` |
| Une seule `theme-color` pour les deux thèmes | Une par valeur de `prefers-color-scheme` |
| Détection du user-agent pour identifier le tactile | Media queries `(hover)` / `(pointer)` |
| Déclarer le bug résolu via l'émulation sur PC | Tester sur du vrai matériel |

## Format de sortie

Appliquez les correctifs. Ensuite, en quelques lignes au maximum :

- **Ce qui n'allait pas** — le symptôme identifié dans le tableau, et la raison en une ligne.
- **Ce qui a changé** — le fichier et la déclaration, une ligne chacun.
- **Ce qui requiert un téléphone** — les correctifs vérifiables depuis le code et ceux que l'utilisateur doit impérativement valider sur matériel réel.

Ne transformez pas cela en un long rapport. Le code est le seul livrable attendu.

## Ton

Tranché et concis. La plupart de ces corrections tiennent en une seule ligne : indiquez la ligne, donnez la raison et passez à la suite. Si la réponse honnête est « Je ne peux pas vérifier ce comportement sans appareil physique », dites-le clairement au lieu d'affirmer que c'est corrigé.
