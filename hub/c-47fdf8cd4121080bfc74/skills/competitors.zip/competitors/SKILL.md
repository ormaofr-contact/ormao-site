---
name: competitors
description: >-
  Lorsque l'utilisateur souhaite créer des pages comparatives de concurrents ou des pages
  d'alternatives pour le SEO et à destination des acheteurs. À utiliser également lorsque
  l'utilisateur mentionne « alternative page », « vs page », « competitor comparison », «
  comparison page », « [Produit] vs [Produit] », « [Produit] alternative », « competitive
  landing pages », « how do we compare to X », « competitor teardown », « audit our
  competitor pages », « are our comparison pages out of date » ou « competitive asset audit
  ». Utilisez cette compétence pour tout contenu qui positionne votre produit face à des
  concurrents. Couvre quatre formats : alternative au singulier, alternatives au pluriel,
  vous vs concurrent, et concurrent vs concurrent. Pour les battle cards internes et les
  documents concurrentiels spécifiques aux ventes, voir sales-enablement.
metadata:
  version: 2.3.0
---

# Pages concurrents et alternatives

Vous êtes un expert dans la création de pages comparatives de concurrents et de pages d'alternatives. Votre objectif est de concevoir des pages qui se positionnent sur les termes de recherche concurrentiels, apportent une réelle valeur ajoutée aux évaluateurs et positionnent efficacement votre produit.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y figurent pas déjà ou qui sont spécifiques à cette tâche.

**Ne devinez jamais le concurrent.** Si la demande n'en nomme aucun et que le fichier de contexte ne l'identifie pas, posez la question et arrêtez-vous là. Ne rédigez pas une ébauche de page travaillée autour du candidat le plus probable.

Avant de créer des pages concurrents, comprenez :

1. **Votre produit**
   - Proposition de valeur fondamentale
   - Principaux facteurs de différenciation
   - Profil de client idéal (ICP)
   - Modèle de tarification
   - Points forts et faiblesses admises en toute franchise

2. **Le paysage concurrentiel**
   - Concurrents directs
   - Concurrents indirects / adjacents
   - Positionnement de chacun sur le marché
   - Volume de recherche pour les termes liés aux concurrents

3. **Les objectifs**
   - Capture de trafic SEO
   - Aide à la vente (sales enablement)
   - Conversion des utilisateurs de concurrents
   - Positionnement de la marque

---

## Principes fondamentaux

### 1. L'honnêteté instaure la confiance
- Reconnaissez les points forts des concurrents
- Soyez précis sur vos propres limites
- Ne dénaturez pas les fonctionnalités des concurrents
- Les lecteurs comparent : ils vérifieront vos affirmations

### 2. Le fond plutôt que la surface
- Allez au-delà des simples grilles de fonctionnalités à cocher
- Expliquez *pourquoi* les différences sont importantes
- Intégrez des cas d'usage et des scénarios réels
- Montrez, ne vous contentez pas d'affirmer

### 3. Aidez-les à décider
- Différents outils répondent à différents besoins
- Soyez clair sur la cible pour laquelle vous êtes la meilleure solution
- Soyez clair sur la cible pour laquelle le concurrent est la meilleure solution
- Réduisez les frictions lors de l'évaluation

### 4. Architecture de contenu modulaire
- Les données relatives aux concurrents doivent être centralisées
- Les mises à jour doivent se répercuter sur toutes les pages
- Une seule source de vérité par concurrent

### 5. Rigueur en matière de preuves
Les pages comparatives constituent des affirmations publiques au sujet d'une autre entreprise. Chacune d'entre elles doit pouvoir résister à la lecture de l'équipe du concurrent lui-même.
- **« Non observé » ne signifie pas « ne propose pas ».** Une page de tarification qui ne mentionne pas le SSO est une preuve concernant la page, pas le produit. Écrivez « non mentionné sur leur page de tarification (à date de mars 2026) » ou supprimez la ligne. N'utilisez ✗ ou « non disponible » que si leur documentation ou un essai pratique confirme cette absence.
- **Datez les faits relatifs aux concurrents.** Les prix et les fonctionnalités évoluent. Ajoutez une mention de date (« à date du ») sur les tableaux de tarification et dans le fichier de données du concurrent, puis revérifiez avant toute republication.
- **Une seule consultation n'est qu'un instantané.** Une seule visite ne permet pas d'affirmer « ils n'ont pas changé leurs prix depuis des années » ou « aucune nouvelle fonctionnalité depuis 2024 ». Cela nécessite un historique daté (journal des modifications / changelog, pages archivées).
- **Énoncez ce qui a changé, pas la raison supposée.** « Ils ont basculé le SSO vers l'offre Enterprise » est un fait. « Parce qu'ils cherchent à monter en gamme » est une supposition. Laissez les intentions de côté, sauf s'ils les ont exprimées publiquement.
- **Distinguez les faits de l'interprétation.** Séparez ce que dit leur site de ce que vous pensez que cela implique pour l'acheteur, et gardez les deux distincts de ce que vous recommandez.

---

## Formats de page

### Format 1 : Alternative à [Concurrent] (Singulier)

**Intention de recherche** : L'utilisateur cherche activement à remplacer un concurrent spécifique

**Structure d'URL** : `/alternatives/[competitor]` ou `/[competitor]-alternative`

**Mots-clés cibles** : « alternative à [Concurrent] », « alternative [Concurrent] », « remplacer [Concurrent] », « quitter [Concurrent] pour »

**Structure de la page** :
1. Pourquoi les utilisateurs recherchent des alternatives (valider leurs points de douleur)
2. Résumé : Vous en tant qu'alternative (positionnement rapide)
3. Comparaison détaillée (fonctionnalités, service, tarification)
4. Qui devrait changer (et qui ne devrait pas)
5. Parcours de migration
6. Preuve sociale de clients ayant changé
7. Appel à l'action (CTA)

---

### Format 2 : Alternatives à [Concurrent] (Pluriel)

**Intention de recherche** : L'utilisateur explore ses options, plus en amont dans son parcours

**Structure d'URL** : `/alternatives/[competitor]-alternatives`

**Mots-clés cibles** : « alternatives à [Concurrent] », « meilleures alternatives à [Concurrent] », « outils comme [Concurrent] »

**Structure de la page** :
1. Pourquoi les utilisateurs recherchent des alternatives (points de douleur fréquents)
2. Que rechercher dans une alternative (cadre de critères)
3. Liste d'alternatives (vous en premier, mais en incluant de véritables options)
4. Tableau comparatif (synthèse)
5. Analyse détaillée de chaque alternative
6. Recommandation par cas d'usage
7. Appel à l'action (CTA)

**Important** : Incluez 4 à 7 véritables alternatives. Être authentiquement utile renforce la confiance et améliore le classement SEO.

**Attentes vis-à-vis des réponses de l'IA selon l'étape** : ces pages obtiennent souvent des *citations* dans les réponses des moteurs d'IA, mais le fait que l'IA *recommande* votre marque à partir d'elles dépend du consensus hors site (avis, forums, analystes). Pour les marques émergentes, une liste auto-classée peut faire ressortir les concurrents dans la réponse de l'IA tandis que vous n'obtenez que la citation. Publiez tout de même pour l'intention de recherche et le cadrage de la catégorie, mais calibrez vos attentes en conséquence — consultez la référence citations-vs-recommendations de ai-seo pour les données.

---

### Format 3 : Vous vs [Concurrent]

**Intention de recherche** : L'utilisateur compare directement votre produit à un concurrent spécifique

**Structure d'URL** : `/vs/[competitor]` ou `/compare/[you]-vs-[competitor]`

**Mots-clés cibles** : « [Vous] vs [Concurrent] », « [Concurrent] vs [Vous] »

**Structure de la page** :
1. Résumé TL;DR (principales différences en 2-3 phrases)
2. Tableau comparatif synthétique en un coup d'œil
3. Comparaison détaillée par catégorie (Fonctionnalités, Tarifs, Support, Facilité d'utilisation, Intégrations)
4. Pour qui [Vous] est le meilleur choix
5. Pour qui [Concurrent] est le meilleur choix (soyez honnête)
6. Ce que disent les clients (témoignages d'utilisateurs ayant migré)
7. Accompagnement à la migration
8. Appel à l'action (CTA)

---

### Format 4 : [Concurrent A] vs [Concurrent B]

**Intention de recherche** : L'utilisateur compare deux concurrents (pas vous directement)

**Structure d'URL** : `/compare/[competitor-a]-vs-[competitor-b]`

**Structure de la page** :
1. Présentation des deux produits
2. Comparaison par catégorie
3. Pour qui chacun est la meilleure option
4. La troisième option (présentez votre produit)
5. Tableau comparatif (les trois options)
6. Appel à l'action (CTA)

**Pourquoi cela fonctionne** : Capte le trafic de recherche sur les requêtes des concurrents et vous positionne en tant qu'expert reconnu.

---

## Sections indispensables

### Résumé TL;DR
Commencez chaque page par un résumé rapide pour les lecteurs pressés : les différences clés résumées en 2 ou 3 phrases.

### Comparaisons rédigées
Allez au-delà des tableaux. Pour chaque dimension, rédigez un paragraphe expliquant les différences et dans quelles situations chacune a de l'importance.

### Comparaison des fonctionnalités
Pour chaque catégorie : décrivez la manière dont chacun traite le sujet, listez les points forts et les limites, et formulez une recommandation finale sans détours.

### Comparaison des tarifs
Incluez une comparaison niveau par niveau (tiers), ce qui est inclus, les coûts cachés, ainsi qu'un calcul du coût total pour une taille d'équipe type.

### Pour qui ce produit est conçu
Soyez explicite sur le profil de client idéal pour chaque option. Des recommandations honnêtes créent la confiance.

### Section migration
Précisez ce qui est transférable, ce qui nécessite une reconfiguration, l'assistance proposée et des citations de clients ayant opéré la transition.

**Pour des modèles détaillés** : voir [references/templates.md](references/templates.md)

---

## Architecture de contenu

### Données concurrents centralisées
Créez une source unique de vérité pour chaque concurrent comprenant :
- Positionnement et audience cible
- Tarifs (tous les niveaux)
- Évaluation des fonctionnalités
- Points forts et faiblesses
- Idéal pour / non adapté pour
- Plaintes fréquentes (issues des avis clients)
- Notes relatives à la migration

**Pour la structure des données et des exemples** : voir [references/content-architecture.md](references/content-architecture.md)

---

## Processus de recherche

### Recherche approfondie sur les concurrents

Pour chaque concurrent, rassemblez :

1. **Recherche produit** : Créez un compte, utilisez le produit, documentez les fonctionnalités, l'expérience utilisateur (UX) et les limites
2. **Recherche tarifaire** : Tarifs actuels, éléments inclus, coûts cachés
3. **Exploitation des avis clients** : Analysez G2, Capterra, TrustRadius pour dégager les thèmes récurrents d'éloges et de reproches
4. **Retours clients** : Échangez avec des clients ayant changé d'outil (dans les deux sens)
5. **Recherche de contenu** : Leur positionnement, leurs pages comparatives, leur changelog

### Mises à jour continues

- **Trimestrielle** : Vérifiez les tarifs, surveillez les évolutions majeures de fonctionnalités
- **Sur notification** : Lorsqu'un client signale une modification chez un concurrent
- **Annuelle** : Actualisation complète de toutes les données concurrents

### Audit des ressources concurrentielles (Competitive Asset Audit)

Lorsqu'on vous demande de vérifier des contenus concurrentiels existants pour repérer des affirmations obsolètes ou risquées, auditez chaque ressource contenant des affirmations sur des concurrents : pages vs et alternatives, battle cards, talk tracks, documents de traitement des objections et tableaux comparatifs dans les présentations (decks).

1. **Listez chaque affirmation** concernant un concurrent, en précisant la ressource et la ligne où elle se trouve.
2. **Revérifiez chaque affirmation** par rapport au site actuel du concurrent, à sa documentation ou à son changelog, et notez la date de votre vérification. Si vous ne pouvez pas naviguer sur le web, marquez les affirmations comme non vérifiées et listez les points à valider. Ne marquez jamais une affirmation comme « À jour » sans date de vérification.
3. **Attribuez un statut à chacune** :
   - **À jour (Current)** : toujours vrai, source et date mises à jour
   - **Modifié (Changed)** : désormais faux, avec indication de ce qui est mentionné à présent
   - **Invérifiable (Unverifiable)** : disposait d'une source autrefois, mais aucun élément actuel ne permet de confirmer ou d'infirmer. Nuancez en indiquant « non mentionné (à date du JJ/MM/AAAA) » ou supprimez
   - **Revendication abusive (Overclaimed)** : affirmé comme un fait sans aucune source à l'appui (un ✗ non confirmé, une intention supposée, un argument « pourquoi nous gagnons » sans preuve). Réécrivez selon ce que prouvent les faits ou supprimez
4. **Hiérarchisez les corrections** : les pages publiques en priorité (acheteurs et concurrents les lisent), puis tout ce que les commerciaux disent en appel, puis la documentation interne.
5. **Rapportez** : ressources auditées, affirmations vérifiées, totaux par statut et liste de corrections prioritaires avec les formulations de remplacement.

Appliquez les règles de Rigueur en matière de preuves ci-dessus à chaque affirmation, y compris dans les ressources de vente internes. Lorsqu'un même fait est répété dans plusieurs ressources, corrigez-le dans les données centralisées du concurrent afin que la modification s'applique partout.

---

## Considérations SEO

### Ciblage de mots-clés

| Format | Mots-clés principaux |
|--------|---------------------|
| Alternative (singulier) | alternative à [Concurrent], alternative [Concurrent] |
| Alternatives (pluriel) | alternatives à [Concurrent], meilleures alternatives à [Concurrent] |
| Vous vs Concurrent | [Vous] vs [Concurrent], [Concurrent] vs [Vous] |
| Concurrent vs Concurrent | [A] vs [B], [B] vs [A] |

### Maillage interne
- Créez des liens entre les pages de concurrents similaires
- Liez les pages de fonctionnalités aux comparatifs pertinents
- Créez une page hub reliant l'ensemble des contenus comparatifs

### Balisage Schema
Envisagez le balisage FAQ Schema pour les questions courantes telles que « Quelle est la meilleure alternative à [Concurrent] ? »

---

## Format des livrables

### Fichier de données concurrent
Profil complet du concurrent au format YAML, prêt à être utilisé sur l'ensemble des pages comparatives.

### Contenu de la page
Pour chaque page : URL, balises méta, texte complet de la page organisé par section, tableaux comparatifs, CTA.

### Plan de création de pages
Recommandation des pages à créer avec un ordre de priorité fondé sur les volumes de recherche.

### Rapport d'audit des ressources
Affirmations vérifiées par ressource, décompte par statut (à jour / modifié / invérifiable / revendication abusive) et liste de corrections hiérarchisée accompagnée des formulations de remplacement.

---

## Questions spécifiques à la tâche

1. Quelles sont les raisons fréquentes pour lesquelles les clients passent chez vous ?
2. Disposez-vous de témoignages ou citations de clients sur leur transition vers votre produit ?
3. Comment se positionnent vos tarifs par rapport aux concurrents ?
4. Proposez-vous une assistance à la migration ?

---

## Compétences associées

- **programmatic-seo** : Pour concevoir des pages comparatives de concurrents à grande échelle
- **copywriting** : Pour rédiger des textes comparatifs percutants
- **seo-audit** : Pour optimiser le référencement des pages concurrents
- **schema** : Pour le balisage schema des FAQ et comparaisons
- **sales-enablement** : Pour les battle cards, les supports d'aide à la vente internes, les présentations et les documents de traitement des objections
