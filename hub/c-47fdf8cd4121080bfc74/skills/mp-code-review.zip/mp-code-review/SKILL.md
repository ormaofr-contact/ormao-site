---
name: code-review
description: "Examine les modifications depuis un point fixe (commit, branche, tag ou merge-base) selon deux axes : Standards (le code respecte-t-il les standards de codage documentés de ce dépôt ?) et Spécifications (le code correspond-il à ce que demandait l'issue/la spécification d'origine ?). Exécute les deux revues dans des sous-agents en parallèle et présente leurs résultats côte à côte. À utiliser lorsque l'utilisateur souhaite réviser une branche, une PR, des modifications en cours, ou demande de « réviser depuis X »."
---

Revue sur deux axes du diff entre `HEAD` et un point fixe fourni par l'utilisateur :

- **Standards** : le code est-il conforme aux standards de codage documentés de ce dépôt ?
- **Spécifications** : le code implémente-t-il fidèlement l'issue / la spécification d'origine ?

Les deux axes s'exécutent sous forme de **sous-agents parallèles** afin de ne pas polluer mutuellement leur contexte, puis cette compétence agrège leurs conclusions.

Le gestionnaire de tickets (issue tracker) devrait vous avoir été fourni. Si ce n'est pas le cas, dites à l'utilisateur d'exécuter `/setup-matt-pocock-skills`.

## Processus

### 1. Définir le point fixe

Quel que soit l'élément indiqué par l'utilisateur comme point fixe (un SHA de commit, un nom de branche, un tag, `main`, `HEAD~5`, etc.). S'il n'en a pas spécifié, demandez-le-lui.

Récupérez la commande de diff une seule fois : `git diff <fixed-point>...HEAD` (trois points, pour que la comparaison se fasse par rapport à la merge-base). Notez également la liste des commits via `git log <fixed-point>..HEAD --oneline`.

Avant d'aller plus loin, confirmez que le point fixe est résolu (`git rev-parse <fixed-point>`) et que le diff n'est pas vide. Une référence invalide ou un diff vide doit échouer ici, et non à l'intérieur de deux sous-agents parallèles.

### 2. Identifier la source des spécifications

Cherchez la spécification d'origine, dans cet ordre :

1. Les références d'issue dans les messages de commit (`#123`, `Closes #45`, GitLab `!67`, etc.), récupérées via le workflow documenté dans le fichier du tracker.
2. Un chemin transmis par l'utilisateur en argument.
3. Un fichier de spécification sous `docs/`, `specs/` ou `.scratch/` correspondant au nom de la branche ou de la fonctionnalité.
4. Si rien n'est trouvé, demandez à l'utilisateur où se trouve la spécification. S'il répond qu'il n'y en a pas, le sous-agent **Spec** ignorera cette étape et signalera « aucune spécification disponible ».

### 3. Identifier les sources des standards

Cherchez dans le dépôt chaque fichier documentant la manière dont le code doit être rédigé. Lorsque `CODING_STANDARDS.md` ou `CONTRIBUTING.md` existe, il doit obligatoirement figurer dans la liste.

En plus de tout ce que le dépôt documente, l'axe Standards intègre toujours la **base de référence des code smells** ci-dessous : un ensemble fixe de code smells de Fowler (_Refactoring_, ch. 3) qui s'applique même lorsqu'un dépôt ne documente rien. Deux règles l'encadrent :

- **Le dépôt prévaut.** Un standard documenté du dépôt l'emporte toujours ; lorsqu'il autorise quelque chose que la base de référence signalerait, supprimez l'alerte sur ce code smell.
- **Toujours une affaire de jugement.** Chaque smell est une heuristique étiquetée (« possible Feature Envy »), jamais une violation absolue. Comme pour tout standard ici, ignorez tout ce qui est déjà appliqué par l'outillage.

Chaque smell se lit sous la forme *ce que c'est* → *comment le corriger* ; comparez-le au diff :

- **Mysterious Name** : une fonction, une variable ou un type dont le nom ne révèle pas ce qu'il fait ou contient. → renommez-le ; si aucun nom explicite ne vient, la conception est floue.
- **Duplicated Code** : la même logique apparaît sous la même forme dans plusieurs hunks ou fichiers de la modification. → extrayez la forme commune, appelez-la depuis les deux endroits.
- **Feature Envy** : une méthode qui accède davantage aux données d'un autre objet qu'aux siennes. → déplacez la méthode vers les données qu'elle convoite.
- **Data Clumps** : les mêmes quelques champs ou paramètres voyagent constamment ensemble (un type qui demande à naître). → regroupez-les en un seul type, passez ce type.
- **Primitive Obsession** : un type primitif ou une chaîne qui remplace un concept de domaine méritant son propre type. → donnez au concept son propre petit type.
- **Repeated Switches** : la même cascade de `switch`/`if` sur le même type réapparaît à plusieurs endroits dans la modification. → remplacez par du polymorphisme, ou par une map partagée par les deux emplacements.
- **Shotgun Surgery** : une seule modification logique entraîne des modifications éparpillées dans de nombreux fichiers du diff. → regroupez ce qui change ensemble dans un seul module.
- **Divergent Change** : un seul fichier ou module est modifié pour plusieurs raisons non liées. → séparez-le pour que chaque module ne change que pour une seule raison.
- **Speculative Generality** : abstraction, paramètres ou hooks ajoutés pour des besoins que la spécification ne mentionne pas. → supprimez-les ; réintégrez-les en ligne jusqu'à ce qu'un réel besoin apparaisse.
- **Message Chains** : une longue chaîne de navigation du type `a.b().c().d()` dont l'appelant ne devrait pas dépendre. → masquez ce parcours derrière une seule méthode sur le premier objet.
- **Middle Man** : une classe ou une fonction qui ne fait principalement que déléguer plus loin. → supprimez-la, appelez directement la vraie cible.
- **Refused Bequest** : une sous-classe ou une implémentation qui ignore ou redéfinit l'essentiel de ce dont elle hérite. → abandonnez l'héritage, utilisez la composition.

### 4. Lancer les deux sous-agents en parallèle

Lancez les deux appels de sous-agents ensemble, au premier plan, et agrégez les rapports qu'ils renvoient.

Le **prompt du sous-agent Standards** doit inclure :

- La commande complète du diff et la liste des commits.
- La liste des fichiers sources de standards identifiés à l'étape 3, **ainsi que la base de référence des smells de l'étape 3** collée dans son intégralité (le sous-agent n'a pas d'autre moyen d'y accéder).
- Les consignes : « Signalez, par fichier/hunk le cas échéant, (a) chaque endroit où le diff enfreint un standard documenté : citez le standard (fichier + règle) ; et (b) chaque smell de référence repéré : nommez-le et citez le hunk. Distinguez les violations strictes des éléments relevant du jugement : les infractions aux standards documentés peuvent être strictes, mais les smells de référence relèvent toujours du jugement, et un standard documenté du dépôt prévaut sur la base de référence. Ignorez tout ce qui est appliqué par l'outillage. Moins de 400 mots. »

Le **prompt du sous-agent Spec** doit inclure :

- La commande de diff et la liste des commits.
- Le chemin ou le contenu récupéré de la spécification.
- Les consignes : « Signalez : (a) les exigences demandées par la spécification qui sont manquantes ou partielles ; (b) les comportements dans le diff qui n'étaient pas demandés (dérive des objectifs / scope creep) ; (c) les exigences qui semblent implémentées mais dont l'implémentation semble incorrecte. Citez la ligne de la spécification pour chaque observation. Moins de 400 mots. »

Si la spécification est manquante, ignorez le sous-agent Spec et indiquez-le dans le rapport final.

### 5. Agréger

Présentez les deux rapports sous les titres `## Standards` et `## Spec`, textuellement ou légèrement nettoyés. Ne fusionnez **pas** et ne reclassez pas les constats, car les deux axes sont délibérément distincts (voir _Pourquoi deux axes_).

Terminez par un résumé d'une ligne : nombre total de constats par axe, et le problème le plus critique _au sein de chaque axe_ (le cas échéant). Ne choisissez pas un seul problème majeur entre les deux axes : c'est précisément ce reclassement que cette séparation cherche à éviter.

## Pourquoi deux axes

Une modification peut réussir sur un axe et échouer sur l'autre :

- Du code qui respecte tous les standards mais implémente la mauvaise chose → **Standards validés, Spec échouée.**
- Du code qui fait exactement ce que demandait l'issue mais enfreint les conventions du projet → **Spec validée, Standards échoués.**

Les rapporter séparément évite qu'un axe ne masque l'autre.
