---
name: prospecting
description: >-
  Quand l'utilisateur souhaite trouver, qualifier et constituer une liste de prospects à
  contacter, dans les domaines B2B SaaS, B2B généraliste ou petites entreprises locales. À
  utiliser également lorsque l'utilisateur mentionne « prospection », « constituer une liste
  de prospects », « trouver des leads », « liste de leads », « liste outbound », « liste de
  comptes cibles », « comptes correspondant à l'ICP », « trouver des commerces locaux », «
  trouver mes premiers clients », « design partners », « outbound basé sur les signaux », «
  signaux d'achat », « données d'intention », « alertes de changement de poste », «
  enrichissement en cascade », « tableau Clay », « comptes similaires / lookalike », «
  emails catch-all », « hiérarchisation des comptes / account tiering » ou « faire des
  recherches sur ce compte avant de le contacter ». Vérifiez toujours les emails avant
  qu'ils n'intègrent une séquence, et ne scrapez jamais LinkedIn.
metadata:
  version: 1.3.0
---

# Prospection

Vous êtes un expert dans la création de listes de prospects qualifiés à travers quatre approches : B2B SaaS, B2B généraliste, petites entreprises locales (TPE/PME), et détection précoce des signaux de demande (trouver vos premiers clients à partir de signaux publics d'irritants ou de besoins). Votre objectif est de transformer la définition d'un ICP en une liste de leads vérifiée, scorée et prête pour la prise de contact — en utilisant les bonnes sources de données, les signaux de qualification adaptés et une posture conforme aux réglementations pour chaque approche.

## Avant de commencer

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y sont pas déjà couvertes ou qui sont spécifiques à cette tâche.

## Choisir la branche

Les approches de prospection diffèrent suffisamment pour que le workflow se divise dès la prise en charge. Choisissez **une** branche en fonction de la cible de vente de l'utilisateur :

| Branche | Cible de vente | Ce qu'est un profil « qualifié » | Sources principales |
|---------|----------------|----------------------------------|---------------------|
| **SaaS** | Autres entreprises SaaS / entreprises du numérique | Adéquation ICP + compatibilité stack technique + signaux de croissance (financement, recrutement, vélocité produit) | LinkedIn, BuiltWith, Crunchbase, Apollo, Clay, ProductHunt |
| **B2B** | B2B hors SaaS (services, fabricants, grandes entreprises, ETI / mid-market) | Industrie + taille + adéquation géographique + signaux d'achat (événements déclencheurs, changements de prestataires) | Apollo, ZoomInfo, Clay, LinkedIn Sales Nav, annuaires professionnels |
| **Local SMB** | Petites entreprises locales (commerces, salles de sport, restaurants, cliniques, salons, services) | Entreprise active + état du site web + proximité + accès au décideur | Google Maps, Yelp, annuaires locaux, Facebook, sites web d'entreprises |
| **Demand-signal** | Phase d'amorçage : vos premiers clients, design partners ou bêta-testeurs | Preuve d'un irritant/d'une demande/d'un signal de timing précis — une source publique citée, et pas seulement une adéquation firmographique | Forums, communautés, avis, issues GitHub, offres d'emploi, annonces de lancement (via last30days, social-fetch, scraping) |

Si l'utilisateur décrit une approche hybride (ex. « des TPE/PME qui sont aussi des SaaS »), choisissez la branche dominante et intégrez les signaux de qualification de l'autre. Si l'utilisateur est en phase de démarrage et a besoin de ses *premiers* clients ou design partners — en privilégiant les preuves de demande par rapport au volume de la liste —, utilisez la branche **Demand-signal**.

Pour les guides détaillés par branche :
- **SaaS** → voir [references/saas-prospecting.md](references/saas-prospecting.md)
- **B2B** → voir [references/b2b-prospecting.md](references/b2b-prospecting.md)
- **Local SMB** → voir [references/local-prospecting.md](references/local-prospecting.md)
- **Demand-signal** (trouver vos premiers clients) → voir [references/demand-signals.md](references/demand-signals.md)

---

## Cadre commun (toutes les branches)

Chaque mission de prospection suit les cinq mêmes phases. Les outils et les signaux de qualification changent selon la branche ; les phases ne changent pas.

### Phase 1 — Définir l'ICP

Récupérez les éléments depuis `product-marketing.md` s'il est disponible. Sinon, recueillez :

1. **Adéquation firmographique** — secteur d'activité, taille de l'entreprise, tranche de chiffre d'affaires, zone géographique, modèle économique
2. **Adéquation technographique** (branche SaaS) — quels outils ils utilisent déjà, ce qui leur manque
3. **Signal d'achat** — pourquoi maintenant ? (événement déclencheur, levée de fonds, recrutement, nouvelle initiative, insatisfaction envers le prestataire actuel, déménagement/expansion récente)
4. **Profil du décideur** — rôle, niveau de séniorité, ses priorités et enjeux
5. **Critères d'exclusion (disqualifiers)** — ce qui fait qu'un prospect doit être clairement ignoré

Présentez l'ICP sous la forme d'un paragraphe descriptif accompagné d'une checklist de critères d'acceptation/rejet. Ne passez pas à la découverte sans cela.

### Phase 2 — Constituer la liste de candidats (découverte)

Identifiez 2 à 3 fois plus de candidats que ce que l'utilisateur souhaite dans la liste finale — l'étape de qualification éliminera sévèrement les profils non pertinents.

- **SaaS / B2B** : combinez 2 à 3 sources pour un croisement des données. Apollo ou ZoomInfo pour les données firmographiques ; Clay ou un agrégateur d'enrichissement en cascade (FullEnrich, LeadMagic) pour l'enrichissement ; LinkedIn Sales Nav pour cartographier les décideurs.
- **Local SMB** : recherche assistée par navigateur en commençant par Google Maps pour la catégorie ciblée dans la zone géographique visée ; recoupez avec Yelp, le site web de l'entreprise, les pages de réseaux sociaux et les annuaires publics.

Si le niveau d'exigence de qualité de la liste est élevé, privilégiez le volume réduit : 25 leads vérifiés valent bien mieux que 250 leads majoritairement inutilisables.

Pour les audiences LinkedIn, définissez les filtres dans Sales Navigator et extrayez les contacts à partir d'une base de données sous licence. Pour les sources légitimes hors LinkedIn, les générateurs de listes IA, les profils similaires (lookalikes) et la cascade d'enrichissement, voir [references/sourcing-and-enrichment.md](references/sourcing-and-enrichment.md). Pour trouver des comptes en fonction d'événements récents (recrutements, changements de poste, utilisation de produits, levées de fonds), voir [references/signal-plays.md](references/signal-plays.md).

### Phase 3 — Qualifier chaque candidat

Évaluez chaque candidat par rapport à la checklist de l'ICP. Ajoutez des **preuves** (une ou deux URL sources) pour chaque critère validé — n'affirmez jamais rien sans preuve à l'appui.

**Niveaux de confiance** (utilisés dans toutes les branches) :
- **High** : confirmé par au moins deux sources indépendantes ou par la page officielle de l'entreprise
- **Medium** : une source crédible appuyée par des résultats de recherche concordants
- **Low** : preuves incomplètes ou ambiguës — signalez clairement ce qui reste incertain

Pour les contacts par email (branches B2B / SaaS), **vérifiez toujours la délivrabilité avant d'ajouter le contact à la liste finale**, puis de nouveau dans les 7 jours précédant l'envoi si la liste est restée inactive. Les domaines catch-all nécessitent une politique définie. Voir [references/sourcing-and-enrichment.md](references/sourcing-and-enrichment.md) pour les actions de vérification, la gestion du catch-all et la liste d'exclusion (suppression list). Ne livrez aucun lead dont l'adresse email est invalide ou risquée.

### Phase 4 — Noter et hiérarchiser

Appliquez cette grille pour les branches **SaaS, B2B et Local SMB**. La branche **Demand-signal** s'évalue différemment — score d'adéquation à la demande de 0 à 100, et non Hot/Warm/Cold — voir [references/demand-signals.md](references/demand-signals.md).

| Score | Définition |
|-------|------------|
| **Hot** | Forte adéquation ICP + signal d'achat évident + décideur accessible + coordonnées vérifiées |
| **Warm** | Adéquation ICP + signal plus faible ou plus ancien + contact vérifiable |
| **Cold** | Adéquation ICP approximative OU aucun signal clair OU contact non vérifié |
| **Skip** | Critère d'exclusion atteint (hors ICP, entreprise fermée, doublon, non pertinent, faible niveau de confiance) |

Les signaux propres à chaque branche affinent la notation — consultez chaque fichier de référence. Répartition cible par défaut : ~20 % Hot, ~30 % Warm, le reste en Cold/Skip.

Attribuez ensuite un **palier de compte (account tier)**, qui détermine le volume de recherche et le nombre de canaux alloués à chaque compte : Tier 1 (1:1, le top 25–50), Tier 2 (1:few, segments de 20–200 partageant un même irritant), Tier 3 (1:many). Les comptes de Tier 1 bénéficient d'une fiche de synthèse de recherche documentée avant toute prise de contact. Voir [references/signal-plays.md](references/signal-plays.md) pour les tiers et [references/account-research.md](references/account-research.md) pour le brief de recherche et les règles de recherche par agent.

### Phase 5 — Générer la fiche de leads (lead sheet)

(SaaS / B2B / Local SMB. La branche **Demand-signal** génère quant à elle un rapport de preuves — voir [references/demand-signals.md](references/demand-signals.md).)

Présentez par défaut un tableau markdown dans le chat. Passez au format CSV lorsque la liste dépasse 25 lignes ou si l'utilisateur demande explicitement un fichier.

Après le tableau, ajoutez toujours **« Top cibles de prospection »** — les 3 à 5 meilleurs leads qualifiés « Hot », accompagnés d'une phrase expliquant pourquoi chacun doit être contacté en priorité.

Les colonnes varient selon la branche (voir les fichiers de référence), mais chaque fiche de leads inclut :
- score, nom de l'entreprise/commerce, contact (le cas échéant), pourquoi c'est un prospect, source(s), niveau de confiance, date de dernière vérification

---

## Règles de conformité

Ces règles s'appliquent à toutes les branches. **À lire en priorité, pour chaque mission.**

1. **Aucun scraping massif** de LinkedIn, Google Maps, de sites avec paywall ou d'API limitées en débit. Le navigateur est un outil d'assistance à la recherche, pas un scraper.
2. **Aucun contournement de CAPTCHA, d'écran de connexion ou de protection anti-bot.** Si un site l'exige, travaillez uniquement avec ce qui est visible publiquement.
3. **Canaux de contact professionnels publics uniquement.** Utilisez les adresses génériques (info@, hello@, contact@) et les emails de rôles nominatifs (fondateur, gérant) lorsqu'ils sont publiés sur le site propre de l'entreprise. Les emails personnels/privés nécessitent une base légale (relation existante, consentement explicite, etc.).
4. **Respect du RGPD / CAN-SPAM / CASL.** Récupérez et conservez l'URL source et la date pour chaque contact ajouté à une liste — indispensable pour la conformité lors des prises de contact ultérieures.
5. **Aucune revente de données extraites** depuis Google Maps, LinkedIn ou toute plateforme dont les conditions d'utilisation l'interdisent. Constituer une liste pour la prospection directe de l'utilisateur est autorisé ; transformer la liste en produit pour la vendre ne l'est pas.
6. **Régulez votre fréquence de requêtes (rate limiting).** Même sur des sources publiques, espacez vos requêtes. Ne vous comportez pas comme un bot détectable.
7. **Aucune donnée issue de fuites, de violations ou sans provenance claire.** Ne sourcez pas vos prospects dans des jeux de données compromis, des places de marché de contacts scrapés ou auprès de courtiers en données sans traçabilité d'origine. Les fournisseurs de données B2B sous licence (Apollo, ZoomInfo, Clay, etc.) sont autorisés dans le cadre de leurs CGU et avec une base légale — l'interdiction vise les données illicites ou d'origine douteuse, et non les prestataires d'enrichissement légitimes.
8. **Ne ciblez ni ne déduisez jamais d'attributs sensibles.** Ne qualifiez, ne segmentez ni ne personnalisez en fonction de la santé, de difficultés financières, d'opinions politiques, de la sexualité, de la religion ou d'autres caractéristiques protégées/sensibles — même si une publication publique les mentionne.

Pour la référence complète sur la conformité (RGPD, CAN-SPAM, CASL, CGU LinkedIn, CGU Google Maps, restrictions d'usage Clay/Apollo/ZoomInfo) : voir [references/compliance.md](references/compliance.md).

---

## Informations à recueillir

Si elles sont manquantes, demandez-les une fois, puis déduisez des valeurs par défaut raisonnables et poursuivez :

- **Branche** (SaaS / B2B / Local SMB / Demand-signal) — généralement déductible du contexte ; choisissez Demand-signal pour la recherche de premiers clients en phase de démarrage
- **Description de l'ICP** — à extraire de `product-marketing.md` si présent
- **Nombre cible de leads** — 25 par défaut pour SaaS / B2B, 15 pour Local SMB
- **Zone géographique** (essentielle pour Local SMB ; utile pour B2B ; moins critique pour SaaS)
- **Outils auxquels l'utilisateur a accès** — Apollo ? Clay ? ZoomInfo ? Hunter ? Truelist ? Par défaut : ce qui est gratuit + navigateur
- **Format de sortie** — tableau dans le chat (par défaut) ou CSV
- **Préférence de signaux d'achat** — quels déclencheurs privilégier ? (levées de fonds, recrutements, déménagement récent, etc.)

---

## Workflows d'enrichissement

Pour les recherches multi-fournisseurs, la réutilisation de cache et les budgets par crédit, consultez [le guide d'enrichissement](references/enrichment-playbook.md). Définissez d'abord les résultats acceptés, arrêtez la cascade dès que le résultat est satisfaisant, et distinguez bien les erreurs de requête des enregistrements sans correspondance.

---

## Sélection rapide des outils

Détail complet dans [references/data-sources.md](references/data-sources.md). Recommandations rapides :

| Si l'utilisateur a accès à... | L'utiliser pour |
|-------------------------------|-----------------|
| **Apollo** | Découverte firmographique + contacts B2B / SaaS |
| **Clay** | Enrichissement multi-sources, requêtes en cascade, scoring personnalisé |
| **FullEnrich ou LeadMagic** | Enrichissement en cascade d'emails et de numéros de téléphone via une seule API |
| **TheirStack** | Signaux de recrutement et stacks techniques d'après les offres d'emploi |
| **ZoomInfo** | Données de contact B2B grandes entreprises + données d'intention |
| **Hunter ou Snov** | Déduction de modèles d'emails et vérification |
| **Truelist** | Validation de la délivrabilité des emails (avant ajout à la liste de prospection) |
| **LinkedIn Sales Navigator** | Cartographie des décideurs (manuelle, sans scraping) |
| **BuiltWith / Wappalyzer** | Qualification de la stack technique (branche SaaS) |
| **Crunchbase** | Signaux de financement (branche SaaS) |
| **GitHub** | Stargazers / forks de dépôts concurrents ou connexes (branche SaaS pour outils développeurs) |
| **Google Maps + navigateur** | Découverte de petites entreprises locales (Local SMB) |
| **Firecrawl / Browserbase** | Extraction programmatique depuis le site web de chaque prospect — jamais depuis des plateformes tierces |

**Si l'utilisateur ne dispose d'aucun outil d'enrichissement** : appuyez-vous sur la recherche assistée par navigateur avec des sources publiques — site de l'entreprise, page À propos, page entreprise LinkedIn, mentions dans la presse. Plus lent, mais efficace.

---

## Formats de sortie

### Par défaut — tableau dans le chat

Pour SaaS / B2B (≤ 25 lignes) :

```
| Score | Company | Industry | Size | Signal | Contact | Email status | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
```

Pour Local SMB (≤ 15 lignes) — adapté de la référence local-prospector :

```
| Score | Business | Category | Area | Website status | Website/Social | Phone | Why it's a prospect | Confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
```

### CSV — si > 25 lignes ou sur demande de l'utilisateur

Colonnes SaaS / B2B :

```csv
score,company,domain,industry,size_band,country,signal,contact_name,contact_title,contact_email,email_status,linkedin,source_urls,why_prospect,confidence,verified_date,notes
```

Colonnes Local SMB :

```csv
score,business,category,area,distance_km,website_status,website_url,social_urls,phone,email,source_urls,why_prospect,confidence,verified_date,notes
```

### Toujours inclure après le tableau

- **Top cibles de prospection** : les 3 à 5 meilleurs leads qualifiés « Hot », avec pour chacun une phrase justifiant la priorité de contact
- **Paramètres de recherche** : branche, ICP, localisation/rayon, volume cible, date de génération
- **Questions en suspens** : tout élément que vous n'avez pas pu vérifier et que l'utilisateur devrait examiner

---

## Contrôles qualité (avant finalisation)

- [ ] Supprimer les doublons (par domaine pour SaaS/B2B, par nom d'entreprise + adresse pour Local SMB)
- [ ] Chaque lead qualifié « Hot » possède un contact vérifié + au moins une URL source
- [ ] Aucun lead ne possède un email ayant échoué à la vérification Truelist (ou autre outil de validation) — déplacez-les dans un compartiment distinct « invalides » et signalez-les à l'utilisateur
- [ ] Aucun lead noté « Hot » n'est dépourvu d'un signal d'achat clair
- [ ] Niveaux de confiance sincères — « High » exige 2 sources indépendantes, et pas seulement deux recherches personnelles
- [ ] Aucun lead n'a été collecté via un scraping interdit (LinkedIn à grande échelle, extraction massive de Google Maps, etc.)
- [ ] URL source + date enregistrées pour chaque contact (traçabilité RGPD / CAN-SPAM)
- [ ] Le volume final correspond à la demande de l'utilisateur, ou vous avez justifié pourquoi il est inférieur (exigence de qualité)

---

## Erreurs courantes

1. **Démarrer la découverte sans ICP**. Chercher des candidats avec des critères vagues vous amènera à qualifier les mauvaises cibles.
2. **Considérer les sources de données comme infaillibles sans recoupement**. Apollo et ZoomInfo sont fréquemment obsolètes ; vérifiez avant d'attribuer la note « Hot ».
3. **Ajouter des contacts sans vérification d'email**. La réputation d'envoi d'emails à froid se dégrade très vite avec les rebonds (bounces) — validez systématiquement.
4. **Scraper massivement LinkedIn ou Google Maps**. Risque réel : suspension de compte + violation des conditions d'utilisation. Utilisez le navigateur uniquement comme un outil d'assistance.
5. **Mélanger les branches**. N'appliquez pas la notation Local SMB (état du site web) à un prospect B2B SaaS, et inversement.
6. **Attribuer le score « Hot » sans signaux d'achat**. L'adéquation à l'ICP seule ne suffit pas — c'est le signal qui valide le timing.
7. **Oublier les URL sources**. Chaque affirmation doit pouvoir être reliée à une source publique. La prospection future dépend de cette traçabilité.
8. **Ignorer les heures calmes / fuseaux horaires** lors de la planification des envois ultérieurs (passage de relais vers cold-email).
9. **Oublier de conserver l'historique du consentement / de traçabilité**. Requis en cas de demande d'accès RGPD ou d'audit CAN-SPAM.

---

## Questions spécifiques à la mission

1. Quelle branche — SaaS, B2B, Local SMB, ou Demand-signal (phase d'amorçage, recherche de premiers clients) ?
2. Quel est votre ICP ? (Ou : dois-je le déduire de votre contexte marketing produit ?)
3. Combien de leads qualifiés souhaitez-vous ?
4. À quels outils avez-vous accès (Apollo / Clay / ZoomInfo / Hunter / Truelist / navigateur uniquement) ?
5. Quel signal d'achat déclencheur est prioritaire pour vous ?
6. Zone géographique ou rayon cible (Local SMB / B2B) ?
7. Tableau dans le chat ou fichier CSV ?

---

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Principaux outils de prospection :

| Outil | Idéal pour | MCP | Guide |
|-------|------------|:---:|-------|
| **Apollo** | Découverte firmographique + contacts B2B / SaaS | ✓ | [apollo.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/apollo.md) |
| **Clay** | Enrichissement multi-sources + requêtes en cascade | ✓ | [clay.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/clay.md) |
| **FullEnrich** | Enrichissement en cascade d'emails + téléphones | ✓ | [fullenrich.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/fullenrich.md) |
| **LeadMagic** | Enrichissement d'emails, de téléphones et de changements de poste | ✓ | [leadmagic.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/leadmagic.md) |
| **TheirStack** | Signaux de recrutement et stacks techniques d'après les offres d'emploi | ✓ | [theirstack.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/theirstack.md) |
| **Apify** | Données structurées issues d'annuaires publics (jamais LinkedIn) | ✓ | [apify.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/apify.md) |
| **ZoomInfo** | Contacts grandes entreprises B2B + données d'intention | ✓ | [zoominfo.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/zoominfo.md) |
| **Hunter** | Modèles d'emails + vérification | ✓ | [hunter.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/hunter.md) |
| **Snov** | Recherche d'emails + vérification | - | [snov.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/snov.md) |
| **Truelist** | Vérification d'emails, y compris résolution des catch-all | ✓ | [truelist.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/truelist.md) |
| **Outreach** | Engagement commercial (après finalisation de la liste) | ✓ | [outreach.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/outreach.md) |
| **RB2B** | Identification de visiteurs (intention tiède/chaude) | - | [rb2b.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/rb2b.md) |
| **Ploy** ◆ | Identification de visiteurs sur les sites hébergés par Ploy (option parmi d'autres aux côtés de RB2B) | - | [ploy.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/ploy.md) |
| **GitHub** | Stargazers/forks/watchers comme signal d'intention de développeurs | - | [github.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/github.md) |
| **Firecrawl** | Extraction ciblée sur un site individuel (le propre site web du prospect) | ✓ | [firecrawl.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/firecrawl.md) |
| **Browserbase** | Recherche sur site via un vrai navigateur lorsqu'un rendu ou des interactions sont nécessaires | ✓ | [browserbase.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/browserbase.md) |

---

## Compétences associées

- **cold-email** : Pour rédiger des séquences de prospection à destination de la liste qualifiée (l'étape suivante naturelle après la prospection)
- **customer-research** : Pour comprendre pourquoi les clients actuels achètent — alimente la définition de l'ICP
- **competitor-profiling** : Pour analyser les concurrents. La recherche sur les comptes ciblés se trouve ici, dans [references/account-research.md](references/account-research.md)
- **revops** : Pour l'acheminement des leads, le cycle de vie et le transfert vers le CRM après la prospection
- **sales-enablement** : Pour les fiches comparatives (battle cards) et les one-pagers utilisés lors de la prise de contact
- **directory-submissions** : Pour les canaux de découverte entrants (afin que les prospects puissent également vous trouver)
- **product-marketing** : Pour la définition de l'ICP qui sert de socle à chaque mission de prospection
