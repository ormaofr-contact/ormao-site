---
name: ig-repurpose
description: >-
  Transforme un contenu long — vidéo YouTube, podcast, livestream, newsletter,
  article de blog ou appel client — en une semaine de reels et de carrousels. À
  utiliser quand l'utilisateur dit "recycle ça", "transforme ça en reels",
  "j'ai une vidéo/un podcast/une transcription", "découpe ça", ou colle un
  contenu long et souhaite le publier sur Instagram.
---

# ig-repurpose

Un bon contenu long contient entre quatre et six publications. La plupart des gens en extraient une seule et jettent le reste.

## Données d'entrée

Une transcription, un article, une newsletter, un script, un compte rendu d'appel, un livestream.
Si l'utilisateur fournit une URL et que cette session dispose d'un outil de transcription, utilise-le ; sinon, demande-lui de coller le texte. Lis l'intégralité du contenu avant d'extraire quoi que ce soit.

Si la source est une vidéo appartenant à l'utilisateur, demande également le fichier. Un Reel construit à partir de ses propres séquences vidéo surpasse un Reel basé sur ses propres mots relus.

## Extraire, ne pas résumer

Le résumé d'une vidéo n'est pas un Reel. Personne ne veut d'un résumé. Parcours le contenu et isole les éléments qui se suffisent à eux-mêmes :

| Élément extrait | Ce que c'est |
| --- | --- |
| **Affirmations** | chaque phrase susceptible de lancer un débat |
| **Chiffres** | chaque donnée chiffrée, coût, durée, pourcentage |
| **Histoires** | chaque moment impliquant une personne, une scène et un coût |
| **Mécanismes** | chaque "voici comment cela fonctionne concrètement..." |
| **Erreurs** | chaque aveu concernant un problème survenu |
| **Citations** | chaque phrase directement citable telle quelle |

Dresse la liste de ce que tu as trouvé, avec les décomptes, avant de rédiger quoi que ce soit. Si le contenu produit moins de quatre éléments, il est trop pauvre, et les quatre publications qu'on tenterait d'en tirer le seront aussi. Dis-le clairement.

## Choisir ensuite le format par extrait

Tout n'est pas un Reel.

- **Affirmation, erreur, histoire** deviennent un Reel. Ils ont besoin d'une voix et d'un visage.
- **Mécanisme, liste numérotée** deviennent un carrousel. Ils ont besoin d'être relus.
- **Une citation percutante** devient une story, pas une publication.

## Construire ensuite la semaine

Chaque extrait devient une publication et chaque publication se suffit entièrement à elle-même. Le spectateur n'a pas vu la source d'origine et ne la verra jamais. N'écris jamais "comme je le disais dans ma dernière vidéo". La publication se suffit à elle-même.

Attribue une formule d'accroche issue de `ig-reel/hooks.json` à chacune et varie-les. Cinq publications issues d'une même source avec la même structure d'accroche ressemblent à une usine à contenu, car c'en est une.

Si la source est la propre vidéo de l'utilisateur, **utilise les séquences réelles**. L'extrait où il prononce la phrase, avec la vraie réaction à l'écran, surpasse un réenregistrement à chaque fois. Coupe sur la phrase, pas sur la respiration.

Ordonne la semaine de sorte que l'affirmation la plus percutante passe en premier, que l'histoire arrive en milieu de semaine, et que le mécanisme arrive en dernier, au moment où les personnes ayant aimé les publications précédentes sont attentives pour le découvrir.

## Sortie

```
SOURCE: "Pourquoi nous avons supprimé les appels de découverte" (podcast de 42 min, 8 900 mots)

TROUVÉ  5 affirmations, 9 chiffres, 3 histoires, 4 mécanismes, 2 erreurs, 7 citations percutantes

SEMAINE
MAR  REEL       #2  Ordre négatif       Arrêtez de faire des appels de découverte
                                        utiliser l'extrait à 14:20, il rigole à la fin
MER  CARROUSEL  Légende Job B           Le formulaire en 4 questions qui a remplacé l'appel
VEN  REEL       #21 En milieu de phrase "...et il a demandé un remboursement neuf jours plus tard"
DIM  REEL       #5  Condensation temps  Six heures gagnées par semaine, un seul lien supprimé

Dis "rédige mardi" et je préparerai le brouillon.
```

Rédige ensuite à la demande, une publication à la fois, chacune passant par `/ig-reel` et `/ig-human`. Ne livre pas quatre scripts finis d'un coup. Ils finiraient tous par se ressembler et l'utilisateur n'en tournera aucun.
