---
name: webapp-testing
description: Boîte à outils pour interagir avec des applications web locales et les tester à l'aide de Playwright. Permet de vérifier les fonctionnalités frontend, déboguer le comportement de l'interface utilisateur, capturer des captures d'écran et consulter les journaux du navigateur.
license: Complete terms in LICENSE.txt
---

# Test d'applications web

Pour tester des applications web locales, écrivez des scripts Playwright natifs en Python.

**Scripts d'aide disponibles** :
- `scripts/with_server.py` - Gère le cycle de vie du serveur (prend en charge plusieurs serveurs)

**Exécutez toujours les scripts avec `--help` en premier** pour voir leur utilisation. NE LISEZ PAS le code source avant d'avoir essayé d'exécuter le script et constaté qu'une solution personnalisée est absolument nécessaire. Ces scripts peuvent être très volumineux et ainsi polluer votre fenêtre de contexte. Ils sont conçus pour être appelés directement en tant que boîtes noires plutôt que d'être ingérés dans votre fenêtre de contexte.

## Arbre de décision : choisir votre approche

```
Tâche utilisateur → S'agit-il de HTML statique ?
    ├─ Oui → Lire directement le fichier HTML pour identifier les sélecteurs
    │         ├─ Succès → Écrire le script Playwright à l'aide des sélecteurs
    │         └─ Échec/Incomplet → Traiter comme dynamique (ci-dessous)
    │
    └─ Non (application web dynamique) → Le serveur fonctionne-t-il déjà ?
        ├─ Non → Exécuter : python scripts/with_server.py --help
        │        Puis utiliser l'assistant + écrire un script Playwright simplifié
        │
        └─ Oui → Reconnaissance puis action :
            1. Naviguer et attendre networkidle
            2. Prendre une capture d'écran ou inspecter le DOM
            3. Identifier les sélecteurs à partir de l'état rendu
            4. Exécuter les actions avec les sélecteurs découverts
```

## Exemple : utilisation de with_server.py

Pour démarrer un serveur, exécutez d'abord `--help`, puis utilisez le script d'aide :

**Serveur unique :**
```bash
python scripts/with_server.py --server "npm run dev" --port 5173 -- python your_automation.py
```

**Plusieurs serveurs (par ex. backend + frontend) :**
```bash
python scripts/with_server.py \
  --server "cd backend && python server.py" --port 3000 \
  --server "cd frontend && npm run dev" --port 5173 \
  -- python your_automation.py
```

Pour créer un script d'automatisation, incluez uniquement la logique Playwright (les serveurs sont gérés automatiquement) :
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True) # Always launch chromium in headless mode
    page = browser.new_page()
    page.goto('http://localhost:5173') # Server already running and ready
    page.wait_for_load_state('networkidle') # CRITICAL: Wait for JS to execute
    # ... your automation logic
    browser.close()
```

## Schéma Reconnaissance puis action

1. **Inspecter le DOM rendu** :
   ```python
   page.screenshot(path='/tmp/inspect.png', full_page=True)
   content = page.content()
   page.locator('button').all()
   ```

2. **Identifier les sélecteurs** à partir des résultats de l'inspection

3. **Exécuter les actions** à l'aide des sélecteurs découverts

## Piège courant

❌ **Ne pas** inspecter le DOM avant d'attendre `networkidle` sur les applications dynamiques
✅ **Toujours** attendre `page.wait_for_load_state('networkidle')` avant l'inspection

## Bonnes pratiques

- **Utiliser les scripts fournis comme des boîtes noires** - Pour accomplir une tâche, vérifiez si l'un des scripts disponibles dans `scripts/` peut vous aider. Ces scripts gèrent des flux de travail courants et complexes de manière fiable, sans encombrer la fenêtre de contexte. Utilisez `--help` pour voir leur utilisation, puis appelez-les directement.
- Utiliser `sync_playwright()` pour les scripts synchrones
- Toujours fermer le navigateur une fois terminé
- Utiliser des sélecteurs descriptifs : `text=`, `role=`, sélecteurs CSS ou ID
- Ajouter des attentes appropriées : `page.wait_for_selector()` ou `page.wait_for_timeout()`

## Fichiers de référence

- **examples/** - Exemples illustrant les modèles courants :
  - `element_discovery.py` - Détection de boutons, liens et champs de saisie sur une page
  - `static_html_automation.py` - Utilisation des URL file:// pour le HTML local
  - `console_logging.py` - Capture des journaux de la console pendant l'automatisation
