---
name: yt-viral
description: >-
  Trouver ce qui fonctionne réellement dans la niche de l'utilisateur sur YouTube et
  le classer selon l'écart de performance de chaque vidéo par rapport à sa propre chaîne,
  puis nommer la formule. À utiliser pour « ce qui marche en ce moment », « trouver des vidéos
  virales dans ma niche », « pourquoi cette vidéo a percé », la veille concurrentielle ou
  un swipe file.
---

# yt-viral

Le nombre brut de vues classe la taille de la chaîne, pas les idées. Cet outil classe par **multiple par rapport à la médiane propre à chaque chaîne**, ce qui est la seule version de la question qui porte véritablement sur la vidéo.

```bash
python3 swipe.py collected.json --min 2.0
```

## Collecter les données d'entrée

Il vous faut au moins **quatre vidéos par chaîne**, sinon une médiane ne signifie rien, et l'outil ignorera la chaîne en vous le signalant. Récupérez-les selon la méthode préférée de l'utilisateur : `yt-dlp --flat-playlist -J` sur l'URL d'une chaîne est le moyen le plus rapide, la page publique fonctionne, une liste manuelle fonctionne aussi.

```json
[{"channel":"...","title":"...","views":412000,"url":"...","duration":613}]
```

**Lisez, ne scrapez pas.** Uniquement des listes publiques, jamais de session connectée, jamais les identifiants de compte de l'utilisateur.

## Lire la sortie

Le multiple est le signal. La ligne de la formule est une évaluation du TITRE, comparé aux [21 formules](../yt-script/hooks.json) — ce n'est pas une affirmation sur la raison pour laquelle la vidéo a fonctionné, et vous devez le préciser lorsque vous la présentez.

Ce qu'il faut restituer : le top cinq avec leurs multiples, la formule utilisée par chacune, et le SEUL point structurel qu'elles partagent. Puis l'étape la plus difficile : lesquelles parmi celles-ci l'utilisateur pourrait réellement produire cette semaine, avec sa propre voix et avec ce dont il dispose.

## La validation

Rien n'est publié ici. Cette compétence rédige et vous publiez. Chaque résultat se termine par un bloc que l'utilisateur copie, et la dernière ligne de chaque exécution est la question : **on publie, ou on modifie ?**
