---
name: ig-carousel
description: >-
  Créer un carrousel Instagram : la couverture qui incite au swipe, le texte
  slide par slide et les fichiers 1080x1350 à publier. À utiliser lorsque
  l'utilisateur dit « carrousel », « slides », « swipe post », « transforme ça
  en carrousel », ou lorsqu'il propose une idée sous forme de liste ou d'étapes
  qui perdrait tout son impact en une seule image.
---

# ig-carousel

Les carrousels sont le format qui retient le plus l'attention sur la grille,
car un balayage (swipe) est une interaction, alors qu'un simple défilement
(scroll) ne l'est pas. Ils bénéficient également d'une seconde chance :
Instagram peut réafficher un carrousel à quelqu'un qui n'a pas interagi la
première fois, en commençant par une slide ultérieure ; la slide deux doit donc
pouvoir fonctionner toute seule.

Ce format récompense une idée découpée en étapes. Il pénalise une légende
découpée en morceaux.

## Quand l'utiliser plutôt qu'un Reel

Utilisez un carrousel lorsque l'idée comporte **une séquence et a besoin d'être
relue** : des étapes, un framework structuré, un avant/après, une liste qui
mérite une capture d'écran. Utilisez un Reel lorsque l'idée implique du
mouvement, un visage ou un dénouement qui doit être vu en action.

Si l'idée ne repose que sur une seule affirmation, ce n'est ni l'un ni l'autre.
Passez le relais à `/ig-reel` et précisez-le.

## Structure

6 à 10 slides. Le maximum autorisé est de 20, et 20 est presque toujours un
livre que personne ne termine. En dessous de 5, le swipe ne démarre jamais.

```
1         COUVERTURE    l'accroche. 6 mots ou moins, d'une taille lisible dans
                        la grille en miniature. Une ligne de promesse en dessous.
2         L'ENJEU       pourquoi c'est important, en une phrase. Cette slide est
                        aussi une seconde couverture, elle ne peut donc pas être
                        une simple introduction.
3 à N     UNE IDÉE PAR SLIDE. Un titre de 3 à 7 mots, 25 mots maximum
                        en dessous. Si une slide a besoin d'un paragraphe, cela
                        fait deux slides.
N+1       RÉCAPITULATIF l'ensemble sous forme de liste. C'est la slide que l'on
                        capture en écran.
DERNIÈRE  CTA           une seule action. Enregistrer, commenter un mot-clé ou
                        s'abonner. Une seule.
```

## Règles de rédaction des slides

- **La couverture représente 80 % du résultat.** Six mots. En grand. Rien dans
  le reste du carrousel ne sauvera une couverture que personne ne swipe.
- **Concevez pour le recadrage de la grille.** La grille du profil recadre en
  un rectangle vertical plus haut que large, et le ratio exact a déjà changé
  plus d'une fois. Concevez en 1080x1350 et gardez le texte de couverture bien
  au centre, à distance des 120 pixels extérieurs de chaque côté, et le
  recadrage ne sera plus un problème.
- **Numérotez les slides** (3/8). Le taux de complétion augmente quand les gens
  voient la fin approcher.
- **Aucune slide n'est un paragraphe.** Si cela ne peut pas être dit en 25 mots,
  divisez-le.
- **La slide récapitulative est celle que les gens capturent et partagent.** Les
  partages en message privé sont le signal le plus fort que vous puissiez
  obtenir. Rendez-la autonome et compréhensible sans aucun contexte.
- **L'identifiant (handle) sur chaque slide**, en petit, dans le coin inférieur.
  Les captures d'écran voyagent sans vous.
- **Du texte alternatif sur la couverture au minimum.** Il est lu par les
  lecteurs d'écran et par Instagram.

## Génération des fichiers

Instagram attend du 1080x1350 (4:5), JPEG ou PNG, jusqu'à 20 éléments. Créez-le
en HTML et imprimez chaque slide :

```bash
# une balise <section> par slide, 1080x1350, page-break-after: always
# puis Chrome headless --print-to-pdf, ou tout outil HTML-vers-image que vous utilisez déjà
```

Rédigez le HTML avec `width:1080px; height:1350px`, une seule couleur d'accent,
et une typographie d'au moins 32px, car cela est lu sur un téléphone à un tiers
de sa taille réelle. Si le projet dispose d'une compétence de marque ou d'un
design system, utilisez-le et n'inventez pas de palette.

## Format de sortie

D'abord le texte slide par slide, sous forme de liste numérotée que
l'utilisateur peut lire en dix secondes et modifier avant tout rendu visuel.
Ensuite la **légende**, qui pour un carrousel correspond au Job B dans
`/ig-caption` : la légende a un vrai rôle ici, car la couverture a déjà épuisé
ses six mots.

Passez les deux dans `/ig-human`. Ne générez les fichiers qu'après validation
du texte par l'utilisateur.

```
CAROUSEL  ·  8 slides

1  COUVERTURE  LA CLAUSE À 18 000 $
               Une ligne que j'inclus désormais dans chaque contrat.
2  ENJEU       J'ai validé le travail. Ils ont demandé le remboursement neuf jours plus tard.
3              CE QU'ELLE DIT
               Paiement à la livraison, pas à la validation.
...
7  RÉCAP       Les quatre lignes, dans l'ordre.
8  CTA         Commentez CONTRAT et je vous envoie la clause complète.

Légende : Job B, accroche en ligne 1, une seule demande, 3 tags.
```

Rien n'est mis en ligne automatiquement. C'est l'utilisateur qui publie.
