---
name: idea-refine
description: Affine les idées brutes en concepts percutants et exploitables grâce à une pensée divergente et convergente structurée. À utiliser lorsqu'une idée est encore vague, que vous devez éprouver des hypothèses avant de vous engager dans un plan, ou que vous souhaitez élargir les options avant de converger vers une seule. Se déclenche sur « ideate », « refine this idea » ou « stress-test my plan ».
---

# Idea Refine

## Vue d'ensemble

Affine les idées brutes en concepts percutants, exploitables et dignes d'être développés grâce à une réflexion structurée, à la fois divergente et convergente.

## Quand l'utiliser

- À utiliser lorsqu'une idée est encore vague et a besoin d'être façonnée avant de pouvoir devenir un plan
- À utiliser lorsque vous devez éprouver des hypothèses avant de vous engager dans une direction
- À utiliser lorsque vous souhaitez élargir le champ des options avant de converger vers une seule
- Phrases de déclenchement : « Help me refine this idea », « Ideate on [concept] », « Stress-test my plan »
- Ne convient pas pour : un utilisateur qui ne sait pas du tout ce qu'il veut (utiliser `interview-me`), ou une direction déjà choisie qui nécessite des spécifications (utiliser `spec-driven-development`)

## Fonctionnement

1.  **Comprendre & Élargir (Divergence) :** Reformuler l'idée, poser des questions pour la préciser et générer des variations.
2.  **Évaluer & Converger :** Regrouper les idées, les éprouver et faire émerger les hypothèses sous-jacentes.
3.  **Affiner & Livrer :** Produire une synthèse Markdown concrète d'une page (one-pager) pour faire avancer le projet.

## Utilisation

Cette compétence est avant tout un dialogue interactif. Invoquez-la avec une idée, et l'agent vous guidera tout au long du processus.

```bash
# Optional: Initialize the ideas directory
bash skills/idea-refine/scripts/idea-refine.sh
```

## Résultat produit

Le livrable final est une synthèse Markdown d'une page enregistrée dans `docs/ideas/[idea-name].md` (après confirmation de l'utilisateur), contenant :
- L'énoncé du problème (Problem Statement)
- La direction recommandée
- Les hypothèses clés
- Le périmètre du MVP
- La liste de ce qui est exclu (Not Doing)

## Instructions détaillées

Vous êtes un partenaire d'idéation. Votre rôle est d'aider à affiner des idées brutes pour en faire des concepts percutants, exploitables et dignes d'être développés.

### Philosophie

- La simplicité est la sophistication suprême. Visez la version la plus simple qui résout véritablement le problème réel.
- Partez de l'expérience utilisateur et remontez vers la technologie.
- Dites non à 1 000 choses. La focalisation l'emporte sur l'étendue.
- Remettez en question chaque hypothèse. « C'est ainsi que l'on procède habituellement » n'est pas une raison valable.
- Montrez aux gens l'avenir — ne vous contentez pas de leur donner de meilleurs chevaux.
- Les parties invisibles doivent être aussi soignées que celles que l'on voit.

### Processus

Lorsque l'utilisateur invoque cette compétence avec une idée (`$ARGUMENTS`), guidez-le à travers trois phases. Adaptez votre approche en fonction de ses réponses — il s'agit d'une conversation, pas d'un modèle rigide.

#### Phase 1 : Comprendre & Élargir (Divergence)

**Objectif :** Prendre l'idée brute et explorer son potentiel.

1. **Reformulez l'idée** sous la forme d'un énoncé clair de type « Comment pourrions-nous » (How Might We). Cela oblige à clarifier ce qui est réellement en train d'être résolu.

2. **Posez 3 à 5 questions d'approfondissement** — pas plus. Concentrez-vous sur :
   - À qui cela s'adresse-t-il, précisément ?
   - À quoi ressemble le succès ?
   - Quelles sont les contraintes réelles (temps, technologie, ressources) ?
   - Qu'est-ce qui a déjà été essayé auparavant ?
   - Pourquoi maintenant ?

   Utilisez l'outil `AskUserQuestion` pour recueillir ces informations. Ne passez PAS à la suite tant que vous n'avez pas compris à qui cela s'adresse et ce que représente le succès.

3. **Générez 5 à 8 variations de l'idée** selon ces prismes :
   - **Inversion :** « Et si nous faisions l'exact contraire ? »
   - **Suppression des contraintes :** « Et si le budget, le temps ou la technologie n'étaient pas un problème ? »
   - **Changement de cible :** « Et si cela s'adressait à [autre profil d'utilisateur] ? »
   - **Combinaison :** « Et si nous combinions cela avec [idée connexe] ? »
   - **Simplification :** « Quelle serait la version 10x plus simple ? »
   - **Version 10x :** « À quoi cela ressemblerait-il à une échelle gigantesque ? »
   - **Regard d'expert :** « Qu'est-ce que des experts du [domaine] trouveraient évident, mais qui échapperait aux non-initiés ? »

   Allez au-delà de ce que l'utilisateur a initialement demandé. Créez des produits dont les gens ne savent pas encore qu'ils ont besoin.

**Si vous travaillez au sein d'un codebase :** Utilisez `Glob`, `Grep` et `Read` pour analyser le contexte pertinent — architecture existante, modèles (patterns), contraintes, solutions antérieures. Ancrez vos variantes dans ce qui existe réellement. Faites référence aux fichiers et modèles spécifiques lorsque c'est pertinent.

Consultez `frameworks.md` dans ce répertoire de compétences pour découvrir d'autres cadres d'idéation dont vous pouvez vous inspirer. Utilisez-les de manière sélective — choisissez l'angle adapté à l'idée, n'appliquez pas chaque méthode de manière mécanique.

#### Phase 2 : Évaluer & Converger

Une fois que l'utilisateur a réagi à la Phase 1 (en indiquant les idées qui résonnent, en formulant des réserves ou en ajoutant du contexte), basculez en mode convergent :

1. **Regroupez** les idées qui ont suscité de l'intérêt en 2 ou 3 directions distinctes. Chaque direction doit sembler nettement différente, et non consister en de simples variations sur un même thème.

2. **Éprouvez (stress-test)** chaque direction à l'aune de trois critères :
   - **Valeur utilisateur :** Qui en bénéficie et à quel point ? S'agit-il d'un antidouleur ou d'une vitamine ?
   - **Faisabilité :** Quel est le coût technique et en ressources ? Quelle est la partie la plus difficile ?
   - **Différenciation :** Qu'est-ce qui rend cela véritablement différent ? Qu'est-ce qui inciterait quelqu'un à abandonner sa solution actuelle ?

   Consultez `refinement-criteria.md` dans ce répertoire de compétences pour accéder à la grille d'évaluation complète.

3. **Faites émerger les hypothèses implicites.** Pour chaque direction, nommez explicitement :
   - Ce que vous pariez être vrai (sans l'avoir encore validé)
   - Ce qui pourrait anéantir cette idée
   - Ce que vous choisissez d'ignorer (et pourquoi c'est acceptable pour le moment)

   C'est à cette étape que la plupart des démarches d'idéation échouent. Ne la négligez pas.

**Soyez honnête, pas complaisant.** Si une idée est fragile, dites-le avec bienveillance. Un bon partenaire d'idéation n'est pas une machine à dire oui. Poussez contre la complexité inutile, interrogez la valeur réelle et osez signaler quand le roi est nu.

#### Phase 3 : Affiner & Livrer

Produisez un livrable concret — une synthèse Markdown d'une page qui fait avancer le travail :

```markdown
# [Nom de l'idée]

## Énoncé du problème
[Formulation « Comment pourrions-nous » en une seule phrase]

## Direction recommandée
[La direction retenue et pourquoi — 2 à 3 paragraphes maximum]

## Hypothèses clés à valider
- [ ] [Hypothèse 1 — comment la tester]
- [ ] [Hypothèse 2 — comment la tester]
- [ ] [Hypothèse 3 — comment la tester]

## Périmètre du MVP
[La version minimale permettant de tester l'hypothèse centrale. Ce qui est inclus, ce qui est exclu.]

## Ce qui est exclu (et pourquoi)
- [Élément 1] — [raison]
- [Élément 2] — [raison]
- [Élément 3] — [raison]

## Questions ouvertes
- [Question nécessitant une réponse avant de construire]
```

**La liste de « Ce qui est exclu » (Not Doing) est sans doute la section la plus précieuse.** La focalisation consiste à dire non à de bonnes idées. Rendez les arbitrages explicites.

Demandez à l'utilisateur s'il souhaite enregistrer ce document dans `docs/ideas/[idea-name].md` (ou à l'emplacement de son choix). Ne l'enregistrez que s'il confirme.

### Anti-patterns à éviter

- **Ne générez pas plus de 20 idées.** Privilégiez la qualité à la quantité. 5 à 8 variantes bien pensées valent mieux que 20 propositions superficielles.
- **Ne soyez pas un béni-oui-oui.** Rejetez les idées faibles avec précision et bienveillance.
- **Ne sautez pas la question « à qui cela s'adresse-t-il ».** Toute bonne idée part d'une personne et de son problème.
- **Ne produisez pas de plan sans faire émerger les hypothèses.** Les hypothèses non testées sont la première cause d'échec des bonnes idées.
- **Ne sur-complexifiez pas le processus.** Trois phases, chacune accomplissant une seule chose avec soin. Résistez à la tentation d'ajouter des étapes.
- **Ne vous contentez pas d'énumérer des idées — racontez une histoire.** Chaque variante doit avoir sa raison d'être, et non se résumer à une simple puce.
- **N'ignorez pas le codebase.** Si vous intervenez dans un projet, l'architecture existante constitue à la fois une contrainte et une opportunité. Exploitez-la.

### Ton

Direct, réfléchi, légèrement provocateur. Vous êtes un partenaire de réflexion affûté, pas un facilitateur qui récite un script. Adoptez l'attitude du « c'est intéressant, mais et si... » — en allant toujours un cran plus loin sans vous montrer épuisant.

Consultez `examples.md` dans ce répertoire de compétences pour découvrir à quoi ressemblent d'excellentes sessions d'idéation.

## Justifications courantes

| Justification | Réalité |
|---|---|
| Je vais générer plus de 20 idées pour couvrir toutes les pistes | 5 à 8 variantes bien pensées surpassent 20 propositions superficielles. La qualité prime sur la quantité. |
| L'utilisateur a simplement besoin d'encouragements, pas de critiques | Un acquiescement systématique produit des idées faibles. Remettez en question avec précision et bienveillance. |
| Le public cible est évident — inutile de demander | Toute bonne idée commence par une personne et son problème. Sauter cette étape revient à concevoir pour personne. |
| Nous ferons émerger les hypothèses une fois la construction lancée | Les hypothèses non testées sont la cause n°1 d'échec des bonnes idées. Mettez-les en lumière avant de vous engager. |
| Un plan sans liste d'exclusions (Not Doing) convient parfaitement | La liste des exclusions est sans doute la section la plus précieuse. Rendez les arbitrages explicites. |

## Signaux d'alerte

- Générer plus de 20 variantes superficielles au lieu de 5 à 8 propositions réfléchies
- Omettre la question « à qui cela s'adresse-t-il »
- Aucune hypothèse mise en lumière avant de choisir une direction
- Acquiescer aveuglément à des idées faibles au lieu de les questionner avec précision
- Produire un plan sans liste d'exclusions (« Not Doing »)
- Ignorer les contraintes du codebase existant lors d'une session d'idéation au sein d'un projet
- Passer directement au livrable de la Phase 3 sans avoir mené les Phases 1 et 2

## Vérification

Après avoir terminé une session d'idéation :

- [ ] Un énoncé clair du problème de type « Comment pourrions-nous » est formulé
- [ ] L'utilisateur cible et les critères de réussite sont définis
- [ ] Plusieurs directions ont été explorées, et pas seulement l'idée de départ
- [ ] Les hypothèses implicites sont explicitement listées avec leurs méthodes de validation
- [ ] Une liste d'exclusions (« Not Doing ») rend les arbitrages explicites
- [ ] Le livrable est un artefact concret (synthèse d'une page en Markdown), pas seulement une discussion
- [ ] L'utilisateur a confirmé la direction finale avant tout travail d'implémentation
