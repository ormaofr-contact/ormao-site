---
name: subagent-driven-development
description: À utiliser lors de l'exécution de plans d'implémentation comportant des tâches indépendantes dans la session en cours
---

# Développement piloté par sous-agents (Subagent-Driven Development)

Exécutez le plan en distribuant un nouveau sous-agent implémenteur par tâche, une revue de tâche (conformité aux spécifications + qualité du code) après chacune, et une revue globale de toute la branche à la fin.

**Pourquoi des sous-agents :** Vous déléguez les tâches à des agents spécialisés avec un contexte isolé. En élaborant précisément leurs instructions et leur contexte, vous garantissez qu'ils restent concentrés et réussissent leur tâche. Ils ne doivent jamais hériter du contexte ou de l'historique de votre session — vous construisez exactement ce dont ils ont besoin. Cela préserve également votre propre contexte pour le travail de coordination.

**Principe fondamental :** Nouveau sous-agent par tâche + revue de tâche (spécification + qualité) + revue finale globale = haute qualité, itération rapide

**Narration :** entre les appels d'outils, n'écrivez au maximum qu'une seule ligne courte — le registre (ledger) et les résultats des outils portent l'historique.

**Exécution continue :** Ne vous interrompez pas pour faire le point avec votre partenaire humain entre les tâches. Exécutez toutes les tâches du plan sans vous arrêter. Les seules raisons de s'arrêter sont les quatre cas mentionnés ci-dessous, ou l'achèvement de toutes les tâches. Les sollicitations du type « Dois-je continuer ? » et les résumés d'avancement leur font perdre leur temps — ils vous ont demandé d'exécuter le plan, alors exécutez-le.

**Des décisions fermes, pas de blocages.** Un plan en cours ne reste pas en attente d'un humain. Conflits, ambiguïtés, défauts du plan, plafond que vous auriez demandé à dépasser — tranchez-les. La spécification est l'autorité absolue, le plan en est l'argumentation, et votre jugement règle ce à quoi ni l'un ni l'autre ne répondent. Consignez chaque décision dans le registre sous la forme `Ruling: <what you decided> — <why> — <what it costs if wrong>`, et continuez. Une mauvaise décision coûte du travail de reprise que votre partenaire humain peut voir et annuler ; une session en pause sur une question lui fait perdre sa journée entière pour rien.

Quatre choses vous arrêtent, et uniquement celles-ci : une opération irréversible ou destructrice ; une action sensible sur le plan de la sécurité ; un effet de bord en dehors de ce worktree pour lequel les usages exigent de demander d'abord (un merge, un push vers une branche partagée, une publication) ; et un plan tellement incohérent que chaque suite envisageable relève de la conjecture. Pour ces cas-là, arrêtez-vous et demandez.

## Quand l'utiliser

```dot
digraph when_to_use {
    "Have implementation plan?" [shape=diamond];
    "Tasks mostly independent?" [shape=diamond];
    "Partner chose inline, or no subagent tool?" [shape=diamond];
    "subagent-driven-development" [shape=box];
    "executing-plans" [shape=box];
    "Manual execution or brainstorm first" [shape=box];

    "Have implementation plan?" -> "Tasks mostly independent?" [label="yes"];
    "Have implementation plan?" -> "Manual execution or brainstorm first" [label="no"];
    "Tasks mostly independent?" -> "Partner chose inline, or no subagent tool?" [label="yes"];
    "Tasks mostly independent?" -> "Manual execution or brainstorm first" [label="no - tightly coupled"];
    "Partner chose inline, or no subagent tool?" -> "executing-plans" [label="yes"];
    "Partner chose inline, or no subagent tool?" -> "subagent-driven-development" [label="no"];
}
```

**Comparé à Executing Plans (inline) :**
- Nouveau sous-agent par tâche (pas de pollution de contexte) au lieu d'un seul contexte réalisant chaque tâche
- Revue après chaque tâche (conformité aux spécifications + qualité du code) au lieu de seulement à la fin
- Coûte un nouveau contexte par tâche et par revue ; l'exécution inline coûte un seul contexte plus un réviseur final
- Les deux s'exécutent dans cette session, partagent le même espace de travail de plan et le même registre, et ne s'interrompent jamais entre les tâches

## Le processus

```dot
digraph process {
    rankdir=TB;

    subgraph cluster_per_task {
        label="Per Task";
        "Dispatch implementer subagent (./implementer-prompt.md)" [shape=box];
        "Implementer asks questions?" [shape=diamond];
        "Answer questions, provide context" [shape=box];
        "Implementer implements, tests, commits, self-reviews" [shape=box];
        "Generate review package, dispatch task reviewer (./task-reviewer-prompt.md)" [shape=box];
        "Spec ✅ and quality approved?" [shape=diamond];
        "Fix loop: read references/fix-loop.md before every round" [shape=box];
        "Append completion to ledger, mark todo complete" [shape=box];
    }

    "Setup: worktree, ledger check, read plan, pre-flight review" [shape=box];
    "More tasks remain?" [shape=diamond];
    "Final review and finish: read references/final-review.md" [shape=box];
    "Final review clean: delete this plan's workspace" [shape=box];
    "Use superpowers:finishing-a-development-branch" [shape=box style=filled fillcolor=lightgreen];

    "Setup: worktree, ledger check, read plan, pre-flight review" -> "Dispatch implementer subagent (./implementer-prompt.md)";
    "Dispatch implementer subagent (./implementer-prompt.md)" -> "Implementer asks questions?";
    "Implementer asks questions?" -> "Answer questions, provide context" [label="yes"];
    "Answer questions, provide context" -> "Implementer implements, tests, commits, self-reviews";
    "Implementer asks questions?" -> "Implementer implements, tests, commits, self-reviews" [label="no"];
    "Implementer implements, tests, commits, self-reviews" -> "Generate review package, dispatch task reviewer (./task-reviewer-prompt.md)";
    "Generate review package, dispatch task reviewer (./task-reviewer-prompt.md)" -> "Spec ✅ and quality approved?";
    "Spec ✅ and quality approved?" -> "Append completion to ledger, mark todo complete" [label="yes"];
    "Spec ✅ and quality approved?" -> "Fix loop: read references/fix-loop.md before every round" [label="no"];
    "Fix loop: read references/fix-loop.md before every round" -> "Append completion to ledger, mark todo complete" [label="addressed, or parked at the cap"];
    "Append completion to ledger, mark todo complete" -> "More tasks remain?";
    "More tasks remain?" -> "Dispatch implementer subagent (./implementer-prompt.md)" [label="yes"];
    "More tasks remain?" -> "Final review and finish: read references/final-review.md" [label="no"];
    "Final review and finish: read references/final-review.md" -> "Final review clean: delete this plan's workspace";
    "Final review clean: delete this plan's workspace" -> "Use superpowers:finishing-a-development-branch";
}
```

## Configuration initiale

Assurez-vous que le travail se déroule dans un espace de travail isolé : utilisez
superpowers:using-git-worktrees pour en créer un ou vérifier celui qui existe déjà.
Ne commencez jamais l'implémentation sur une branche main/master sans le consentement
explicite de votre partenaire humain.

La mémoire de conversation ne survit pas au compactage de contexte. Dans des sessions
réelles, des contrôleurs ayant perdu le fil ont re-distribué des séquences entières
de tâches déjà terminées — l'échec le plus coûteux jamais observé. Suivez la progression
dans un fichier registre (ledger), pas seulement dans des todos.

- Chaque plan possède un espace de travail : au démarrage de la compétence, exécutez la
  commande de cette compétence `bash scripts/sdd-workspace PLAN_FILE` — elle affiche le
  répertoire git-ignored du plan (sous `<repo-root>/.superpowers/sdd/`), où résident
  tous les artefacts de CE plan : registre, briefs, rapports, paquets de revue.
  Le répertoire d'un autre plan ne doit jamais être lu ou modifié par vous.
- Vérifiez la présence du registre de ce plan dans `<workspace>/progress.md`. S'il en
  existe un, lisez [references/resuming.md](references/resuming.md) avant toute autre
  chose : il indique à qui appartient le registre et où reprendre.
- Créez le registre avec son identifiant comme première ligne :
  `# SDD ledger — plan: <plan file path>`.
- Le registre est votre plan de reprise : les commits qu'il mentionne existent dans git
  même lorsque votre contexte ne se souvient plus de les avoir créés. Après un compactage,
  fiez-vous au registre et à `git log` plutôt qu'à vos propres souvenirs.
- `git clean -fdx` détruira l'espace de travail (c'est une zone de travail temporaire
  ignorée par git) ; si cela se produit, récupérez la situation à partir de `git log`.

Lisez le plan une fois, notez son contexte ainsi que les contraintes globales (Global Constraints),
et créez un todo par tâche. Si le plan mentionne une spécification (Spec), lisez-la également :
la spécification est l'autorité sur laquelle s'appuie le plan, et les conflits au sein du plan
sont tranchés en sa faveur. Un plan sans spécification accessible reçoit une note dans le registre
l'indiquant — les décisions prises sans elle sont provisoires.

Avant de distribuer la Tâche 1, lisez [references/preflight.md](references/preflight.md)
et lancez l'analyse de conflits qu'il décrit. Son tableau et ses arbitrages vont dans le
registre.

## Sélection du modèle

Utilisez le modèle le moins puissant capable d'assumer chaque rôle afin de réduire les coûts et d'augmenter la vitesse.

**Tâches d'implémentation mécaniques** (fonctions isolées, spécifications claires, 1-2 fichiers) : utilisez un modèle rapide et économique. La plupart des tâches d'implémentation sont mécaniques lorsque le plan est bien spécifié.

**Tâches d'intégration et de jugement** (coordination multi-fichiers, reconnaissance de motifs, débogage) : utilisez un modèle standard.

**Tâches d'architecture et de conception** : utilisez le modèle le plus performant disponible.
La revue finale de toute la branche en fait partie — distribuez-la sur le modèle disponible
le plus performant, pas sur le modèle par défaut de la session.

**Tâches de revue** : choisissez le modèle avec le même discernement, proportionné à la taille
du diff, à sa complexité et à son risque. Un petit diff mécanique n'a pas besoin du modèle le plus
performant ; une modification subtile liée à la concurrence en a besoin. Les nouvelles revues
ciblées de petits diffs de correction relèvent d'un niveau économique à intermédiaire.

**Escalade dans la boucle de correction (tours 4-5)** : utilisez un modèle supérieur d'au moins
un niveau par rapport à l'implémenteur qui s'est retrouvé bloqué.

**Spécifiez toujours explicitement le modèle lors de la distribution d'un sous-agent.** Un modèle
omis hérite du modèle de votre session — souvent le plus performant et le plus cher — ce qui
annule silencieusement les consignes de cette section.

**Le nombre de tours l'emporte sur le prix des tokens.** Le temps réel et le coût en contexte
augmentent avec le nombre de tours nécessaires à un sous-agent, et les modèles les plus économiques
prennent couramment 2 à 3 fois plus de tours sur des tâches en plusieurs étapes — coûtant au final
plus cher. Utilisez un modèle de niveau intermédiaire comme plancher pour les réviseurs et pour
les implémenteurs travaillant à partir de descriptions en texte brut. Lorsque le texte du plan
de la tâche contient l'intégralité du code à écrire, l'implémentation se résume à de la transcription
et des tests : utilisez le niveau le plus économique pour cet implémenteur. Les corrections
mécaniques sur un seul fichier relèvent également du niveau le plus économique.

**Indicateurs de complexité des tâches (tâches d'implémentation) :**
- Touche 1-2 fichiers avec une spécification complète → modèle économique
- Touche plusieurs fichiers avec des enjeux d'intégration → modèle standard
- Nécessite un jugement de conception ou une compréhension approfondie de la base de code → modèle le plus performant

## La boucle de tâche

**Travaux similaires de petite taille :** lorsque le plan liste plusieurs petites modifications
du même type à travers plusieurs fichiers, lisez [references/batching.md](references/batching.md)
avant de les distribuer.

Tout ce que vous collez dans un prompt de distribution — et tout ce qu'un sous-agent
renvoie en sortie — reste résident dans votre contexte pour le reste de la session
et est relu à chaque tour ultérieur. Transmettez les artefacts sous forme de fichiers.

**Attente des sous-agents distribués :** ne scrutez jamais une interface d'attente
avec des timeouts courts, et ne restez pas non plus dans une attente silencieuse et
sans fin. Tant que vous avez du travail local — mises à jour du registre, préparation
du paquet pour la prochaine revue, lecture de rapports — continuez à travailler ;
les résultats enfants arrivent d'eux-mêmes. Lorsque vous êtes véritablement inactif,
attendez par intervalles délimités (cinq à dix minutes, si votre plateforme le permet),
et entre deux intervalles, publiez une ligne d'état et faites le point sur vos agents
enfants en cours : listez-les, et relancez ceux qui ont terminé sans faire de rapport.
Un intervalle délimité conserve la quasi-totalité de l'efficacité d'une longue attente
tout en garantissant qu'un enfant bloqué ou égaré soit repéré en quelques minutes,
et non à la fin de la session.

### 1. Distribuer l'implémenteur

Enregistrez le commit de BASE (`git rev-parse HEAD`) avant la distribution — le paquet
de revue et les diffs des tours de correction en ont besoin.

- **Brief de la tâche :** avant de distribuer un implémenteur, exécutez la commande de
  cette compétence `bash scripts/task-brief PLAN_FILE N` — elle extrait le texte intégral
  de la tâche dans un fichier nommé de façon unique et affiche son chemin. Rédigez la
  distribution de sorte que le brief reste la source unique des exigences. Votre
  distribution doit contenir : (1) une ligne indiquant où cette tâche s'insère dans le
  projet ; (2) le chemin du brief, introduit par « lisez ceci en premier — ce sont vos
  exigences, avec les valeurs exactes à utiliser telles quelles » ; (3) les interfaces
  et décisions des tâches précédentes que le brief ne peut pas connaître ; (4) votre
  résolution de toute ambiguïté remarquée dans le brief ; (5) le chemin du fichier de
  rapport et le contrat de rapport. Les valeurs exactes (nombres, chaînes magiques,
  signatures, cas de test) figurent uniquement dans le brief. Ne faites jamais lire le
  fichier de plan complet à un sous-agent.
- **Fichier de rapport :** nommez le fichier de rapport de l'implémenteur d'après le brief
  (brief `…/task-N-brief.md` → rapport `…/task-N-report.md`) et indiquez-le dans le prompt
  de distribution. L'implémenteur y écrit le rapport complet et ne retourne que le statut,
  les commits, un résumé des tests sur une ligne, et les éventuelles préoccupations.
- Un prompt de distribution décrit une seule tâche, pas l'historique de la session. Ne
  collez pas de résumés cumulés des tâches antérieures (« état après les tâches 1-3 »)
  dans les distributions suivantes — lors d'une session réelle, une distribution a atteint
  42 000 caractères dont 99 % n'étaient que de l'historique collé. Un nouveau sous-agent a
  besoin de sa tâche, des interfaces qu'il touche et des contraintes globales. Rien d'autre.
- La distribution comprend le contrat d'interdiction des sous-agents (il est dans le modèle
  d'implémenteur) : l'implémenteur ne distribue jamais de sous-agents — pas d'aides, et
  surtout jamais de réviseur. La revue provient de vous, après le rapport. Dans des sessions
  réelles, chaque réviseur lancé par un agent ouvrier faisait doublon avec la revue de tâche
  que le contrôleur distribuait de toute façon — un poste de revue supplémentaire et inutile
  par tâche.
- Si une tâche précédente a mis en attente une remarque dans la zone que cette tâche touche,
  transmettez une référence à cette entrée du registre dans la distribution.
- Enregistrez l'identifiant d'agent de l'implémenteur à partir du résultat de la distribution —
  les tours 1 à 3 de la boucle de correction reprennent cet agent.
- Ne distribuez jamais plusieurs sous-agents d'implémentation en parallèle (risques de conflits).

Modèle : [implementer-prompt.md](implementer-prompt.md)

### 2. Traiter le rapport

Les sous-agents implémenteurs rapportent l'un des quatre statuts. Traitez chacun de façon appropriée :

**DONE :** Générez le paquet de revue (`bash scripts/review-package PLAN_FILE BASE HEAD`, depuis le répertoire de cette compétence — la commande affiche le chemin unique du fichier créé ; BASE est le commit enregistré avant d'avoir distribué l'implémenteur — jamais `HEAD~1`, qui éliminerait silencieusement tous les commits sauf le dernier dans une tâche à commits multiples), puis distribuez le réviseur de tâche avec le chemin affiché.

**Tout autre statut** (DONE_WITH_CONCERNS, NEEDS_CONTEXT, BLOCKED) : lisez
[references/handling-reports.md](references/handling-reports.md) et appliquez-le,
à chaque fois que vous en recevez un.

Si l'implémenteur pose des questions — avant de commencer ou en cours de tâche —
répondez clairement et complètement, fournissez le contexte additionnel si nécessaire,
et ne le précipitez pas dans l'implémentation.

### 3. Réviser la tâche

Les revues par tâche sont des étapes de contrôle circonscrites à la tâche. La revue globale a lieu
une seule fois, lors de la revue finale de toute la branche. Ne sautez jamais la revue de tâche,
et n'acceptez jamais un rapport auquel il manque l'un ou l'autre verdict — la conformité aux
spécifications ET la qualité de la tâche sont toutes deux exigées. L'auto-revue de l'implémenteur
ne remplace jamais la revue de tâche ; les deux sont indispensables.

- Transmettez son diff au réviseur sous forme de fichier : exécutez la commande de cette
  compétence `bash scripts/review-package PLAN_FILE BASE HEAD` et passez au réviseur le
  chemin de fichier qu'elle affiche (ou, sans bash : `git log --oneline`, `git diff --stat`,
  et `git diff -U10` pour la plage, redirigés vers un fichier nommé de façon unique). La sortie
  n'entre jamais dans votre propre contexte, et le réviseur voit la liste des commits, le résumé
  stat et le diff complet avec contexte en un seul appel de lecture. Utilisez le commit BASE
  enregistré avant la distribution de l'implémenteur — jamais `HEAD~1`, qui tronque silencieusement
  les tâches multi-commits. Ne distribuez jamais un réviseur de tâche sans fichier de diff.
- **Entrées du réviseur :** le réviseur de tâche reçoit trois chemins — le même fichier de brief,
  le fichier de rapport et le paquet de revue — en plus des contraintes globales qui régissent la tâche.
- Le bloc des contraintes globales fourni au réviseur constitue sa grille d'analyse. Recopiez
  textuellement les exigences contraignantes de la section Global Constraints du plan ou de la
  spécification : valeurs exactes, formats exacts et relations définies entre les composants
  (« même disposition que X », « correspond à Y »). Le modèle du réviseur contient déjà les
  règles de processus (YAGNI, rigueur des tests, méthode de revue) — le bloc des contraintes sert
  à préciser ce qu'exige la spécification de CE projet.
- N'ajoutez pas de directives vagues telles que « vérifier toutes les utilisations » ou « exécuter
  les tests de race condition si utile » sans raison concrète et spécifique à la tâche.
- Ne demandez pas à un réviseur de réexécuter des tests que l'implémenteur a déjà exécutés sur
  le même code — le rapport de l'implémenteur fournit déjà la preuve des tests.
- Ne préjugez pas des constats pour le réviseur — ne lui donnez jamais pour consigne d'ignorer
  ou de ne pas signaler un problème spécifique. Si vous pensez qu'un constat serait un faux
  positif, laissez le réviseur le relever et arbitrez-le dans la boucle de revue. Si le prompt
  que vous écrivez contient « ne signale pas », « ne traite pas X comme un défaut », « tout au
  plus Mineur » ou « le plan a choisi » — arrêtez-vous : vous êtes en train de préjuger,
  le plus souvent pour vous éviter une boucle de revue.
Si le réviseur signale des éléments « ⚠️ Cannot verify from diff », lisez
[references/cannot-verify.md](references/cannot-verify.md) avant de marquer la tâche comme terminée.

Modèle : [task-reviewer-prompt.md](task-reviewer-prompt.md)

### 4. La boucle de correction

La boucle se déclenche lorsque la revue signale spec ❌, un constat Critical ou Important,
ou un élément ⚠️ que vous avez confirmé comme étant une réelle lacune.

Quand elle se déclenche, lisez [references/fix-loop.md](references/fix-loop.md) et
appliquez-le. Relisez-le avant chaque tour, même si vous l'avez lu plus tôt dans la session :
il contient le plafond de tours, le disjoncteur (breaker) et la ligne de registre que
chaque tour doit inscrire, et votre souvenir de ces consignes ne survivra pas à un compactage.

### 5. Terminer la tâche

Lorsque la revue revient sans anomalie — ou que chaque constat ouvert est mis en attente avec
un arbitrage formel au niveau du plafond — ajoutez la ligne d'achèvement au registre dans le
même message que vos autres opérations de suivi :

- `Task <N>: complete (commits <base7>..<head7>, review clean)`
- `Task <N>: complete (commits <base7>..<head7>, <K> parked)` après déclenchement d'un disjoncteur

Puis marquez la tâche comme terminée dans le todo et passez à la suite. Ne passez jamais à la
tâche suivante tant que la revue comporte des problèmes Critical/Important ouverts qui ne sont
ni corrigés ni mis en attente avec décision formelle au plafond.

## Revue finale

Lorsque chaque tâche est terminée, lisez
[references/final-review.md](references/final-review.md) et suivez ses instructions.
Ce document traite de la revue complète de la branche, de son unique vague de correction,
et de la façon de clore le processus.

## Rationalisations courantes

| Excuse | Réalité |
|--------|---------|
| « C'est suffisamment proche de la spécification » | Le réviseur a trouvé des écarts par rapport à la spec = ce n'est pas terminé. Corrigez ou atteignez le plafond et arbitrez — ce sont les seules issues. |
| « Je vais le corriger moi-même, distribuer un agent est trop lourd » | Les corrections apportées par le contrôleur polluent votre contexte et sautent l'étape de revue. Relancez l'implémenteur. |
| « Un tour de plus et ça va converger » | Au-delà du plafond, les tours ne convergent pas — l'échec est structurel. Arbitrez et réorientez. |
| « Le réviseur va de toute façon trouver quelque chose de nouveau » | Les réexamens ciblés vérifient les correctifs ; ils ne dérivent pas. De nouveaux constats sur du code non modifié vont dans le registre, pas dans la boucle. |
| « Ce constat est manifestement faux, je l'ignore » | Vous n'arbitrez qu'au plafond, et chaque arbitrage fait l'objet d'une entrée dans le registre. Les rejets silencieux sont interdits. |
| « La correction était minime, passons la re-revue » | C'est par des corrections non révisées que les régressions s'introduisent. Chaque tour se termine par une revue ciblée. |
| « Les revues ralentissent la boucle » | Une boucle sans revues n'est qu'une agitation non vérifiée. Les revues sont les freins et la direction de la boucle. |
| « La tenue du registre est superflue » | Le registre est ce qui survit au compactage de contexte. Des contrôleurs sans registre ont re-distribué des séquences entières de tâches déjà faites. |
| « L'implémenteur a lancé son propre réviseur — une garantie supplémentaire bienvenue » | C'est un réviseur en double qui examine le même diff ; la revue de tâche est l'unique validation faisant foi. Un réviseur lancé par un ouvrier est une anomalie à signaler, pas un gage de rigueur. |
