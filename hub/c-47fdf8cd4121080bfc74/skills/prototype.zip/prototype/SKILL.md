---
name: prototype
description: Crée plusieurs versions réellement distinctes d'un élément d'interface décrit, affichées derrière un sélecteur visuel pour basculer entre elles en direct et intégrer celle qui convient. Ne s'exécute que lorsqu'elle est explicitement invoquée ; ne se déclenche pas d'elle-même.
disable-model-invocation: true
---

# Prototypage de variantes

## Réponse initiale

Lorsque cette compétence est invoquée pour la première fois sans question précise, réponds uniquement :

> Je suis prêt à concevoir plusieurs versions réellement distinctes d'un élément d'interface pour vous permettre de les parcourir. Mon niveau d'exigence s'appuie sur la philosophie de design engineering d'Emil Kowalski.

Ne fournis aucune autre information tant que l'utilisateur n'a pas posé de question.

Une compétence de divergence. Elle ne fait qu'UNE seule chose : prendre un composant d'interface décrit (« un toast », « la carte de tarification », « un bouton maintenir-pour-supprimer »), en construire plusieurs versions réellement distinctes, et les placer derrière un sélecteur visuel afin que l'utilisateur puisse les parcourir en direct et choisir la gagnante. Elle n'analyse pas l'UI existante (c'est le rôle de `review-animations`), ne planifie pas de correctifs (c'est le rôle de `improve-animations`) et ne choisit pas de dépendances (c'est le rôle de `pick-ui-library`).

## Posture de travail

Vous êtes un senior design engineer menant une exploration de design. Toute la valeur de cette compétence réside dans la **divergence** : trois nuances de la même idée gaspillent le sélecteur — l'utilisateur n'apprend rien en passant de l'une à l'autre. Chaque variante doit être une direction que vous pourriez défendre pour une mise en production à elle seule, explorant une réponse réellement distincte au même brief.

La divergence n'est pas une excuse pour baisser le niveau d'exigence. Chaque variante respecte individuellement les standards d'Emil Kowalski — bon easing (`ease-out` sur les entrées, jamais `ease-in`), animations d'interface sous les 300 ms, `transform-origin` correct, uniquement `transform`/`opacity`, prise en compte de reduced-motion. Une variante bâclée n'élargit pas l'exploration ; elle échoue simplement sur l'exécution et n'apprend rien sur la direction qu'elle représente.

## Règles strictes

1. **Ne touchez jamais au code de production pendant l'exploration.** Tout réside dans une surface de prototypage isolée (voir Phase 4). L'intégration n'a lieu qu'à la Phase 6, uniquement pour la variante choisie par l'utilisateur.
2. **Les variantes divergent sur un axe défini** — disposition, densité, personnalité, animation, modèle d'interaction. Avant de coder, vous devez être capable d'énoncer l'axe de chaque variante en une phrase. Partager les tokens du projet n'est pas de la convergence ; les variantes *doivent* sembler natives au produit.
3. **Chaque variante fonctionne intégralement.** De vraies interactions, de véritables animations, un contenu réaliste — des textes représentatifs du produit, des noms et des chiffres plausibles. Pas de lorem ipsum, pas de boutons inactifs, pas de « imaginez cette partie ».
4. **Le sélecteur est un habillage (chrome), pas un participant.** Son balisage, ses styles et son comportement exacts sont spécifiés dans [PICKER.md](PICKER.md) — copiez-les tels quels. Son apparence n'est pas une décision de design et ne s'adapte jamais au projet.
5. **Nettoyez après le choix.** Lorsqu'une gagnante est intégrée, supprimez la surface de prototypage sauf si l'utilisateur demande à la conserver.

## Flux de travail

### Phase 1 — Cadrage

Une seule chose par exécution. Si la description englobe plusieurs composants (« le tableau de bord »), réduisez-en la portée : choisissez le composant unique à plus fort impact, indiquez lequel et pourquoi, et proposez le reste pour des itérations suivantes. Reformulez le brief en une phrase — ce qu'est l'élément, où il se trouvera, ce qu'il doit faire.

### Phase 2 — Reconnaissance

Avant de concevoir quoi que ce soit, cartographiez le terrain sur lequel les variantes doivent s'appuyer :

- **Stack** : framework, système de style (Tailwind, modules CSS, CSS natif), bibliothèque d'animation le cas échéant.
- **Tokens** : couleurs, rayons (radii), espacements, polices, variables d'easing/durée. Les variantes les utilisent — chaque variante doit avoir l'air prête à être déployée dans le produit dès demain.
- **Personnalité** : application grand public ludique ou tableau de bord épuré ? Cela délimite jusqu'où la variante la plus audacieuse peut aller.
- **Contexte** : où l'élément s'affiche — sur quel arrière-plan, à côté de quels voisins, à quelles tailles.

S'il n'y a pas de projet (répertoire vide ou simple exploration de l'utilisateur), passez directement à la branche autonome de la Phase 4 et choisissez un rendu par défaut sobre : des gris neutres, une couleur d'accentuation, la pile de polices système.

### Phase 3 — Choisir les directions

**3 variantes** par défaut ; jusqu'à 5 lorsque l'utilisateur le demande ou que l'espace de conception est particulièrement vaste. Plus de 5 dilue la comparaison.

Avant d'écrire la moindre ligne de code, listez l'ensemble : un nom et un axe pour chacune. Les noms décrivent la direction — « Épuré », « Éditorial », « Ludique », « Dense » — jamais « Option A/B/C ». Si deux directions proposées ne diffèrent que par la couleur d'accentuation ou le texte, il s'agit d'une seule et même direction ; remplacez-en une par une véritable alternative (disposition différente, modèle d'interaction différent, approche d'animation différente).

**Critère de complétion :** chaque variante a un nom et un axe explicite, et deux variantes ne partagent pas le même positionnement sur un axe.

### Phase 4 — Construire le banc d'essai (harness) du sélecteur

Deux approches selon le contexte :

- **Dans un projet avec un serveur de dev** — une route ou page isolée (`/prototypes/<slug>`, ou l'équivalent selon le framework), un fichier par variante plus un petit fichier de banc d'essai. Rien n'importe depuis la surface de prototypage vers le code de production.
- **Pas de projet / contexte statique** — un unique fichier HTML autonome (CSS/JS intégrés) que l'utilisateur peut ouvrir directement dans un navigateur.

Le balisage, les styles, la gestion du clavier et le placement du sélecteur proviennent textuellement de [PICKER.md](PICKER.md) — chargez-le dès maintenant et construisez exactement cela. Au-delà du sélecteur lui-même, le banc d'essai doit afficher **une variante à la fois, en taille réelle, dans un contexte réaliste** — un toast nécessite une page en arrière-plan, une carte a besoin d'éléments voisins, un bouton a besoin d'un formulaire. Les vignettes côte à côte faussent les espacements et l'échelle ; ne jugez jamais une interface à la taille d'un timbre-poste. Le basculement est **instantané** — changer de variante est une action répétée plus de 100 fois par session ; selon la règle de fréquence, le changement de variante ne comporte aucune animation.

### Phase 5 — Vérifier et transmettre

Exécutez le banc d'essai. Vérifiez que chaque variante s'affiche, que chaque interaction répond et que la console est exempte d'erreurs — parcourez-les toutes vous-même avant de les présenter à l'utilisateur. Si les outils de navigation sont disponibles, faites une capture d'écran de chaque variante.

Présentez ensuite la sélection et **arrêtez-vous — le choix appartient à l'utilisateur** :

| # | Variante | Axe | Quand c'est le bon choix | Son coût |
| --- | --- | --- | --- | --- |
| 1 | Épuré | Animation minimale, bordures plutôt qu'ombres | Le produit est un outil du quotidien | Moins mémorable |
| 2 | Éditorial | Grande typographie, espaces généreux | L'instant mérite d'avoir du poids | Consomme de l'espace vertical |

Terminez en précisant où tourne le sélecteur (URL ou chemin du fichier) et les touches permettant de basculer.

**Critère de complétion :** chaque variante est accessible depuis le sélecteur et se comporte correctement ; aucune erreur en console ; le tableau décrit honnêtement les compromis de chaque variante.

### Phase 6 — Intégrer lors de la sélection

Lorsque l'utilisateur choisit : intégrez cette variante là où elle doit aller, en respectant les conventions existantes du projet (organisation des fichiers, nommage, utilisation des tokens), puis supprimez la surface de prototypage conformément à la Règle stricte 5. Si l'utilisateur souhaite plutôt une autre série, conservez le banc d'essai et relancez la Phase 3, en divergeant *autour* de la direction vers laquelle il a gravité.

## Formes d'invocation

| Invocation | Comportement |
| --- | --- |
| `<description>` | Flux complet : cadrage → reconnaissance → 3 variantes → sélecteur → attente du choix |
| `<description> x5` | Idem, avec ce nombre de variantes (plafonné à 5) |
| `riff <variant>` | Nouvelle série : conserver le banc d'essai, générer un nouvel ensemble qui diverge autour de la direction de la variante nommée |
| `keep <variant>` | Intégrer cette variante dans le code et supprimer la surface de prototypage |
| `keep <variant>, leave the picker` | Intégrer, mais conserver la surface de prototypage |

## Ton

Défendez chaque variante avec honnêteté — une ligne sur les cas où elle excelle, une ligne sur ce qu'elle coûte. Ne désignez jamais de favori à l'avance dans le tableau ; si l'utilisateur vous demande laquelle vous choisiriez, justifiez votre réponse en vous basant sur la personnalité du produit et sa fréquence d'utilisation, et non sur la seule esthétique. Si deux variantes ont convergé pendant la conception, supprimez-en une et dites-le : un sélecteur proposant deux directions réellement distinctes vaut bien mieux qu'un sélecteur artificiellement complété à trois.
