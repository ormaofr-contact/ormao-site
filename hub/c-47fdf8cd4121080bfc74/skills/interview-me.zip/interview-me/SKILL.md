---
name: interview-me
description: Extrait ce que l'utilisateur veut réellement au lieu de ce qu'il pense devoir vouloir. Y parvient par un entretien question par question jusqu'à atteindre une confiance d'environ 95 % sur l'intention sous-jacente. À utiliser lorsqu'une demande est sous-spécifiée ("construis-moi X" sans "pour qui" ni "pourquoi maintenant"), lorsque l'utilisateur l'invoque explicitement ("interviewe-moi", "cuisine-moi", "en est-on sûrs ?", "éprouve ma réflexion"), ou lorsque vous vous surprenez à combler silencieusement des exigences ambiguës avant qu'aucun plan, spécification ou code n'existe.
---

# Interview Me

## Vue d'ensemble

Ce que les gens demandent et ce qu'ils veulent réellement sont deux choses différentes. Ils demandent "un tableau de bord" parce que c'est ce que l'on demande d'habitude, pas parce qu'un tableau de bord résout leur problème. Ils disent "rends-le plus rapide" sans fixer de chiffre à atteindre.

Le moment le moins coûteux pour identifier cet écart se situe avant qu'aucun plan, aucune spécification ou aucun code n'existe. Une fois la construction commencée, les coûts de changement deviennent bien réels, et l'utilisateur rationalisera la mauvaise solution pour en faire quelque chose de "suffisamment bon". L'inadéquation s'installe définitivement.

Cette compétence comble l'écart avant qu'il ne coûte quoi que ce soit. Les autres compétences de la phase de définition partent du principe que vous savez déjà à peu près ce que vous voulez : `idea-refine` génère des variations à partir d'une idée, `spec-driven-development` rédige les exigences, `doubt-driven-development` met un plan à l'épreuve après en avoir rédigé une ébauche. Interview-me se situe en amont de tout cela : vous y posez une seule question à la fois, accompagnée de votre meilleure hypothèse, jusqu'à pouvoir prédire ce que l'utilisateur va répondre avant même qu'il ne le dise.

## Quand l'utiliser

Appliquez cette compétence lorsque :

- La demande omet au moins l'un des éléments suivants : **qui** est l'utilisateur, **pourquoi** il le veut, à quoi ressemble le **succès**, quelle est la **contrainte** déterminante
- La demande est conventionnelle plutôt que spécifique ("construis-moi X", "rends-le plus rapide") et vous ne pouvez pas décortiquer la convention sans deviner
- Vous êtes tenté de démarrer avec des suppositions que vous n'avez pas explicitées
- L'utilisateur n'a pas précisé quelle valeur il optimise lorsque deux valeurs raisonnables sont en tension (simplicité vs flexibilité, coût vs vitesse)
- L'utilisateur l'invoque explicitement : "interviewe-moi", "cuisine-moi", "avant de commencer, en est-on sûrs ?", "éprouve ma réflexion"

**Quand NE PAS l'utiliser :**

- La demande est sans ambiguïté et autonome ("renomme cette variable", "corrige cette coquille")
- L'utilisateur a explicitement demandé la rapidité au détriment de la vérification
- Demandes de pure information ("comment fonctionne X ?", "que fait ce code ?")
- Opérations mécaniques (renommages, formatages, déplacements de fichiers)
- Vous avez déjà une confiance ≥ 95 % ; relisez la condition d'arrêt ci-dessous avant de supposer que ce n'est pas le cas

## Contraintes de chargement

Cette compétence nécessite un utilisateur disponible et interactif. **Ne l'invoquez pas dans des contextes non interactifs** tels que les pipelines CI, les exécutions planifiées, `/loop` ou autonomous-loop. Si vous vous trouvez dans l'un de ces contextes et que la demande est sous-spécifiée, signalez-le comme un point bloquant à l'utilisateur au lieu de deviner.

## Le processus

### Étape 1 : Formuler une hypothèse, avec un niveau de confiance chiffré

Avant de poser la moindre question, écrivez votre meilleure interprétation actuelle de ce que veut l'utilisateur en **une seule phrase**, accompagnée d'un niveau de confiance honnête (0 à 100 %) :

```
HYPOTHÈSE : Vous voulez un moyen de répondre à "où en sommes-nous ?" pendant le standup, et "tableau de bord" était la convention qui vous est venue à l'esprit.
CONFIANCE : ~30 % — manquent : à qui cela s'adresse, ce que signifient les "métriques" en contexte, et à quoi ressemble le succès
```

Le chiffre force l'honnêteté. Si vous avez noté un chiffre élevé mais que vous êtes incapable de prédire les réactions de l'utilisateur aux trois prochaines questions que vous poseriez, ce chiffre est faux. Commencez au niveau de confiance que vous pouvez défendre.

Lorsque la confiance est inférieure à ~70 %, ajoutez une brève justification sur la même ligne — ce qui reste non résolu ou manquant. Cela indique exactement à l'utilisateur ce que l'entretien doit faire émerger, et évite que le chiffre ne soit qu'un signal vague.

### Étape 2 : Poser une question à la fois, chacune assortie d'une supposition

Format :

```
Q : <une question ciblée>
SUPPOSITION : <votre hypothèse de réponse, avec le raisonnement qui l'a produite>
```

Attendez la réaction de l'utilisateur avant de poser la question suivante.

**Pourquoi une à la fois, et non par lot :**

- L'utilisateur ne peut pas réagir à vos hypothèses si vous les noyez dans une liste
- Les lots incitent au survol rapide et aux réponses superficielles
- La troisième question dépend souvent de la réponse à la première ; les poser toutes d'un coup fige un mauvais cadrage
- L'énergie de l'utilisateur pour réfléchir posément est limitée ; dépensez-la une question à la fois

**Pourquoi joindre une supposition :**

- L'utilisateur réagit plus vite à une supposition erronée qu'il ne formule une réponse de zéro
- Cela vous engage sur une hypothèse sur laquelle vous pouvez manifestement vous tromper, ce qui vous garde honnête
- Cela met en lumière *vos* propres suppositions, ce que l'entretien a précisément pour but d'exposer

Le risque ici est qu'un utilisateur poli acquiesce à votre supposition par complaisance. Atténuez ce risque en montrant clairement que vous êtes prêt à vous tromper, et faites parfois une supposition dans une direction où vous vous attendez à ce que l'utilisateur vous contredise.

### Étape 3 : Guetter le "vouloir vs devoir vouloir"

Les réponses les plus dangereuses sont celles où l'utilisateur dit ce à quoi une réponse réfléchie *devrait ressembler*, plutôt que ce qu'il veut réellement. Repérez :

- Les réponses calquées sur le discours des bonnes pratiques ("je veux que ce soit scalable", "une architecture propre") sans détails précis
- Les réponses qui s'en remettent à la convention ("comme le font la plupart des applications", "l'approche standard")
- Les formulations comme "je devrais probablement…", "je crois que je suis censé…", "les bonnes pratiques d'ingénierie disent que…"
- Les mots à la mode érigés en objectifs — quand "moderne", "scalable", "robuste" constituent la réponse au lieu d'un résultat spécifique

Lorsque vous entendez cela, la question à poser est :

> *"Si vous n'aviez de comptes à rendre à personne, que voudriez-vous réellement ?"*

Cette seule question accomplit souvent plus de travail que les cinq précédentes réunies.

### Étape 4 : Reformuler l'intention avec les propres mots de l'utilisateur

Lorsque votre confiance est élevée, reformulez par écrit ce que vous pensez désormais que l'utilisateur veut. Restez concis (5 à 8 lignes), reprenez ses termes dans la mesure du possible, et structurez la restitution pour que l'utilisateur puisse confirmer ou corriger ligne par ligne :

```
Voici ce que je pense maintenant que vous voulez :

- Résultat :     <une ligne>
- Utilisateur :  <une ligne — qui en bénéficie>
- Pourquoi mnt : <une ligne — ce qui a changé>
- Succès :       <une ligne — comment savoir si cela a fonctionné>
- Contrainte :   <une ligne — la limite déterminante>
- Hors périmètre:<une ligne — ce que nous ne faisons explicitement pas>

Oui / non / à affiner ?
```

Inclure "Hors périmètre" est non négociable. La moitié des désalignements provient d'un désaccord silencieux sur ce qui n'est *pas* en cours de construction.

### Étape 5 : Confirmer — un oui explicite, pas un "fais comme tu penses"

Le point de passage obligatoire est un "oui" explicite. Les réponses suivantes ne sont **pas** des oui :

- "Fais ce qui te semble le mieux." → L'utilisateur délègue, ce qui signifie qu'il n'a pas non plus 95 % de confiance. Reposez la question avec deux options concrètes présentées sous forme de choix.
- "Ça a l'air bien." → Ambigu. Demandez : "Quelque chose à affiner ?" Le silence n'est pas une confirmation.
- "Bien sûr, allons-y." → Souvent une porte de sortie polie, pas une adhésion réelle. Même relance.
- Un silence suivi de "d'accord, commençons." → L'utilisateur a abandonné l'entretien, il n'a pas convergé. Arrêtez-vous et demandez si vous êtes passé à côté de quelque chose.

S'il vous corrige, intégrez la correction et reformulez. Répétez la boucle jusqu'à obtenir un oui explicite.

### Étape 6 : Tour terminal et règle d'arrêt (CRITIQUE)

Lorsque l'utilisateur confirme la déclaration d'intention par un "oui" explicite :

1. **Délivrez la déclaration d'intention confirmée.**
2. **Proposez les pistes pour la suite** (proposer de la sauvegarder dans `docs/intent/[topic].md`, de rédiger une spécification avec `spec-driven-development`, ou de passer à la planification des tâches après la spécification).
3. **ARRÊTEZ IMMÉDIATEMENT VOTRE TOUR.** N'invoquez AUCUN outil et ne commencez aucun travail en aval durant ce tour. Rendez le contrôle à l'utilisateur pour qu'il choisisse la prochaine étape.

### L'arrêt à 95 % de confiance

Vous avez terminé lorsque vous pouvez répondre oui à cette question :

> *Puis-je prédire la réaction de l'utilisateur aux trois prochaines questions que je poserais ?*

Si oui, vous partagez une compréhension commune. Arrêtez l'entretien et produisez la reformulation. Si non, vous n'avez pas terminé ; posez la question suivante.

Il s'agit d'un test vérifiable, pas d'une impression diffuse. Il possède aussi un seuil plancher : si vous avez enchaîné plusieurs tours et ne parvenez toujours rien à prédire, c'est une information sur la demande en elle-même, pas une raison de continuer à insister aveuglément. Arrêtez-vous et dites à l'utilisateur : "J'ai posé X questions et je ne parviens toujours pas à prédire vos réactions. Quelque chose de fondamental nous échappe. Voulez-vous que l'on prenne du recul ?"

## Livrable

Le résultat produit par cette compétence est une **déclaration d'intention confirmée** : la reformulation de l'Étape 4, validée par un oui explicite à l'Étape 5. C'est le livrable. Les spécifications, plans et listes de tâches viennent en aval ; ils exploitent l'intention produite par cette compétence.

Si l'utilisateur souhaite que cette intention soit conservée (projet sur plusieurs sessions, passage de relais à un autre collaborateur), proposez de la sauvegarder dans `docs/intent/[topic].md`. N'enregistrez que s'il confirme.

## Exemple

Un bref avant / après.

**Sans `interview-me` :**

```
Utilisateur : construis-moi un tableau de bord pour nos métriques
Agent :       <commence à proposer des bibliothèques de graphiques et des mises en page>
```

L'agent a supposé : à qui cela s'adresse, quelles métriques, ce que signifie "pour notre équipe", à quoi ressemble le succès. Rien de tout cela n'a été énoncé. Chaque supposition est un point où l'utilisateur pourra dire plus tard : "ce n'est pas ce que je voulais dire".

**Avec `interview-me` :**

```
Utilisateur : construis-moi un tableau de bord pour nos métriques

Agent :
HYPOTHÈSE : Vous voulez un moyen de répondre à "où en sommes-nous ?" pendant le standup, et "tableau de bord" est venu à l'esprit car c'est la réponse conventionnelle.
CONFIANCE : ~30 % — manquent : à qui cela s'adresse, ce que sont les "métriques", et à quoi ressemble le succès

Q :           Quand vous dites "où en sommes-nous ?", qui demande — vous seul, l'équipe d'ingénierie en standup, ou la hiérarchie (par ex. votre responsable, un dirigeant, un conseil) ?
SUPPOSITION : l'équipe d'ingénierie en standup, car "nous" s'entend généralement ainsi et c'est en standup qu'on pose cette question. Si c'est pour des dirigeants, les métriques et le cadrage changent radicalement.

Utilisateur : C'est en fait pour moi. Je perds sans cesse le fil des expériences en cours et de leurs premiers signaux.

Agent :
Lecture mise à jour : pas du tout un tableau de bord d'équipe. C'est un outil personnel de suivi d'expériences. Confiance : ~60 % — manquent encore : ce que signifie "premiers signaux" et à quoi ressemble le travail terminé.

Q :           Le problème vient-il du fait que vous ne savez pas quelles expériences existent, ou du fait que vous ne pouvez pas voir leurs résultats au même endroit ?
SUPPOSITION : la seconde option. Vous avez une liste d'expériences quelque part, mais leurs résultats se trouvent dans cinq outils différents, et c'est le rapprochement manuel qui vous épuise.

Utilisateur : La première en fait. Je n'ai littéralement aucune liste. Elles sont dispersées dans différents documents.

Agent : <continue>
```

En deux questions, l'agent a découvert que la demande réelle n'est pas "un tableau de bord". C'est "une liste". Artefact différent, périmètre différent, travail différent. Le tableau de bord aurait été une erreur.

## Interaction avec d'autres compétences

- **`idea-refine`** : en aval. Si l'intention confirmée est "Je veux X mais je ne sais pas comment en définir le périmètre", passez le relais à `idea-refine` pour générer des variations par rapport à l'intention désormais explicite.
- **`spec-driven-development`** : en aval. Si l'intention confirmée est concrète ("Je veux X pour Y utilisateurs avec Z critères de succès"), passez le relais à `spec-driven-development` pour la formaliser par écrit.
- **`planning-and-task-breakdown`** : deux étapes en aval de cette compétence (après la spécification).
- **`doubt-driven-development`** : à l'autre extrémité de la chronologie. Interview-me est une extraction d'intention pré-décisionnelle ; doubt-driven est une revue d'artefact post-décisionnelle. Les deux permettent de repérer les divergences, mais à des moments distincts.
- **`source-driven-development`** : orthogonal. Interview-me clarifie ce que veut l'utilisateur ; SDD vérifie des faits relatifs aux frameworks. Elles ne sont pas en concurrence.

## Rationalisations courantes

| Rationalisation | Réalité |
|---|---|
| "La demande est assez claire" | Si vous ne pouvez pas écrire le résultat souhaité par l'utilisateur en une phrase dès maintenant, la demande n'est pas claire. Exécutez l'Étape 1 avant de trancher. |
| "Poser trop de questions lui fait perdre son temps" | Le temps perdu par 4 à 6 questions ciblées est infime. Le temps perdu à construire la mauvaise chose est énorme, et c'est l'utilisateur qui en assume le coût. |
| "Je comprendrai au fur et à mesure que je construis" | Les coûts de changement une fois que le code existe sont 10 fois plus élevés que maintenant. Découvrir les besoins pendant l'implémentation implique de tout refaire. |
| "Il a dit 'fais comme tu penses', je devrais donc simplement décider" | "Fais comme tu penses" est une délégation, pas une décision. Reposez la question avec deux options concrètes formulées comme un choix. |
| "Je devrais lui proposer plusieurs options parmi lesquelles choisir" | Les options fonctionnent quand l'utilisateur sait ce qu'il veut et arbitre entre des compromis. Il ne sait pas encore ce qu'il veut. Lister des options élargit la recherche ; poser des questions la resserre. |
| "Si je joins ma supposition, je l'influence" | L'influencer est précisément le but. Réagir est plus rapide que générer de zéro. Le risque est la flatterie/complaisance, pas l'influence ; compensez en montrant clairement que vous êtes prêt à avoir tort. |
| "On a assez discuté, j'ai compris" | Testez-le : pouvez-vous prédire sa réaction aux trois prochaines questions ? Si non, vous n'avez pas encore compris. |
| "L'utilisateur a dit oui, on a fini" | Si le oui a suivi une reformulation vague ou un "ça a l'air bien" sans engagement, ce oui est creux. Reformulez concrètement et reconfirmez. |

## Signaux d'alerte

- Trois questions ou plus dans un seul message : c'est du traitement par lot, pas un entretien
- Une question sans votre hypothèse attachée : c'est un sondage, pas une prise de position
- Accepter "fais ce qui te semble le mieux" comme réponse finale
- Produire une spécification, un plan ou une liste de tâches avant que l'utilisateur n'ait explicitement confirmé votre reformulation
- Invoquer des outils ou démarrer le travail en aval immédiatement après la confirmation de l'intention au lieu d'arrêter votre tour
- Des questions formulées sous la forme "quelle serait la bonne pratique ?" au lieu de "que voulez-vous réellement ?"
- L'utilisateur donne une réponse pour paraître avisé ("scalable", "propre", "moderne") et vous l'acceptez sans chercher à savoir si c'est ce qu'il veut vraiment
- Trois tours ou plus sans que votre confiance n'augmente visiblement : vous posez les mauvaises questions, prenez du recul et reformulez
- Un niveau de confiance inférieur à ~70 % sans raison précisée : l'utilisateur ne peut pas aider à combler l'écart s'il ignore ce qui manque
- Sauvegarder le document d'intention avant que l'utilisateur n'ait confirmé (le document lui-même sous-entend un oui que l'utilisateur n'a pas donné)
- Sauter la ligne "Hors périmètre" dans la reformulation (le désaccord silencieux sur ce qui n'est pas visé représente la moitié des désalignements)

## Vérification

Après avoir appliqué interview-me :

- [ ] Une hypothèse explicite avec un niveau de confiance chiffré a été énoncée lors du premier tour
- [ ] Chaque niveau de confiance inférieur à ~70 % était accompagné d'une raison en une ligne (ce qui reste non résolu ou manquant)
- [ ] Les questions ont été posées une par une, chacune accompagnée de la supposition de l'agent
- [ ] Au moins une relance du type "que voudriez-vous réellement si vous n'aviez de comptes à rendre à personne ?" a été effectuée lorsque l'utilisateur a donné une réponse dictée par les conventions ou le paraître
- [ ] Une reformulation concrète (Résultat / Utilisateur / Pourquoi mnt / Succès / Contrainte / Hors périmètre) a été soumise à l'utilisateur
- [ ] L'utilisateur a confirmé la reformulation par un oui explicite (pas un "fais comme tu penses", pas un "ça a l'air bien", pas un silence)
- [ ] Au point d'arrêt, l'agent était capable de prédire les réactions aux trois prochaines questions qu'il poserait
- [ ] Dès réception de la confirmation explicite, le tour a été arrêté immédiatement sans invoquer d'outils ni démarrer de travail en aval
- [ ] Tout passage de relais à une compétence en aval (`idea-refine`, `spec-driven-development`) a été formulé sur la base de l'intention confirmée, et non de la demande initiale sous-spécifiée
