---
name: content-strategy
description: Lorsque l'utilisateur souhaite planifier une stratégie de contenu, décider quels contenus créer ou déterminer les sujets à couvrir. À utiliser également lorsque l'utilisateur mentionne "stratégie de contenu", "sur quoi devrais-je écrire", "idées de contenu", "stratégie de blog", "clusters thématiques", "planification de contenu", "calendrier éditorial", "marketing de contenu", "feuille de route de contenu", "quel contenu devrais-je créer", "sujets de blog", "piliers de contenu" ou "je ne sais pas quoi écrire". Utilisez cette compétence dès que quelqu'un a besoin d'aide pour décider du contenu à produire, et pas seulement pour le rédiger. Pour la rédaction de contenus individuels, voir copywriting. Pour les audits spécifiques au SEO, voir seo-audit. Pour le contenu spécifique aux réseaux sociaux, voir social.
metadata:
  version: 2.1.4
---

# Stratégie de contenu

Vous êtes un stratège de contenu. Votre objectif est d'aider à planifier du contenu qui génère du trafic, assoit l'autorité et produit des leads en étant soit recherchable (searchable), soit partageable (shareable), soit les deux.

## Avant la planification

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md`, dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

Rassemblez ce contexte (demandez-le s'il n'est pas fourni) :

### 1. Contexte de l'entreprise
- Que fait l'entreprise ?
- Quel est le client idéal (ICP) ?
- Quel est l'objectif principal du contenu ? (trafic, leads, notoriété de marque, thought leadership)
- Quels problèmes votre produit résout-il ?

### 2. Recherche client
- Quelles questions les clients posent-ils avant d'acheter ?
- Quelles objections reviennent lors des appels commerciaux ?
- Quels sujets apparaissent régulièrement dans les tickets de support ?
- Quels termes les clients utilisent-ils pour décrire leurs problèmes ?

### 3. État des lieux
- Avez-vous déjà du contenu existant ? Qu'est-ce qui fonctionne ?
- De quelles ressources disposez-vous ? (rédacteurs, budget, temps)
- Quels formats de contenu pouvez-vous produire ? (écrit, vidéo, audio)

### 4. Paysage concurrentiel
- Quels sont vos principaux concurrents ?
- Quelles lacunes de contenu (content gaps) existent sur votre marché ?

---

## Traiter le contenu comme un produit

Chaque publication est son propre lancement. Le contenu n'est pas une charge opérationnelle, c'est de la **surface d'exposition de la marque** (brand surface area) : chaque article publié est un nouveau point d'entrée par lequel un inconnu peut vous découvrir, et des centaines d'articles s'accumulent pour devenir des centaines de portes d'entrée actives 24h/24 et 7j/7. Planifiez, livrez et promouvez chaque contenu avec la même rigueur que pour le lancement d'un produit. Un article rédigé puis oublié n'a pratiquement aucune surface d'exposition ; un article distribué (voir **Créer une fois, distribuer deux fois** ci-dessous) la démultiplie.

Cette section aborde le prisme recherchable/partageable (searchable/shareable), puis la couche d'exécution et de priorisation : quels contenus créer (notation), comment répartir le calendrier, et la rigueur par format.

## Searchable vs Shareable

Chaque contenu doit être recherchable (searchable), partageable (shareable), ou les deux. Priorisez dans cet ordre : le trafic issu de la recherche organique est la base.

Le **contenu recherchable (searchable)** capte une demande existante. Il est optimisé pour les personnes qui recherchent activement des réponses.

Le **contenu partageable (shareable)** crée de la demande. Il diffuse des idées et suscite la conversation.

### Lors de la rédaction d'un contenu recherchable

**Le filtre du gain d'information (information-gain gate) :** avant de vous engager sur un article recherchable, lisez les résultats actuels les mieux classés pour cette requête et écrivez une seule phrase expliquant ce que votre contenu apportera de plus qu'aucun d'entre eux ne possède : des données originales, un exemple de produit réel, un outil ou un modèle fonctionnel, une réponse plus claire, une opinion plus tranchée. Si vous ne pouvez pas écrire cette phrase, n'écrivez pas l'article. Ce ne sera que la onzième copie du même texte, et ni Google ni les assistants IA n'auront de raison de le privilégier.

- Ciblez un mot-clé ou une question spécifique
- Répondez précisément à l'intention de recherche (search intent) : fournissez ce que cherche l'internaute
- Utilisez des titres clairs qui correspondent aux requêtes de recherche
- Structurez avec des sous-titres reflétant les schémas de recherche
- Placez les mots-clés dans le titre, les sous-titres, le premier paragraphe et l'URL
- Offrez une couverture exhaustive (ne laissez aucune question en suspens)
- Intégrez des données, des exemples et des liens vers des sources faisant autorité
- Optimisez pour la découverte par les IA/LLM : positionnement clair, contenu structuré, cohérence de la marque sur le Web

### Lors de la rédaction d'un contenu partageable

- Ouvrez avec un angle novateur, des données originales ou une prise de position contre-intuitive
- Remettez en question les idées reçues avec des arguments bien étayés
- Racontez des histoires qui suscitent une émotion
- Créez du contenu que les gens veulent partager pour paraître avisés ou pour aider les autres
- Raccrochez-vous aux tendances actuelles ou aux problèmes émergents
- Partagez des expériences vulnérables et sincères dont d'autres peuvent tirer des leçons

---

## Types de contenu

### Types de contenu recherchable

**Contenu axé sur les cas d'usage (Use-Case)**
Formule : [persona] + [cas d'usage]. Cible des mots-clés de longue traîne.
- "Gestion de projet pour les designers"
- "Suivi des tâches pour les développeurs"
- "Collaboration client pour les freelances"

**Modèle Hub and Spoke**
Hub = vue d'ensemble complète. Spokes = sous-thèmes associés.
```
/topic (hub)
├── /topic/subtopic-1 (spoke)
├── /topic/subtopic-2 (spoke)
└── /topic/subtopic-3 (spoke)
```
Créez d'abord le hub, puis développez les spokes. Liez-les entre eux de manière stratégique.

**Remarque :** La plupart des contenus fonctionnent très bien sous `/blog`. Ne réservez les structures d'URL dédiées de type hub/spoke qu'aux thématiques majeures présentant une réelle profondeur hiérarchique (par exemple, le guide `/agile` d'Atlassian). Pour des articles de blog classiques, `/blog/post-title` est suffisant.

**Bibliothèques de modèles (Templates)**
Mots-clés à forte intention d'achat + adoption du produit.
- Ciblez des recherches comme "modèle de plan marketing"
- Fournissez une valeur immédiate et autonome
- Montrez comment le produit enrichit et automatise le modèle

### Types de contenu partageable

**Thought Leadership (Leadership d'opinion)**
- Formulez des concepts que tout le monde ressent mais que personne n'a encore nommés
- Remettez en cause les idées reçues, preuves à l'appui
- Partagez des retours d'expérience honnêtes et transparents

**Contenu basé sur les données (Data-Driven)**
- Analyse des données du produit (insights anonymisés)
- Analyse de données publiques (mise en évidence de tendances)
- Recherche originale (mener des expériences, partager les résultats)

**Tours de table d'experts (Expert Roundups)**
15 à 30 experts répondant à une question précise. Distribution virale intégrée.

**Études de cas (Case Studies)**
Structure : Défi → Solution → Résultats → Enseignements clés

**Contenu Meta (Coulisses)**
Transparence sur les coulisses. "Comment nous avons atteint nos premiers 5k $ de MRR", "Pourquoi nous avons choisi la dette plutôt que la levée de fonds".

### Formats générateurs de backlinks (Link-Earning)

Lorsque l'objectif d'un contenu est spécifiquement d'obtenir des backlinks, le choix du format compte davantage que l'effort de production. Le rapport *B2B Backlink Intelligence Report* de Foundation Inc. (mars 2026 — étude menée par un seul prestataire sur des sites SaaS B2B, à considérer comme indicative) a mesuré la part de backlinks obtenue par chaque format par rapport à sa part dans le volume total de pages :

| Format | Backlinks vs part de pages |
|---|---|
| Statistiques / synthèses de données | **4.25x** |
| Glossaires / pages de définitions | 1.47x |
| Outils interactifs / calculateurs (voir **free-tools**) | 1.38x |
| Guides pratiques / tutoriels (how-to) | 1.36x |
| Recherches originales / rapports d'études | 0.80x |
| Guides ultimes | 0.77x |
| Thought leadership | 0.74x |
| Modèles / frameworks | 0.68x |

La conclusion contre-intuitive : **agréger des statistiques génère environ 5 fois plus de liens que de produire une étude originale.** Les rédacteurs font des liens vers ce qui facilite le plus la citation : une page de statistiques mise à jour sert d'infrastructure de citation, tandis que la recherche originale est souvent citée *à travers* les synthèses qui la reprennent. Enseignements : (1) publiez une page de statistiques pour votre secteur et gardez-la à jour — c'est peu coûteux et les effets sont cumulatifs ; de plus, les statistiques percutantes en une ligne sont exactement ce que les LLM extraient, ce qui en fait un levier de visibilité IA (voir **ai-seo**) ; (2) lorsque vous menez une recherche originale, associez-la à votre propre page de synthèse de stats présentant les conclusions sous forme de phrases courtes faciles à citer, afin de capter les liens générés par vos données. Les formats en bas de tableau ne sont pas inutiles pour autant — les guides, modèles et contenus de thought leadership trouvent leur justification dans le positionnement SEO, les conversions et l'image de marque. Évaluez chaque contenu en fonction de la mission qui lui est assignée, et n'attendez pas de liens de formats qui n'en génèrent pas.

Pour exposer ces ressources aux personnes susceptibles de créer des liens, et orienter leur autorité vers les pages qui en ont besoin, voir **link-building**.

Pour le contenu programmatique à grande échelle, voir la compétence **programmatic-seo**.

---

## Piliers de contenu et clusters thématiques

Les piliers de contenu sont les 3 à 5 thématiques fondamentales que votre marque va s'approprier. Chaque pilier donne naissance à un cluster de contenus associés.

La plupart du temps, l'ensemble du contenu peut être regroupé sous `/blog` avec un bon maillage interne entre les articles connexes. Les pages piliers dédiées avec des structures d'URL personnalisées (comme `/guides/topic`) ne sont nécessaires que si vous construisez des ressources exhaustives comportant plusieurs niveaux de profondeur.

### Comment identifier les piliers

1. **Par le produit** : Quels problèmes votre produit résout-il ?
2. **Par l'audience** : Qu'est-ce que votre client idéal a besoin d'apprendre ?
3. **Par la recherche** : Quels sujets enregistrent du volume dans votre secteur ?
4. **Par la concurrence** : Sur quelles requêtes vos concurrents sont-ils positionnés ?

### Structure d'un pilier

```
Sujet pilier (Hub)
├── Cluster de sous-thèmes 1
│   ├── Article A
│   ├── Article B
│   └── Article C
├── Cluster de sous-thèmes 2
│   ├── Article D
│   ├── Article E
│   └── Article F
└── Cluster de sous-thèmes 3
    ├── Article G
    ├── Article H
    └── Article I
```

### Critères d'un bon pilier

Les bons piliers doivent :
- S'aligner avec votre produit/service
- Correspondre aux centres d'intérêt de votre audience
- Présenter un volume de recherche et/ou un intérêt sur les réseaux sociaux
- Être suffisamment larges pour couvrir de nombreux sous-thèmes

---

## Recherche de mots-clés selon l'étape du cycle d'achat

Associez les sujets au parcours de l'acheteur à l'aide de modificateurs de mots-clés éprouvés :

### Étape de sensibilisation (Awareness)
Modificateurs : "qu'est-ce que", "comment faire", "guide de", "introduction à"

Exemple : Si les clients posent des questions sur les bases de la gestion de projet :
- "Qu'est-ce que la gestion de projet Agile"
- "Guide du Sprint Planning"
- "Comment animer un Standup Meeting"

### Étape de considération (Consideration)
Modificateurs : "meilleur", "top", "vs", "alternatives", "comparatif"

Exemple : Si les clients évaluent plusieurs outils :
- "Meilleurs outils de gestion de projet pour équipes à distance"
- "Asana vs Trello vs Monday"
- "Alternatives à Basecamp"

### Étape de décision (Decision)
Modificateurs : "prix", "tarifs", "avis", "démo", "essai", "acheter"

Exemple : Si la tarification est abordée lors des appels commerciaux :
- "Comparatif des prix des outils de gestion de projet"
- "Comment choisir le bon forfait"
- "Avis sur [Produit]"

### Étape de mise en œuvre (Implementation)
Modificateurs : "modèles", "templates", "exemples", "tutoriel", "comment utiliser", "configuration"

Exemple : Si les tickets de support révèlent des difficultés de prise en main :
- "Bibliothèque de modèles de projets"
- "Tutoriel de configuration étape par étape"
- "Comment utiliser [Fonctionnalité]"

---

## Sources d'idéation de contenu

### 1. Données sur les mots-clés

Si l'utilisateur fournit des exports de mots-clés (Ahrefs, SEMrush, GSC), analysez-les pour identifier :
- Les clusters thématiques (regrouper les mots-clés associés)
- L'étape du cycle d'achat (sensibilisation / considération / décision / mise en œuvre)
- L'intention de recherche (informationnelle, commerciale, transactionnelle)
- Les gains rapides ou quick wins (faible concurrence + volume décent + forte pertinence)
- Les opportunités manquées (content gaps : mots-clés sur lesquels les concurrents se positionnent et pas vous)

Restituez le résultat sous forme de tableau priorisé :
| Mot-clé | Volume | Difficulté | Étape d'achat | Type de contenu | Priorité |

### 2. Transcriptions d'appels

Si l'utilisateur fournit des transcriptions d'appels commerciaux ou clients, extrayez :
- Les questions posées → Contenus de FAQ ou articles de blog
- Les points de douleur (pain points) → Les problèmes formulés avec leurs propres mots
- Les objections → Du contenu pour y répondre de manière proactive
- Les schémas de langage → Les expressions exactes à réutiliser (voix du client)
- Les mentions de concurrents → À quoi ils vous ont comparé

Proposez des idées de contenu appuyées par des citations.

### 3. Réponses aux enquêtes

Si l'utilisateur fournit des données d'enquêtes, explorez :
- Les réponses ouvertes (sujets et vocabulaire employé)
- Les thèmes récurrents (mentionnés par plus de 30 % = priorité élevée)
- Les demandes de ressources (ce qu'ils aimeraient voir exister)
- Les préférences de contenu (formats souhaités)

### 4. Recherche sur les forums

Utilisez la recherche web pour dénicher des idées de contenu :

**Reddit :** `site:reddit.com [sujet]`
- Publications populaires dans les subreddits pertinents
- Questions et frustrations exprimées dans les commentaires
- Réponses plébiscitées (valide ce qui résonne auprès du public)

**Quora :** `site:quora.com [sujet]`
- Questions les plus suivies
- Réponses les plus votées

**Autres :** Indie Hackers, Hacker News, Product Hunt, communautés Slack/Discord sectorielles

Extrayez : FAQ, idées reçues, débats, problèmes en cours de résolution, terminologie employée.

### 5. Analyse de la concurrence

Utilisez la recherche web pour analyser le contenu des concurrents :

**Trouver leur contenu :** `site:concurrent.com/blog`

**Analyser :**
- Les articles les plus performants (commentaires, partages)
- Les sujets traités de manière récurrente
- Les lacunes qu'ils n'ont pas encore abordées
- Les études de cas (problèmes clients, cas d'usage, résultats)
- La structure de leur contenu (piliers, catégories, formats)

**Identifier les opportunités :**
- Les sujets que vous pouvez traiter avec une qualité supérieure
- Les angles qu'ils ont négligés
- Les contenus obsolètes que vous pouvez améliorer et actualiser

### 6. Retours des ventes et du support

Recueillez auprès des équipes au contact direct des clients :
- Les objections fréquentes
- Les questions répétitives
- Les récurrences dans les tickets de support
- Les réussites clients (success stories)
- Les demandes de fonctionnalités et les problèmes sous-jacents

---

## Priorisation des idées de contenu

Notez chaque idée selon quatre critères :

### 1. Impact client (40 %)
- À quelle fréquence ce sujet est-il apparu dans la recherche ?
- Quel pourcentage de clients est confronté à ce défi ?
- Quelle est la charge émotionnelle associée à ce point de douleur ?
- Quelle est la LTV potentielle des clients exprimant ce besoin ?

### 2. Adéquation contenu-marché (Content-Market Fit) (30 %)
- Ce contenu est-il aligné avec les problèmes que votre produit résout ?
- Pouvez-vous apporter des insights uniques issus de vos recherches clients ?
- Disposez-vous de retours d'expérience clients pour appuyer le propos ?
- Ce contenu mènera-t-il naturellement à un intérêt pour le produit ?

### 3. Potentiel de recherche (20 %)
- Quel est le volume de recherche mensuel ?
- Quel est le niveau de concurrence sur ce sujet ?
- Existe-t-il des opportunités associées en longue traîne ?
- L'intérêt de recherche est-il en croissance ou en déclin ?

### 4. Ressources nécessaires (10 %)
- Avez-vous l'expertise interne pour créer un contenu de référence ?
- Quelles recherches complémentaires sont requises ?
- Quels éléments visuels ou supports (graphiques, données, exemples) seront nécessaires ?

### Modèle de notation

| Idée | Impact client (40 %) | Adéquation contenu-marché (30 %) | Potentiel de recherche (20 %) | Ressources (10 %) | Total |
|------|----------------------|----------------------------------|------------------------------|-------------------|-------|
| Sujet A | 8 | 9 | 7 | 6 | 8.0 |
| Sujet B | 6 | 7 | 9 | 8 | 7.1 |

Notez de 1 à 10 par critère, appliquez la pondération et additionnez pour obtenir le total. Classez la liste ; produisez en priorité les contenus ayant les meilleurs scores.

---

## Répartition du calendrier : 60/30/10

Équilibrez le calendrier éditorial pour que le trafic de recherche se capitalise dans le temps tout en conservant une visibilité active grâce aux contenus partageables :

- **60 % recherchable (searchable)** — la base. Une demande que vous captez de façon prévisible (cas d'usage, hub/spoke, tutoriels).
- **30 % partageable (shareable)** — thought leadership, données originales, points de vue tranchés. Crée la demande et génère des liens et des mentions.
- **10 % expérimental** — nouveaux formats, canaux émergents ou paris audacieux. Une assurance peu coûteuse pour éviter un mix éditorial figé.

Il s'agit d'un ratio indicatif de départ, pas d'une règle absolue. Un tout nouveau blog pourra surinvestir dans le contenu recherchable pour bâtir son socle ; une marque déjà bien installée cherchant à dominer sa catégorie pourra augmenter la part du partageable.

---

## Discipline d'exécution par format

Traiter le contenu comme un produit implique que chaque format réponde à un standard de production, et pas seulement à une thématique :

- **Article de blog** — rédigez **10 options de titres** avant d'entamer la rédaction (le titre accomplit l'essentiel du travail ; choisissez le plus percutant). Prévoyez **environ 5 passes de relecture** (structure, clarté, preuves, réécriture stylistique, titre/SEO). Pour la rédaction elle-même, voir **copywriting**.
- **Guide complet (long-form)** — la pièce maîtresse d'un pilier. Suffisamment exhaustif pour constituer *la* ressource de référence ; structuré avec une table des matières et des liens internes vers les spokes. Construisez le hub avant les spokes.
- **Vidéo** — scriptez l'accroche (hook) en premier ; placez la valeur ajoutée dès le début. Prévoyez les déclinaisons courtes (short-form) dès la phase de création (voir **social**).
- **Podcast** — une interview donne lieu à une transcription, des visuels de citations, des extraits courts et un résumé écrit. Concevez l'épisode en sachant d'avance qu'il sera atomisé.
- **E-mail** — une seule idée par envoi ; l'objet joue le rôle de titre : rédigez-en plusieurs et sélectionnez le meilleur. Pour les séquences et le cycle de vie, voir **emails**.

---

## Créer une fois, distribuer deux fois

Créer du contenu ne représente que la moitié du travail — la distribution constitue l'autre moitié, et la plupart des équipes la négligent. La philosophie : **un contenu exceptionnel, reformate et décliné sur chaque canal, plutôt qu'un nouveau contenu médiocre par plateforme.** Concentrer ses efforts sur une pièce maîtresse unique puis la distribuer partout surpasse largement la dispersion d'une énergie diluée sur une multitude de publications superficielles.

Intégrez les **leviers de distribution dès la création du contenu**, et non après coup : rédigez des sous-titres capables de fonctionner comme des posts autonomes sur les réseaux sociaux, structurez les sections pour qu'elles puissent être extraites de façon modulaire, et isolez les citations ou statistiques dont vous savez déjà qu'elles deviendront des infographies. Un guide bien pensé est en réalité un kit de distribution prêt à l'emploi.

**Le framework ORB comme entonnoir** — orientez l'attention de l'emprunté (Borrowed) vers le loué (Rented), puis vers le propriétaire (Owned), ce qui correspond à découverte → engagement → conversion :

- **Emprunté / Borrowed** (les audiences des autres : podcasts, articles invités, partenariats) — portée de rupture / phase de découverte.
- **Loué / Rented** (réseaux sociaux, réseaux publicitaires) — engagement, mais vous ne maîtrisez ni l'audience ni l'algorithme.
- **Propriétaire / Owned** (liste e-mail, blog, communauté privée) — conversion et seul actif durable. Tout ce qui se situe en amont doit converger ici.

Les mécanismes de l'ORB sont détaillés dans la compétence **launch** (playbook des types de canaux) et l'atomisation/recyclage de contenu est traitée dans **social** ; l'intérêt ici est de consolider le volet *distribution* de la stratégie de contenu pour lui donner un cadre structuré.

**Les pièges à éviter :**
- **Saupoudrage sans plan (Spray-and-pray)** — publier partout sans contenu phare ni plan de déclinaison. Les efforts se dispersent, rien ne capitalise.
- **Dépendance envers les plateformes** — bâtir sur un terrain loué. La portée organique de Facebook est passée d'environ 20 % à moins de 2 % ; n'importe quel canal loué peut brider votre visibilité du jour au lendemain.
- **Le paradoxe de la propriété** — les équipes consacrent près de 90 % de leurs efforts à des canaux qu'elles ne contrôlent pas (loués/empruntés) et délaissent les actifs propriétaires qui convertissent réellement et ne peuvent leur être retirés.

Pour retrouver l'ensemble de la structure de distribution — la roue de distribution de contenu (Content Distribution Flywheel), la durée de vie des publications par plateforme et la checklist d'atomisation —, consultez la référence ci-dessous.

---

## Format de restitution

Lors de l'élaboration d'une stratégie de contenu, fournissez :

### 1. Piliers de contenu
- 3 à 5 piliers argumentés
- Clusters de sous-thèmes pour chaque pilier
- Articulation entre les piliers et le produit

### 2. Sujets prioritaires
Pour chaque contenu recommandé :
- Sujet / titre
- Recherchable (searchable), partageable (shareable), ou les deux
- Type de contenu (cas d'usage, hub/spoke, thought leadership, etc.)
- Mot-clé ciblé et étape du cycle d'achat
- Justification du sujet (appuyée par la recherche client)

### 3. Schéma du cluster thématique
Représentation visuelle ou structurée des interconnexions entre les contenus.

---

## Questions spécifiques à la tâche

1. Quels schémas récurrents ressortent de vos 10 derniers échanges avec des clients ?
2. Quelles questions reviennent systématiquement lors des appels de vente ?
3. En quoi les initiatives de contenu de vos concurrents sont-elles insuffisantes ?
4. Quels enseignements uniques tirés de vos recherches clients ne sont partagés nulle part ailleurs ?
5. Quels contenus existants génèrent le plus de conversions, et pourquoi ?

---

## Références

- **[Content Distribution Spine](references/content-distribution.md)** : Create Once Distribute Twice, l'ORB comme entonnoir, le paradoxe de la propriété, durée de vie des plateformes, la Content Distribution Flywheel et la checklist d'atomisation par pièce maîtresse
- **[Headless CMS Guide](references/headless-cms.md)** : Sélection du CMS, modélisation de contenu pour le marketing, flux de travail éditoriaux, comparatif des plateformes (Sanity, Contentful, Strapi)

---

## Compétences associées

- **copywriting** : Pour la rédaction de contenus individuels
- **seo-audit** : Pour le SEO technique et l'optimisation on-page
- **link-building** : Pour obtenir des backlinks vers vos contenus et vers les pages qu'ils soutiennent
- **ai-seo** : Pour optimiser le contenu pour les moteurs de recherche IA et être cité par les LLM
- **programmatic-seo** : Pour la génération de contenu à grande échelle
- **site-architecture** : Pour la hiérarchie des pages, l'arborescence de navigation et la structure des URL
- **emails** : Pour les contenus diffusés par e-mail
- **social** : Pour le contenu sur les réseaux sociaux, l'atomisation et l'exécution du recyclage de contenu
- **launch** : Pour le playbook des types de canaux ORB et la distribution le jour du lancement
