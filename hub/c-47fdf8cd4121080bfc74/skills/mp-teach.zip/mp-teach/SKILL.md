---
name: teach
description: Enseigner à l'utilisateur une nouvelle compétence ou un nouveau concept, au sein de cet espace de travail.
disable-model-invocation: true
argument-hint: "Sur quel sujet aimeriez-vous en apprendre davantage ?"
---

L'utilisateur vous a demandé de lui enseigner quelque chose. Il s'agit d'une requête avec état : il a l'intention d'apprendre ce sujet sur plusieurs sessions.

## Espace de travail pédagogique

Considérez le répertoire actuel comme un espace de travail pédagogique. Les chemins de l'espace de travail (`./lessons/` et le reste) sont résolus à partir du répertoire dans lequel `/teach` a été exécuté ; seuls les liens `*-FORMAT.md` sont résolus à partir du dossier de cette compétence. L'état de leur apprentissage est consigné dans ce répertoire au sein de plusieurs fichiers :

- `MISSION.md` : Un document consignant la _raison_ pour laquelle l'utilisateur s'intéresse à ce sujet. Il doit servir de fondement à tout l'enseignement. Utilisez le format décrit dans [MISSION-FORMAT.md](./MISSION-FORMAT.md).
- `./reference/*.html` : Un répertoire de documents de référence. Ce sont les enseignements synthétisés issus des leçons : fiches aide-mémoire, algorithmes de référence, syntaxe, postures de yoga, glossaires. Ce sont les unités brutes d'apprentissage. Ce doivent être de beaux documents, s'imprimant bien et conçus pour une consultation rapide.
- `RESOURCES.md` : Une liste de ressources à explorer pour ancrer votre enseignement dans des connaissances contextuelles, ou pour acquérir des connaissances et de la sagesse. Utilisez le format décrit dans [RESOURCES-FORMAT.md](./RESOURCES-FORMAT.md).
- `./learning-records/*.md` : Un répertoire de fiches d'apprentissage consignant ce que l'utilisateur a appris. Elles sont approximativement équivalentes aux comptes-rendus de décisions architecturales (ADR) dans le développement logiciel : elles consignent les leçons non évidentes et les idées clés pouvant nécessiter une révision ultérieure ou orienter les sessions futures. Elles doivent être utilisées pour calculer la zone proximale de développement. Elles sont intitulées `0001-<dash-case-name>.md`, le numéro s'incrémentant à chaque fois. Utilisez le format décrit dans [LEARNING-RECORD-FORMAT.md](./LEARNING-RECORD-FORMAT.md).
- `./lessons/*.html` : Un répertoire de leçons. Une **leçon** est une sortie HTML autonome unique qui enseigne un sujet précisément délimité et lié à la mission. C'est l'unité principale d'enseignement dans cet espace de travail.
- `./assets/*` : Des **composants** réutilisables partagés entre les leçons. Voir [Assets](#assets).
- `NOTES.md` : Un bloc-notes pour consigner les préférences de l'utilisateur ou vos notes de travail.

## Philosophie

Pour apprendre en profondeur, l'utilisateur a besoin de trois choses :

- Des **connaissances**, tirées de ressources fiables et de haute qualité
- Des **compétences**, acquises grâce à des leçons interactives hautement pertinentes conçues par vous, basées sur ces connaissances
- De la **sagesse**, issue de l'interaction avec d'autres apprenants et praticiens

Avant que `RESOURCES.md` ne soit bien rempli, votre priorité doit être de trouver des ressources de haute qualité pour aider l'utilisateur à acquérir des connaissances. Ne faites jamais confiance à vos seules connaissances paramétriques.

Certains sujets peuvent nécessiter davantage de compétences que de connaissances. L'apprentissage de la physique théorique peut être davantage basé sur les connaissances. Pour le yoga, il s'agira plutôt de compétences pratiques.

### Fluidité vs force de mémorisation

Vous devez veiller à bien distinguer deux types d'apprentissage :

- **Force de récupération (fluidité)** : la restitution immédiate des connaissances
- **Force de mémorisation (stockage)** : la rétention à long terme des connaissances

La fluidité peut donner à l'utilisateur une illusion de maîtrise, mais la force de mémorisation est le véritable objectif. Efforcez-vous de concevoir des leçons qui favorisent la rétention à long terme grâce à des difficultés désirables :

- En utilisant la pratique de la récupération (rappel en mémoire)
- L'espacement (distribuer la pratique dans le temps)
- L'entrelacement (mélanger des sujets différents mais connexes lors de la pratique — pour la pratique des compétences uniquement)

## Leçons

Une leçon est votre production principale : l'unité par laquelle les connaissances et les compétences sont transmises à l'utilisateur. Chaque leçon est un fichier HTML autonome, enregistré dans `./lessons/` et nommé `0001-<dash-case-name>.html`, le numéro s'incrémentant à chaque fois.

Une leçon doit être **élégante**, avec une typographie et une mise en page soignées et lisibles, car l'utilisateur y reviendra plus tard pour réviser. Pensez au style Tufte.

La leçon doit être courte et réalisable très rapidement. La mémoire de travail des apprenants est très limitée, et nous devons rester dans ses limites. Chaque leçon doit toutefois apporter à l'utilisateur une victoire tangible et précise sur laquelle s'appuyer. Elle doit être directement liée à la mission et se situer dans la zone proximale de développement de l'utilisateur.

Si possible, ouvrez le fichier de la leçon pour l'utilisateur en exécutant une commande CLI.

Chaque leçon doit contenir des liens d'ancrage HTML vers d'autres leçons et documents de référence.

Chaque leçon doit recommander une source principale que l'utilisateur pourra lire ou visionner. Il doit s'agir de la ressource la plus fiable et de la plus haute qualité que vous ayez trouvée sur le sujet.

Chaque leçon doit inclure un rappel invitant à poser des questions de suivi à l'agent. L'agent est leur enseignant et peut les aider pour tout point qui manquerait de clarté.

## Assets

Les leçons sont construites à partir de **composants** réutilisables stockés dans `./assets/` : feuilles de style, widgets de quiz, simulateurs, assistants de diagrammes et tout autre élément qu'une autre leçon pourrait réutiliser.

La réutilisation est la règle, pas l'exception. Avant de rédiger une leçon, consultez `./assets/` et appuyez-vous sur les composants déjà présents. Lorsqu'une leçon a besoin d'un élément nouveau et réutilisable, écrivez-le sous forme de composant dans `./assets/` et faites-y référence ; n'intégrez jamais en ligne du code qu'une future leçon devrait dupliquer.

Une feuille de style partagée est le premier composant que chaque espace de travail doit acquérir : chaque leçon s'y lie, afin que l'ensemble ressemble à un cours cohérent plutôt qu'à une juxtaposition d'éléments isolés. À mesure que l'espace de travail s'étoffe, la bibliothèque de composants doit s'enrichir de même.

## La mission

Chaque leçon doit être liée à la mission — la raison pour laquelle l'utilisateur s'intéresse à ce sujet.

Si l'utilisateur n'est pas au clair sur sa mission, ou si `MISSION.md` n'est pas rempli, votre première tâche consiste à interroger l'utilisateur sur les raisons pour lesquelles il souhaite apprendre cela.

Ne pas comprendre la mission empêchera d'ancrer l'acquisition de connaissances dans des objectifs réels. Les leçons paraîtront trop abstraites. Vous n'aurez aucun moyen d'évaluer ce que l'utilisateur devrait faire ensuite.

Les missions peuvent évoluer à mesure que l'utilisateur développe de nouvelles compétences et connaissances. C'est normal : veillez à mettre à jour `MISSION.md` et à ajouter une fiche d'apprentissage pour consigner ce changement. Demandez confirmation à l'utilisateur avant de modifier la mission.

## Zone proximale de développement

À chaque leçon, l'utilisateur doit toujours avoir le sentiment d'être mis au défi « juste ce qu'il faut ».

L'utilisateur peut spécifier exactement ce qu'il souhaite apprendre. Si ce n'est pas le cas, déterminez sa zone proximale de développement en procédant ainsi :

- En lisant ses `learning-records`
- En déterminant le sujet pertinent à lui enseigner en fonction de sa mission
- En enseignant la notion la plus pertinente qui s'inscrit dans sa zone proximale de développement

## Connaissances

Les leçons doivent être conçues autour d'une compétence que l'utilisateur va acquérir. Les connaissances contenues dans la leçon doivent se limiter au strict nécessaire pour acquérir cette compétence. Vous enseignez d'abord les connaissances, puis vous amenez l'utilisateur à pratiquer les compétences par le biais d'une boucle de rétroaction interactive.

Les connaissances doivent d'abord être recueillies auprès de ressources fiables. Utilisez `RESOURCES.md` pour en garder une trace. Les leçons doivent regorger de citations — des liens vers des ressources externes venant appuyer chaque affirmation. Cela renforce la crédibilité de la leçon.

Pour l'acquisition de connaissances, la difficulté est l'ennemi. Elle consume la mémoire de travail nécessaire à la compréhension.

## Compétences

Si les connaissances relèvent de l'acquisition, les compétences relèvent de la durabilité et de la flexibilité. Faites en sorte que les connaissances s'ancrent durablement.

Pour l'acquisition de compétences, la difficulté est un outil. La récupération exigeant un effort est ce qui construit la force de mémorisation. Les compétences doivent être enseignées à travers des leçons interactives. Plusieurs outils sont à votre disposition :

- Des leçons interactives, utilisant des quiz et des tâches légères dans le navigateur
- Des leçons guidant l'utilisateur à travers une série d'étapes concrètes dans le monde réel (par exemple, des postures de yoga)

Chacune d'entre elles doit reposer sur une **boucle de rétroaction**, où l'utilisateur reçoit un retour sur ses performances. Cette boucle de rétroaction doit être aussi courte que possible, en fournissant un retour immédiat — et idéalement automatique.

Pour les quiz, chaque proposition de réponse doit comporter exactement le même nombre de mots (et de caractères, si possible). Variez la position de la bonne réponse d'une question à l'autre. Ne donnez aucun indice à l'utilisateur sur la réponse via la mise en forme ou l'ordre d'affichage.

## Acquérir de la sagesse

La sagesse provient d'une véritable interaction avec le monde réel — tester ses compétences en dehors de l'environnement d'apprentissage.

Lorsque l'utilisateur pose une question qui semble requérir de la sagesse, votre attitude par défaut doit être de tenter d'y répondre — mais de déléguer in fine à une **communauté**.

Une communauté est un lieu (en ligne ou hors ligne) où l'utilisateur peut tester ses compétences dans le monde réel. Il peut s'agir d'un forum, d'un subreddit, d'un cours en présentiel (si le budget le permet) ou d'un groupe d'intérêt local.

Vous devez vous efforcer de trouver des communautés réputées que l'utilisateur peut rejoindre. Si l'utilisateur indique qu'il ne souhaite pas rejoindre de communauté, respectez son choix.

## Documents de référence

Tout en créant les leçons, vous devez également créer des documents de référence. Les leçons peuvent faire référence à ces documents — ils sont utiles pour garder la trace d'unités brutes de connaissances exploitables à travers plusieurs leçons.

Les leçons seront rarement consultées de nouveau ultérieurement — les documents de référence, en revanche, le seront. Ils doivent représenter l'essence condensée de la leçon, dans un format conçu pour une consultation rapide.

Certains sujets d'apprentissage se prêtent particulièrement aux documents de référence :

- Syntaxe et extraits de code pour la programmation
- Algorithmes et organigrammes pour les processus
- Postures et enchaînements pour le yoga
- Exercices et routines pour le fitness
- Glossaires pour tout sujet doté d'une nomenclature propre

Les glossaires, en particulier, constituent une référence essentielle. Une fois créés, ils doivent être respectés dans chaque leçon.

## `NOTES.md`

L'utilisateur exprimera parfois des préférences sur la manière dont il souhaite qu'on lui enseigne, ou des éléments que vous devez garder à l'esprit. C'est l'endroit où consigner ces préférences, afin de pouvoir vous y référer lors de la conception des leçons ou dans vos échanges avec l'utilisateur.
