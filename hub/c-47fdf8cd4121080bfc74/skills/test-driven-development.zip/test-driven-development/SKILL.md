---
name: test-driven-development
description: À utiliser lors de l'implémentation de toute fonctionnalité ou correction de bug, avant d'écrire le code d'implémentation
---

# Test-Driven Development (TDD)

## Vue d'ensemble

Écrivez le test d'abord. Regardez-le échouer. Écrivez le code minimal pour qu'il réussisse.

**Principe fondamental :** Si vous n'avez pas vu le test échouer, vous ne savez pas s'il teste la bonne chose.

**Violer la lettre des règles, c'est violer l'esprit des règles.**

## Quand l'utiliser

**Toujours :**
- Nouvelles fonctionnalités
- Corrections de bugs
- Refactorisation
- Changements de comportement

**Exceptions (demandez à votre partenaire humain) :**
- Prototypes jetables
- Code généré
- Fichiers de configuration

Vous pensez « ignorer le TDD juste pour cette fois » ? Arrêtez. C'est une rationalisation.

## La règle d'airain

```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

Vous avez écrit du code avant le test ? Supprimez-le. Recommencez.

**Aucune exception :**
- Ne le gardez pas comme « référence »
- Ne l'« adaptez » pas pendant l'écriture des tests
- Ne le regardez pas
- Supprimer signifie supprimer

Implémentez de zéro à partir des tests. Point final.

## Red-Green-Refactor

```dot
digraph tdd_cycle {
    rankdir=LR;
    red [label="RED\nWrite failing test", shape=box, style=filled, fillcolor="#ffcccc"];
    verify_red [label="Verify fails\ncorrectly", shape=diamond];
    green [label="GREEN\nMinimal code", shape=box, style=filled, fillcolor="#ccffcc"];
    verify_green [label="Verify passes\nAll green", shape=diamond];
    refactor [label="REFACTOR\nClean up", shape=box, style=filled, fillcolor="#ccccff"];
    next [label="Next", shape=ellipse];

    red -> verify_red;
    verify_red -> green [label="yes"];
    verify_red -> red [label="wrong\nfailure"];
    green -> verify_green;
    verify_green -> refactor [label="yes"];
    verify_green -> green [label="no"];
    refactor -> verify_green [label="stay\ngreen"];
    verify_green -> next;
    next -> red;
}
```

### RED - Écrire un test qui échoue

Écrivez un test minimal montrant ce qui devrait se passer.

<Good>
```typescript
test('retries failed operations 3 times', async () => {
  let attempts = 0;
  const operation = () => {
    attempts++;
    if (attempts < 3) throw new Error('fail');
    return 'success';
  };

  const result = await retryOperation(operation);

  expect(result).toBe('success');
  expect(attempts).toBe(3);
});
```
Nom clair, teste un comportement réel, une seule chose
</Good>

<Bad>
```typescript
test('retry works', async () => {
  const mock = jest.fn()
    .mockRejectedValueOnce(new Error())
    .mockRejectedValueOnce(new Error())
    .mockResolvedValueOnce('success');
  await retryOperation(mock);
  expect(mock).toHaveBeenCalledTimes(3);
});
```
Nom vague, teste le mock et non le code
</Bad>

**Exigences :**
- Un seul comportement
- Un nom clair
- Du vrai code (aucun mock sauf si inévitable)

### Vérifier RED - Le regarder échouer

**OBLIGATOIRE. Ne sautez jamais cette étape.**

```bash
npm test path/to/test.test.ts
```

Vérifiez que :
- Le test échoue (sans générer d'erreur d'exécution)
- Le message d'échec est celui attendu
- L'échec est dû à la fonctionnalité manquante (pas à des fautes de frappe)

**Le test passe ?** Vous testez un comportement existant. Corrigez le test.

**Le test génère une erreur ?** Corrigez l'erreur, relancez jusqu'à ce qu'il échoue correctement.

### GREEN - Code minimal

Écrivez le code le plus simple pour faire passer le test.

<Good>
```typescript
async function retryOperation<T>(fn: () => Promise<T>): Promise<T> {
  for (let i = 0; i < 3; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i === 2) throw e;
    }
  }
  throw new Error('unreachable');
}
```
Juste assez pour passer
</Good>

<Bad>
```typescript
async function retryOperation<T>(
  fn: () => Promise<T>,
  options?: {
    maxRetries?: number;
    backoff?: 'linear' | 'exponential';
    onRetry?: (attempt: number) => void;
  }
): Promise<T> {
  // YAGNI
}
```
Surconçu
</Bad>

N'ajoutez pas de fonctionnalités, ne refactorisez pas d'autre code et n'« améliorez » rien au-delà de ce que demande le test.

### Vérifier GREEN - Le regarder passer

**OBLIGATOIRE.**

```bash
npm test path/to/test.test.ts
```

Vérifiez que :
- Le test passe
- Les autres tests passent toujours
- La sortie est impeccable (pas d'erreurs, pas d'avertissements)

**Le test échoue ?** Corrigez le code, pas le test.

**D'autres tests échouent ?** Corrigez-les immédiatement.

**« Les autres tests » désignent l'ensemble de la suite du projet, pas seulement votre fichier.** Un passage au vert du test que vous avez écrit ne signifie pas que la suite est au vert. Avant de considérer la modification comme terminée, exécutez la commande de test du projet (`pytest`, `npm test`, `cargo test` sans argument — peu importe ce que le dépôt utilise), même si votre tâche ne mentionnait qu'un seul fichier de test. La définition du périmètre de votre tâche limite le livrable, pas votre vérification. Tout échec révélé par cette exécution — y compris un échec que vous n'avez pas causé — doit figurer dans votre rapport avec son nom ; un test rouge que vous avez vu défiler sans le mentionner constitue un rapport falsifié par omission.

### REFACTOR - Nettoyer

Uniquement après être passé au vert :
- Supprimez la duplication
- Améliorez les noms
- Extrayez des fonctions d'aide

Gardez les tests au vert. N'ajoutez aucun comportement.

### Répéter

Test suivant qui échoue pour la fonctionnalité suivante.

## De bons tests

| Qualité | Bon | Mauvais |
|---------|-----|---------|
| **Minimal** | Une seule chose. Un « et » dans le nom ? Séparez-le. | `test('validates email and domain and whitespace')` |
| **Clair** | Le nom décrit le comportement | `test('test1')` |
| **Exprime l'intention** | Démontre l'API souhaitée | Masque ce que le code devrait faire |

Lors de l'écriture ou de la modification d'un test, consultez [writing-good-tests.md](writing-good-tests.md) pour connaître les règles qui garantissent l'intégrité des tests :
- Nommez le changement en production qui ferait échouer le test — avant de l'écrire
- Faites des assertions sur le comportement réel, jamais sur le comportement d'un mock
- Gardez le code réservé aux tests dans des utilitaires de test, en dehors des classes de production
- Comprenez les effets de bord d'une dépendance avant de la mocker

## Rationalisations courantes

| Excuse | Réalité |
|--------|---------|
| « Trop simple pour être testé » | Le code simple casse aussi. Le test prend 30 secondes. |
| « Je testerai après » | Les tests écrits après passent immédiatement — ce qui ne prouve rien. Ils peuvent tester la mauvaise chose, tester l'implémentation au lieu du comportement, ou manquer le cas limite que vous avez oublié. Vous ne l'avez jamais vu échouer, donc vous n'avez jamais prouvé qu'il peut détecter le bug. Écrire le test en premier force cet échec. |
| « Les tests après coup atteignent le même objectif (l'esprit, pas le rituel) » | Les tests écrits après répondent à « que fait ceci ? » ; les tests écrits avant répondent à « que devrait faire ceci ? ». Les tests écrits après sont biaisés par le code que vous avez déjà écrit — vous vérifiez les cas auxquels vous avez pensé, pas ceux que vous auriez découverts. C'est de la couverture sans preuve que les tests fonctionnent. |
| « Déjà testé manuellement » | Le test manuel est ad hoc : aucune trace de ce que vous avez couvert, aucun moyen de le rejouer quand le code change, risque d'oublier des cas sous la pression. « Ça fonctionnait quand j'ai essayé » ≠ exhaustif. Les tests automatisés s'exécutent de la même façon à chaque fois. |
| « Supprimer X heures de travail est un gâchis » | Biais des coûts irrécupérables — ce temps est déjà perdu dans tous les cas. Le vrai choix : réécrire avec le TDD (confiance élevée) contre garder le code et y greffer des tests après coup (faible confiance, bugs probables). Conserver du code auquel vous ne pouvez pas faire confiance, voilà le véritable gâchis. |
| « Le garder comme référence, écrire les tests d'abord » | Vous allez l'adapter. C'est du test après coup. Supprimer signifie supprimer. |
| « Besoin d'explorer d'abord » | Très bien. Jetez le code exploratoire, repartez avec le TDD. |
| « Test difficile = conception floue » | Écoutez le test. Difficile à tester = difficile à utiliser. |
| « Le TDD va me ralentir » | Le TDD EST la voie pragmatique : il intercepte les bugs avant le commit, prévient les régressions, vous permet de refactoriser sans crainte. Les raccourcis « pragmatiques » mènent au débogage en production — c'est plus lent, pas plus rapide. |
| « Le test manuel est plus rapide » | Le manuel ne valide pas les cas limites. Vous devrez tout retester à chaque modification. |
| « Le code existant n'a pas de tests » | Vous êtes en train de l'améliorer. Ajoutez des tests pour le code existant. |

## Signaux d'alerte - ARRÊTEZ et recommencez

- Code avant le test
- Test après l'implémentation
- Le test passe immédiatement
- Impossible d'expliquer pourquoi le test a échoué
- Tests ajoutés « plus tard »
- Rationalisation : « juste pour cette fois »
- « Je l'ai déjà testé manuellement »
- « Les tests après coup remplissent le même rôle »
- « C'est une question d'esprit, pas de rituel »
- « Garder comme référence » ou « adapter le code existant »
- « Déjà passé X heures dessus, supprimer est un gâchis »
- « Le TDD est dogmatique, je suis pragmatique »
- « C'est différent parce que... »

**Tout cela signifie : Supprimez le code. Recommencez avec le TDD.**

## Exemple : Correction de bug

**Bug :** Adresse e-mail vide acceptée

**RED**
```typescript
test('rejects empty email', async () => {
  const result = await submitForm({ email: '' });
  expect(result.error).toBe('Email required');
});
```

**Vérifier RED**
```bash
$ npm test
FAIL: expected 'Email required', got undefined
```

**GREEN**
```typescript
function submitForm(data: FormData) {
  if (!data.email?.trim()) {
    return { error: 'Email required' };
  }
  // ...
}
```

**Vérifier GREEN**
```bash
$ npm test
PASS
```

**REFACTOR**
Extraire la validation pour plusieurs champs si nécessaire.

## Liste de vérification

Avant de marquer le travail comme terminé :

- [ ] Chaque nouvelle fonction/méthode a un test
- [ ] A vu chaque test échouer avant l'implémentation
- [ ] Chaque test a échoué pour la raison attendue (fonctionnalité manquante, pas une faute de frappe)
- [ ] A écrit le code minimal pour faire passer chaque test
- [ ] Tous les tests passent
- [ ] La sortie est impeccable (pas d'erreurs, pas d'avertissements)
- [ ] Les tests utilisent du vrai code (mocks uniquement si inévitable)
- [ ] Les cas limites et les erreurs sont couverts

Vous ne pouvez pas cocher toutes les cases ? Vous avez sauté le TDD. Recommencez.

## En cas de blocage

| Problème | Solution |
|----------|----------|
| Vous ne savez pas comment tester | Écrivez l'API idéale souhaitée. Écrivez l'assertion en premier. Demandez à votre partenaire humain. |
| Test trop compliqué | Conception trop compliquée. Simplifiez l'interface. |
| Obligé de tout mocker | Code trop couplé. Utilisez l'injection de dépendances. |
| Configuration de test énorme | Extrayez des fonctions d'aide. Toujours complexe ? Simplifiez la conception. |

## Intégration lors du débogage

Bug détecté ? Écrivez un test qui échoue en le reproduisant. Suivez le cycle TDD. Le test prouve la correction et prévient les régressions.

Ne corrigez jamais de bugs sans un test.

## Règle finale

```
Production code → test exists and failed first
Otherwise → not TDD
```

Aucune exception sans la permission de votre partenaire humain.
