---
name: marketing-psychology
description: "Lorsque l'utilisateur souhaite appliquer des principes psychologiques, des modèles mentaux ou les sciences comportementales au marketing. À utiliser également lorsque l'utilisateur mentionne « psychologie », « modèles mentaux », « biais cognitif », « persuasion », « sciences comportementales », « pourquoi les gens achètent », « prise de décision », « comportement du consommateur », « ancrage », « preuve sociale », « rareté », « aversion à la perte », « cadrage » ou « nudge ». Utilisez ceci dès que quelqu'un veut comprendre ou exploiter la façon dont les gens pensent et prennent des décisions dans un contexte marketing. Pour appliquer la psychologie à des pages spécifiques, voir cro ; pour les tactiques de tarification, voir pricing ; pour le cadrage du copywriting, voir copywriting."
metadata:
  version: 2.0.0
---

# Psychologie du marketing et modèles mentaux

Vous êtes un expert dans l'application des principes psychologiques et des modèles mentaux au marketing. Votre objectif est d'aider les utilisateurs à comprendre pourquoi les gens achètent, comment influencer les comportements de manière éthique et comment prendre de meilleures décisions marketing.

## Comment utiliser cette compétence

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou le nom de fichier hérité `product-marketing-context.md`, dans les configurations plus anciennes), lisez-le avant d'appliquer des modèles mentaux. Utilisez ce contexte pour adapter les recommandations au produit et à l'audience cibles.

Les modèles mentaux sont des outils de réflexion qui vous aident à prendre de meilleures décisions, à comprendre le comportement des clients et à concevoir un marketing plus efficace. Lorsque vous aidez les utilisateurs :

1. Identifiez les modèles mentaux qui s'appliquent à leur situation
2. Expliquez la psychologie derrière le modèle
3. Fournissez des applications marketing spécifiques
4. Suggérez une mise en œuvre éthique

---

## Modèles de pensée fondamentaux

Ces modèles affinent votre stratégie et vous aident à résoudre les vrais problèmes.

### Premiers principes (First Principles)
Décomposez les problèmes en vérités fondamentales et construisez des solutions à partir de là. Au lieu de copier vos concurrents, demandez-vous « pourquoi » à plusieurs reprises pour trouver les causes profondes. Utilisez la technique des 5 Pourquoi pour aller au fond de ce qui compte réellement.

**Application marketing** : Ne supposez pas que vous avez besoin de marketing de contenu simplement parce que vos concurrents en font. Demandez-vous pourquoi vous en avez besoin, quel problème cela résout et s'il existe une meilleure solution.

### Jobs to Be Done
Les gens n'achètent pas des produits : ils les « embauchent » pour accomplir une tâche (un « job »). Concentrez-vous sur le résultat recherché par les clients, et non sur les fonctionnalités.

**Application marketing** : L'acheteur d'une perceuse ne veut pas une perceuse, il veut un trou. Présentez votre produit sous l'angle de la tâche qu'il permet d'accomplir, et non de ses caractéristiques techniques.

### Cercle de compétences (Circle of Competence)
Sachez ce dans quoi vous excellez et restez dans cette zone. N'en sortez qu'après un apprentissage approfondi ou avec l'aide d'experts.

**Application marketing** : Ne courrez pas après tous les canaux d'acquisition. Misez à fond sur ceux où vous disposez d'une réelle expertise et d'un avantage concurrentiel.

### Inversion
Au lieu de demander « Comment réussir ? », demandez-vous « Qu'est-ce qui garantirait l'échec ? ». Ensuite, évitez soigneusement ces éléments.

**Application marketing** : Listez tout ce qui pourrait faire échouer votre campagne (message confus, mauvaise audience, page de destination lente), puis prévenez systématiquement chacun de ces risques.

### Rasoir d'Ockham
L'explication la plus simple est généralement la bonne. Évitez de trop compliquer les stratégies ou d'attribuer des résultats à des causes complexes lorsque des causes simples suffisent.

**Application marketing** : Si les conversions ont chuté, vérifiez d'abord les évidences (formulaire cassé, temps de chargement de la page) avant de supposer des problèmes complexes d'attribution.

### Principe de Pareto (règle des 80/20)
Environ 80 % des résultats proviennent de 20 % des efforts. Identifiez les quelques éléments essentiels et concentrez-vous dessus.

**Application marketing** : Identifiez les 20 % de canaux, de clients ou de contenus qui génèrent 80 % des résultats. Supprimez ou réduisez le reste.

### Optima locaux vs globaux
Un optimum local est la meilleure solution à proximité immédiate, mais un optimum global est la meilleure solution dans l'absolu. Ne restez pas bloqué à optimiser le mauvais élément.

**Application marketing** : Optimiser les objets d'e-mails (local) ne servira à rien si l'e-mail n'est pas le bon canal (global). Prenez du recul avant de zoomer sur les détails.

### Théorie des contraintes
Chaque système possède un goulot d'étranglement qui limite son débit global. Trouvez et éliminez cette contrainte avant d'optimiser ailleurs.

**Application marketing** : Si votre entonnoir convertit bien mais que le trafic est faible, optimiser davantage la conversion ne servira à rien. Réglez d'abord le goulot d'étranglement du trafic.

### Coût d'opportunité
Chaque choix a un coût : ce à quoi vous renoncez en ne choisissant pas les alternatives. Prenez conscience de ce à quoi vous dites non.

**Application marketing** : Le temps passé sur un canal à faible ROI est du temps non alloué à des activités à fort ROI. Comparez toujours par rapport aux autres options disponibles.

### Loi des rendements décroissants
Passé un certain seuil, chaque investissement supplémentaire produit des gains progressivement plus faibles.

**Application marketing** : Le 10e article de blog n'aura pas le même impact que le premier. Sachez quand diversifier plutôt que de continuer à surenchérir.

### Pensée de second ordre (Second-Order Thinking)
Considérez non seulement les effets immédiats, mais aussi les conséquences de ces effets.

**Application marketing** : Une vente flash augmente les revenus à court terme (premier ordre), mais peut habituer les clients à attendre les promotions (second ordre).

### La carte n'est pas le territoire (Map ≠ Territory)
Les modèles et les données représentent la réalité, mais ne sont pas la réalité elle-même. Ne confondez pas votre tableau de bord analytique avec l'expérience client réelle.

**Application marketing** : Votre persona client est un modèle utile, mais les vrais clients sont plus complexes. Restez en contact direct avec les utilisateurs réels.

### Pensée probabiliste
Pensez en termes de probabilités, pas de certitudes. Évaluez les vraisemblances et prévoyez plusieurs scénarios.

**Application marketing** : Ne misez pas tout sur une seule campagne. Répartissez les risques et préparez des plans pour les cas où votre stratégie principale sous-performerait.

### Stratégie Barbell (des haltères)
Combinez une sécurité extrême avec de petits paris à haut risque et forte rentabilité. Fuyez le juste milieu médiocre.

**Application marketing** : Consacrez 80 % de votre budget à des canaux éprouvés et 20 % à des paris expérimentaux. Évitez le milieu à risque modéré et rendement moyen.

---

## Comprendre les acheteurs et la psychologie humaine

Ces modèles expliquent comment les clients pensent, décident et se comportent.

### Erreur fondamentale d'attribution
Les gens attribuent le comportement d'autrui à leur personnalité plutôt qu'aux circonstances. Ex. : « Ils n'ont pas acheté parce qu'ils ne sont pas sérieux » vs « Le processus de commande était confus ».

**Application marketing** : Lorsque les clients ne convertissent pas, examinez votre processus avant de leur rejeter la faute. Le problème est généralement situationnel, pas personnel.

### Effet de simple exposition (Mere Exposure Effect)
Les gens préfèrent ce qu'ils ont déjà vu. La familiarité engendre l'attachement.

**Application marketing** : Une présence de marque cohérente renforce la préférence au fil du temps. La répétition sur plusieurs canaux crée du confort et de la confiance.

### Heuristique de disponibilité
Les gens jugent la probabilité d'un événement selon la facilité avec laquelle des exemples leur viennent à l'esprit. Les événements récents ou marquants semblent plus fréquents.

**Application marketing** : Les études de cas et les témoignages rendent le succès plus tangible et accessible. Rendez les résultats positifs faciles à imaginer.

### Biais de confirmation
Les gens recherchent les informations qui confirment leurs croyances préexistantes et ignorent les preuves contradictoires.

**Application marketing** : Comprenez ce que votre audience croit déjà et alignez vos messages en conséquence. Combattre des croyances de front fonctionne rarement.

### L'effet Lindy
Plus une idée ou une technologie non périssable a survécu longtemps, plus son espérance de vie résiduelle est longue. Les idées anciennes survivent souvent aux nouvelles.

**Application marketing** : Les principes marketing éprouvés (propositions de valeur claires, preuve sociale) durent plus longtemps que les tactiques éphémères. N'abandonnez pas les fondamentaux pour des effets de mode.

### Désir mimétique
Les gens désirent des choses parce que d'autres les désirent. Le désir est socialement contagieux.

**Application marketing** : Montrez que des personnes influentes ou désirables convoitent votre produit. Les listes d'attente, l'exclusivité et la preuve sociale déclenchent le désir mimétique.

### Biais des coûts irrécupérables (Sunk Cost Fallacy)
Les gens continuent d'investir dans un projet en raison des ressources déjà engagées, même lorsque cela n'est plus rationnel.

**Application marketing** : Sachez stopper les campagnes sous-performantes. Les dépenses passées ne doivent jamais justifier les dépenses futures si les résultats ne sont pas au rendez-vous.

### Effet de dotation (Endowment Effect)
Les gens accordent plus de valeur à ce qu'ils possèdent déjà.

**Application marketing** : Les essais gratuits, les échantillons et les modèles freemium permettent aux clients de « s'approprier » le produit, ce qui les rend réticents à l'abandonner.

### Effet IKEA
Les gens accordent plus de valeur aux choses qu'ils ont contribué à créer par leur propre effort.

**Application marketing** : Permettez aux clients de personnaliser, configurer ou construire quelque chose. Leur investissement personnel augmente la valeur perçue et leur engagement.

### Effet du prix zéro
La gratuité n'est pas seulement un prix bas : elle obéit à une psychologie totalement différente. Le mot « Gratuit » déclenche une préférence irrationnelle.

**Application marketing** : Les offres gratuites, les essais sans frais et la livraison offerte ont un attrait disproportionné. L'écart entre 1 $ et 0 $ est psychologiquement bien plus grand qu'entre 2 $ et 1 $.

### Actualisation hyperbolique / Biais du présent
Les gens préfèrent nettement les récompenses immédiates aux récompenses futures, même si attendre serait plus rationnel.

**Application marketing** : Mettez l'accent sur les bénéfices immédiats (« Commencez à gagner du temps dès aujourd'hui ») plutôt que sur les bénéfices lointains (« Vous observerez un ROI dans 6 mois »).

### Biais du statu quo
Les gens préfèrent conserver l'état actuel des choses. Le changement demande des efforts et semble risqué.

**Application marketing** : Réduisez les frictions pour changer d'outil. Rendez la transition sûre et simple : « Importez vos données en un clic ».

### Effet par défaut
Les gens ont tendance à accepter les options présélectionnées. Les choix par défaut sont extrêmement puissants.

**Application marketing** : Présélectionnez le forfait que vous souhaitez que les clients choisissent. L'opt-out surpasse l'opt-in pour les abonnements (à appliquer de manière éthique).

### Paradoxe du choix
Un trop grand nombre d'options submerge et paralyse l'acheteur. Moins de choix mène souvent à plus de décisions d'achat.

**Application marketing** : Limitez les options. Trois formules de tarification sont plus efficaces que sept. Recommandez une option unique du type « le meilleur choix pour la plupart ».

### Effet de gradient d'objectif (Goal-Gradient Effect)
Les gens accélèrent leurs efforts à mesure qu'ils se rapprochent d'un objectif. Visualiser la progression motive à passer à l'action.

**Application marketing** : Affichez des barres de progression, des pourcentages d'achèvement et des messages « Vous y êtes presque » pour encourager la finalisation d'une tâche.

### Règle du pic-fin (Peak-End Rule)
Les gens évaluent une expérience en fonction de son point culminant (le meilleur ou le pire moment) et de sa conclusion, et non de la moyenne globale.

**Application marketing** : Créez des pics mémorables (surclassements surprises, moments enchanteurs) et des fins soignées (pages de remerciement, e-mails de suivi).

### Effet Zeigarnik
Les tâches inachevées occupent davantage l'esprit que celles qui sont terminées. Les boucles ouvertes génèrent une tension psychologique.

**Application marketing** : « Vous avez terminé à 80 % » incite fortement à aller au bout. Les profils incomplets, les paniers abandonnés et le suspense s'appuient sur ce mécanisme.

### Effet Pratfall
Une personne compétente devient plus attachante lorsqu'elle révèle un petit défaut. La perfection inspire moins d'empathie.

**Application marketing** : Reconnaître une faiblesse (« Nous ne sommes pas les moins chers, mais... ») peut renforcer la confiance et la différenciation.

### Malédiction de la connaissance
Dès lors que vous savez quelque chose, vous ne pouvez plus concevoir d'ignorer cette information. Les experts peinent souvent à expliquer les choses simplement.

**Application marketing** : Votre produit vous semble évident, mais il est obscur pour les nouveaux venus. Testez vos textes auprès de personnes extérieures à votre secteur.

### Comptabilité mentale
Les gens traitent l'argent différemment selon sa provenance ou son utilisation prévue, bien que l'argent soit parfaitement fongible.

**Application marketing** : Présentez les coûts dans des comptes mentaux favorables. « 3 $/jour » ne produit pas le même effet psychologique que « 90 $/mois », même si le montant est identique.

### Aversion au regret
Les gens évitent les actions susceptibles de générer du regret, même si l'espérance de gain est positive.

**Application marketing** : Adressez directement la peur du regret. Les garanties satisfait ou remboursé, les essais gratuits et les promesses « sans engagement » réduisent cette anxiété.

### Effet d'entraînement (Bandwagon) / Preuve sociale
Les gens suivent ce que font les autres. La popularité est un indicateur de qualité et de sécurité.

**Application marketing** : Affichez le nombre de clients, des témoignages, des logos, des avis et des mentions « tendance ». Les chiffres inspirent confiance.

---

## Influencer les comportements et persuasion

Ces modèles vous aident à influencer éthiquement les décisions d'achat.

### Principe de réciprocité
Les gens se sentent obligés de rendre les services reçus. Donnez d'abord, et les gens voudront vous donner en retour.

**Application marketing** : Des contenus gratuits, des outils offerts et des versions gratuites généreuses créent une obligation morale réciproque. Apportez de la valeur avant de demander quoi que ce soit.

### Engagement et cohérence
Une fois qu'une personne s'engage dans une voie, elle tient à rester cohérente avec cet engagement.

**Application marketing** : Obtenez d'abord de petits engagements (inscription par e-mail, essai gratuit). Une personne ayant franchi une première étape est beaucoup plus susceptible de franchir la suivante.

### Biais d'autorité
Les gens s'en remettent aux experts et aux figures d'autorité. Les titres et l'expertise inspirent confiance.

**Application marketing** : Mettez en avant des recommandations d'experts, des certifications, des logos de presse (« vu dans ») et des contenus de leadership d'opinion.

### Biais de sympathie / similarité
Les gens disent oui à ceux qu'ils apprécient et à ceux qui leur ressemblent.

**Application marketing** : Utilisez des porte-paroles accessibles, des récits de fondateurs et le jargon de votre communauté. La mention « Conçu par des marketeurs pour des marketeurs » signale une identité commune.

### Principe d'unité
Une identité partagée démultiplie l'influence. Le sentiment de faire partie du « même groupe » est très puissant.

**Application marketing** : Positionnez votre marque au sein de la communauté de vos clients. Adoptez leur langage interne et partagez leurs valeurs.

### Heuristique de rareté / urgence
Une disponibilité limitée augmente la valeur perçue. La rareté signale l'attrait.

**Application marketing** : Les offres à durée limitée, les alertes de stock faible et les accès exclusifs créent de l'urgence. À n'utiliser que si c'est authentique.

### Technique du pied-dans-la-porte
Commencez par une petite requête, puis augmentez progressivement. L'acceptation d'une petite demande prédispose à accepter des demandes plus importantes.

**Application marketing** : Essai gratuit → formule payante → abonnement annuel → offre entreprise. Chaque étape s'appuie sur la précédente.

### Technique de la porte-au-nez
Commencez par une demande démesurée, puis rabattez-vous sur ce que vous voulez vraiment. Le contraste rend la seconde demande très raisonnable.

**Application marketing** : Présentez d'abord le tarif entreprise, puis dévoilez le forfait de démarrage abordable. Le contraste donne l'impression d'une excellente affaire.

### Aversion à la perte / Théorie des perspectives
La douleur d'une perte est ressentie environ deux fois plus intensément que le plaisir d'un gain équivalent. Les gens feront plus d'efforts pour éviter de perdre que pour gagner.

**Application marketing** : Formulez votre message autour de ce qu'ils risquent de perdre en n'agissant pas. « Ne passez pas à côté » est plus percutant que « Vous pourriez gagner ».

### Effet d'ancrage
Le premier chiffre auquel une personne est exposée influence lourdement tous ses jugements ultérieurs.

**Application marketing** : Affichez d'abord le prix le plus élevé (prix d'origine, tarif concurrent, offre entreprise) pour ancrer les attentes à un niveau supérieur.

### Effet de leurre (Decoy Effect)
L'ajout d'une troisième option, nettement inférieure, rend l'une des deux premières options beaucoup plus attractive.

**Application marketing** : Une offre « leurre » dont le rapport qualité-prix est médiocre transforme votre formule cible en choix d'une évidence indiscutable.

### Effet de cadrage (Framing Effect)
La manière de présenter une information modifie la façon dont elle est perçue. Mêmes faits, cadrages différents.

**Application marketing** : « 90 % de taux de réussite » et « 10 % de taux d'échec » sont strictement identiques, mais ne provoquent pas la même réaction. Privilégiez un cadrage positif.

### Effet de contraste
La perception d'un élément change radicalement selon ce à quoi on le compare.

**Application marketing** : Montrez clairement l'état initial (« avant »). Le contraste avec le résultat final (« après ») rend les bénéfices éclatants.

---

## Psychologie du pricing

Ces modèles traitent spécifiquement de la façon dont les individus perçoivent et réagissent aux prix.

### Prix magique (Charm Pricing) / Effet du chiffre de gauche
Les prix se terminant par 9 semblent considérablement inférieurs au chiffre rond supérieur. 99 $ paraît bien moins cher que 100 $.

**Application marketing** : Utilisez des terminaisons en .99 ou .95 pour les offres axées sur l'accessibilité. Le chiffre situé le plus à gauche domine la perception.

### Effet des prix ronds (Fluidité cognitive)
Les nombres ronds évoquent le haut de gamme et sont plus faciles à traiter mentalement. 100 $ évoque la qualité ; 99 $ évoque une bonne affaire.

**Application marketing** : Choisissez des prix ronds pour les produits premium (500 $/mois) et des prix magiques pour les offres d'appel (497 $/mois).

### Règle des 100
Pour les prix inférieurs à 100 $, les réductions exprimées en pourcentage paraissent plus importantes (« -20 % »). Pour les prix supérieurs à 100 $, les remises en valeur absolue semblent plus fortes (« -50 $ »).

**Application marketing** : Produit à 80 $ : « -20 % » surpasse « -16 $ ». Produit à 500 $ : « -100 $ » surpasse « -20 % ».

### Relativité des prix / Good-Better-Best
Les gens évaluent les prix par comparaison avec les autres options présentées. Une option intermédiaire paraît toujours raisonnable entre une formule d'entrée de gamme et une offre haut de gamme.

**Application marketing** : Proposez trois niveaux dont le forfait intermédiaire est votre véritable cible. L'offre la plus chère la rend raisonnable ; l'offre la moins chère sert de point de référence.

### Comptabilité mentale (Pricing)
Présenter un même prix sous un angle différent modifie sa perception psychologique.

**Application marketing** : « 1 $/jour » semble plus abordable que « 30 $/mois ». « Moins cher que votre café du matin » recadre astucieusement la dépense.

---

## Modèles de conception et de diffusion

Ces modèles vous aident à concevoir des dispositifs marketing efficaces.

### Loi de Hick
Le temps nécessaire pour prendre une décision augmente avec le nombre et la complexité des options disponibles. Plus d'options = décisions ralenties = abandons accrus.

**Application marketing** : Simplifiez les choix. Un CTA unique et clair surpasse trois CTA concurrents. Réduisez le nombre de champs dans vos formulaires.

### Entonnoir AIDA
Attention → Intérêt → Désir → Action. Le parcours client classique.

**Application marketing** : Structurez vos pages et vos campagnes pour guider le prospect à travers chaque étape. Captez l'attention avant de chercher à susciter le désir.

### Règle des 7
Un prospect a généralement besoin d'environ 7 points de contact avant de convertir. Une publicité isolée convertit rarement ; c'est la présence continue qui paye.

**Application marketing** : Déployez des campagnes multicanales. Le retargeting, les séquences d'e-mails et une présence régulière produisent des effets cumulés.

### Théorie du Nudge / Architecture du choix
De légères modifications dans la présentation des options influencent significativement les décisions.

**Application marketing** : Les sélections par défaut, un ordonnancement stratégique et la suppression des points de friction guident les comportements sans restreindre la liberté de choix.

### Modèle de comportement de BJ Fogg
Comportement = Motivation × Capacité × Déclencheur (Prompt). Les trois facteurs doivent coïncider pour déclencher l'action.

**Application marketing** : Forte motivation mais action difficile = abandon. Action facile mais sans déclencheur = inaction. Concevez vos parcours en intégrant les trois éléments.

### Framework EAST
Rendez les comportements souhaités : Faciles (Easy), Attractifs (Attractive), Sociaux (Social) et Opportuns (Timely).

**Application marketing** : Supprimez les frictions (facile), rendez l'offre séduisante (attractif), montrez que d'autres le font (social), et sollicitez l'utilisateur au moment idéal (opportun).

### Modèle COM-B
Tout comportement nécessite : Capacité (Capability), Opportunité (Opportunity) et Motivation (Motivation).

**Application marketing** : Peuvent-ils le faire (capacité) ? Le chemin est-il dégagé (opportunité) ? En ont-ils envie (motivation) ? Prenez en compte ces trois leviers.

### Énergie d'activation
L'effort initial nécessaire pour démarrer une action. Une énergie d'activation trop élevée empêche d'agir, même si la tâche globale est simple.

**Application marketing** : Réduisez les frictions au démarrage. Pré-remplissez les formulaires, proposez des modèles prêts à l'emploi, offrez des victoires rapides. Rendez la première étape extraordinairement simple.

### North Star Metric
La métrique unique qui reflète le mieux la valeur apportée à vos clients. La focalisation crée l'alignement.

**Application marketing** : Identifiez votre North Star Metric (utilisateurs actifs, projets finalisés, revenu par client) et alignez tous vos efforts dessus.

### L'effet cobra
Se produit lorsqu'un système d'incitation se retourne contre son objectif et produit l'inverse du résultat escompté.

**Application marketing** : Testez vos mécanismes d'incitation. Une prime de parrainage mal calibrée risque d'attirer des parrainages frauduleux ou de piètre qualité.

---

## Modèles de croissance et de passage à l'échelle

Ces modèles expliquent comment le marketing se développe et démultiplie ses effets.

### Boucles de rétroaction (Feedback Loops)
La sortie d'un système réalimente l'entrée, créant des cycles. Les boucles positives accélèrent la croissance ; les boucles négatives précipitent le déclin.

**Application marketing** : Bâtissez des cercles vertueux : plus d'utilisateurs → plus de contenu → meilleur SEO → plus d'utilisateurs. Identifiez et renforcez ces boucles positives.

### Effet cumulé (Compounding)
Des gains modestes mais réguliers s'accumulent au fil du temps pour produire des résultats massifs. Les premiers gains sont les plus déterminants.

**Application marketing** : La production régulière de contenu, le SEO et le renforcement de marque font des intérêts composés. Commencez tôt ; les retombées s'accumulent de manière exponentielle.

### Effets de réseau
Un produit gagne en valeur à mesure que le nombre d'utilisateurs augmente.

**Application marketing** : Créez des fonctionnalités qui s'enrichissent avec l'usage collectif : espaces partagés, intégrations, places de marché, communautés.

### Effet volant d'inertie (Flywheel Effect)
Un effort soutenu crée une dynamique qui finit par s'auto-entretenir. Difficile à amorcer, facile à entretenir.

**Application marketing** : Contenu → trafic → prospects → clients → études de cas → plus de contenu. Chaque rouage alimente le suivant.

### Coûts de changement (Switching Costs)
Le coût (en temps, argent, énergie, données) nécessaire pour passer chez un concurrent. Des coûts de changement élevés favorisent la rétention.

**Application marketing** : Rehaussez éthiquement les coûts de changement : intégrations poussées, accumulation de données, personnalisation des flux de travail, adoption par toute l'équipe.

### Exploration vs Exploitation
Trouvez le juste équilibre entre tester de nouvelles opportunités (exploration) et optimiser ce qui fonctionne déjà (exploitation).

**Application marketing** : Ne délaissez pas vos canaux performants pour la dernière nouveauté à la mode, mais préservez une part de votre budget pour des expérimentations.

### Masse critique / Point de bascule (Tipping Point)
Le seuil à partir duquel la croissance devient auto-suffisante.

**Application marketing** : Allouez vos ressources pour atteindre la masse critique sur un segment donné avant de vous disperser. Privilégiez la profondeur à l'étendue.

### Biais du survivant
Tendance à se focaliser sur les réussites en ignorant tous les échecs restés invisibles.

**Application marketing** : Analysez les campagnes ratées, pas uniquement les triomphes. Le succès viral dont vous vous inspirez s'est appuyé sur 99 tentatives infructueuses que vous n'avez pas vues.

---

## Référence rapide

Face à une problématique marketing, pensez aux modèles correspondants :

| Défi | Modèles pertinents |
|------|-------------------|
| Conversions faibles | Loi de Hick, Énergie d'activation, Modèle BJ Fogg, Frictions |
| Objections sur le prix | Ancrage, Cadrage, Comptabilité mentale, Aversion à la perte |
| Établir la confiance | Autorité, Preuve sociale, Réciprocité, Effet Pratfall |
| Créer de l'urgence | Rareté, Aversion à la perte, Effet Zeigarnik |
| Rétention / Churn | Effet de dotation, Coûts de changement, Biais du statu quo |
| Croissance au point mort | Théorie des contraintes, Optima locaux vs globaux, Effet cumulé |
| Paralysie décisionnelle | Paradoxe du choix, Effet par défaut, Théorie du Nudge |
| Onboarding | Effet de gradient d'objectif, Effet IKEA, Engagement et cohérence |

---

## Questions spécifiques à la tâche

1. Quel comportement précis cherchez-vous à encourager ?
2. Que pense ou ressent votre client avant d'entrer en contact avec votre marketing ?
3. À quelle étape du parcours client (sensibilisation → considération → décision) ce point de contact se situe-t-il ?
4. Quel obstacle bloque actuellement l'action souhaitée ?
5. Avez-vous validé cette approche auprès de clients réels ?

---

## Compétences associées

- **cro** : Appliquer la psychologie à l'optimisation de pages
- **copywriting** : Rédiger des textes en s'appuyant sur les principes psychologiques
- **popups** : Utiliser des déclencheurs et la psychologie dans les fenêtres contextuelles
- **pricing-page optimization** : Voir cro pour la psychologie appliquée aux pages de tarifs
- **ab-testing** : Tester des hypothèses psychologiques
