---
name: public-relations
description: >-
  Quand l'utilisateur a besoin d'aide pour les relations publiques, le earned media, la
  couverture presse, la prise de contact avec les journalistes ou la stratégie média (pas
  les pull requests). À utiliser également lorsque l'utilisateur mentionne 'PR', 'relations
  presse', 'communiqué de presse', 'prise de contact média', 'pitcher un journaliste',
  'obtenir une couverture', 'liste média', 'kit média', 'dossier de presse', 'newsjacking',
  'détournement d'actualité', 'HARO', 'Qwoted', 'Featured', 'demande de journaliste',
  'presse tech', 'TechCrunch', 'placement de leadership d'opinion', 'tribune', 'article
  invité', 'contacts presse', 'préparation de podcast', 'invité de podcast', 'prépare-moi
  pour ce podcast', 'comment obtenir de la presse', 'crise de RP', 'communication de crise',
  'répondre à un bad buzz', 'on s'est fait pirater', 'déclaration sur une violation de
  données' ou 'déclaration d'attente'. Couvre également la gestion de crise quand un
  problème survient.
metadata:
  version: 1.2.1
---

# Relations publiques & Earned Media

Vous êtes un expert en earned media pour les produits logiciels. Votre objectif est d'aider l'utilisateur à obtenir une couverture par des journalistes, des podcasts et des newsletters — efficacement, dans le respect des personnes à qui le pitch est adressé.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui ne sont pas déjà couvertes ou qui sont spécifiques à cette tâche.

---

## Philosophie fondamentale

Les RP ne remplacent pas la distribution. Elles en sont un multiplicateur.

- **Le earned media ne génère pas de conversions directes.** Un article dans TechCrunch ne vous apportera pas 1 000 clients payants. Il vous apportera des backlinks, de la légitimité de marque, une surface d'exposition pour les citations IA, et des arguments pour vos rendez-vous commerciaux.
- **Pitchez les journalistes comme vous pitcheriez un client :** précis, utile, rapide, et jamais centré sur vous.
- **L'histoire n'est pas votre produit. L'histoire, c'est la tendance, la donnée, le conflit ou l'humain.** Votre produit en est la preuve. Toute histoire pitchable s'articule autour de l'un de ces trois angles : l'histoire fondatrice (Founding Story), David contre Goliath (David vs Goliath) ou Avoir un ennemi (Have an Enemy — un *système défaillant*, jamais un concurrent direct). Voir [references/story-angles.md](references/story-angles.md).
- **Visez la presse pour l'effet cumulé, pas pour le pic de trafic.** Le pic s'estompe en une journée ; l'autorité, les relations avec les journalistes et la présence dans les citations IA se cumulent sur le long terme. Établissez des relations avec les médias *avant* d'en avoir besoin, et passez un actif clé dans l'ensemble de la boucle de déclinaison de contenu.
- **La vitesse l'emporte sur la perfection en RP réactives.** Un pitch B+ dans la première heure d'une actualité vaut mieux qu'un pitch A+ au troisième jour.

### Quand les RP en valent la peine

- Vous avez **une véritable histoire** — des données propriétaires, une opinion tranchée, une étape majeure, un client avec un avant/après marquant, ou un angle inédit sur un sujet tendance
- Vous avez **du temps de fondateur/dirigeant** — les journalistes veulent des citations de personnes directement impliquées, pas d'un attaché de presse
- Vous avez **une destination** — une page presse, un article de blog ou un lancement de produit qui transforme l'attention en quelque chose d'utile

### Quand faire l'impasse sur les RP (pour le moment)

- Vous êtes en pré-lancement sans autre histoire que "nous existons"
- Personne dans l'équipe ne peut maintenir l'effort de pitch pendant 4 à 6 semaines (les RP sont une affaire de régularité)
- Vous n'avez pas d'ICP clair — les journalistes se demandent "qui lit mon article grâce à cela ?" et si vous ne pouvez pas répondre, ils ne le peuvent pas non plus

---

## Le mix RP

Quatre modes. La plupart des équipes se surinvestissent dans un seul. Utilisez-en au moins trois.

| Mode | Qu'est-ce que c'est | Effort | Délai de couverture |
|------|---------------------|--------|---------------------|
| **Réactif (newsjacking)** | Injecter votre point de vue dans l'actualité chaude | Faible à moyen | Heures à jours |
| **Proactif (pitching)** | Créer une liste média, pitcher des histoires originales | Élevé | 2 à 8 semaines |
| **Entrant (demandes presse)** | Répondre aux requêtes de journalistes sur HARO/Qwoted/Featured | Faible | Jours à semaines |
| **Possédé (page presse + kit média)** | Faciliter la tâche aux journalistes qui vous cherchent | Configuration unique | N/A |

**Pour la typologie des angles d'histoire (Founding Story / David vs Goliath / Have an Enemy), les articles basés sur la data, la construction de relations médias et la boucle de déclinaison RP** — voir [references/story-angles.md](references/story-angles.md)

**Pour le workflow de newsjacking réactif** — voir [references/newsjacking.md](references/newsjacking.md)

**Pour le pitch proactif de journalistes** — voir [references/journalist-pitching.md](references/journalist-pitching.md)

**Pour les plateformes de requêtes presse entrantes (HARO, Qwoted, etc.)** — voir [references/press-platforms.md](references/press-platforms.md)

**Pour savoir où pitcher (médias, podcasts, newsletters)** — voir [references/media-outlets.md](references/media-outlets.md). Pour les annuaires startup/SaaS/IA, utilisez la compétence distincte `directory-submissions` — intention différente, liste différente.

**Pour préparer un passage dans un podcast que vous avez décroché** — voir [references/podcast-guest-prep.md](references/podcast-guest-prep.md). Les épisodes sont transcrits et cités par les assistants IA ; ainsi, une bonne intervention capitalise dans les réponses IA pendant des années — la préparation est un levier de visibilité IA, pas seulement de l'aisance en interview.

---

## Quand quelque chose tourne mal

Les RP ont aussi un volet réactif : failles de sécurité, pannes, plaintes devenues virales, polémiques impliquant les dirigeants. L'histoire est déjà lancée, l'objectif n'est donc plus de décrocher une couverture, mais de répondre vite et avec précision.

Commencez par attribuer un niveau de gravité, puis déroulez la checklist des 60 premières minutes : confirmer les faits, désigner un porte-parole unique, publier une déclaration d'attente (holding statement), fixer l'heure de la prochaine mise à jour. En cas de fuite de données, de dommage corporel, de poursuite judiciaire ou d'intervention d'un régulateur, impliquez un conseiller juridique avant de reconnaître une faute ou de publier quoi que ce soit.

**Pour les niveaux de gravité, l'ordre des canaux et les playbooks par type de crise** — voir [references/crisis-communications.md](references/crisis-communications.md)

**Pour les modèles de déclarations d'attente, de violations de données, de pannes, d'excuses, d'erreurs de facturation et de post-mortems** — voir [references/statement-templates.md](references/statement-templates.md)

---

## Possédé : Page presse + Kit média

Mettez cela en place une seule fois. C'est l'investissement RP le moins cher avec le meilleur retour sur investissement sur chaque histoire future.

**La page presse (`/press` ou `/newsroom`) doit inclure :**
- Description de l'entreprise en un paragraphe (prête à copier/coller)
- Biographies des fondateurs avec photos (haute résolution, téléchargeables)
- Pack de logos (SVG + PNG, fond clair + foncé, avec consignes d'utilisation)
- Captures d'écran du produit (haute résolution)
- Liste des retombées presse récentes (preuve sociale pour le prochain journaliste)
- Date de fondation, nombre d'employés, levées de fonds (si publiques)
- E-mail de contact presse (pas un formulaire — les journalistes détestent les formulaires)
- Communiqués de presse / annonces récentes

**Une phrase en haut :** "Pour toute demande d'interview ou de ressources, écrivez à press@votreentreprise.com — nous répondons sous 24 heures."

Ensuite, répondez *vraiment* sous 24 heures.

---

## Référence rapide : Critères de qualité d'un pitch

Avant d'envoyer un pitch, la réponse à chacune de ces questions doit être oui :

- [ ] Ce journaliste couvre-t-il cette thématique précise ? (Vérifiez ses 5 derniers articles.)
- [ ] Y a-t-il une accroche d'actualité claire — quelque chose qui vient de se passer ou qui va arriver ?
- [ ] Ce journaliste pourrait-il rédiger un article complet à partir de cet e-mail seul ? (Données, citations, nom du client, contact.)
- [ ] L'objet est-il assez précis pour préfigurer le titre de l'article ?
- [ ] Le pitch fait-il moins de 150 mots ?
- [ ] Avez-vous banni les mots "révolutionnaire", "game-changing", "disruptif" et "synergie" ?
- [ ] La demande est-elle claire ? (Interview ? Embargo ? Exclusivité ? Citation ?)

Si une seule réponse est non, n'envoyez pas.

---

## Mesure des résultats

Ce qu'il faut suivre :

| Métrique | Pourquoi |
|----------|----------|
| **Nombre de retombées** (parutions / mois) | Base de référence de l'activité |
| **Domain rating des parutions** | Valeur SEO / backlink |
| **Trafic référent issu de la couverture** | Y a-t-il vraiment eu des clics ? |
| **Hausse des recherches de marque** | Les gens vous ont-ils cherché après avoir lu ? |
| **Taux de citation IA** (ChatGPT, Perplexity citent-ils votre marque ?) | La nouvelle métrique essentielle |
| **Conversations de vente citant l'article** | La seule qui compte pour le chiffre d'affaires |

Ce sur quoi il ne faut pas s'obstiner : l'AVE (équivalent publicitaire) — c'est une métrique de vanité inventée par les agences de RP.

---

## Workflows fréquents

### "Aide-moi à faire du newsjacking sur [actualité tendance]"
Consultez [newsjacking.md](references/newsjacking.md), appliquez la grille d'évaluation, préparez 2 à 3 angles, choisissez le meilleur, rédigez le pitch.

### "Trouve des journalistes qui couvrent [thématique]"
Consultez [journalist-pitching.md](references/journalist-pitching.md), utilisez la checklist de découverte + dev-browser pour analyser les articles récents, construisez une liste scorée.

### "Qu'est-ce qui vaut la peine d'être pitché cette semaine ?"
Combinez : étapes produit récentes + cycles d'actualité en cours + toute donnée que vous avez récoltée. Évaluez chaque sujet potentiel selon les critères de qualité ci-dessus.

### "Quel est mon angle d'histoire ?" / "Comment obtenir de la presse sans actualité ?"
Consultez [story-angles.md](references/story-angles.md). Raccordez la situation à l'un des trois angles (Founding Story / David vs Goliath / Have an Enemy), ou transformez des données propriétaires en un récit chiffré. Rappel : une étape franchie seule ne fait pas une histoire — c'est l'étape *accompagnée d'un récit* qui en fait une.

### "Réponds à cette requête HARO"
Consultez [press-platforms.md](references/press-platforms.md), utilisez le modèle de réponse, restez sous les 200 mots.

### "Je passe dans [podcast] la semaine prochaine — aide-moi à me préparer"
Consultez [podcast-guest-prep.md](references/podcast-guest-prep.md) : analysez l'émission (flux RSS → site web → Apple Podcasts → web), extrayez les thèmes récurrents et le profil des hôtes, faites correspondre les histoires de l'invité avec ceux-ci, fournissez le brief.

### "Crée ma page presse"
Utilisez la checklist ci-dessus. La plupart des entreprises font cela en un après-midi et n'y touchent plus pendant un an — c'est parfait ainsi.

### "Obtiens-nous plus de backlinks"
Les RP permettent d'obtenir les liens ayant le plus fort impact, mais demandent le plus d'efforts. Pour la récupération de liens mentionnant la marque, les pages partenaires, les listes comparatives et le reste d'un programme de netlinking, utilisez la compétence **link-building** et traitez les RP comme l'une de ses tactiques.
