---
name: skill-creator
description: Créer de nouvelles compétences, modifier et améliorer des compétences existantes, et mesurer leurs performances. À utiliser lorsque les utilisateurs souhaitent créer une compétence à partir de zéro, modifier ou optimiser une compétence existante, exécuter des évaluations pour tester une compétence, évaluer les performances d'une compétence avec une analyse de variance, ou optimiser la description d'une compétence pour améliorer la précision de son déclenchement.
---

# Skill Creator

Une compétence pour créer de nouvelles compétences et les améliorer de manière itérative.

Dans les grandes lignes, le processus de création d'une compétence se déroule ainsi :

- Décider de ce que la compétence doit faire et, approximativement, de la manière dont elle doit le faire
- Rédiger un premier jet de la compétence
- Créer quelques invites de test et exécuter dessus Claude avec accès à la compétence
- Aider l'utilisateur à évaluer les résultats, tant sur le plan qualitatif que quantitatif
  - Pendant que les exécutions tournent en arrière-plan, rédiger des évaluations quantitatives s'il n'en existe pas encore (s'il en existe déjà, vous pouvez soit les utiliser telles quelles, soit les modifier si des ajustements s'avèrent nécessaires). Expliquez-les ensuite à l'utilisateur (ou s'il en existait déjà, expliquez celles qui sont en place)
  - Utiliser le script `eval-viewer/generate_review.py` pour présenter les résultats à l'utilisateur afin qu'il les examine, et lui donner également accès aux métriques quantitatives
- Réécrire la compétence en vous basant sur les retours de l'utilisateur après son évaluation des résultats (ainsi que sur les défauts majeurs révélés par les benchmarks quantitatifs)
- Répéter jusqu'à obtenir satisfaction
- Élargir l'ensemble de tests et recommencer à plus grande échelle

Votre rôle lors de l'utilisation de cette compétence est d'identifier où se situe l'utilisateur dans ce processus, puis d'intervenir pour l'aider à franchir ces étapes. Par exemple, s'il vous dit « Je veux créer une compétence pour X », vous pouvez l'aider à préciser sa pensée, rédiger un premier jet, écrire les cas de test, déterminer la méthode d'évaluation, lancer toutes les invites et itérer.

En revanche, s'il dispose déjà d'une ébauche de compétence, vous pouvez passer directement à la phase d'évaluation et d'itération de la boucle.

Bien entendu, faites toujours preuve de souplesse : si l'utilisateur vous dit « Pas besoin de lancer une batterie d'évaluations, avançons simplement ensemble au feeling », adaptez-vous.

Ensuite, une fois la compétence finalisée (mais là encore, l'ordre reste adaptable), vous pouvez également exécuter l'optimiseur de description de compétence, pour lequel un script dédié est fourni, afin d'optimiser le déclenchement de la compétence.

Tout est clair ? Parfait.

## Communiquer avec l'utilisateur

Le créateur de compétences est susceptible d'être utilisé par des personnes ayant des niveaux de familiarité très variés avec le jargon technique. Depuis peu, la puissance de Claude incite des plombiers à ouvrir un terminal et des grands-parents à chercher sur Google « comment installer npm ». Cela dit, la majorité des utilisateurs possède probablement un bon niveau de compétences informatiques.

Soyez donc particulièrement attentif aux indices contextuels pour adapter votre niveau de langage ! À titre indicatif, dans le cas général :

- « évaluation » et « benchmark » sont à la limite, mais acceptables
- pour « JSON » et « assertion », attendez de déceler des signaux clairs indiquant que l'utilisateur maîtrise ces notions avant de les employer sans explication

N'hésitez pas à expliquer brièvement les termes en cas de doute, et clarifiez-les par une courte définition si vous n'êtes pas certain que l'utilisateur les comprenne.

---

## Créer une compétence

### Cerner l'intention

Commencez par comprendre l'intention de l'utilisateur. La conversation en cours contient peut-être déjà un flux de travail que l'utilisateur souhaite formaliser (par exemple, s'il dit « transforme ceci en compétence »). Si c'est le cas, extrayez d'abord les éléments de l'historique de conversation : les outils utilisés, l'enchaînement des étapes, les corrections apportées par l'utilisateur, les formats d'entrée et de sortie observés. L'utilisateur devra peut-être combler les manques et devra confirmer avant de passer à l'étape suivante.

1. Que doit permettre à Claude de faire cette compétence ?
2. Quand cette compétence doit-elle se déclencher ? (quelles phrases/contextes utilisateur)
3. Quel est le format de sortie attendu ?
4. Devons-nous mettre en place des cas de test pour vérifier le bon fonctionnement de la compétence ? Les compétences ayant des sorties objectivement vérifiables (transformations de fichiers, extraction de données, génération de code, étapes de flux de travail fixes) bénéficient grandement des cas de test. Les compétences avec des sorties subjectives (style d'écriture, art) n'en ont souvent pas besoin. Suggérez le choix par défaut approprié selon le type de compétence, mais laissez l'utilisateur décider.

### Échange et recherche

Posez proactivement des questions sur les cas limites, les formats d'entrée/sortie, les fichiers d'exemple, les critères de réussite et les dépendances. Attendez d'avoir bien clarifié ces points avant de rédiger des invites de test.

Vérifiez les MCP disponibles : s'ils sont utiles pour la recherche (consulter de la documentation, trouver des compétences similaires, chercher les meilleures pratiques), faites vos recherches en parallèle via des sous-agents si possible, ou directement dans le fil sinon. Venez avec du contexte pour alléger la charge de l'utilisateur.

### Rédiger le SKILL.md

Sur la base de vos échanges avec l'utilisateur, renseignez les éléments suivants :

- **name** : Identifiant de la compétence
- **description** : Quand la déclencher, ce qu'elle fait. C'est le mécanisme de déclenchement principal : incluez à la fois ce que la compétence fait ET les contextes spécifiques dans lesquels l'utiliser. Toutes les indications sur « quand l'utiliser » doivent se trouver ici, et non dans le corps du texte. Remarque : actuellement, Claude a tendance au « sous-déclenchement » des compétences, c'est-à-dire qu'il ne les utilise pas toujours quand elles seraient utiles. Pour contrer cela, rendez les descriptions de compétences légèrement « insistantes ». Par exemple, au lieu de « Comment construire un tableau de bord simple et rapide pour afficher les données internes d'Anthropic. », écrivez plutôt : « Comment construire un tableau de bord simple et rapide pour afficher les données internes d'Anthropic. Veillez à utiliser cette compétence dès que l'utilisateur mentionne des tableaux de bord, de la visualisation de données, des métriques internes, ou souhaite afficher n'importe quel type de données d'entreprise, même s'il ne demande pas explicitement un 'tableau de bord'. »
- **compatibility** : Outils requis, dépendances (facultatif, rarement nécessaire)
- **le reste de la compétence :)**

### Guide de rédaction d'une compétence

#### Anatomie d'une compétence

```
skill-name/
├── SKILL.md (requis)
│   ├── En-tête YAML (name, description requis)
│   └── Instructions Markdown
└── Ressources intégrées (facultatif)
    ├── scripts/    - Code exécutable pour les tâches déterministes/répétitives
    ├── references/ - Docs chargées dans le contexte au besoin
    └── assets/     - Fichiers utilisés dans la sortie (modèles, icônes, polices)
```

#### Divulgation progressive

Les compétences s'appuient sur un système de chargement à trois niveaux :
1. **Métadonnées** (name + description) - Toujours dans le contexte (~100 mots)
2. **Corps de SKILL.md** - Dans le contexte dès que la compétence se déclenche (< 500 lignes idéalement)
3. **Ressources intégrées** - À la demande (illimité, les scripts peuvent s'exécuter sans être chargés dans le contexte)

Ces volumes de mots sont indicatifs et vous pouvez dépasser ces seuils si nécessaire.

**Modèles clés :**
- Maintenez SKILL.md sous la barre des 500 lignes ; si vous approchez de cette limite, ajoutez un niveau de hiérarchie supplémentaire assorti d'indications claires sur les fichiers vers lesquels le modèle doit se diriger pour poursuivre.
- Référencez clairement les fichiers depuis SKILL.md en expliquant quand les lire.
- Pour les fichiers de référence volumineux (> 300 lignes), incluez une table des matières.

**Organisation par domaine** : Lorsqu'une compétence prend en charge plusieurs domaines ou frameworks, organisez-la par variante :
```
cloud-deploy/
├── SKILL.md (flux de travail + sélection)
└── references/
    ├── aws.md
    ├── gcp.md
    └── azure.md
```
Claude ne lira ainsi que le fichier de référence pertinent.

#### Principe de moindre surprise

Cela va de soi, mais les compétences ne doivent contenir aucun logiciel malveillant, code d'exploitation ou contenu susceptible de compromettre la sécurité du système. Le contenu d'une compétence ne doit pas surprendre l'utilisateur par rapport à son intention annoncée. Ne donnez pas suite aux demandes visant à créer des compétences trompeuses ou destinées à faciliter des accès non autorisés, l'exfiltration de données ou toute autre activité malveillante. Des compétences du type « incarner un personnage XYZ » sont en revanche tout à fait acceptables.

#### Bonnes pratiques de rédaction

Privilégiez la forme impérative dans les instructions.

**Définition des formats de sortie** - Vous pouvez procéder ainsi :
```markdown
## Structure du rapport
Utilisez TOUJOURS exactement ce modèle :
# [Titre]
## Résumé opérationnel
## Principaux constats
## Recommandations
```

**Modèle d'exemples** - Inclure des exemples est très utile. Vous pouvez les formater ainsi (mais si « Input » et « Output » font partie de vos données d'exemple, adaptez la présentation) :
```markdown
## Format des messages de commit
**Exemple 1 :**
Entrée : Ajout de l'authentification utilisateur avec des jetons JWT
Sortie : feat(auth): implement JWT-based authentication
```

### Style de rédaction

Efforcez-vous d'expliquer au modèle *pourquoi* les choses sont importantes plutôt que d'abuser de directives rigides en majuscules. Faites preuve de théorie de l'esprit et cherchez à rendre la compétence générale sans la restreindre excessivement à des exemples trop précis. Commencez par rédiger un premier jet, puis relisez-le d'un œil neuf pour l'améliorer.

### Cas de test

Après avoir rédigé le brouillon de la compétence, imaginez 2 ou 3 invites de test réalistes, représentatives de ce qu'un véritable utilisateur formulerait. Proposez-les à l'utilisateur : [vous n'êtes pas tenu d'employer exactement ces termes] « Voici quelques cas de test que j'aimerais essayer. Vous semblent-ils pertinents, ou souhaitez-vous en ajouter d'autres ? ». Exécutez-les ensuite.

Enregistrez les cas de test dans `evals/evals.json`. N'écrivez pas encore d'assertions : contentez-vous des invites. Vous rédigerez les assertions à l'étape suivante pendant que les exécutions sont en cours.

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "Invite de tâche de l'utilisateur",
      "expected_output": "Description du résultat attendu",
      "files": []
    }
  ]
}
```

Consultez `references/schemas.md` pour le schéma complet (incluant le champ `assertions`, que vous ajouterez plus tard).

## Exécuter et évaluer les cas de test

Cette section forme une séquence continue : ne vous arrêtez pas en cours de route. N'utilisez PAS `/skill-test` ni aucune autre compétence de test.

Placez les résultats dans `<skill-name>-workspace/` au même niveau que le répertoire de la compétence. À l'intérieur de l'espace de travail, organisez les résultats par itération (`iteration-1/`, `iteration-2/`, etc.) et, au sein de chacune, attribuez un répertoire à chaque cas de test (`eval-0/`, `eval-1/`, etc.). Ne créez pas tout d'avance : créez les répertoires au fur et à mesure de votre progression.

### Étape 1 : Lancer toutes les exécutions (avec compétence ET référence) dans le même tour

Pour chaque cas de test, lancez deux sous-agents au cours du même tour : un avec la compétence, un sans. Ce point est capital : ne lancez pas d'abord les exécutions avec compétence pour ne revenir aux versions de référence que plus tard. Lancez tout en même temps pour que tout se termine à peu près au même moment.

**Exécution avec la compétence :**

```
Execute this task:
- Skill path: <path-to-skill>
- Task: <eval prompt>
- Input files: <eval files if any, or "none">
- Save outputs to: <workspace>/iteration-<N>/eval-<ID>/with_skill/outputs/
- Outputs to save: <ce qui importe à l'utilisateur — ex. « le fichier .docx », « le CSV final »>
```

**Exécution de référence (baseline)** (même invite, mais la référence dépend du contexte) :
- **Création d'une nouvelle compétence** : aucune compétence du tout. Même invite, aucun chemin de compétence, enregistrer dans `without_skill/outputs/`.
- **Amélioration d'une compétence existante** : l'ancienne version. Avant toute modification, prenez un instantané de la compétence (`cp -r <skill-path> <workspace>/skill-snapshot/`), puis faites pointer le sous-agent de référence vers cet instantané. Enregistrez dans `old_skill/outputs/`.

Rédigez un fichier `eval_metadata.json` pour chaque cas de test (le tableau des assertions peut rester vide pour le moment). Donnez à chaque évaluation un nom descriptif fondé sur ce qu'elle teste, et pas simplement « eval-0 ». Utilisez également ce nom pour le répertoire. Si cette itération fait appel à des invites nouvelles ou modifiées, créez ces fichiers pour chaque nouveau répertoire d'évaluation sans supposer qu'ils sont reconduits des itérations précédentes.

```json
{
  "eval_id": 0,
  "eval_name": "nom-descriptif-ici",
  "prompt": "L'invite de tâche de l'utilisateur",
  "assertions": []
}
```

### Étape 2 : Pendant les exécutions, rédiger les assertions

Ne restez pas inactif en attendant la fin des exécutions : mettez ce temps à profit. Rédigez des assertions quantitatives pour chaque cas de test et expliquez-les à l'utilisateur. Si des assertions existent déjà dans `evals/evals.json`, passez-les en revue et expliquez ce qu'elles vérifient.

De bonnes assertions sont objectivement vérifiables et portent des noms descriptifs : elles doivent être limpides dans le visualiseur de benchmark pour que quiconque observant les résultats comprenne immédiatement ce que chacune contrôle. Les compétences subjectives (style d'écriture, qualité graphique) s'évaluent mieux de manière qualitative : ne forcez pas l'usage d'assertions sur des aspects qui requièrent un jugement humain.

Mettez à jour les fichiers `eval_metadata.json` et `evals/evals.json` avec les assertions dès qu'elles sont rédigées. Expliquez également à l'utilisateur ce qu'il verra dans le visualiseur, à la fois pour les sorties qualitatives et pour le benchmark quantitatif.

### Étape 3 : À la fin de chaque exécution, enregistrer les données de temps

Lorsque chaque tâche de sous-agent s'achève, vous recevez une notification contenant `total_tokens` et `duration_ms`. Enregistrez immédiatement ces données dans `timing.json` au sein du répertoire de l'exécution :

```json
{
  "total_tokens": 84852,
  "duration_ms": 23332,
  "total_duration_seconds": 23.3
}
```

C'est votre unique opportunité de capturer ces données : elles sont transmises par la notification de tâche et ne sont conservées nulle part ailleurs. Traitez chaque notification dès son arrivée plutôt que d'essayer de les grouper.

### Étape 4 : Noter, agréger et lancer le visualiseur

Une fois toutes les exécutions terminées :

1. **Noter chaque exécution** — lancez un sous-agent évaluateur (grader) ou notez directement dans le fil en vous appuyant sur `agents/grader.md` pour évaluer chaque assertion par rapport aux sorties. Enregistrez les résultats dans `grading.json` au sein de chaque répertoire d'exécution. Le tableau des attentes dans `grading.json` doit obligatoirement utiliser les champs `text`, `passed` et `evidence` (et non `name`/`met`/`details` ou d'autres variantes), car le visualiseur dépend strictement de ces noms de champs. Pour les assertions vérifiables par programme, écrivez et exécutez un script plutôt que de juger à l'œil nu : les scripts sont plus rapides, plus fiables et réutilisables d'une itération à l'autre.

2. **Agréger dans le benchmark** — exécutez le script d'agrégation depuis le répertoire de skill-creator :
   ```bash
   python -m scripts.aggregate_benchmark <workspace>/iteration-N --skill-name <name>
   ```
   Cette commande génère `benchmark.json` et `benchmark.md` avec pass_rate, time et tokens pour chaque configuration, accompagnés de la moyenne ± écart-type et de la variation (delta). Si vous générez `benchmark.json` manuellement, consultez `references/schemas.md` pour connaître le schéma exact attendu par le visualiseur.
Placez chaque version with_skill avant son homologue de référence.

3. **Effectuer une analyse approfondie** — analysez les données du benchmark pour mettre en lumière les schémas que les statistiques globales pourraient dissimuler. Consultez `agents/analyzer.md` (section « Analyzing Benchmark Results ») pour savoir quoi chercher : par exemple, des assertions qui réussissent systématiquement quelle que soit la compétence (non discriminantes), des évaluations à forte variance (potentiellement instables), ou des arbitrages temps/jetons.

4. **Lancer le visualiseur** avec à la fois les sorties qualitatives et les données quantitatives :
   ```bash
   nohup python <skill-creator-path>/eval-viewer/generate_review.py \
     <workspace>/iteration-N \
     --skill-name "my-skill" \
     --benchmark <workspace>/iteration-N/benchmark.json \
     > /dev/null 2>&1 &
   VIEWER_PID=$!
   ```
   À partir de l'itération 2, ajoutez également `--previous-workspace <workspace>/iteration-<N-1>`.

   **Environnements Cowork / sans interface graphique (headless) :** Si `webbrowser.open()` n'est pas disponible ou que l'environnement ne possède pas d'affichage, utilisez `--static <output_path>` pour générer un fichier HTML autonome au lieu de démarrer un serveur. Les retours seront téléchargés sous forme d'un fichier `feedback.json` lorsque l'utilisateur cliquera sur « Submit All Reviews ». Après le téléchargement, copiez `feedback.json` dans le répertoire de l'espace de travail pour qu'il soit pris en compte lors de l'itération suivante.

Remarque : veillez à utiliser generate_review.py pour générer le visualiseur ; il n'est pas nécessaire d'écrire du code HTML sur mesure.

5. **Indiquer à l'utilisateur** un message du genre : « J'ai ouvert les résultats dans votre navigateur. Deux onglets sont disponibles : 'Outputs' vous permet de parcourir chaque cas de test et de laisser des commentaires, et 'Benchmark' présente la comparaison quantitative. Quand vous aurez terminé, revenez ici me le faire savoir. »

### Ce que l'utilisateur voit dans le visualiseur

L'onglet « Outputs » présente un cas de test à la fois :
- **Prompt** : la tâche qui a été soumise
- **Output** : les fichiers produits par la compétence, affichés directement dans la page lorsque c'est possible
- **Previous Output** (à partir de l'itération 2) : section repliée montrant la sortie de l'itération précédente
- **Formal Grades** (si la notation a été exécutée) : section repliée indiquant la réussite ou l'échec de chaque assertion
- **Feedback** : une zone de texte avec sauvegarde automatique au fil de la frappe
- **Previous Feedback** (à partir de l'itération 2) : ses commentaires de l'itération passée, affichés sous la zone de texte

L'onglet « Benchmark » présente le récapitulatif statistique : taux de réussite, durée et consommation de jetons pour chaque configuration, avec le détail par évaluation et les observations de l'analyse.

La navigation s'effectue via les boutons précédent/suivant ou les touches fléchées. Une fois la revue finie, l'utilisateur clique sur « Submit All Reviews », ce qui enregistre tous les commentaires dans `feedback.json`.

### Étape 5 : Lire les retours

Lorsque l'utilisateur vous informe qu'il a terminé, lisez `feedback.json` :

```json
{
  "reviews": [
    {"run_id": "eval-0-with_skill", "feedback": "il manque les étiquettes d'axes sur le graphique", "timestamp": "..."},
    {"run_id": "eval-1-with_skill", "feedback": "", "timestamp": "..."},
    {"run_id": "eval-2-with_skill", "feedback": "parfait, j'adore", "timestamp": "..."}
  ],
  "status": "complete"
}
```

Un retour vide signifie que le résultat convenait à l'utilisateur. Concentrez vos efforts d'amélioration sur les cas de test pour lesquels l'utilisateur a formulé des remarques précises.

Arrêtez le serveur du visualiseur lorsque vous n'en avez plus besoin :

```bash
kill $VIEWER_PID 2>/dev/null
```

---

## Améliorer la compétence

Voici le cœur de la boucle. Vous avez exécuté les cas de test, l'utilisateur a examiné les résultats, et vous devez maintenant perfectionner la compétence à partir de ses retours.

### Comment aborder les améliorations

1. **Généraliser à partir des retours.** L'objectif global ici est de concevoir des compétences capables d'être utilisées des millions de fois (peut-être littéralement, voire davantage) sur une grande variété d'invites. Ici, vous et l'utilisateur itérez de manière répétée sur un petit nombre d'exemples afin d'avancer plus vite. L'utilisateur connaît ces exemples sur le bout des doigts et peut rapidement évaluer de nouvelles sorties. Mais si la compétence que vous co-développez ne fonctionne que pour ces cas précis, elle devient inutile. Plutôt que d'introduire des ajustements pointilleux menant au surapprentissage (overfitting) ou des contraintes étouffantes, si un problème persiste, essayez de changer d'angle, d'utiliser d'autres métaphores ou de recommander d'autres méthodes de travail. Cela coûte peu d'essayer et vous pourriez trouver une excellente approche.

2. **Garder l'invite concise et légère.** Supprimez tout ce qui n'apporte pas de valeur démontrée. Veillez à lire les transcriptions complètes, et pas seulement les sorties finales : si vous constatez que la compétence pousse le modèle à perdre du temps dans des démarches improductives, essayez de retirer les passages concernés et observez l'impact.

3. **Expliquer le pourquoi.** Efforcez-vous d'expliquer le **pourquoi** derrière chaque instruction donnée au modèle. Les LLM actuels sont *intelligents*. Ils ont une bonne théorie de l'esprit et, guidés par un bon cadre, ils savent aller au-delà des consignes mécaniques pour accomplir de grandes choses. Même si les retours de l'utilisateur sont laconiques ou traduisent de la frustration, cherchez à comprendre véritablement la tâche, la raison pour laquelle l'utilisateur a rédigé ce qu'il a rédigé, ainsi que le sens profond de ses propos, puis insufflez cette compréhension dans les instructions. Si vous vous surprenez à écrire TOUJOURS ou JAMAIS en majuscules, ou à imposer des structures ultra-rigides, voyez-y un signal d'alerte : si possible, reformulez et explicitez le raisonnement pour que le modèle comprenne pourquoi ce que vous demandez est important. C'est une démarche plus intelligente, plus puissante et plus efficace.

4. **Repérer les tâches répétées entre les cas de test.** Lisez les transcriptions des exécutions de test et vérifiez si les sous-agents ont tous écrit indépendamment des scripts d'aide similaires ou suivi la même démarche en plusieurs étapes. Si les 3 cas de test ont conduit le sous-agent à écrire un `create_docx.py` ou un `build_chart.py`, c'est une indication forte que la compétence devrait intégrer ce script. Écrivez-le une fois pour toutes, placez-le dans `scripts/`, et indiquez à la compétence de s'en servir. Cela évitera à chaque appel futur de réinventer la roue.

Cette tâche est de première importance (nous cherchons à créer des milliards de valeur économique par an !) et votre temps de réflexion ne constitue pas un goulot d'étranglement : prenez votre temps et mûrissez bien les choses. Je vous conseille de rédiger une ébauche de révision, puis de la relire avec un regard neuf pour l'améliorer. Faites vraiment de votre mieux pour vous mettre à la place de l'utilisateur et cerner ses attentes et ses besoins.

### La boucle d'itération

Après avoir amélioré la compétence :

1. Appliquez vos modifications à la compétence
2. Relancez tous les cas de test dans un nouveau répertoire `iteration-<N+1>/`, y compris les exécutions de référence (baseline). Si vous créez une nouvelle compétence, la référence reste systématiquement `without_skill` (sans compétence) tout au long des itérations. Si vous améliorez une compétence existante, déterminez avec discernement ce qui fait le plus de sens comme référence : la version initiale fournie par l'utilisateur, ou l'itération précédente.
3. Lancez le visualiseur en faisant pointer `--previous-workspace` vers l'itération précédente
4. Attendez que l'utilisateur examine les résultats et vous prévienne qu'il a terminé
5. Lisez les nouveaux retours, améliorez à nouveau, et répétez le cycle

Poursuivez jusqu'à ce que :
- L'utilisateur se déclare satisfait
- Les retours soient tous vides (tout convient)
- Vous ne constatiez plus de progrès significatif

---

## Avancé : Comparaison à l'aveugle

Pour les situations où vous souhaitez une comparaison plus rigoureuse entre deux versions d'une compétence (par exemple, si l'utilisateur demande « la nouvelle version est-elle réellement meilleure ? »), un système de comparaison à l'aveugle est disponible. Consultez `agents/comparator.md` et `agents/analyzer.md` pour les détails. Le principe de base est le suivant : soumettez deux sorties à un agent indépendant sans lui révéler laquelle correspond à quelle version, et laissez-le juger de la qualité. Analysez ensuite les raisons de la victoire de la version retenue.

Ce mécanisme est facultatif, nécessite des sous-agents, et la plupart des utilisateurs n'en auront pas besoin. La boucle de revue humaine suffit généralement.

---

## Optimisation de la description

Le champ description de l'en-tête YAML de SKILL.md est le mécanisme principal déterminant si Claude invoque ou non une compétence. Après avoir créé ou amélioré une compétence, proposez d'optimiser la description pour obtenir une meilleure précision de déclenchement.

### Étape 1 : Générer les requêtes d'évaluation du déclenchement

Créez 20 requêtes d'évaluation : un mélange de requêtes devant déclencher la compétence (should-trigger) et ne devant pas la déclencher (should-not-trigger). Enregistrez-les au format JSON :

```json
[
  {"query": "l'invite de l'utilisateur", "should_trigger": true},
  {"query": "une autre invite", "should_trigger": false}
]
```

Les requêtes doivent être réalistes et correspondre à ce qu'un utilisateur de Claude Code ou Claude.ai écrirait réellement. Pas des demandes abstraites, mais des demandes concrètes, précises et suffisamment détaillées. Par exemple : des chemins de fichiers, du contexte personnel sur le métier ou la situation de l'utilisateur, des noms de colonnes et des valeurs, des noms d'entreprises, des URL. Un brin de mise en contexte. Certaines requêtes peuvent être écrites en minuscules, comporter des abréviations, des fautes de frappe ou un style relâché. Variez les longueurs et concentrez-vous sur les cas limites plutôt que sur des cas évidents (l'utilisateur aura l'occasion de les valider).

Mauvais exemples : `"Formate ces données"`, `"Extrais le texte du PDF"`, `"Crée un graphique"`

Bon exemple : `"bon alors ma cheffe vient de m'envoyer ce fichier xlsx (il est dans mes téléchargements, il s'appelle un truc du genre 'Q4 sales final FINAL v2.xlsx') et elle veut que j'ajoute une colonne avec la marge bénéficiaire en pourcentage. Le chiffre d'affaires est en colonne C et les coûts en colonne D je crois"`

Pour les requêtes **devant déclencher la compétence** (8 à 10), visez la couverture. Proposez différentes formulations de la même intention, certaines formelles, d'autres familières. Intégrez des cas où l'utilisateur ne nomme pas explicitement la compétence ni le format de fichier, mais en a manifestement besoin. Ajoutez quelques cas d'usage rares et des situations où cette compétence est en concurrence avec une autre mais doit l'emporter.

Pour les requêtes **ne devant pas déclencher la compétence** (8 à 10), les plus précieuses sont les faux amis : des requêtes partageant des mots-clés ou des concepts avec la compétence, mais réclamant en réalité un traitement différent. Pensez à des domaines adjacents, à des formulations ambiguës où une simple correspondance par mot-clé déclencherait la compétence à tort, ou à des cas où la requête effleure ce que fait la compétence, mais dans un contexte où un autre outil est plus pertinent.

Le piège absolu à éviter : ne rendez pas les requêtes négatives triviales ou manifestement hors-sujet. Proposer « Écris une fonction fibonacci » comme test négatif pour une compétence PDF est trop facile et ne teste rien. Les cas négatifs doivent présenter une réelle difficulté.

### Étape 2 : Relire avec l'utilisateur

Présentez l'ensemble d'évaluation à l'utilisateur pour relecture à l'aide du modèle HTML :

1. Lisez le modèle dans `assets/eval_review.html`
2. Remplacez les variables de substitution :
   - `__EVAL_DATA_PLACEHOLDER__` → le tableau JSON des éléments d'évaluation (sans guillemets autour : il s'agit d'une affectation de variable JavaScript)
   - `__SKILL_NAME_PLACEHOLDER__` → le nom de la compétence
   - `__SKILL_DESCRIPTION_PLACEHOLDER__` → la description actuelle de la compétence
3. Écrivez le résultat dans un fichier temporaire (ex. `/tmp/eval_review_<skill-name>.html`) et ouvrez-le : `open /tmp/eval_review_<skill-name>.html`
4. L'utilisateur peut modifier les requêtes, basculer l'indicateur should-trigger, ajouter/supprimer des entrées, puis cliquer sur « Export Eval Set »
5. Le fichier est téléchargé dans `~/Downloads/eval_set.json` — vérifiez le dossier Téléchargements pour récupérer la version la plus récente au cas où il y en aurait plusieurs (ex. `eval_set (1).json`)

Cette étape est déterminante : de mauvaises requêtes d'évaluation conduisent inévitablement à de mauvaises descriptions.

### Étape 3 : Exécuter la boucle d'optimisation

Indiquez à l'utilisateur : « Cela va prendre un peu de temps — je vais lancer la boucle d'optimisation en arrière-plan et venir vérifier son avancement régulièrement. »

Enregistrez l'ensemble d'évaluation dans l'espace de travail, puis lancez le traitement en arrière-plan :

```bash
python -m scripts.run_loop \
  --eval-set <path-to-trigger-eval.json> \
  --skill-path <path-to-skill> \
  --model <model-id-powering-this-session> \
  --max-iterations 5 \
  --verbose
```

Utilisez l'identifiant de modèle (model ID) issu de votre prompt système (celui qui propulse la session actuelle) afin que le test de déclenchement corresponde exactement à ce que l'utilisateur expérimente.

Pendant que la boucle tourne, surveillez périodiquement la sortie pour tenir l'utilisateur informé de l'itération en cours et de l'évolution des scores.

Le script prend en charge l'intégralité de la boucle d'optimisation de manière automatisée. Il sépare l'ensemble d'évaluation en 60 % pour l'entraînement (train) et 40 % pour le test indépendant (test), évalue la description courante (en exécutant chaque requête 3 fois pour obtenir un taux de déclenchement fiable), puis sollicite Claude pour proposer des améliorations en fonction des échecs constatés. Il réévalue chaque nouvelle description sur le jeu d'entraînement et sur le jeu de test, en itérant jusqu'à 5 fois. Une fois terminé, il ouvre un rapport HTML dans le navigateur détaillant les résultats par itération et renvoie un JSON contenant `best_description` — sélectionnée sur la base du score de test plutôt que du score d'entraînement pour prévenir le surapprentissage.

### Comment fonctionne le déclenchement des compétences

Comprendre le mécanisme de déclenchement permet de concevoir de meilleures requêtes d'évaluation. Les compétences apparaissent dans la liste `available_skills` de Claude avec leur nom et leur description, et Claude décide ou non de consulter une compétence en se basant sur cette description. Point essentiel : Claude ne fait appel aux compétences que pour les tâches qu'il ne peut pas aisément accomplir par lui-même. Des requêtes simples en une seule étape comme « lis ce PDF » peuvent très bien ne pas déclencher de compétence, même si la description correspond parfaitement, car Claude peut les traiter directement avec ses outils de base. En revanche, les requêtes complexes, en plusieurs étapes ou spécialisées déclenchent les compétences de façon fiable lorsque la description concorde.

Par conséquent, vos requêtes d'évaluation doivent être suffisamment substantielles pour que Claude tire un réel bénéfice à consulter une compétence. Les requêtes simplistes du style « lis le fichier X » constituent de mauvais cas de test : elles ne déclencheront pas les compétences, quelle que soit la qualité de la description.

### Étape 4 : Appliquer le résultat

Récupérez `best_description` depuis la sortie JSON et mettez à jour l'en-tête de SKILL.md de la compétence. Montrez à l'utilisateur l'avant/après et communiquez les scores obtenus.

---

### Empaqueter et présenter (uniquement si l'outil `present_files` est disponible)

Vérifiez si vous avez accès à l'outil `present_files`. Si ce n'est pas le cas, ignorez cette étape. Si vous y avez accès, empaquetez la compétence et présentez le fichier .skill à l'utilisateur :

```bash
python -m scripts.package_skill <path/to/skill-folder>
```

Une fois l'empaquetage terminé, orientez l'utilisateur vers le chemin du fichier `.skill` obtenu afin qu'il puisse l'installer.

---

## Instructions spécifiques à Claude.ai

Dans Claude.ai, le flux de travail de base reste le même (brouillon → test → revue → amélioration → répétition), mais comme Claude.ai ne dispose pas de sous-agents, certains mécanismes s'adaptent :

**Exécution des cas de test** : L'absence de sous-agents exclut l'exécution parallèle. Pour chaque cas de test, lisez le fichier SKILL.md de la compétence, puis suivez ses instructions pour exécuter vous-même l'invite de test. Traitez-les l'une après l'autre. C'est moins rigoureux qu'avec des sous-agents indépendants (vous avez rédigé la compétence et vous l'exécutez également, vous disposez donc de tout le contexte), mais cela offre un contrôle de cohérence utile — que l'étape de revue humaine vient compenser. Omettez les exécutions de référence : utilisez simplement la compétence pour accomplir la tâche demandée.

**Revue des résultats** : Si vous ne pouvez pas ouvrir de navigateur (par exemple, si la machine virtuelle de Claude.ai n'a pas d'interface graphique ou si vous êtes sur un serveur distant), faites l'impasse sur le visualiseur dans le navigateur. Présentez plutôt les résultats directement au sein de la conversation. Pour chaque cas de test, affichez l'invite et la sortie obtenue. Si la sortie est un fichier que l'utilisateur doit consulter (comme un .docx ou un .xlsx), enregistrez-le dans le système de fichiers et indiquez son emplacement afin qu'il puisse le télécharger et l'inspecter. Demandez ses retours dans le fil : « Qu'en pensez-vous ? Y a-t-il des éléments à modifier ? »

**Benchmarks** : Laissez de côté le benchmark quantitatif : il repose sur des comparaisons de référence qui perdent leur sens sans sous-agents. Concentrez-vous sur les retours qualitatifs de l'utilisateur.

**La boucle d'itération** : Identique à la démarche standard — améliorer la compétence, relancer les cas de test, demander des retours — simplement sans visualiseur dans le navigateur entre les étapes. Vous pouvez toujours organiser les résultats dans des répertoires d'itération sur le système de fichiers si vous y avez accès.

**Optimisation de la description** : Cette section nécessite l'outil en ligne de commande `claude` (spécifiquement `claude -p`), qui n'est disponible que dans Claude Code. Ignorez-la sur Claude.ai.

**Comparaison à l'aveugle** : Nécessite des sous-agents. À ignorer.

**Empaquetage** : Le script `package_skill.py` fonctionne partout où Python et un système de fichiers sont disponibles. Sur Claude.ai, vous pouvez l'exécuter et l'utilisateur pourra télécharger le fichier `.skill` généré.

**Mise à jour d'une compétence existante** : Il se peut que l'utilisateur vous demande de mettre à jour une compétence existante et non d'en créer une nouvelle. Dans ce cas :
- **Conservez le nom d'origine.** Relevez le nom du répertoire de la compétence et le champ frontmatter `name` : réutilisez-les à l'identique. Par exemple, si la compétence installée s'appelle `research-helper`, produisez `research-helper.skill` (et non `research-helper-v2`).
- **Copiez vers un emplacement accessible en écriture avant modification.** Le chemin de la compétence installée peut être en lecture seule. Copiez vers `/tmp/skill-name/`, effectuez les modifications à cet endroit et empaquetez depuis la copie.
- **En cas d'empaquetage manuel, préparez d'abord dans `/tmp/`**, puis copiez vers le répertoire de sortie : les écritures directes peuvent échouer pour des raisons de permissions.

---

## Instructions spécifiques à Cowork

Si vous êtes dans Cowork, voici les points essentiels à retenir :

- Vous disposez de sous-agents, ce qui signifie que le flux principal (lancer les cas de test en parallèle, exécuter les références, noter, etc.) fonctionne pleinement. (Néanmoins, si vous rencontrez d'importants problèmes de délais d'attente dépassés, il est tout à fait acceptable d'exécuter les invites de test en série plutôt qu'en parallèle.)
- Vous n'avez ni navigateur ni affichage graphique : lors de la génération du visualiseur d'évaluation, utilisez `--static <output_path>` pour produire un fichier HTML autonome au lieu de lancer un serveur. Proposez ensuite un lien sur lequel l'utilisateur peut cliquer pour ouvrir le fichier HTML dans son propre navigateur.
- Pour une raison indéterminée, la configuration de Cowork a tendance à dissuader Claude de générer le visualiseur d'évaluation après avoir exécuté les tests. Pour lever toute ambiguïté : que vous soyez dans Cowork ou dans Claude Code, après avoir exécuté les tests, vous devez TOUJOURS générer le visualiseur d'évaluation pour que l'humain puisse examiner les exemples avant de réviser la compétence vous-même et d'essayer de corriger des éléments, en utilisant `generate_review.py` (sans coder votre propre HTML maison). Désolé d'avance pour les majuscules, mais insistons : GÉNÉREZ LE VISUALISEUR D'ÉVALUATION *AVANT* d'évaluer vous-même les entrées. Vous devez les soumettre au regard humain LE PLUS VITE POSSIBLE !
- La gestion des retours fonctionne différemment : en l'absence de serveur actif, le bouton « Submit All Reviews » du visualiseur téléchargera `feedback.json` sous forme de fichier. Vous pourrez ensuite le lire depuis cet emplacement (il vous faudra peut-être demander l'accès au préalable).
- L'empaquetage fonctionne sans problème : `package_skill.py` ne requiert que Python et un système de fichiers.
- L'optimisation de la description (`run_loop.py` / `run_eval.py`) fonctionne très bien dans Cowork puisqu'elle exploite `claude -p` via un sous-processus sans faire appel à un navigateur, mais réservez-la pour le moment où la compétence sera entièrement achevée et où l'utilisateur aura confirmé qu'elle lui convient.
- **Mise à jour d'une compétence existante** : L'utilisateur peut vous demander d'actualiser une compétence déjà en place plutôt que d'en concevoir une nouvelle. Suivez dans ce cas les directives de mise à jour indiquées dans la section Claude.ai ci-dessus.

---

## Fichiers de référence

Le répertoire agents/ contient des instructions destinées à des sous-agents spécialisés. Consultez-les dès que vous devez lancer le sous-agent concerné.

- `agents/grader.md` — Comment évaluer les assertions face aux sorties
- `agents/comparator.md` — Comment réaliser une comparaison A/B à l'aveugle entre deux sorties
- `agents/analyzer.md` — Comment analyser les raisons de la victoire d'une version sur une autre

Le répertoire references/ contient de la documentation complémentaire :
- `references/schemas.md` — Structures JSON pour evals.json, grading.json, etc.

---

Rappelons une dernière fois la boucle principale pour insister sur l'essentiel :

- Définir le périmètre et la fonction de la compétence
- Rédiger ou modifier la compétence
- Exécuter Claude avec accès à la compétence sur les invites de test
- Évaluer les sorties de concert avec l'utilisateur :
  - Créer benchmark.json et exécuter `eval-viewer/generate_review.py` pour aider l'utilisateur à les examiner
  - Exécuter les évaluations quantitatives
- Répéter le cycle jusqu'à ce que vous et l'utilisateur soyez pleinement satisfaits
- Empaqueter la compétence finale et la transmettre à l'utilisateur.

Pensez à consigner ces étapes dans votre TodoList si vous disposez d'un tel outil, afin de n'en omettre aucune. Si vous évoluez dans Cowork, inscrivez expressément dans votre TodoList : « Créer le JSON d'évaluations et exécuter `eval-viewer/generate_review.py` pour que l'humain puisse examiner les cas de test », pour garantir que cette étape soit bien menée à bien.

Bonne chance !
