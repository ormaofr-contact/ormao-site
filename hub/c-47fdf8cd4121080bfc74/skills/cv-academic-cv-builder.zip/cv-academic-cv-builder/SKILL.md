---
name: academic-cv-builder
description: Met en forme des CV pour des postes universitaires avec publications, subventions et enseignement
---

# Academic CV Builder

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Postule à des postes académiques (corps professoral, recherche, post-doctorat)
- Doit créer ou mettre à jour un curriculum vitae
- Souhaite mettre en forme ses publications, subventions et son expérience d'enseignement
- Évolue dans le milieu universitaire ou effectue une transition vers des carrières académiques
- Mentionne : « CV académique », « curriculum vitae », « poste professoral », « CV recherche », « CV professeur »

## Capacités principales

- Structurer des CV pour des postes académiques
- Mettre en forme les publications, présentations et subventions
- Organiser l'expérience d'enseignement et de recherche
- Inclure les sections académiques appropriées
- Adapter le contenu selon les différents rôles académiques (tenure-track, post-doctorat, chargé de cours)
- Équilibrer la recherche, l'enseignement et le service à la communauté universitaire

## CV académique vs CV classique (Resume)

| CV classique (Resume) | CV académique |
|-----------------------|---------------|
| 1-2 pages | 2-20+ pages (la longueur augmente avec la carrière) |
| Met en valeur l'expérience pertinente | Bilan exhaustif |
| Axé sur les résultats | Axé sur l'érudition et les travaux de recherche |
| Mots-clés de l'industrie | Expertise disciplinaire |
| Section compétences mise en avant | Publications mises en avant |
| Formation minimale | Formation détaillée |

## Sections standard d'un CV académique

### Ordre typique

```
1. Coordonnées
2. Formation (Education)
3. Postes de recherche / Postes académiques
4. Publications
5. Présentations
6. Subventions et financements (Grants & Funding)
7. Expérience d'enseignement (Teaching Experience)
8. Mentorat et encadrement (Mentoring)
9. Service à la communauté universitaire
10. Affiliations professionnelles
11. Prix et distinctions
12. Références (ou « Disponibles sur demande »)
```

### L'ordre des sections varie selon :
- **Poste axé sur la recherche :** Publications, subventions, expérience de recherche en premier
- **Poste d'enseignement :** Enseignement, conception de cours en premier
- **Poste administratif :** Leadership, service en premier

## Guide section par section

### 1. Coordonnées (Contact Information)

```
PRÉNOM DEUXIÈME-PRÉNOM NOM, Ph.D.
Department of [Field]
[University Name]
[Building, Room Number]
[City, State ZIP]

Email: email@university.edu
Phone: (555) 123-4567
Web: www.yoursite.edu
ORCID: 0000-0000-0000-0000
```

### 2. Formation (Education)

**Format :** Diplôme, Domaine, Établissement, Année

```
EDUCATION

Ph.D. in Molecular Biology, Stanford University, 2019
  Dissertation: "Title of Your Dissertation"
  Advisor: Dr. Jane Smith
  Committee: Dr. A, Dr. B, Dr. C

M.S. in Biology, UC Berkeley, 2015

B.S. in Biochemistry, UCLA, 2013
  Summa Cum Laude
```

**À inclure :**
- Tous les diplômes (par ordre chronologique inverse)
- Titre de la thèse / du mémoire
- Directeur(s) de thèse
- Membres du jury de thèse (pour le doctorat)
- Distinctions (cum laude, félicitations, etc.)
- Mineures ou certificats pertinents

### 3. Postes de recherche / Postes académiques

```
ACADEMIC APPOINTMENTS

Assistant Professor of Biology, University of Michigan, 2022-Present
  Department of Molecular, Cellular, and Developmental Biology

Postdoctoral Fellow, MIT, 2019-2022
  Advisor: Dr. John Doe
  Lab: Computational Biology Lab

Graduate Research Assistant, Stanford University, 2014-2019
  Advisor: Dr. Jane Smith
```

### 4. Publications

**La section la plus importante pour les postes de recherche**

#### Options de mise en forme

**Option 1 : Liste numérotée (Courant en sciences)**
```
PUBLICATIONS

Peer-Reviewed Journal Articles

15. Last, F.M., Co-Author, A.B., & Senior, C.D. (2023). Article title. Journal Name, 45(2), 123-145. doi:10.1000/xyz

14. Last, F.M., & Co-Author, A.B. (2022). Article title. Journal Name, 44(1), 10-25. doi:10.1000/abc
```

**Option 2 : Catégories (Utile en cas de formats variés)**
```
PUBLICATIONS

Peer-Reviewed Journal Articles (15)

Book Chapters (3)

Books (1)

Under Review (2)

In Preparation (3)
```

**Détails de mise en forme :**
- **Mettez votre nom en gras** dans les listes d'auteurs
- Incluez les DOI dès qu'ils sont disponibles
- Indiquez les facteurs d'impact si demandé ou pertinent
- Signalez les étudiants co-auteurs par un astérisque*
- Certaines disciplines attendent un ordre chronologique inverse ; d'autres un ordre chronologique

**Catégories à envisager :**
- Articles de revues avec comité de lecture
- Livres et chapitres d'ouvrages
- Actes de conférences (proceedings)
- Rapports techniques
- Publications sans comité de lecture
- Travaux soumis / en cours d'évaluation (under review)
- Travaux en préparation

### 5. Présentations

```
PRESENTATIONS

Invited Talks

"Talk Title," Conference Name, Location, Date.
"Talk Title," Department Seminar, University Name, Date.

Conference Presentations

"Poster/Talk Title," Conference Name, Location, Date. [Poster/Oral]
```

**Catégoriser par :**
- Conférences invitées (keynotes, séminaires)
- Présentations en conférence
- Interventions universitaires internes
- Conférences grand public / vulgarisation

### 6. Subventions et financements (Grants & Funding)

```
GRANTS AND FUNDING

Awarded

NIH R01 (Co-PI), "Project Title," 2023-2028, $2.5M total ($500K to my lab)

NSF CAREER Award (PI), "Project Title," 2022-2027, $650,000

Internal Grant (PI), "Project Title," 2021, $25,000

Pending

NIH R21 (PI), "Project Title," submitted January 2024

Not Funded (Optional)

[Some fields expect you to list unfunded submissions]
```

**À inclure :**
- Organisme de financement et type de subvention
- Votre rôle (PI, Co-PI, Co-I)
- Titre du projet
- Dates
- Montant total (et montant alloué à votre laboratoire si partagé)

### 7. Expérience d'enseignement (Teaching Experience)

```
TEACHING EXPERIENCE

Courses Taught

BIOL 301: Molecular Biology (Instructor of Record)
  University of Michigan, Fall 2022, Fall 2023
  Enrollment: 45 students
  Developed new course curriculum

BIOL 101: Introduction to Biology (Lab Instructor)
  Stanford University, 2015-2018
  
Guest Lectures

"Topic," Course Name, Professor's Name, University, Date
```

**À inclure :**
- Numéro et intitulé du cours
- Votre rôle (responsable de cours, chargé de TD/TP, intervenant invité)
- Établissement et dates
- Nombre d'étudiants inscrits
- Conception de cours ou nouveaux programmes élaborés
- Synthèse des évaluations d'enseignement (si elles sont positives)

### 8. Mentorat et encadrement (Mentoring)

```
MENTORING

Graduate Students
- Student Name (Ph.D. expected 2025), Dissertation: "Title"
- Student Name (Ph.D. 2023), Current position: Postdoc at MIT

Postdoctoral Fellows
- Name (2021-2023), Current position: Assistant Professor at X

Undergraduate Researchers
- Name (2022-2023), Thesis: "Title," Current: PhD program at Y
- Name (2021-2022), Thesis: "Title," Current: Industry position
```

### 9. Service à la communauté universitaire (Service)

```
SERVICE

To the Profession
- Editorial Board Member, Journal Name, 2022-Present
- Grant Reviewer, NIH Study Section XYZ, 2023
- Conference Organizer, Conference Name, 2022

To the University
- Graduate Admissions Committee, 2022-Present
- Faculty Search Committee, 2023
- Curriculum Committee, 2022-2023

To the Department
- Seminar Coordinator, 2022-Present
- Undergraduate Advisor, 2022-Present
```

### 10. Affiliations professionnelles

```
PROFESSIONAL MEMBERSHIPS

American Society for Cell Biology (ASCB), 2015-Present
Society for Neuroscience (SfN), 2018-Present
```

### 11. Prix et distinctions

```
HONORS AND AWARDS

NSF CAREER Award, 2022
Best Paper Award, Conference Name, 2021
Outstanding Graduate Student Award, Stanford University, 2018
National Science Foundation Graduate Research Fellowship, 2015-2018
Phi Beta Kappa, 2013
```

## Priorités selon le type de poste

### Poste de professeur menant à la permanence (Tenure-Track)

**Mettre l'accent sur :**
1. Les publications (en particulier récentes, à fort impact)
2. Les subventions (en particulier les financements indépendants)
3. La trajectoire et le projet de recherche
4. L'expérience d'enseignement
5. Les antécédents d'encadrement / mentorat

### Poste de post-doctorat

**Mettre l'accent sur :**
1. Les publications (issues du doctorat et du post-doctorat)
2. L'expérience et les compétences de recherche
3. L'expérience de collaboration
4. Le potentiel de recherche futur
5. Tout financement ou bourse obtenu

### Poste d'enseignant / Chargé de cours (Lecturer)

**Mettre l'accent sur :**
1. L'expérience d'enseignement (cours dispensés, évaluations)
2. La conception de programmes et de cours
3. La formation pédagogique
4. L'encadrement d'étudiants de premier cycle
5. Les prix d'excellence en enseignement

### Chercheur scientifique (Research Scientist)

**Mettre l'accent sur :**
1. Les publications
2. Les compétences techniques
3. L'expérience en rédaction de demandes de subventions
4. Le bilan des collaborations
5. L'expérience de recherche pertinente

## Usages selon les disciplines

### Sciences exactes et naturelles (Biologie, Chimie, Physique)
- L'ordre des auteurs a une signification précise (premier auteur = principal contributeur, dernier auteur = responsable d'équipe/chercheur senior)
- Facteurs d'impact parfois mentionnés
- Listes numérotées de publications courantes
- Présentations en conférence moins valorisées que les articles publiés

### Sciences humaines (Histoire, Littérature, Philosophie)
- Publications en auteur unique très valorisées
- Ouvrages et monographies indispensables
- Présentations en conférence importantes
- Diffusion auprès du grand public (public scholarship) appréciée

### Sciences sociales
- Travaux individuels et collaboratifs valorisés
- Mixte d'articles de revues et d'ouvrages
- Recherche financée importante
- Impact sur les politiques publiques valorisé

## Recommandations de longueur de CV

| Étape de carrière | Longueur attendue |
|-------------------|-------------------|
| Doctorant | 2-4 pages |
| Post-doctorant | 3-6 pages |
| Début de carrière professorale | 5-10 pages |
| Milieu de carrière professorale | 10-20 pages |
| Professeur senior | 15-30+ pages |

**Règle :** Votre CV s'étoffe tout au long de votre carrière. Ne le meublez pas artificiellement, mais ne réduisez pas non plus sa longueur sans raison.

## Format de sortie

Lors de la création d'un CV académique :

```markdown
# STRUCTURE DU CV ACADÉMIQUE POUR [NOM]

## Ordre recommandé des sections
[Basé sur le type de poste et la discipline]

1. [Section]
2. [Section]
...

## Contenu des sections

### Formation
[Section formation mise en forme]

### Publications
[Mises en forme selon le style approprié à la discipline]

### [Autres sections]
[Contenu mis en forme]

---

## Remarques de mise en forme
- [Usages spécifiques à la discipline à respecter]
- [Recommandations de guide de style]

## Éléments à ajouter / mettre à jour
- [ ] [Élément manquant]
- [ ] [Élément nécessitant une mise à jour]
```

## Liste de contrôle du CV académique

- ✅ Coordonnées complètes (y compris ORCID le cas échéant)
- ✅ Formation incluant tous les diplômes, directeurs de recherche, thèses
- ✅ Publications correctement formatées avec votre nom mis en évidence
- ✅ Toutes les subventions listées avec montants et rôle précisé
- ✅ Expérience d'enseignement exhaustive
- ✅ Services à la communauté universitaire documentés
- ✅ Mise en forme cohérente sur l'ensemble du document
- ✅ Ordre chronologique inverse (généralement)
- ✅ Aucune période d'inactivité inexpliquée
- ✅ Mis à jour au cours des 6 derniers mois
