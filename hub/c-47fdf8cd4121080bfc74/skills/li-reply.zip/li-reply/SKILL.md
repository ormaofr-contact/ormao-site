---
name: li-reply
description: >-
  Gérer les réponses sous les propres publications LinkedIn de l'utilisateur -
  rédiger des réponses à chaque commentaire, triées selon celles qui méritent
  une réponse. À utiliser lorsque l'utilisateur colle les commentaires de sa
  publication, dit « réponds à ceci », « gère mes commentaires », « quelqu'un
  a dit X sous mon post », ou fait face à une critique ou à un prospect dans
  les commentaires.
---

# li-reply

Le fil de réponses sous votre propre publication est l'endroit où la portée se joue réellement. Chaque réponse constitue un deuxième événement d'engagement sur le post, et la première heure de réponses fait l'essentiel du travail. Mais la valeur n'est pas la même d'un commentaire à l'autre, c'est pourquoi cette compétence effectue un tri avant de rédiger.

## Entrée

L'utilisateur colle les commentaires, idéalement avec les noms et les postes. Les captures d'écran conviennent parfaitement. N'extrayez pas le fil à l'aide d'un outil de navigation.

## Trier d'abord

Classez chaque commentaire dans l'une des cinq catégories et annoncez le décompte à voix haute :

| catégorie | ce que c'est | ce qu'il reçoit |
| --- | --- | --- |
| **LEAD** | quelqu'un décrivant le problème que vous résolvez | une vraie réponse + une porte entrouverte en douceur |
| **SUBSTANCE** | apporte des données, exprime un désaccord, prolonge la réflexion | la réponse la plus longue du fil |
| **PEER** | un nom aux côtés duquel il est pertinent d'être vu | une réponse qui lui apporte de la valeur |
| **SUPPORT** | « super post », 🔥, une mention | un like, et une réponse de 3 à 8 mots maximum |
| **NOISE** | démarchage, spam, mauvaise foi | rien, ou une seule ligne sans relance |

Rédigez ensuite dans cet ordre, et arrêtez d'écrire dès qu'il n'y a plus de valeur ajoutée.

## Comment répondre

- **Répondez à la véritable question.** Si quelqu'un demande comment faire, expliquez-le-lui dans la réponse. Ne le renvoyez pas vers les messages privés pour obtenir une réponse qu'il aurait pu lire directement.
- **Utilisez son nom une seule fois**, au début, et jamais avec un point d'exclamation.
- **Adaptez-vous à sa longueur.** Un commentaire de deux lignes ne mérite pas une réponse de six lignes.
- **Face à un détracteur :** concédez d'abord la part de vérité, dans ses propres termes, puis maintenez votre position sur ce en quoi vous croyez. Ne supprimez jamais, ne soyez jamais sur la défensive, ne répondez jamais deux fois dans le même fil.
- **Face à un prospect :** répondez de manière exhaustive et publique. La porte entrouverte se résume à une phrase à la fin, et c'est une proposition d'aide, pas un pitch commercial. C'est la valeur apportée publiquement qui incitera la personne suivante à vous contacter en privé.
- **Face à un démarchage dans vos commentaires :** ignorez-le. Répondre lui donne de la visibilité.

## Sortie

Un seul bloc, regroupé par catégorie, chaque réponse prête à être copiée et déjà humanisée :

```
REPLIES  ·  17 comments  ·  1 LEAD, 3 SUBSTANCE, 4 PEER, 8 SUPPORT, 1 NOISE

LEAD
@Sarah Chen - "we have the same problem with proposals"
> The part that fixed it for us was pulling the pricing table out of the doc
> entirely and sending it as its own page. Cut a whole review round. Happy to
> send you the template if it is useful.

SUBSTANCE
@Marcus Webb - disagrees on cadence
> Fair, and 4x a week only worked because I had 8 months of posts behind it.
> From a standing start I would do what you said.

SUPPORT  (like these, reply to the first three)
@... "This is great" -> Thanks Dan.
...

NOISE  (1)
Skipped: an agency pitch. Replying gives it reach.
```

Puis le point de contrôle : **rien n'est publié tant que l'utilisateur n'a pas donné son accord.** C'est lui qui colle les réponses lui-même.
