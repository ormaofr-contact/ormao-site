---
name: ig-viral
description: >-
  Trouver les reels qui fonctionnent réellement en ce moment dans la niche de
  l'utilisateur, les classer selon l'écart de performance par rapport à leur
  propre compte, identifier la formule d'accroche utilisée par chacun et
  transformer le tout en un swipe file exploitable pour tourner des vidéos. À
  utiliser lorsque l'utilisateur dit « trouve des vidéos virales », « qu'est-ce
  qui marche en ce moment », « que publient les gens dans ma niche », « fais du
  reverse engineering sur ce compte », « crée-moi un swipe file », « pourquoi
  ce reel cartonne-t-il », ou lorsqu'il demande quoi créer ensuite sans avoir de
  données concrètes pour décider.
---

# ig-viral

La compétence de recherche. Tout le reste dans ce pack écrit ; celle-ci observe et analyse. Exécutez-la une fois par mois, pas tous les jours. Les formules durent une saison.

Un seul outil se trouve dans ce dossier et s'exécute ainsi :

```bash
python3 swipe.py captured.tsv --out ~/.claude/instagram/swipe.md
```

## L'idée fondamentale qui justifie cette démarche

**Le nombre brut de vues n'est pas une preuve.** Un compte avec deux millions d'abonnés qui fait 400 000 vues a simplement passé un mardi tranquille. Un compte avec quatre mille abonnés qui fait 400 000 vues a trouvé quelque chose, et ce quelque chose peut être reproduit.

Tout ici est donc classé selon le **multiple de surperformance** : le nombre de vues divisé par la médiane récente de ce même compte. Tout ce qui dépasse 3x constitue un signal. Tout ce qui est inférieur à 1,5x correspond au quotidien normal de ce compte et ne vous apprend rien, peu importe à quel point le chiffre paraît impressionnant.

Rassemblez des comptes **dont la taille ne dépasse pas environ 10 fois celle de l'utilisateur**. Une formule qui fonctionne à 2 millions d'abonnés fonctionne souvent uniquement parce que le compte a 2 millions d'abonnés.

## Étape 1 : choisir les comptes

Demandez à l'utilisateur 6 à 12 comptes, ou proposez-les et faites-les valider :

- **4 directs** - même niche, même offre, légèrement plus avancés.
- **4 adjacents** - niche différente, même audience. C'est ici que l'on emprunte des formats avant que quiconque dans la niche ne les utilise.
- **2 à 4 hors normes** - comptes beaucoup plus grands, uniquement pour le format, jamais pour la fréquence de publication ni pour le ton.

Demandez-lui également d'ouvrir sa propre collection de **posts enregistrés**. C'est le corpus le plus rapide et le plus pertinent qui existe, et il est déjà filtré par ses goûts.

## Étape 2 : aller observer

Utilisez l'outil de navigation disponible dans cette session : un navigateur intégré, une extension de navigateur connectée au Chrome de l'utilisateur ou un outil de computer-use. Il n'existe pas d'API pour cela et ce n'est pas nécessaire, car le volume est suffisamment restreint pour être lu manuellement.

**Règles non négociables :**

- **Ne vous connectez jamais à Instagram à la place de l'utilisateur et ne demandez jamais de mot de passe.** Si une page nécessite une connexion, c'est l'utilisateur qui doit déjà être connecté. Naviguez sur son navigateur en sa présence, ou demandez-lui de copier-coller les données.
- **Il s'agit d'une lecture, pas d'un scraping.** Dix comptes, une douzaine de reels chacun, à un rythme humain. La collecte automatisée en volume enfreint les conditions d'utilisation d'Instagram et entraîne le blocage des comptes. Ne concevez pas de crawler, n'utilisez pas de service de scraping et ne faites pas tourner cette tâche en boucle en arrière-plan.
- **Copiez la formule, jamais la vidéo.** La structure de l'accroche, l'architecture du contenu, la durée, le rythme des coupes. Pas leur script, pas leur voix, pas leur montage. Attribuez chaque ligne du swipe file au compte dont elle provient.

**Ce qu'il faut relever par reel**, dans les mots exacts du créateur :

| champ | notes |
| --- | --- |
| account | pseudonyme (handle) |
| followers | depuis le profil |
| median | évaluer à l'œil les 12 derniers reels et prendre la valeur médiane des vues |
| views | ce reel précis |
| hook | la première phrase, prononcée ou à l'écran, mot à mot, y compris les fautes de grammaire |
| on-screen | le premier texte affiché à l'écran, s'il est différent |
| length | durée en secondes |
| cta | ce qui est demandé à la fin |

La médiane est la donnée essentielle. Sans elle, vous vous retrouvez à classer par nombre d'abonnés, ce qui est précisément ce que cette compétence vise à éviter.

**Quand Instagram refuse de vous montrer assez d'éléments :** la même grammaire d'accroche fonctionne sur YouTube Shorts, où les compteurs de vues et les transcriptions sont publics et ne nécessitent aucune connexion. C'est un second corpus tout à fait légitime, et l'accroche parlée y est plus facile à extraire :

```bash
# nombre de vues pour les shorts d'une chaîne
python3 -m yt_dlp --flat-playlist --playlist-end 40 -J \
  "https://www.youtube.com/@HANDLE/shorts" > channel.json

# la première phrase prononcée d'un short, depuis ses sous-titres automatiques
python3 -m yt_dlp --skip-download --write-auto-subs --sub-langs "en.*" \
  --sub-format json3 -o hook "https://www.youtube.com/watch?v=VIDEO_ID"
```

Prenez chaque mot du sous-titre dont le timestamp est inférieur à 3,0 secondes. C'est l'accroche telle qu'elle a été prononcée, et non telle qu'elle a été rédigée.

## Étape 3 : classer les résultats

Remplissez un fichier séparé par des tabulations avec une ligne d'en-tête et lancez le script :

```
account	followers	median	views	hook
@someone	48000	11000	412000	nobody tells you your first 30 reels are supposed to flop
```

```bash
python3 swipe.py captured.tsv --out ~/.claude/instagram/swipe.md
```

Le script calcule le multiple de surperformance, identifie la formule d'accroche en utilisant les 26 mêmes formules dont s'inspire `/ig-reel`, note chaque accroche avec `hookscore.py`, et met en évidence ce qui distingue le tiers supérieur du tiers inférieur.

## Étape 4 : interpréter avec rigueur

Rapportez trois éléments, et rien de plus :

1. **Quelles formules sur-performent** dans le tiers supérieur, avec les décomptes. Deux formules qui apparaissent quatre fois chacune sur six comptes constituent une vraie découverte. Une formule qui apparaît deux fois ne l'est pas.
2. **Ce que le tiers supérieur partage sur le plan structurel** que le tiers inférieur n'a pas : longueur de l'accroche, caractère visuel de la révélation, présence de mouvement dès la première image, emplacement de l'appel à l'action.
3. **Les lignes non classifiées.** Chaque accroche que le classificateur n'a pas pu identifier est soit du bruit, soit une formule qui ne figure pas encore dans `hooks.json`. Relisez-les manuellement. C'est la colonne la plus précieuse des résultats, et c'est pour cette raison que le script affiche le décompte.

Indiquez ensuite la taille de l'échantillon et le niveau de confiance avec des mots simples. Quarante reels répartis sur six comptes justifient une conclusion. Douze ne suffisent pas, et le reconnaître fait toute la différence entre une recherche méthodique et de l'astrologie.

## Étape 5 : transformer les données en idées de tournage

Pour les trois formules de tête, rédigez **la version de l'utilisateur** : sa propre histoire, son propre chiffre, dans le format qui fonctionne actuellement. Transmettez chacune d'entre elles à `/ig-reel` avec l'identifiant de formule déjà défini.

Ne renvoyez jamais simplement « fais un reel comme celui-ci ». Fournissez une phrase d'accroche concrète que l'utilisateur pourrait prononcer dès demain.

## Sortie

```
SWIPE  ·  38 reels  ·  7 accounts  ·  baseline: account median

OUTLIERS (above 3x)
  38.4x  hook 86  #3  Nobody Tells You   @acct_a    412,000  (median 10,700)
  11.2x  hook 79  #9  The Steal          @acct_c    180,000  (median 16,100)
  ...

WHAT IS OVER-INDEXING
  #3 Nobody Tells You   x5 in the top third, 0 in the bottom
  #2 Negative Command   x4
  median hook length    8 words up top, 19 at the bottom

UNCLASSIFIED (6)
  Two of these are the same shape and it is not in hooks.json: a hook that
  opens on someone else's comment read out loud. Worth adding.

YOUR VERSION
  #3  "Nobody tells you the first 20 proposals are supposed to lose."
  ...
```

Enregistrez le swipe file dans `~/.claude/instagram/swipe.md`. `/ig-reel` et `/ig-plan` le lisent tous les deux, ce qui est tout l'intérêt : une fois cette étape exécutée, le reste du pack travaille à partir des données réelles de l'utilisateur plutôt qu'à partir de réglages par défaut.

Cette compétence ne publie, ne suit, ne like et n'envoie de message à personne. Elle se contente de lire.
