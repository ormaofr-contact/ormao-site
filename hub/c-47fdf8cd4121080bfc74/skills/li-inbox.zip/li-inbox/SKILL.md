---
name: li-inbox
description: >-
  Trie la boîte de réception LinkedIn : classe les demandes de connexion et les messages privés en prospects, recruteurs, pairs et spams, et rédige les réponses qui méritent d'être envoyées. À utiliser lorsque l'utilisateur dit « ma boîte de réception est un bazar », « trie mes messages », « est-ce que je devrais répondre à ça », colle une série de messages LinkedIn ou est submergé par les demandes de connexion.
---

# li-inbox

La plupart des boîtes de réception LinkedIn sont composées à 80 % de bruit, et le coût de ce bruit est que les 20 % restants restent sans réponse pendant une semaine. Cette compétence fait le tri, puis ne rédige que ce qui vaut la peine d'être écrit.

## Entrée

L'utilisateur colle les messages. Les captures d'écran sont acceptées. Ne vous connectez pas à son compte et ne lisez pas sa boîte de réception avec un outil de navigation.

## Trier en cinq catégories

| catégorie | signal | action |
| --- | --- | --- |
| **LEAD** | décrit un problème que l'utilisateur résout, ou propose de travailler ensemble | répondre aujourd'hui, réponse complète |
| **RECRUITER** | un poste, une entreprise, une fourchette de rémunération | répondre si le poste est réel, une seule ligne sinon |
| **PEER** | quelqu'un du même domaine qui a quelque chose à dire | répondre cette semaine, rester humain |
| **ASK** | demande un conseil, du temps, une mise en relation, un service | répondre si cela demande peu d'effort et est précis, refuser poliment sinon |
| **SPAM** | pitch d'agence, séquence de prospection, crypto, « petite question » sans question | archiver, pas de réponse |

Affichez d'abord les totaux. Voir « 3 leads, 2 recruiters, 41 spam » apporte l'essentiel de la valeur.

## Détecter une séquence

La prospection automatisée a une forme typique : une note d'invitation sans précision, un message qui arrive quelques minutes après l'acceptation, « une petite question », « j'ai remarqué que vous êtes dans le secteur {industry} », un lien de calendrier dès le premier message, puis une relance exactement quatre jours plus tard. Lorsque vous repérez ce schéma, marquez-le comme SPAM et indiquez quel indice l'a trahi. L'utilisateur ne doit aucune réponse à un script.

## Réponses

- **LEAD** - répondez précisément à la question posée dans le message, de manière complète et gratuite. Si cela correspond à une opportunité, l'offre tient en une seule phrase à la fin. Si ce n'est pas le cas, dites-le et orientez la personne vers une ressource utile. Les deux issues sont positives.
- **RECRUITER** - si le poste est véritablement intéressant, demandez les trois informations que le message a omises : fourchette de rémunération, niveau de séniorité et présence sur site. Si ce n'est pas le cas, répondez en une ligne : pas en recherche, ravi de recommander quelqu'un (et pensez-le vraiment).
- **ASK** - si cela prend moins de dix minutes et que la demande est spécifique, répondez-y. S'il s'agit d'un « pourrions-nous échanger autour d'un café / bénéficier de vos lumières », refusez chaleureusement en une phrase et donnez directement la réponse que vous auriez donnée lors de l'appel. C'est la façon polie de faire, et c'est aussi la plus utile.
- **REFUS** - ils doivent être courts, chaleureux et définitifs. Pas de « reparlons-en au T3 » s'il n'y a pas de T3.

## Sortie

Regroupé par catégorie, les totaux en premier, des brouillons uniquement pour les catégories qui reçoivent une réponse, chacun rendu naturel et humain. Enfin, le point de contrôle : c'est l'utilisateur qui les envoie.

```
INBOX  ·  52 items  ·  3 LEAD, 2 RECRUITER, 4 PEER, 2 ASK, 41 SPAM

SPAM  (41) - archive. 38 are the same sequence: no-specifics invite,
"quick question" within 4 minutes of accept, calendar link in message one.
