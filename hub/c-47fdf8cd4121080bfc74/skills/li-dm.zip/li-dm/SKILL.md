---
name: li-dm
description: >-
  Rédigez des notes d'invitation et des relances par message privé qui
  obtiennent des réponses : l'invitation de 200 caractères, le premier message
  et les deux relances. À utiliser lorsque l'utilisateur dit « rédige une demande
  de connexion », « envoie un MP à cette personne », « message de prospection »,
  « comment faire une relance », ou contacte quelqu'un en particulier sur LinkedIn.
---

# li-dm

La note d'invitation fait 200 caractères. Le premier MP détermine s'il y en aura
un deuxième. Ni l'un ni l'autre n'est un pitch de vente.

## Avant de rédiger, obtenez les détails précis

Demandez, en une seule question groupée :

1. **Qui** - nom, poste, entreprise.
2. **L'accroche** - la véritable raison de prendre contact maintenant. Un post
   qu'elle a rédigé, une nouveauté lancée par son entreprise, une relation en
   commun, une conférence donnée. Pas « cette personne correspond à mon ICP ».
3. **Ce que veut l'utilisateur** - une conversation, une recommandation, un
   emploi, une vente. Soyez honnête en interne, même si le message ne commence
   pas directement par cela.

S'il n'y a aucune raison précise d'envoyer un message à cette personne
aujourd'hui, dites-le. Un message sans motif particulier est ce que tout le monde
envoie, et c'est la raison pour laquelle leur taux de réponse est de 2 %.

## La note d'invitation (200 caractères)

```
{one specific reference to them} + {one line of who you are} + {no ask}
```

La note ne demande rien. Elle existe pour rendre l'acceptation évidente. Moins de
200 caractères espaces compris — comptez-les et affichez le décompte.

```
Saw your post on killing the discovery call - we did the same thing in March
and it worked. I run ops at a 12-person studio. Would like to follow along.
                                                                    [187/200]
```

## Le premier message, après acceptation

Attendez un jour. Puis :

- **Deux à quatre phrases.** Un pavé de texte finit à la corbeille.
- **Faites référence à l'élément précis** mentionné dans la note — la continuité
  est la raison d'être de la spécificité de la note.
- **Donnez quelque chose avant de demander.** Un chiffre, un modèle, un nom, une
  réponse.
- **Une seule demande, et restez modeste.** « Seriez-vous ouvert à un échange
  de 15 minutes ? » est bien plus efficace que « laissez-moi vous présenter notre
  plateforme ».
- **Pas de lien de calendrier dans le premier message.** Cela ressemble à un
  tunnel de conversion, car c'en est un.

## Relances

Deux. C'est le chiffre exact.

- **+4 jours** - apportez un élément nouveau. Jamais de « je me permets de
  remonter ce message » ou « pour faire suite à mon dernier message ». Si vous
  n'avez rien de nouveau à apporter, ne relancez pas.
- **+10 jours** - le message de clôture. Dites que vous vous arrêtez là, et
  pensez-le vraiment. Celui-ci génère une part surprenante du total des
  réponses, car il lève la pression.

Puis arrêtez-vous. Une troisième relance ne convertit personne et ruine la
relation.

## À ne jamais faire

- N'envoyez jamais de séquence automatisée d'invitations ou de messages. Les
  outils d'automatisation de prospection violent les Conditions d'utilisation de
  LinkedIn et entraînent la restriction des comptes.
- N'inventez jamais une relation commune, une école partagée ou le fait d'avoir
  lu quelque chose que l'utilisateur n'a pas lu.
- N'écrivez jamais un message qui commence par « J'espère que vous allez bien ».
- N'envoyez jamais plus de 20 invitations par jour. Au-delà, LinkedIn bride le
  compte, et un compte bridé est un compte mort.

## Format de sortie

La note d'invitation avec son décompte de caractères, le premier message et les
deux relances avec le jour d'envoi prévu. Le tout humanisé via `/li-human`.
L'utilisateur envoie chacun d'eux manuellement.
