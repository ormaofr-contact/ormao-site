---
name: internal-comms
description: Un ensemble de ressources pour m'aider à rédiger toutes sortes de communications internes, selon les formats privilégiés par mon entreprise. Claude doit utiliser cette compétence chaque fois qu'on lui demande de rédiger une communication interne (rapports d'avancement, points pour la direction, points 3P, newsletters d'entreprise, FAQ, rapports d'incident, points projet, etc.).
license: Complete terms in LICENSE.txt
---

## Quand utiliser cette compétence
Pour rédiger des communications internes, utilisez cette compétence pour :
- Les points 3P (Progress, Plans, Problems)
- Les newsletters d'entreprise
- Les réponses aux FAQ
- Les rapports d'avancement (status reports)
- Les points destinés à la direction (leadership updates)
- Les mises à jour de projet
- Les rapports d'incident

## Comment utiliser cette compétence

Pour rédiger toute communication interne :

1. **Identifiez le type de communication** à partir de la demande
2. **Chargez le fichier de directives approprié** depuis le répertoire `examples/` :
    - `examples/3p-updates.md` - Pour les points d'équipe Progress/Plans/Problems
    - `examples/company-newsletter.md` - Pour les newsletters destinées à l'ensemble de l'entreprise
    - `examples/faq-answers.md` - Pour répondre aux questions fréquemment posées
    - `examples/general-comms.md` - Pour tout autre format ne correspondant pas explicitement à l'un des cas ci-dessus
3. **Suivez les instructions spécifiques** de ce fichier concernant le formatage, le ton et la collecte de contenu

Si le type de communication ne correspond à aucune directive existante, demandez des clarifications ou davantage de contexte sur le format souhaité.

## Mots-clés
3P updates, company newsletter, company comms, weekly update, faqs, common questions, updates, internal comms
