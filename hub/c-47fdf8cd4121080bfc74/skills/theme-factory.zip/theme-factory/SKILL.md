---
name: theme-factory
description: Boîte à outils pour appliquer un style visuel avec un thème à des artefacts. Ces artefacts peuvent être des diapositives, des documents, des rapports, des pages de destination HTML, etc. Comprend 10 thèmes prédéfinis avec couleurs et polices à appliquer à tout artefact créé, ou permet de générer un nouveau thème à la volée.
license: Complete terms in LICENSE.txt
---


# Compétence Theme Factory

Cette compétence fournit une collection sélectionnée de thèmes professionnels de polices et de couleurs, chacun doté de palettes de couleurs et d'associations typographiques soigneusement choisies. Une fois un thème sélectionné, il peut être appliqué à n'importe quel artefact.

## Objectif

Pour appliquer un style cohérent et professionnel à des présentations de diapositives, utilisez cette compétence. Chaque thème comprend :
- Une palette de couleurs cohérente avec des codes hexadécimaux
- Des associations de polices complémentaires pour les titres et le corps du texte
- Une identité visuelle distincte adaptée à différents contextes et publics

## Instructions d'utilisation

Pour appliquer un style à une présentation ou à un autre artefact :

1. **Afficher la vitrine des thèmes** : Affichez le fichier `theme-showcase.pdf` pour permettre aux utilisateurs de visualiser l'ensemble des thèmes disponibles. Ne lui apportez aucune modification ; affichez simplement le fichier pour consultation.
2. **Demander leur choix** : Demandez quel thème appliquer à la présentation
3. **Attendre la sélection** : Obtenez une confirmation explicite sur le thème choisi
4. **Appliquer le thème** : Une fois le thème choisi, appliquez ses couleurs et polices à la présentation ou à l'artefact

## Thèmes disponibles

Les 10 thèmes suivants sont disponibles, chacun étant présenté dans `theme-showcase.pdf` :

1. **Ocean Depths** - Thème maritime professionnel et apaisant
2. **Sunset Boulevard** - Couleurs de coucher de soleil chaudes et éclatantes
3. **Forest Canopy** - Tons de terre naturels et enracinés
4. **Modern Minimalist** - Nuances de gris épurées et contemporaines
5. **Golden Hour** - Palette automnale riche et chaleureuse
6. **Arctic Frost** - Thème d'inspiration hivernale, frais et vivifiant
7. **Desert Rose** - Teintes poudrées douces et sophistiquées
8. **Tech Innovation** - Esthétique technologique audacieuse et moderne
9. **Botanical Garden** - Couleurs de jardin fraîches et végétales
10. **Midnight Galaxy** - Teintes profondes cosmiques et saisissantes

## Détails des thèmes

Chaque thème est défini dans le répertoire `themes/` avec des spécifications complètes comprenant :
- Une palette de couleurs cohérente avec des codes hexadécimaux
- Des associations de polices complémentaires pour les titres et le corps du texte
- Une identité visuelle distincte adaptée à différents contextes et publics

## Processus d'application

Une fois le thème souhaité sélectionné :
1. Lisez le fichier de thème correspondant dans le répertoire `themes/`
2. Appliquez de manière cohérente les couleurs et les polices spécifiées sur l'ensemble de la présentation
3. Assurez-vous d'un contraste et d'une lisibilité adéquats
4. Maintenez l'identité visuelle du thème sur toutes les diapositives

## Créer votre propre thème
Pour gérer les cas où aucun des thèmes existants ne convient à un artefact, créez un thème personnalisé. À partir des éléments fournis, générez un nouveau thème similaire à ceux présentés ci-dessus. Donnez au thème un nom dans le même esprit décrivant ce que représentent les combinaisons de polices et de couleurs. Utilisez toute description de base fournie pour choisir les couleurs et polices appropriées. Après avoir généré le thème, soumettez-le pour examen et vérification. Ensuite, appliquez le thème comme décrit ci-dessus.
