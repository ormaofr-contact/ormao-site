---
name: writing-for-agents
description: Rédaction de documents pour les agents. À utiliser lors de la création ou de l'édition de skills, ou lors de la modification de AGENTS.md ou CLAUDE.md.
---

Référence pour la rédaction de tout document consommé par un agent : un skill, un `AGENTS.md` / `CLAUDE.md`, ou un document accessible via un pointeur. Le format diffère ; la rédaction ne change pas : les mêmes leviers rendent chacun d'eux prévisible, puisque l'agent suit le même _processus_ à chaque exécution plutôt que de produire le même résultat.

Lorsque le document que vous rédigez est un skill, consultez [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md) pour le frontmatter, le choix d'invocation et les router skills.

## Pointeurs de contexte

Un **pointeur de contexte** est une référence conservée dans le contexte de l'agent qui désigne du contenu hors-contexte et encode la condition pour y accéder. La description d'un skill en est un ; une ligne dans `AGENTS.md` désignant un document est le même objet. La _formulation_ du pointeur, et non sa cible, détermine quand l'agent accède au contenu, et avec quelle fiabilité. Une cible indispensable derrière un pointeur mal formulé est un bug de variance : affinez d'abord la formulation, et n'intégrez le contenu en ligne que si cet affinage échoue.

Un pointeur accomplit deux fonctions : indiquer ce qu'est le contenu, et lister les **branches** qui doivent déclencher son accès (une branche est un cas distinct traité par le document, de sorte que différentes exécutions empruntent des chemins différents à travers celui-ci). Chaque mot d'un pointeur toujours chargé a un coût à chaque tour, ce qui justifie un élagage encore plus strict que pour le corps :

- **Placez le mot directeur en tête** : c'est au début du pointeur qu'il accomplit son travail de déclenchement.
- **Un seul déclencheur par branche.** Les synonymes qui renomment une même branche ne sont qu'une seule branche écrite deux fois ; fusionnez-les et ne conservez que les branches réellement distinctes.
- **Supprimez les éléments d'identité que le corps contient déjà.**

## Les deux charges

Chaque document et pointeur que vous ajoutez entame l'un de deux budgets :

- La **charge de contexte** est le coût du contenu toujours chargé dans la fenêtre de l'agent : une ligne dans `AGENTS.md`, une description de skill, tout élément présent dans le contexte à chaque tour, consommant des tokens et de l'attention qu'il soit déclenché ou non.
- La **charge cognitive** est le coût pour l'humain : savoir quels documents existent et quand recourir à chacun. L'humain est l'index. Ce n'est pas un coût à minimiser : c'est le prix de l'autonomie humaine ; consacrez-la là où le jugement humain compte, éliminez-la là où il n'a pas lieu d'être.

Le contenu accessible uniquement via un pointeur échappe à la charge de contexte au prix de la propre ligne du pointeur ; le contenu dépourvu de tout pointeur repose entièrement sur la charge cognitive.

## Hiérarchie de l'information

Un document se compose de deux types de contenu : les **étapes** (les actions ordonnées que l'agent exécute) et la **référence** (définitions, règles, faits consultés à la demande). Les deux se mélangent librement : tout en étapes (une recette), tout en référence (les règles d'une revue, ce skill), ou les deux. La décision fondamentale réside dans l'emplacement de chaque élément sur la **hiérarchie de l'information**, une échelle ordonnée selon l'urgence avec laquelle l'agent a besoin du contenu :

1. **Étape dans le fichier** est le niveau principal : ce que l'agent fait, dans l'ordre.
2. **Référence dans le fichier** est consultée à la demande. Souvent un ensemble de pairs légitimement plat (toutes les règles d'une revue au même échelon), ce qui est une bonne organisation, et non un défaut de conception.
3. **Référence déportée** est repoussée dans un fichier séparé, accessible par un pointeur de contexte, chargée uniquement lorsque le pointeur se déclenche. Va d'un fichier frère dans le même dossier jusqu'à une référence entièrement externe située n'importe où et vers laquelle n'importe quel document peut pointer.

Ne descendez pas assez d'éléments et le sommet s'alourdit ; descendez-en trop et vous masquez du contenu dont l'agent a réellement besoin. Cette tension constitue toute la décision.

La **divulgation progressive** est le déplacement vers le bas de l'échelle (hors du fichier principal et derrière un pointeur) afin que le sommet reste lisible. Ce n'est pas avant tout une optimisation de tokens : c'est ainsi que la hiérarchie est préservée. Le découpage en branches est le test de divulgation le plus net : intégrez directement ce dont chaque branche a besoin, et reléguez derrière un pointeur ce que seules certaines branches atteignent. Lorsqu'un document contient des étapes, une référence dans le fichier qui devrait être déportée les enterre et transforme leur prise en compte en un coup de dés : un levier de variance, pas seulement de lisibilité.

La **co-localisation** est son pendant au sein du fichier : là où l'échelle détermine _à quelle profondeur_ se situe un élément, la co-localisation décide de _ce qui se trouve à ses côtés_ une fois en place. Conservez la définition d'un concept, ses règles et ses avertissements sous un seul titre plutôt que de les disperser, de sorte que la lecture d'une partie entraîne celle de ses voisines. Le test : le document doit se lire comme une documentation rédigée pour l'agent. Le contenu regroupé se lit ainsi ; le contenu dispersé, non. (À distinguer de la duplication : celle-ci répète un même sens à deux endroits ; la dispersion fragmente un même sens à travers plusieurs.)

L'**étalement** est le mode de défaillance ici : un document tout simplement trop long, même si chaque ligne est active et unique. L'attention s'étiole sur ce surplus, et chaque ligne supplémentaire est une ligne de plus à maintenir pertinente. Le remède est l'échelle : déportez la référence derrière des pointeurs, et scindez par branche ou par séquence afin que chaque parcours n'emporte que ce dont il a besoin.

## Étapes et critères d'achèvement

Chaque étape se termine par un **critère d'achèvement**, la condition qui indique à l'agent que le travail est terminé. Deux propriétés en font un levier :

- **Clarté** : l'agent peut-il distinguer le fait d'avoir terminé de celui de ne pas avoir terminé ? Une limite floue (« compréhension atteinte ») incite à un **achèvement prématuré** : terminer l'étape avant qu'elle ne soit réellement finie, l'attention glissant vers le _fait d'avoir terminé_. Les étapes visibles encore à venir (les **étapes post-achèvement**) exercent une attraction ; la clarté du critère offre la résistance. Défendez dans l'ordre : **affinez d'abord la limite** (local et peu coûteux) ; seulement si elle est irréductiblement floue _et_ que vous observez une précipitation, masquez les étapes ultérieures en scindant la séquence. Masquer ne fonctionne qu'à travers une véritable frontière de contexte (un passage de relais ou une délégation à un sous-agent ; un appel inline laisse les étapes ultérieures dans le contexte et ne libère rien).
- **Exigence** : ce qu'il requiert. « Chaque modèle modifié est pris en compte » impose un travail approfondi là où « produire une liste de modifications » ne le fait pas. L'exigence suscite le **travail de fond** (les recherches approfondies que l'agent mène au sein de la tâche, sous-jacentes dans la formulation plutôt qu'écrites sous forme d'étape distincte), et elle n'est pas liée aux étapes : « chaque règle appliquée » lie un ensemble de références plates tout comme « chaque étape accomplie » lie une séquence, ce qui permet à un document uniquement constitué de références d'imposer tout de même une barre d'exhaustivité.

Les critères les plus solides sont à la fois vérifiables et exhaustifs.

## Quand scinder

Scinder un document en deux entame l'une des deux charges ; ne scindez donc que lorsque la séparation en vaut la peine :

- **Par séquence** : scindez une suite d'étapes lorsque les étapes post-achèvement incitent l'agent à bâcler celle qui précède. Les garder hors de vue encourage davantage de travail de fond sur la tâche en cours. Attention à l'inverse : fusionner des séquences expose les étapes ultérieures de chaque étape à la suite, incitant à un achèvement prématuré.
- **Par invocation**, propre aux skills : voir [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md).

## Mots directeurs

Un **mot directeur** est un concept compact déjà présent dans le pré-entraînement du modèle avec lequel l'agent réfléchit lors de l'exécution du document (_lesson_, _fog of war_, _tracer bullets_). Répété sous forme de token, jamais sous forme de phrase, il accumule une définition distribuée et ancre toute une zone de comportement en un minimum de tokens, en mobilisant des a priori déjà détenus par le modèle. En inventer un fonctionne si vous le définissez clairement, mais un mot forgé ne mobilise aucun a priori : vous payez en tokens de définition ce qu'un mot pré-entraîné fournit gratuitement ; privilégiez d'abord un mot existant.

Il ancre à deux niveaux. Dans le corps, l'**exécution** : l'agent adopte le même comportement chaque fois que le mot apparaît, et au sein d'une référence plate, il concentre l'attention sur une catégorie d'éléments à rechercher. Dans un pointeur, l'**invocation** : lorsque le même mot est présent dans vos prompts, votre documentation et votre base de code, l'agent relie ce langage partagé au contenu et y accède de manière plus fiable.

Traquez les occasions de refactoriser avec des mots directeurs. Une triade formulée à trois endroits, un pointeur consacrant une phrase entière à esquisser une seule idée. Chacun est un passage qui ne demande qu'à être condensé en un seul token :

- « rapide, déterministe, à faible surcharge » → _tight_ (une boucle _tight_).
- « une boucle en laquelle vous avez confiance » → _red_, transformant une condition floue en un état observable binaire (la boucle passe au _red_ sur le bug, ou pas).

Vous gagnez sur les deux plans : moins de tokens, et un ancrage plus net sur lequel l'agent peut appuyer sa réflexion. Partez du principe que chaque document comporte des reformulations que des mots directeurs peuvent éliminer. Partez à leur recherche.

La **négation** est le mode de défaillance corollaire de ce levier : piloter par l'interdiction amène le comportement interdit dans le contexte et le rend _plus_ disponible, et non moins. Dites _Ne pensez pas à un éléphant_, et l'éléphant est tout ce qui reste ; la négation est un modificateur faible que le concept fortement activé submerge, de sorte que l'interdiction se lit à moitié comme une consigne de faire la chose. Incitez par le **positif** : indiquez le comportement cible (« écrivez des commentaires d'une seule ligne ») pour que le comportement banni ne soit jamais prononcé. Une interdiction ne mérite sa place qu'en tant que garde-fou strict impossible à formuler positivement ; même alors, associez-la à la cible positive afin que l'attention se porte sur ce qu'il faut faire.

## Élagage

- Conservez chaque signification dans une **source unique de vérité** : un emplacement faisant autorité, de sorte que modifier le comportement ne nécessite qu'une modification à un seul endroit. La **duplication** (la même signification à plusieurs endroits) coûte de la maintenance et des tokens, et gonfle artificiellement l'importance d'une notion sur l'échelle au-delà de son rang réel. (L'inverse involontaire d'un mot directeur, qui répète délibérément un token, jamais la signification.)
- L'**environnement** est également une source de vérité (scripts dans `package.json`, fichiers de configuration, structure des répertoires, sortie de `--help`), et un document qui le reformule est un **cache** : une copie d'une recherche, ne justifiant sa charge que lorsque la recherche est coûteuse. Mettez en cache ce que l'agent ne peut pas trouver par simple observation : la convention non écrite, la raison derrière un choix, le piège qu'aucune configuration n'avoue. Laissez les vérifications d'un seul fichier ou d'une seule commande à l'environnement, où elles ne risquent pas de devenir obsolètes.
- Vérifiez la **pertinence** de chaque ligne : a-t-elle encore un impact sur ce que fait le document ? Une ligne perd sa pertinence lorsqu'elle n'a jamais d'impact sur la tâche (simple exposé, ou branche qui devrait être déportée) ou lorsqu'elle devient obsolète à mesure que le comportement ou le monde qu'elle décrit évolue. Des documents plus courts sont plus faciles à maintenir pertinents. Sans discipline d'élagage, le sort par défaut est la **sédimentation** : des couches obsolètes qui se déposent parce qu'ajouter semble sûr et supprimer semble risqué, jusqu'à ce qu'il faille forer à travers elles pour retrouver ce qui est encore actif.
- Traquez les **instructions sans effet** (no-ops) phrase par phrase : une consigne que le modèle respecte déjà par défaut consomme de la charge pour ne rien dire. Le test (cela modifie-t-il le comportement par rapport au comportement par défaut ?) est relatif au modèle, et non au lecteur : deux personnes en désaccord sur un no-op sont en désaccord sur le comportement par défaut, et tranchent en exécutant le document, non par débat. Lorsqu'une phrase échoue au test, supprimez la phrase entière plutôt que de rogner quelques mots. Ce test évalue également les mots directeurs : un mot trop faible pour l'emporter sur le comportement par défaut (_soyez rigoureux_ quand l'agent est déjà à peu près rigoureux) est un no-op, et la solution est un mot plus fort (_relentless_), pas une technique différente.
