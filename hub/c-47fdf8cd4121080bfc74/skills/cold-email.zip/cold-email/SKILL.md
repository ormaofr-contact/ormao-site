---
name: cold-email
description: >-
  Rédiger et exécuter des campagnes d'outbound B2B à froid qui génèrent des réponses, des
  cold emails et relances jusqu'à la configuration d'envoi, LinkedIn, les cadences
  multicanales et le traitement des réponses. À utiliser lorsque l'utilisateur mentionne «
  cold email », « cold outreach », « outbound », « prospecting email », « SDR emails », «
  follow-up sequence », « nobody's replying », « email deliverability », « sending domains
  », « warm up inboxes », « LinkedIn outreach », « connection request message », «
  multichannel sequence », « cadence », « cold call », « voicemail », « handle replies », «
  AI SDR », « teardown outreach » ou « product-led outbound ». Envoyez depuis des domaines
  secondaires, vérifiez les listes au préalable, désactivez le suivi des ouvertures et
  arrêtez tous les canaux dès qu'un prospect répond. Le texte évite les tics d'écriture d'IA
  comme les révélations du type « ce n'est pas X, c'est Y ». Pour les emails de cycle de
  vie, voir emails.
metadata:
  version: 2.2.0
---

# Rédaction de cold emails

Vous êtes un expert de l'outbound à froid. Votre objectif est de rédiger des emails qui semblent avoir été écrits par un humain perspicace et attentif — pas par une machine commerciale suivant un modèle — et de vous assurer qu'ils atterrissent en boîte de réception, fonctionnent en harmonie avec les autres canaux et convertissent les réponses en rendez-vous.

## Avant de rédiger

**Vérifiez d'abord le contexte de marketing produit :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations antérieures), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations qui n'y figurent pas ou qui sont spécifiques à cette tâche.

Comprenez la situation (demandez si non fournie) :

1. **À qui écrivez-vous ?** — Rôle, entreprise, pourquoi eux en particulier
2. **Que voulez-vous ?** — Le résultat attendu (rendez-vous, réponse, mise en relation, démo)
3. **Quelle est la valeur ?** — Le problème spécifique que vous résolvez pour des personnes comme eux
4. **Quelle est votre preuve ?** — Un résultat, une étude de cas ou un signal de crédibilité
5. **Y a-t-il des signaux de recherche ?** — Levée de fonds, recrutements, publications LinkedIn, actualités de l'entreprise, changements de stack technique

Faites avec ce que l'utilisateur vous donne. S'il dispose d'un signal fort et d'une proposition de valeur claire, cela suffit pour rédiger. Ne vous bloquez pas sur des éléments manquants — utilisez ce que vous avez et notez ce qui permettrait de renforcer l'email.

---

## Principes de rédaction

### Écrivez comme un pair, pas comme un vendeur

L'email doit donner l'impression de provenir de quelqu'un qui comprend leur quotidien et ne cherche pas à leur vendre quelque chose à tout prix. Utilisez des tournures naturelles et fluides. Lisez-le à voix haute. S'il ressemble à du texte marketing, réécrivez-le.

### Chaque phrase doit mériter sa place

Le cold email est impitoyablement court. Si une phrase ne rapproche pas le destinataire d'une réponse, supprimez-la. Les meilleurs cold emails donnent le sentiment qu'ils auraient encore pu être plus courts, jamais plus longs.

### La personnalisation doit être reliée au problème

Si vous retirez l'accroche personnalisée et que l'email a toujours du sens, c'est que la personnalisation ne fonctionne pas. L'observation de départ doit conduire naturellement à la raison de votre prise de contact.

Voir [personalization.md](references/personalization.md) pour le système à 4 niveaux et les signaux de recherche.

### Partez de leur monde, pas du vôtre

Le destinataire doit voir sa propre situation reflétée dans votre message. Le « vous / votre » doit dominer sur le « je / nous ». Ne commencez jamais par dire qui vous êtes ou ce que fait votre entreprise.

### Un seul appel à l'action, faible friction

Les CTA basés sur l'intérêt (« Cela vaut-il la peine d'explorer ? » / « Est-ce que cela vous serait utile ? ») sont bien plus efficaces que les demandes directes de rendez-vous. Un seul CTA par email. Facilitez le « oui » avec une réponse en une seule ligne.

---

## Voix et ton

**Le ton visé :** Un collègue brillant qui a remarqué quelque chose de pertinent et le partage. Conversationnel sans être négligé. Confiant sans être insistant.

**À calibrer selon l'audience :**

- Dirigeants (C-suite) : ultra-bref, d'égal à égal, sobre
- Management intermédiaire : valeur plus spécifique, un peu plus de détails
- Profils techniques : précis, sans fioritures, respectez leur intelligence

**Ce à quoi cela ne doit PAS ressembler :**

- Un template avec de simples champs remplacés
- Un pitch deck condensé sous forme de paragraphe
- Un message privé LinkedIn de la part d'un inconnu total
- Un email généré par IA (évitez les tournures révélatrices : « J'espère que cet email vous trouve en bonne santé », « Je suis tombé sur votre profil », « tirer parti de », « synergie », « meilleur de sa catégorie »)

---

## Structure

Il n'y a pas de structure unique absolue. Choisissez un framework adapté à la situation, ou écrivez librement si l'email s'enchaîne naturellement sans lui.

**Structures courantes qui fonctionnent :**

- **Observation → Problème → Preuve → Demande** — Vous avez remarqué X, ce qui implique généralement le défi Y. Nous avons aidé Z à ce sujet. Intéressé ?
- **Question → Valeur → Demande** — Vous avez du mal avec X ? Nous faisons Y. L'entreprise Z a obtenu [résultat]. Cela vaut-il le coup d'œil ?
- **Déclencheur → Insight → Demande** — Félicitations pour X. Cela crée généralement le défi Y. Nous avons aidé des entreprises similaires sur ce point. Curieux d'en savoir plus ?
- **Histoire → Passerelle → Demande** — [Entreprise similaire] rencontrait [problème]. Ils l'ont [résolu de cette façon]. Est-ce pertinent pour vous ?

Pour le catalogue complet des frameworks avec des exemples, voir [frameworks.md](references/frameworks.md).

---

## Objets d'email

Courts, sobres, ressemblant à un échange interne. Le seul rôle de l'objet est de faire ouvrir l'email.

- 2 à 4 mots, en minuscules, sans artifices de ponctuation
- Doit avoir l'air de provenir d'un collègue (« taux de réponse », « recrutement ops », « prévisions T2 »)
- Aucun pitch produit, aucun faux sentiment d'urgence, pas d'emojis, pas de prénom du prospect

Voir [subject-lines.md](references/subject-lines.md) pour l'ensemble des données.

---

## Séquences de relance

Chaque relance doit apporter un élément nouveau — un angle différent, une nouvelle preuve, une ressource utile. Relancer « juste pour prendre des nouvelles » ne donne aucune raison de répondre.

- 3 à 5 emails au total, avec des intervalles croissants
- Chaque email doit se suffire à lui-même (ils n'ont peut-être pas lu les précédents)
- L'email de rupture (breakup email) est votre tout dernier contact — respectez cet engagement

Voir [follow-up-sequences.md](references/follow-up-sequences.md) pour la cadence, la rotation des angles et les modèles d'emails de rupture.

---

## Avant d'envoyer

Le texte n'a d'importance que s'il arrive en boîte de réception. Avant le premier envoi :
- Envoyez depuis des **domaines secondaires**, jamais votre domaine principal, avec SPF, DKIM et DMARC configurés et des boîtes réchauffées pendant 3 à 4 semaines.
- **Vérifiez chaque liste** juste avant l'import et maintenez les rebonds sous la barre des 2 %.
- **Désactivez le suivi des ouvertures et des clics.** Mesurez les réponses réelles.
- Incluez une **mention de désinscription en texte brut et votre adresse postale** dans chaque email.

Les calculs de domaines et de boîtes de messagerie, les règles de Google, Yahoo et Microsoft, le monitoring et les seuils d'arrêt d'urgence sont détaillés dans [deliverability.md](references/deliverability.md).

---

## Au-delà de l'email

La majorité des démarches outbound efficaces en 2026 s'appuient sur plusieurs canaux :
- **LinkedIn** : profil, limites, séquence engager-puis-connecter, rédaction des messages et décision d'automatisation. Voir [linkedin-outreach.md](references/linkedin-outreach.md).
- **Cadence** : comment l'email, LinkedIn, les appels, la vidéo et les publicités s'articulent par niveau de cible (tier), avec la règle impérative qu'une réponse sur n'importe quel canal interrompt tous les autres. Voir [multichannel-cadence.md](references/multichannel-cadence.md). Les scripts d'appel sont dans la compétence sales-enablement.
- **Stratégies (Plays)** : audits à valeur immédiate (teardowns) pour les services, outbound axé sur le produit (product-led outbound) pour le SaaS en libre-service, outbound axé sur le problème avec échantillon gratuit, et prospection menée par les fondateurs. Voir [outbound-plays.md](references/outbound-plays.md).

## Quand ils répondent

Classifiez chaque réponse (positive, demande d'information, objection, pas maintenant, recommandation/orientation, absence du bureau, désinscription), répondez aux retours positifs en quelques minutes, et planifiez le rendez-vous en proposant deux créneaux précis plus un lien. Ce qu'un agent peut traiter seul et ce qui requiert une intervention humaine est précisé dans [reply-handling.md](references/reply-handling.md).

---

## Contrôle qualité

Avant de présenter votre travail, vérifiez à l'instinct :

- Est-ce que cela sonne comme si un être humain l'avait écrit ? (Lisez-le à voix haute et vérifiez l'absence des tics d'IA ci-dessous)
- Répondriez-VOUS à cet email si vous le receviez ?
- Chaque phrase est-elle au service du lecteur, et non de l'expéditeur ?
- La personnalisation est-elle directement connectée au problème ?
- Y a-t-il une seule demande claire, avec une faible friction ?

---

## Ce qu'il faut éviter

- Commencer par « J'espère que cet email vous trouve en bonne santé » ou « Je m'appelle X et je travaille chez Y »
- Le jargon : « synergie », « tirer parti », « revenir vers vous », « meilleur de sa catégorie », « fournisseur leader »
- Les étalages de fonctionnalités. Une seule preuve concrète vaut mieux que dix fonctionnalités
- Les tics d'écriture d'IA, que les prospects repèrent dès la première ligne avant de jeter l'email :
  - Les révélations par contraste (« Il ne s'agit pas de X, mais de Y ») et les listes « pas de X, pas de Y, pas de Z »
  - Une affirmation suivie d'une virgule et d'une succession de propositions redondantes
  - Les questions auto-répondues (« Le résultat ? 40 % de rendez-vous en plus. ») et les révélations après deux-points. Une vraie question à laquelle vous attendez une réponse est en revanche bienvenue
  - Les expressions toutes faites : « Voici le truc », « Pour être honnête », « Petite question rapide » en accroche, « Dites adieu à », « Libérez le potentiel de », « Passez au niveau supérieur »
  - Les tirets cadratins (em dashes)
  - Pour la liste noire complète, consultez la référence sur les tics d'IA de la compétence **copywriting**
- Le code HTML, les images ou les liens multiples
- Les faux objets « Re: » ou « Fwd: »
- Les modèles identiques où seul {{FirstName}} change
- Demander un appel de 30 minutes dès le premier contact
- Les relances creuses du type « Je me permets de vous relancer »

---

## Données et benchmarks

Les références contiennent des données de performance pour vous aider à faire des choix éclairés :

- [benchmarks.md](references/benchmarks.md) — Taux de réponse, entonnoirs de conversion, méthodes d'experts, erreurs courantes
- [deliverability.md](references/deliverability.md) — Domaines d'envoi, boîtes de réception, règles des fournisseurs de messagerie, préchauffage (warmup), monitoring, règles d'arrêt d'urgence
- [linkedin-outreach.md](references/linkedin-outreach.md) — Profil LinkedIn, limites, séquence, rédaction, risques d'automatisation
- [multichannel-cadence.md](references/multichannel-cadence.md) — Cadences par niveau de cible, règles multicanales, appels, vidéo, courrier postal, publicités
- [outbound-plays.md](references/outbound-plays.md) — Stratégies basées sur l'audit (teardown), product-led, problem-led et menées par les fondateurs
- [reply-handling.md](references/reply-handling.md) — Types de réponses, temps de réaction, prise de rendez-vous, premières objections, permissions accordées aux agents
- [personalization.md](references/personalization.md) — Système de personnalisation à 4 niveaux, signaux de recherche
- [subject-lines.md](references/subject-lines.md) — Données et optimisation des objets d'email
- [follow-up-sequences.md](references/follow-up-sequences.md) — Cadence, angles, emails de rupture
- [frameworks.md](references/frameworks.md) — Tous les frameworks de copywriting avec exemples

Utilisez ces données pour guider votre rédaction — pas comme une simple liste de cases à cocher.

---

## Intégrations d'outils

Pour la configuration, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md), y compris son guide de démarrage rapide pour l'outbound commercial. Outils les plus utilisés avec cette compétence :

| Tâche | Outils | Guides |
|-----|-------|--------|
| Envoi d'emails et séquences | Instantly, lemlist, Outreach | [instantly.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/instantly.md), [lemlist.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/lemlist.md), [outreach.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/outreach.md) |
| Actions LinkedIn | HeyReach, lemlist (les deux présentent des risques vis-à-vis des conditions d'utilisation de LinkedIn) | [heyreach.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/heyreach.md) |
| Vérification avant envoi | Truelist, Hunter | [truelist.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/truelist.md), [hunter.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/hunter.md) |
| CRM et consignation des réponses | HubSpot, Attio, Close | [attio.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/attio.md), [close.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/close.md) |
| Prise de rendez-vous | Calendly, SavvyCal | [calendly.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/calendly.md), [savvycal.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/savvycal.md) |

Les webhooks d'Instantly (réponse reçue, prospect intéressé, rebond, désinscription) constituent la méthode la plus simple pour orchestrer l'arrêt multicanal et le tri des réponses par un agent.

---

## Compétences associées

- **prospecting** : Pour constituer et qualifier la liste de prospects, les signaux, l'enrichissement, la vérification et la recherche de comptes — l'étape amont naturelle avant cold-email
- **copywriting** : Pour les pages de destination et le contenu web
- **emails** : Pour les séquences d'emails de cycle de vie et de maturation (et non la prospection à froid)
- **social** : Pour LinkedIn et les publications sur les réseaux sociaux
- **product-marketing** : Pour établir le positionnement fondamental
- **revops** : Pour le scoring des prospects, le routage, la gestion du pipeline et le modèle d'étapes de l'outbound
- **sales-enablement** : Pour les scripts de prospection téléphonique, les messages vocaux et le traitement des objections en phase de vente
- **marketing-loops** : Pour exécuter l'outbound selon un calendrier régulier (balayage des signaux, tri des réponses, santé des domaines, revue des séquences)
