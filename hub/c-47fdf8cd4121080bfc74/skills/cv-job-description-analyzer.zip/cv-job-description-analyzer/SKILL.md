---
name: job-description-analyzer
description: Analyser les offres d'emploi, calculer les scores de correspondance, identifier les écarts et créer une stratégie de candidature
---

# Job Description Analyzer

## Quand utiliser cette compétence

Utilisez cette compétence lorsque l'utilisateur :
- Souhaite analyser une offre d'emploi
- Demande « devrais-je postuler à cette offre ? »
- Veut connaître son pourcentage de correspondance pour un poste
- A besoin d'aide pour comprendre les exigences d'un poste
- Souhaite adapter son CV pour un poste spécifique
- Mentionne : « analyse cette offre », « suis-je qualifié », « score de correspondance », « devrais-je postuler »

Utilisez ceci AVANT d'adapter le CV afin de vous assurer que l'effort en vaut la peine.

## Capacités principales

- Extraire et catégoriser les exigences du poste (indispensables vs appréciées)
- Calculer le score de correspondance entre l'expérience de l'utilisateur et les exigences du poste
- Identifier les lacunes de compétences et les points forts
- Détecter les signaux d'alerte (red flags) dans les offres d'emploi
- Hiérarchiser les expériences à mettre en valeur
- Générer une stratégie d'adaptation du CV
- Créer des arguments clés pour la lettre de motivation
- Évaluer les indicateurs d'adéquation avec la culture d'entreprise

## Le problème stratégique

La plupart des candidats perdent du temps sur :
- Des postes pour lesquels ils sont sous-qualifiés (<60 % de correspondance)
- Des postes pour lesquels ils sont surqualifiés (risque de départ rapide)
- Des postes présentant des signaux d'alerte (forte rotation du personnel, culture toxique)
- Postuler à plus de 50 offres à l'aveugle en espérant que ça morde

Une meilleure approche :
- Postuler à 10-15 offres de manière stratégique
- Cibler les offres avec 70 à 90 % de correspondance
- Personnaliser en profondeur pour chacune
- Taux de réponse plus élevé, moins d'épuisement

## Processus d'analyse

### Étape 1 : Extraire les exigences

Décomposer la fiche de poste en catégories :

**Requis (Indispensable / Must-Have)**
- Exigences en matière de formation
- Années d'expérience
- Compétences techniques spécifiques
- Certifications / licences
- Expérience dans le secteur

**Souhaité (Apprécié / Nice-to-Have)**
- Compétences « bonus »
- Certifications avancées
- Expertise sectorielle / domaine
- Expérience avec des outils spécifiques

**Compétences relationnelles / Culture (Soft Skills)**
- Style de communication
- Environnement de travail
- Structure de l'équipe
- Valeurs de l'entreprise

### Étape 2 : Extraction des mots-clés

Identifier trois types :

**Compétences techniques (Hard Skills)** (capacités techniques)
- Outils : Salesforce, Python, AWS, Excel
- Méthodologies : Agile, Six Sigma, SDLC
- Certifications : PMP, CPA, AWS Certified

**Compétences relationnelles (Soft Skills)** (interpersonnelles)
- Leadership, collaboration, communication
- Résolution de problèmes, esprit critique
- Adaptabilité, prise d'initiative

**Connaissance du secteur / du domaine**
- B2B SaaS, santé, fintech
- Grandes entreprises vs PME
- Connaissances réglementaires (HIPAA, SOX, GDPR)

### Étape 3 : Calculer le score de correspondance

```
MATCH CALCULATION:

Required Skills:
- User has 8 out of 10 required = 80%

Preferred Skills:
- User has 3 out of 5 preferred = 60%

Overall Match:
- Weight required 70%, preferred 30%
- (80% × 0.7) + (60% × 0.3) = 74%

INTERPRETATION:
90-100% = Overqualified (may be flight risk)
75-89% = Excellent fit (apply immediately)
60-74% = Good fit (apply with strong cover letter)
50-59% = Stretch role (apply if passionate)
<50% = Under-qualified (skip unless dream job)
```

### Étape 4 : Analyse des écarts

Pour chaque exigence manquante :
- **Écart critique** : Rédhibitoire (ne pas postuler)
- **Écart majeur** : Significatif mais surmontable (à mentionner dans la lettre de motivation)
- **Écart mineur** : Facile à acquérir (minimiser ou valoriser des compétences connexes)

### Étape 5 : Détection des signaux d'alerte (Red Flags)

Rechercher les signaux d'avertissement :

**Signaux d'alerte liés à la charge de travail :**
- « Polyvalent / porter plusieurs casquettes »
- « Environnement au rythme soutenu »
- « Être immédiatement opérationnel »
- « Autonomie dans des situations ambiguës »

**Signaux d'alerte liés à la culture :**
- « Rockstar / Ninja / Guru »
- « Work hard, play hard »
- « Congés illimités »
- « Comme une famille »

**Signaux d'alerte liés à la rémunération :**
- « Salaire compétitif » (ne donne pas la fourchette)
- « Forte part d'equity / actions » (faible rémunération fixe)
- « Rémunération à la commission » (aucun salaire de base)
- « Selon expérience » sans fourchette indiquée

## Format de sortie du score de correspondance

```markdown
# JOB ANALYSIS REPORT

**Position:** Senior Product Manager
**Company:** TechCorp Inc.
**Location:** San Francisco, CA (Hybrid)
**Salary Range:** $140K-$180K + equity

═══════════════════════════════════════════

## OVERALL MATCH SCORE: 78% ✅

**Recommendation:** STRONG FIT - Apply within 48 hours

**Application Priority:** HIGH
**Estimated Competition:** Medium (Posted 2 days ago)
**Time to Tailor Resume:** 30-45 minutes

═══════════════════════════════════════════

## REQUIREMENTS BREAKDOWN

### Required Skills - 8/10 ✅

✅ 5+ years product management (You have: 6 years)
✅ B2B SaaS experience (You have: 4 years)
✅ Agile/Scrum (You have: 5 years)
✅ Cross-functional leadership (You have: Strong experience)
✅ Data-driven decision making (You have: 3 years analytics)
✅ API products (You have: 2 years)
✅ Roadmap planning (You have: Extensive)
✅ User research (You have: 2 years)
❌ SQL/data analysis (You have: Basic Excel only) ⚠️
❌ Mobile product experience (You don't have) ⚠️

### Preferred Skills - 4/6 ✅

✅ MBA or equivalent (You have: MBA from UC Berkeley)
✅ Developer tools experience (You have: 2 years)
✅ Payment systems (You have: 1 year)
✅ International markets (You have: Worked with EU teams)
❌ E-commerce background (You don't have)
❌ Machine learning products (You don't have)

### Soft Skills - 5/5 ✅

✅ Stakeholder management (Strong mentions in your resume)
✅ Communication (You present regularly)
✅ Strategic thinking (MBA + senior experience)
✅ Influence without authority (You've done this)
✅ Customer empathy (User research experience)

═══════════════════════════════════════════

## STRENGTHS TO EMPHASIZE

**Your Top 3 Selling Points:**

1. **B2B SaaS PM Experience**
   - 4 years in SaaS, exactly what they want
   - Lead with this in resume summary

2. **API Product Background**
   - Your developer tools experience is highly relevant
   - This differentiates you from other candidates

3. **Data-Driven Approach**
   - Your analytics background addresses their need
   - Emphasize metrics and data in every bullet

═══════════════════════════════════════════

## GAPS TO ADDRESS

**Critical Gaps:** None ✅

**Major Gaps:**
⚠️ **SQL/Data Analysis**
- They mention this 5x in job description
- They want PM who can query data independently

**Strategy:**
- Don't avoid this gap
- Address in cover letter: "While my primary analytics work has been in Excel and BI tools, I'm actively learning SQL through DataCamp and can currently write basic queries"
- Emphasize your data-driven mindset and collaboration with data team

**Minor Gaps:**
- Mobile product experience (mentioned 2x)
- Not a dealbreaker - they want "any product," mobile just a plus

**Strategy:**
- Don't mention this gap
- If asked in interview, pivot to "transferable product skills"

═══════════════════════════════════════════

## RESUME CUSTOMIZATION STRATEGY

### Priority 1: Lead with Most Relevant Experience

**Current Resume Order:**
1. Company ABC - General PM work
2. Company XYZ - Your developer tools role
3. Company 123 - Early career

**Recommended Order:**
1. Company XYZ - Developer tools role (MOST RELEVANT)
2. Company ABC - B2B SaaS work
3. Company 123 - Only if space allows

### Priority 2: Keyword Integration

**Add These Exact Phrases:**
- "SQL and data analysis" (mentioned 5x in JD)
- "API product management" (mentioned 4x)
- "Developer-focused products" (mentioned 3x)
- "Stakeholder alignment" (mentioned 3x)

**Where to Add:**
- Professional Summary: Mention "API products" and "data-driven"
- Skills Section: Add "SQL (basic), Data Analysis, API Design"
- Experience: Weave into existing bullets

### Priority 3: Quantify Everything

They mention "metrics" and "KPIs" 7 times total.

**Enhance These Bullets:**

Current: "Led product roadmap"
Better: "Defined product roadmap based on analysis of 50+ customer interviews and usage data from 100K+ users"

Current: "Launched new features"
Better: "Launched 8 features in 12 months, increasing user engagement by 35% and reducing churn by 20%"

═══════════════════════════════════════════

## COVER LETTER TALKING POINTS

### Opening Hook (Choose One):

**Option 1 - Specific Company Knowledge:**
"I noticed TechCorp recently launched your API marketplace - I've spent the last 2 years as PM for a developer tools platform, and I'm excited about the opportunity to bring that experience to your growing API ecosystem."

**Option 2 - Mutual Connection:**
"[Name] on your product team mentioned you're looking for a PM to lead the API product line - my 2 years in developer tools and B2B SaaS background would be a strong fit."

**Option 3 - Problem-Solver:**
"Your JD mentions challenges in stakeholder alignment across technical teams - I've navigated this exact challenge at my current role, aligning engineering, design, and sales teams across 6 concurrent product initiatives."

### Body - Address the Match:
- "Your requirement for B2B SaaS experience: I have 4 years with..." 
- "Your focus on data-driven decisions: In my current role, I..."
- "Your need for API product expertise: At [Company], I..."

### Addressing SQL Gap (Optional):
"While my data analysis has primarily been in Excel and Tableau, I'm expanding my SQL skills and can currently write basic queries. More importantly, I've built strong partnerships with data teams and consistently use data to inform product decisions."

═══════════════════════════════════════════

## RED FLAGS ANALYSIS

### Potential Concerns: ⚠️ MINOR

**Flag 1:** "Fast-paced environment"
- Appears 2x in description
- Interpretation: Likely startup or high-growth
- May mean: Long hours, ambiguity, rapid changes

**Flag 2:** Salary range is wide ($140K-$180K)
- 29% spread
- May indicate: Experience range is flexible, or negotiation room

### Positive Signals: ✅

**Signal 1:** Detailed job description
- Shows company knows what they want
- Well-organized role

**Signal 2:** Mentions specific tools (JIRA, Amplitude)
- Shows operational maturity

**Signal 3:** Hybrid flexibility mentioned
- Modern workplace practices

### Company Research Needed:

Before applying, check:
- Glassdoor reviews (look for patterns in 1-2 star reviews)
- Recent funding/news (layoffs? growth?)
- LinkedIn: Check how long people stay (high turnover?)
- Levels.fyi: Verify salary range is accurate

═══════════════════════════════════════════

## APPLICATION TIMELINE

**✅ Day 1 (Today):**
- Customize resume (30-45 minutes)
- Write cover letter (30 minutes)

**✅ Day 1-2:**
- Submit application
- Connect with 2-3 current employees on LinkedIn
- Research company more deeply

**✅ Week 1:**
- Follow up if no response after 7 days

**📊 Expected Response Time:** 1-2 weeks

**📊 Interview Process (from job posting):**
1. Recruiter screen (30 min)
2. Hiring manager (1 hour)
3. Product case study (take-home)
4. Team interviews (3-4 hours)
5. Executive interview (1 hour)

═══════════════════════════════════════════

## DECISION FACTORS

### Reasons to Apply ✅

1. Strong match (78%) - You meet most requirements
2. Role aligns with career goals
3. Salary range is appropriate for your experience
4. Company stage fits your preferences
5. You have unique relevant experience (developer tools)

### Reasons to Hesitate ⚠️

1. SQL gap is real - prepare to address this
2. "Fast-paced" may mean high pressure
3. Need to research company culture more

### Overall Recommendation:

**APPLY - This is a strong opportunity**

You meet 80% of required skills and 67% of preferred skills. Your developer tools and B2B SaaS experience makes you a differentiated candidate. The SQL gap is addressable with honesty and emphasis on your analytical skills. Apply within 48 hours while posting is fresh.
```

## Guide de classification des exigences

### Identifier « Indispensable » vs « Apprécié »

**Formulations indiquant un caractère OBLIGATOIRE :**
- « Doit avoir... »
- « Requis : X années de... »
- « Vous avez... »
- « Qualifications essentielles »
- Listé sous « Exigences »
- Mentionné 3 fois ou plus dans l'offre

**Formulations indiquant un caractère SOUHAITÉ :**
- « Apprécié... »
- « Un bonus si vous avez... »
- « Qualifications souhaitées / préférées »
- « Idéalement, vous disposez de... »
- « Un plus si... »
- Mentionné seulement 1 ou 2 fois

### Détection des critères rédhibitoires

**Critères absolument rédhibitoires (ne pas postuler) :**
- Licence/titre obligatoire que vous n'avez pas (médical, juridique, CPA)
- Habilitation requise que vous ne pouvez pas obtenir
- Années d'expérience inférieures de plus de 50 % à l'exigence
- Diplôme requis que vous n'avez pas (lorsqu'il est explicitement indiqué comme « requis »)
- Exigence géographique que vous ne pouvez pas respecter

**Critères non rédhibitoires (postuler malgré tout) :**
- Années d'expérience légèrement inférieures (ex. 3 ans alors qu'ils en demandent 5)
- Diplôme « souhaité » que vous n'avez pas
- Outils/compétences appréciés que vous pouvez apprendre
- Expérience sectorielle lorsque vous disposez de compétences transférables

## Liste de contrôle de mise en œuvre

Lors de l'analyse d'une offre :

1. ✅ Extraire toutes les exigences (requises vs souhaitées)
2. ✅ Identifier tous les mots-clés (compétences techniques, relationnelles, termes sectoriels)
3. ✅ Calculer le score de correspondance
4. ✅ Identifier les points forts à valoriser
5. ✅ Identifier les écarts et les stratégies pour y répondre
6. ✅ Détecter les signaux d'alerte
7. ✅ Établir un plan de personnalisation du CV
8. ✅ Générer des arguments clés pour la lettre de motivation
9. ✅ Faire des recherches sur l'entreprise
10. ✅ Fournir une recommandation de candidature et un calendrier

## Cas particuliers

### Offres d'emploi vagues
- Signaler comme un signal d'alerte potentiel
- Extraire les mots-clés possibles
- Recommander de demander des clarifications avant de postuler
- Utiliser les exigences standard du secteur comme référence

### Rôles multiples dans une seule offre
- Identifier le rôle principal vs les « autres tâches »
- Concentrer le score de correspondance sur les responsabilités principales
- Signaler les risques d'élargissement excessif du périmètre (scope creep)

### Candidatures internes (travaille déjà dans l'entreprise)
- Stratégie différente : mettre l'accent sur la connaissance interne
- Souligner les relations inter-équipes
- Faire référence à des initiatives spécifiques de l'entreprise

### Offres republiées
- Peut indiquer : l'embauche précédente n'a pas fonctionné, le poste a évolué, ou la première recherche a échoué
- Vaut la peine de postuler, mais chercher à savoir pourquoi elle a été republiée
- Vérifier si les exigences ont changé par rapport à la publication d'origine
