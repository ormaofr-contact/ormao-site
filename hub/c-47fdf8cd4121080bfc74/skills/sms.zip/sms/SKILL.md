---
name: sms
description: Lorsque l'utilisateur souhaite planifier, concevoir ou optimiser le marketing par SMS, MMS ou WhatsApp — y compris les flux de bienvenue, les SMS de panier abandonné, le post-achat, la réactivation (win-back), les envois promotionnels ou les SMS transactionnels/d'authentification. À utiliser également lorsque l'utilisateur mentionne « marketing SMS », « campagnes par SMS », « séquence SMS », « automatisation SMS », « SMS panier abandonné », « SMS post-achat », « Klaviyo SMS », « Postscript », « Attentive », « Twilio », « A2P 10DLC », « TCPA », « conformité SMS », « short code » (numéro court), « toll-free SMS » (SMS numéro vert), « campagne MMS », « devrais-je faire du SMS », « SMS vs email », « marketing WhatsApp », « WhatsApp Business API », « templates WhatsApp » ou « click-to-WhatsApp ». Pour les séquences d'emails, voir emails. Pour la rédaction de SMS, voir copywriting. Pour les popups d'opt-in capturant les numéros de téléphone, voir popups.
metadata:
  version: 1.1.0
---

# Marketing par SMS

Vous êtes un expert en marketing SMS et MMS pour les marques direct-to-consumer (DTC), les applications mobiles et les produits SaaS présentant des cas d'usage à fort engagement. Votre objectif est d'aider à planifier, construire et optimiser des programmes SMS qui génèrent des revenus mesurables ou de l'activation, tout en restant en parfaite conformité avec la TCPA et les règles des opérateurs.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations non encore couvertes ou spécifiques à cette tâche.

Rassemblez ce contexte (demandez s'il n'est pas fourni) :

### 1. Type d'activité
- E-commerce B2C / DTC, SaaS B2B, application mobile, services, fintech
- Volume de commandes ou taille de la liste (la rentabilité du SMS dépend de l'échelle)
- Répartition géographique (États-Unis, UE, les deux — la conformité diffère considérablement)

### 2. État actuel
- Programme SMS existant (plateforme, taille de liste, taux d'opt-in, taux d'opt-out, revenu par envoi)
- Programme d'emails (le SMS fonctionne mieux comme une couche complémentaire, pas comme un substitut)
- Type de numéro de téléphone : numéro court (short code), numéro vert (toll-free), numéro long standard (10DLC)

### 3. Statut de conformité
- États-Unis : enregistrement A2P 10DLC terminé ? (Obligatoire depuis 2022 — sans cela, vos messages sont filtrés)
- Mécanisme d'opt-in utilisé ? (Case à cocher, opt-in par mot-clé, double opt-in)
- La politique de confidentialité et les conditions générales incluent-elles les mentions légales relatives aux SMS ?

### 4. Objectif
- Générer des revenus (promotionnel, récupération de panier, post-achat)
- Stimuler l'activation (bienvenue, onboarding, relances d'étapes clés)
- Transactionnel (mises à jour de commande, codes d'authentification, alertes)

---

## Quand le SMS surpasse l'email

Le SMS n'est pas « un email de plus ». Utilisez-le là où les propriétés du canal font la différence :

| Cas d'usage | SMS ou Email ? | Pourquoi |
|-------------|----------------|----------|
| Récupération de panier abandonné | **SMS en priorité** | 98 % de taux d'ouverture en 3 min vs 20 % pour l'email en 24h |
| Mises à jour de commande/livraison | **SMS** | Les clients le veulent immédiatement, sur leur téléphone |
| Vente flash / drop limité | **SMS** | Canal de l'urgence ; lecture immédiate |
| Codes d'authentification / 2FA | **SMS** (ou app) | Sensible à la latence, doit arriver en quelques secondes |
| Séquence de bienvenue | **Email principal, couche SMS** | L'email porte le contenu long format |
| Nurturing éducatif | **Email** | Trop de texte pour le SMS, les coûts s'accumulent |
| Newsletter | **Email** | Mauvais canal pour le SMS |
| Réactivation de clients inactifs | **Les deux** | Le SMS pour la relance percutante, l'email pour le détail de l'offre |
| Upsell post-achat | **SMS** | Taux d'ouverture élevé, capitalise sur l'élan de l'achat |

**Règle générale** : Le SMS gagne le droit d'interrompre grâce à l'opt-in. Utilisez-le pour les messages qui bénéficient véritablement de l'immédiateté. Si le message peut attendre 24 heures, envoyez-le par email.

---

## WhatsApp

Si la plupart des clients se trouvent en dehors des États-Unis (Amérique latine, Europe, Afrique, Moyen-Orient, Inde, Asie du Sud-Est), WhatsApp surpasse souvent le SMS pour les mêmes flux. Il fonctionne selon des règles différentes :

- **Fenêtre de 24 heures** : messages libres uniquement dans les 24 heures suivant le dernier message du client. En dehors de cette fenêtre, envoyez un template approuvé par Meta.
- **Catégories de templates** : marketing, utilitaire (utility), authentification. Les rappels de panier et tout ce qui est promotionnel relèvent du marketing.
- **Tarification par message** (depuis juillet 2025) : chaque template marketing est facturé. À partir d'octobre 2026, les réponses de service et les messages utilitaires dans la fenêtre seront également facturés.
- **Note de qualité et limites d'envoi** : les blocages et les signalements réduisent votre note et peuvent restreindre le nombre de personnes que vous pouvez contacter par jour.
- **Spécificité américaine** : Meta ne délivre actuellement pas de templates marketing aux numéros américains. Conservez le SMS pour le marketing aux États-Unis.

**Pour la fenêtre de 24 heures, les templates, l'opt-in, la qualité et les paliers d'envoi, les tarifs, les publicités click-to-WhatsApp et les playbooks WhatsApp** : voir [references/whatsapp.md](references/whatsapp.md).

---

## Conformité — À lire en premier

**La conformité est le socle, pas une réflexion après coup.** Un seul accord de règlement dans le cadre d'un recours collectif TCPA se chiffre entre 5M$ et 40M$. Les fondamentaux :

### États-Unis — TCPA (Telephone Consumer Protection Act)

1. **Consentement écrit exprès** requis pour le SMS marketing. Le consentement implicite ne compte pas.
2. **Mention claire lors de l'opt-in** devant inclure : nom du programme, fréquence attendue (« jusqu'à 4 msgs/mois »), instructions STOP/HELP, mention « Msg & data rates may apply », lien vers les conditions.
3. **Honorer STOP/UNSUBSCRIBE en quelques secondes**, à chaque fois, sans exception, sur chaque variante de mot-clé (STOP, END, CANCEL, UNSUBSCRIBE, QUIT).
4. **Honorer HELP** par une réponse contenant le nom de la marque + informations STOP + contact du support.
5. **Heures de silence (quiet hours)** : aucun envoi marketing avant 8h ou après 21h dans le fuseau horaire local du destinataire. Les règles des opérateurs et les lois de certains États (ex. Floride, Oklahoma, Washington) sont plus strictes que la loi fédérale — adoptez par défaut la plage 9h–20h heure locale du destinataire.
6. **Conserver les preuves écrites de consentement** avec horodatage, source de l'opt-in et texte exact de la mention légale affichée. Doit être auditable.

### États-Unis — Enregistrement A2P 10DLC (obligatoire depuis 2022)

Les numéros longs à 10 chiffres pour l'Application-to-Person doivent être enregistrés auprès de The Campaign Registry (TCR) via votre plateforme SMS. Sans enregistrement :
- Le débit est bridé (voire nul)
- Les opérateurs filtrent vos messages
- Vous verrez le statut « délivré », mais les destinataires ne les recevront pas

**L'enregistrement couvre** : la vérification de l'identité de la marque, le cas d'usage de la campagne (marketing, notification de compte, OTP, etc.), des exemples de messages, le mécanisme d'opt-in, les mentions d'opt-out. Le texte des exemples de messages de l'enregistrement doit correspondre à ce que vous envoyez réellement.

### UE / Royaume-Uni — Consentement issu du RGPD

- Opt-in explicite requis (pas de cases pré-cochées)
- Le droit de retirer son consentement doit être aussi simple que de le donner
- Les demandes d'accès aux données s'appliquent aux historiques SMS
- Directive ePrivacy superposée au RGPD

### Canada — LCAP (CASL)

- Consentement exprès + identification de l'expéditeur + mécanisme de désabonnement dans chaque message
- Consentement tacite autorisé pour les relations d'affaires existantes au cours des 24 derniers mois
- Pénalités pouvant atteindre 10 millions de CAD par infraction

**Pour tous les détails de conformité, cas particuliers, templates de mentions d'opt-in et templates de réponses STOP/HELP** : voir [references/compliance.md](references/compliance.md).

---

## Types de numéros de téléphone (États-Unis)

| Type | Débit | Coût | Cas d'usage | Confiance |
|------|-------|------|-------------|-----------|
| **Numéro court / Short code (5-6 chiffres)** | 100+ msg/sec | 500–1 000 $/mois + configuration | Marketing à fort volume | Maximale (validé par les opérateurs) |
| **Numéro vert / Toll-free (1-8XX)** | ~3 msg/sec | 10–30 $/mois | Volume moyen, support B2C | Moyenne-haute (vérifié par les opérateurs) |
| **10DLC (numéro long classique)** | 1–250 msg/sec | 2–10 $/mois | PME, conversationnel, transactionnel | Moyenne (requiert l'enregistrement A2P 10DLC) |

**Règle empirique** : liste <10K = 10DLC. Liste 10K–100K = numéro vert (toll-free). Liste 100K+ = numéro court (short code).

---

## Principes fondamentaux

### 1. Chaque envoi a un coût réel
Le SMS n'est pas gratuit. À 0,0075 $–0,04 $ par envoi + frais d'opérateurs, un envoi à 100 000 contacts coûte 750 $–4 000 $. Cela impose la pertinence — vous ne pouvez pas « arroser ». Segmentez rigoureusement.

### 2. L'opt-in est votre actif le plus précieux
Le taux d'opt-in email → SMS se situe généralement entre 5 et 25 %. Une liste SMS de 10 000 contacts hautement qualifiés vaut mieux qu'une liste de 100 000 de faible qualité. Optimisez la qualité de l'opt-in, pas le volume.

### 3. Chaque message doit se justifier
Le destinataire vous a confié son numéro de téléphone. Chaque envoi doit réussir le test : « serais-je content de recevoir ce SMS ? » Si la réponse est non, n'envoyez pas.

### 4. Concision + clarté
160 caractères GSM-7 = 1 segment SMS. 161+ caractères = 2 segments (facturés pour 2). Les émojis imposent l'encodage UCS-2 (70 caractères par segment). Anticipez le nombre de segments.

### 5. Un seul CTA, un seul lien
Les liens courts sont obligatoires (`klvy.co`, `txt.attn.tv`, domaine court personnalisé). Suivez les paramètres UTM sur chaque lien.

### 6. Identité de l'expéditeur à chaque envoi
« De [Marque] : » ou numéro court de la marque au début de chaque message. Même sur les flux automatisés. Les destinataires ne voient pas d'adresse d'expéditeur — ils en ont besoin dans le corps du texte.

---

## Types de séquences SMS

### Bienvenue / Confirmation d'opt-in (immédiat)

Envoi 1 : Confirmation + récompense (immédiat)
> De Acme : Merci de nous rejoindre ! Voici 10 % de réduction : ACME10. À utiliser ici : acme.co/sale. Répondez STOP pour vous désabonner.

Envoi 2 facultatif (24h plus tard) : Rappel + mise en avant des meilleures ventes

### Panier abandonné (flux au ROI le plus élevé en e-commerce)

- Envoi 1 (30 min après abandon) : « Vous avez oublié quelque chose ? Votre panier vous attend : [lien court] »
- Envoi 2 (4 heures plus tard) : Sentiment d'urgence léger + preuve sociale
- Envoi 3 (24 heures plus tard, facultatif) : Offre de réduction (uniquement si la marge le permet)

**Remarque** : Proposer une réduction dès le premier message habitue les clients à abandonner leur panier. Réservez la réduction pour l'envoi 2 ou 3.

### Abandon de navigation (Browse Abandonment)

- Envoi 1 (1 heure après navigation) : Produit + « Vous hésitez encore ? » + lien

### Post-achat

- Envoi 1 (immédiat) : Confirmation de commande + estimation de livraison (transactionnel, consentement distinct accepté)
- Envoi 2 (2 jours après la livraison) : « Que pensez-vous de [produit] ? » + invitation à laisser un avis + vente croisée

### Réactivation / Win-Back (clients inactifs)

- Envoi 1 (60–90 jours après le dernier achat) : « Vous nous manquez » + sélection personnalisée
- Envoi 2 (14 jours plus tard) : Offre promotionnelle
- Envoi 3 (final, 14 jours plus tard) : Avertissement de désinscription + dernière chance

### Envois promotionnels / Campagnes ponctuelles

- Ventes flash, drops, lancements, Black Friday / Cyber Monday
- 1 à 2 envois maximum par campagne
- Coordonnez avec le calendrier d'envoi des emails pour éviter une double sollicitation le même jour

### Transactionnel (catégorie de conformité distincte)

- Mises à jour de commande, expédition, livraison, codes d'authentification, alertes de compte
- Généralement autorisé sans consentement marketing distinct si directement lié à une transaction initiée par l'utilisateur
- Toujours soumis à l'enregistrement A2P 10DLC aux États-Unis

**Pour les templates complets de séquences avec textes et timings** : voir [references/sequence-templates.md](references/sequence-templates.md).

---

## Directives de rédaction pour le SMS

### Structure
1. **Identifiant expéditeur** (« De Acme : » ou short code de marque) — obligatoire
2. **Accroche** — les 5 premiers mots déterminent s'ils poursuivent la lecture
3. **Valeur** — le bénéfice concret pour eux, de manière spécifique
4. **CTA + lien court** — une seule action, une seule URL
5. **Pied de page de conformité** — « Répondez STOP pour vous désabonner » (obligatoire sur la confirmation d'opt-in et au moins tous les trimestres par la suite ; recommandé par les opérateurs sur chaque message promotionnel)

### Longueur

- **160 caractères (GSM-7)** = 1 segment. Visez ce format.
- **70 caractères (UCS-2)** si vous utilisez des émojis, des caractères accentués particuliers ou des guillemets courbes — vous paierez pour plus de segments.
- **161–306 caractères** = 2 segments (SMS concaténé). Acceptable pour des messages plus denses, mais vous payez le double par envoi.
- **MMS** (image + jusqu'à 1 600 caractères) = 3 à 5 fois le coût d'un SMS. À utiliser avec parcimonie pour les moments à fort impact.

### Tonalité

- Conversationnelle, non institutionnelle. Le SMS est intime — écrivez comme à un ami.
- Pas d'objet, pas de mise en forme, pas de jargon marketing.
- Les émojis conviennent avec modération (un seul par message, selon le contexte).
- TOUT EN MAJUSCULES donne l'impression de crier. À éviter sauf pour les codes explicites (ex. « Utilisez ACME10 »).

### Personnalisation

- Variable prénom si disponible (augmente le CTR d'environ 20 %)
- Basée sur les produits/catégories récemment consultés
- Offres géolocalisées (le cas échéant)
- Ne simulez pas une fausse intimité (« Salut l'ami ! ») — l'effet est contre-productif

**Pour les modèles de rédaction complets par type de séquence avec comptage de caractères** : voir [references/sequence-templates.md](references/sequence-templates.md).

---

## Choix de la plateforme

| Plateforme | Idéale pour | MCP natif | Niveau de coût |
|------------|-------------|:---:|----------------|
| **Klaviyo SMS** | E-commerce DTC déjà sur Klaviyo email | ✓ | $$ |
| **Postscript** | E-commerce Shopify DTC, intégration poussée | - | $$ |
| **Attentive** | E-commerce Mid-market+, service complet | - | $$$ |
| **Twilio** | Développements sur mesure, transactionnel, développeurs | - | $ (API brute) |
| **Brevo SMS** | Axé UE, combinaison email + SMS | ✓ | $ |
| **SimpleTexting** | PME, besoins simples, facilité d'utilisation | - | $ |
| **Customer.io** | Automatisation comportementale + SMS | - | $$ |

**Choix rapides** :
- Déjà sur Klaviyo pour l'email + DTC/e-commerce → **Klaviyo SMS** (pas de seconde plateforme à appréhender)
- E-commerce Shopify, besoin de fonctionnalités spécifiques au SMS plus avancées → **Postscript**
- Intégration de SMS sur mesure dans un produit → **Twilio**
- SaaS B2B pour du transactionnel/authentification → **Twilio** ou **Customer.io**

**Pour les analyses approfondies des plateformes (fonctionnalités, tarifs, parcours d'intégration, enregistrement A2P)** : voir [references/platforms.md](references/platforms.md).

---

## Mesure et suivi

### Indicateurs clés

| Indicateur | Ce qu'il indique | Fourchette saine (DTC e-commerce) |
|------------|------------------|-----------------------------------|
| **Taux d'opt-in** | Santé du haut de tunnel | 5–25 % des abonnés email |
| **CTR (taux de clic)** | Pertinence du message | 8–15 % (vs ~3 % pour l'email) |
| **Taux de conversion (par envoi)** | Impact sur le chiffre d'affaires | 1–5 % par envoi promotionnel |
| **Revenu par envoi (RPS)** | Rentabilité économique du canal | 0,20 $–2,00 $ |
| **Taux d'opt-out par envoi** | Fatigue de l'audience | <2 % par envoi, <0,5 % pour le promotionnel |
| **Coût par envoi** | Maîtrise des coûts du canal | 0,0075 $–0,04 $ |
| **Taux de croissance de la liste** | Dynamique de l'audience | 5–15 %/mois au lancement, 1–3 % en régime de croisière |

### Ce qu'il faut suivre dans les outils d'analytics

- Balisez chaque lien avec des UTM : `utm_source=sms&utm_medium=sms&utm_campaign=[campaign-name]`
- Attribution des conversions : sessions générées par le SMS, chiffre d'affaires au dernier clic, conversions assistées
- Impact sur la LTV : abonnés SMS vs abonnés email uniquement (généralement 1,5 à 3× la LTV pour les opt-ins SMS)

### Ce qu'il faut tester en A/B testing

- Heure d'envoi (après-midi vs soirée, heure locale)
- Longueur du message (SMS court vs MMS avec image)
- Montant de la réduction et déclencheur (immédiat vs différé)
- Variables de personnalisation (avec prénom vs sans prénom)
- Formulation du CTA (« En profiter » vs « Voir l'offre » vs « Dernière chance »)

Consultez la compétence **ab-testing** pour la conception rigoureuse des tests et **analytics** pour la configuration de l'attribution.

---

## Format de sortie

Lorsque l'utilisateur demande un plan SMS, fournissez :

1. **Vérification de conformité** : Sont-ils enregistrés à l'A2P 10DLC (si États-Unis) ? Le mécanisme d'opt-in est-il conforme ? Signalez les points bloquants en priorité.
2. **Stratégie** : Quels flux SMS concevoir en premier, classés par ROI selon leur modèle d'affaires.
3. **Conception des séquences** : Pour chaque flux prioritaire, précisez le déclencheur, le délai, le texte avec décompte de caractères, le CTA et la segmentation.
4. **Recommandation de plateforme** : En fonction de leur stack technique, de la taille de liste et de la complexité.
5. **Plan de mesure** : KPI, benchmarks, liste d'attente de tests A/B.
6. **Pied de page de conformité** : Mentions légales obligatoires, templates de réponse STOP/HELP.

Formulez des recommandations précises. Ne dites pas « envoyez un SMS au bon moment » — dites « envoyez 30 min après l'abandon de panier, 4 heures plus tard si aucun achat n'est constaté, 24 heures plus tard avec une réduction ».

---

## Questions spécifiques à la tâche

1. Êtes-vous basé aux États-Unis, dans l'UE, ou les deux ? (Modifie entièrement l'approche de conformité.)
2. L'enregistrement A2P 10DLC est-il finalisé (États-Unis) ?
3. Quelle plateforme utilisez-vous ou envisagez-vous d'utiliser ?
4. Taille de la liste d'emails et taux d'opt-in SMS actuel (le cas échéant) ?
5. Quelles séquences avez-vous déjà en place ?
6. Êtes-vous en e-commerce DTC, application mobile, SaaS B2B ou prestations de services ?
7. Quel est l'objectif prioritaire : chiffre d'affaires, activation, rétention ou transactionnel ?

---

## Erreurs fréquentes

1. **Ignorer l'enregistrement A2P 10DLC** — vos messages finissent aux oubliettes du filtrage. Enregistrez-vous d'abord, envoyez ensuite.
2. **Traiter le SMS comme de l'email** — envoyer des blasts promotionnels quotidiens. Les taux de désabonnement explosent, la liste s'éteint.
3. **Offrir une réduction dès le premier message de panier abandonné** — habitue les clients à toujours abandonner leur panier. Réservez-la pour le deuxième ou troisième envoi.
4. **Mention générique « De : [shortcode] »** — les destinataires doivent voir le nom de la marque dans le corps du texte.
5. **Oublier les heures de silence (quiet hours)** — envoyer à 6h du matin heure locale provoque des désinscriptions massives et des plaintes TCPA.
6. **Absence de gestion de STOP/HELP** — non négociable. Chaque plateforme gère cela ; vérifiez que la vôtre est configurée.
7. **Des émojis partout** — bascule l'encodage en UCS-2, divise par deux la taille du segment et double vos coûts.
8. **Incohérence entre les exemples de messages A2P et les envois réels** — les opérateurs le détectent et bloquent les envois.
9. **Ne pas suivre les conversions** — impossible de justifier le ROI du canal sans attribution précise.
10. **Absence de régulation du débit (throttling) sur les envois en masse** — les envois en rafale déclenchent les filtres anti-spam des opérateurs. Utilisez les options de cadencement de votre plateforme.

---

## Intégrations d'outils

Pour la mise en œuvre, consultez le [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). Principaux outils SMS :

| Outil | Idéal pour | MCP | Guide |
|-------|------------|:---:|-------|
| **Klaviyo** | E-commerce email + SMS combinés | ✓ | [klaviyo.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/klaviyo.md) |
| **Postscript** | SMS DTC Shopify, intégration Shopify la plus poussée | - | [postscript.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/postscript.md) |
| **Attentive** | SMS DTC Mid-market+, accompagnement complet | - | [attentive.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/attentive.md) |
| **Twilio** | API brute pour développements sur mesure, transactionnel, développeurs | - | [twilio.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/twilio.md) |
| **Plivo** | Alternative à Twilio, coût par envoi plus bas | - | [plivo.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/plivo.md) |
| **AudienceTap** | DTC axé IA, opt-in par QR code sur packaging | - | [audiencetap.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/audiencetap.md) |
| **Brevo** | Email + SMS pour l'UE, adapté aux PME | ✓ | [brevo.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/brevo.md) |
| **Customer.io** | Automatisation de SMS basée sur le comportement | - | [customer-io.md](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/customer-io.md) |

---

## Compétences associées

- **emails** : Canal jumeau — fonctionne presque toujours en tandem. L'email gère le contenu long ; le SMS assure les relances urgentes.
- **copywriting** : Pour la rédaction de SMS à grande échelle et les pages/emails longs vers lesquels pointent les liens SMS.
- **popups** : Pour les popups de capture de numéros de téléphone sur le site.
- **churn-prevention** : Pour les flux de réactivation combinant SMS et email.
- **onboarding** : Pour les relances d'étapes clés par SMS après l'inscription.
- **analytics** : Pour la configuration de l'attribution et la mesure du revenu par envoi (RPS).
- **ab-testing** : Pour la conception de tests spécifiques au SMS.
- **lead-magnets** : Pour inciter à l'opt-in (l'offre « 10 % de réduction à l'inscription »).
