---
name: prototype
description: Construire un prototype jetable pour répondre à une question de conception. À utiliser lorsque l'utilisateur veut vérifier si un modèle d'état ou une logique tient la route, ou explorer à quoi devrait ressembler une interface utilisateur.
---

# Prototype

Un prototype est **du code jetable qui répond à une question**. La question détermine sa forme.

## Choisir une approche

Identifiez à quelle question vous répondez, en vous basant sur la demande de l'utilisateur, le code environnant, ou en lui posant la question s'il est disponible :

- **« Cette logique / ce modèle d'état semble-t-il cohérent ? »** → [LOGIC.md](LOGIC.md). Créez un unique fichier HTML partageable (boutons en mode libre et scénarios guidés par onglets) qui pousse la machine à états dans des cas difficiles à appréhender sur le papier, et qu'un non-développeur peut manipuler.
- **« À quoi cela devrait-il ressembler ? »** → [UI.md](UI.md). Générez plusieurs variantes d'interface radicalement différentes sur une seule route, commutables via un paramètre de recherche URL et une barre flottante en bas de l'écran.

Les deux approches produisent des artefacts très différents, se tromper rend donc tout le prototype inutile. Si la question est véritablement ambiguë et que l'utilisateur n'est pas joignable, choisissez par défaut l'approche qui correspond le mieux au code environnant (un module backend → logique ; une page ou un composant → interface utilisateur) et mentionnez cette hypothèse en haut du prototype.

## Règles applicables aux deux cas

1. **Jetable dès le premier jour, et clairement identifié comme tel.** Placez le code du prototype à proximité de l'endroit où il sera réellement utilisé (à côté du module ou de la page qu'il prototype) afin que le contexte soit évident, mais nommez-le de manière à ce qu'un lecteur occasionnel voie clairement qu'il s'agit d'un prototype et non de la production. Pour les routes d'interface jetables, respectez la convention de routage déjà en place dans le projet ; n'inventez pas une nouvelle structure de premier niveau.
2. **Trivial à exécuter.** Un prototype d'interface se lance avec une seule commande dans le gestionnaire de tâches du projet : `pnpm <name>`, `python <path>`, `bun <path>`, etc. Une démo de logique est un simple fichier HTML sur lequel l'utilisateur double-clique. Dans les deux cas, aucun effort de réflexion ne doit être requis pour le démarrer.
3. **Aucune persistance par défaut.** L'état réside en mémoire. La persistance est ce que le prototype _vérifie_, et non quelque chose dont il devrait dépendre. Si la question implique explicitement une base de données, utilisez une base de données temporaire ou un fichier local avec un nom explicite du type « PROTOTYPE, wipe me ».
4. **Faites l'impasse sur les finitions.** Pas de tests, pas de gestion des erreurs au-delà de ce qui rend le prototype _exécutable_, pas d'abstractions. L'objectif est d'apprendre rapidement.
5. **Rendez l'état visible.** Après chaque action (logique) ou à chaque changement de variante (UI), affichez ou faites le rendu de l'intégralité de l'état pertinent afin que l'utilisateur puisse voir ce qui a changé.
6. **Conservez-le une fois terminé.** Intégrez toute décision validée dans le code réel, puis conservez le prototype lui-même en tant que **source primaire** : committez-le sur une branche temporaire, en dehors de main, et laissez un lien contextuel vers cette branche dans l'issue d'implémentation. Consignez également la réponse (le verdict et la question tranchée) dans l'issue ou dans un commit. La branche main ne conserve que la décision validée.
