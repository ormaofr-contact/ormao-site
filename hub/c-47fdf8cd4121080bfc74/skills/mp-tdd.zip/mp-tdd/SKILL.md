---
name: tdd
description: Développement piloté par les tests (TDD). À utiliser lorsque l'utilisateur souhaite créer des fonctionnalités ou corriger des bugs en écrivant les tests d'abord, mentionne « red-green-refactor » ou demande des tests d'intégration.
---

# Développement piloté par les tests (TDD)

Le TDD est la boucle rouge → vert (red → green). Cette compétence est la référence permettant à cette boucle de produire des tests qui méritent d'être conservés : ce qu'est un bon test, où placer les tests, les anti-patterns et les règles de la boucle. Chaque section s'applique à chaque cycle : consultez-les avant et pendant la boucle, pas après.

Lors de l'exploration de la base de code, lisez `GLOSSARY.md` (s'il existe) afin que les noms des tests et le vocabulaire des interfaces correspondent au langage métier du projet, et respectez les ADR du domaine sur lequel vous intervenez.

## Ce qu'est un bon test

Les tests vérifient le comportement à travers les interfaces publiques, et non les détails d'implémentation. Le code peut changer entièrement ; les tests ne le devraient pas. Un bon test se lit comme une spécification : « l'utilisateur peut finaliser sa commande avec un panier valide » vous indique exactement quelle fonctionnalité existe, et il résiste aux refactorisations car il ne se soucie pas de la structure interne.

Consultez [tests.md](tests.md) pour des exemples et [mocking.md](mocking.md) pour les directives de mock.

## Jonctions (seams) : où placer les tests

Une **seam** (point de jonction) est la frontière publique sur laquelle vous effectuez les tests : l'interface à travers laquelle vous observez le comportement sans pénétrer dans les détails internes. Les tests résident au niveau des seams, jamais face aux éléments internes.

**Testez uniquement au niveau des seams convenues au préalable.** Avant d'écrire un test, notez les seams à tester et confirmez-les avec l'utilisateur. Aucun test ne doit être écrit sur une seam non confirmée. Vous ne pouvez pas tout tester ; convenir des seams à l'avance permet donc de concentrer l'effort de test sur les chemins critiques et la logique complexe plutôt que sur chaque cas limite.

Demandez : « Quelle est l'interface publique, et quelles seams devrions-nous tester ? » Accompagnez chaque seam proposée d'une brève note d'une ligne sur ce qu'elle couvre et ce qu'elle omet.

Lorsque la forme de cette interface est elle-même remise en question (la profondeur du module, l'emplacement de la seam, ce que l'interface doit exposer), appelez l'outil Skill avec « codebase-design » pour le vocabulaire. C'est la source commune pour les termes module, interface, depth, seam, adapter, leverage et locality, et c'est une référence à consulter, pas une session à exécuter.

## Anti-patterns

- **Couplage à l'implémentation (implementation-coupled)** : mocker des collaborateurs internes, tester des méthodes privées ou vérifier via un canal détourné (interroger la base de données au lieu d'utiliser l'interface). Le signe révélateur : le test échoue lors d'un refactoring alors que le comportement n'a pas changé.
- **Tautologique (tautological)** : l'assertion recalcule la valeur attendue de la même manière que le code (`expect(add(a, b)).toBe(a + b)`, un instantané (snapshot) dérivé manuellement de la même façon, une constante affirmée égale à elle-même), de sorte qu'il réussit par construction et ne peut jamais être en désaccord avec le code. Les valeurs attendues doivent provenir d'une source de vérité indépendante : un littéral valide et connu, un exemple concret résolu, la spécification.
- **Découpage horizontal (horizontal slicing)** : écrire tous les tests d'abord, puis toute l'implémentation. Les tests en bloc vérifient un comportement _imaginé_ : vous testez la _forme_ des choses plutôt que le comportement visible pour l'utilisateur, les tests deviennent insensibles aux changements réels, et vous figez la structure des tests avant de comprendre l'implémentation. Travaillez plutôt en **découpage vertical (vertical slices)** : un test → une implémentation → répéter, chaque test servant de **balle traçante (tracer bullet)** qui s'ajuste selon les enseignements du cycle précédent.

## Règles de la boucle

- **Le rouge avant le vert (Red before green).** Écrivez d'abord le test qui échoue, puis uniquement le code nécessaire pour le faire passer. N'anticipez pas les tests futurs et n'ajoutez pas de fonctionnalités spéculatives.
- **Une tranche à la fois.** Une seam, un test, une implémentation minimale par cycle.
- **Le refactoring ne fait pas partie de la boucle.** Il relève de l'étape de revue (voir la compétence `code-review`), et non du cycle d'implémentation rouge → vert.
