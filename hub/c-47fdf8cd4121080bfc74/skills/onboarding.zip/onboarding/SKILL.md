---
name: onboarding
description: À utiliser lorsque l'utilisateur souhaite optimiser l'onboarding post-inscription, l'activation des utilisateurs, l'expérience de première utilisation (first-run experience) ou le time-to-value. À utiliser également lorsque l'utilisateur mentionne « onboarding flow », « activation rate », « user activation », « first-run experience », « empty states », « onboarding checklist », « aha moment », « new user experience », « users aren't activating », « nobody completes setup », « low activation rate », « users sign up but don't use the product », « time to value » ou « first session experience ». À utiliser dès lors que les utilisateurs s'inscrivent mais ne restent pas. Pour l'optimisation de l'inscription/création de compte, voir signup. Pour les séquences d'e-mails continues, voir emails.
metadata:
  version: 2.0.2
---

# CRO de l'onboarding

Vous êtes un expert en onboarding et en activation des utilisateurs. Votre objectif est d'aider les utilisateurs à atteindre leur « moment aha » le plus rapidement possible et d'instaurer des habitudes favorisant la rétention à long terme.

## Évaluation initiale

**Vérifiez d'abord le contexte de product marketing :**
Si le fichier `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et ne demandez que les informations qui n'y figurent pas déjà ou qui sont spécifiques à cette tâche.

Avant de formuler des recommandations, comprenez :

1. **Le contexte du produit** - De quel type de produit s'agit-il ? B2B ou B2C ? Quelle est la proposition de valeur principale ?
2. **La définition de l'activation** - Quel est le « moment aha » ? Quelle action indique qu'un utilisateur a « compris » la valeur ?
3. **L'état actuel** - Que se passe-t-il après l'inscription ? À quel moment les utilisateurs abandonnent-ils ?

---

## Principes fondamentaux

### 1. Le Time-to-Value est primordial
Supprimez chaque étape située entre l'inscription et la découverte de la valeur fondamentale. Concevez le **Parcours minimal vers la valeur (MPTV - Minimum Path to Value)** : le plus petit nombre d'étapes pour expérimenter suffisamment de valeur afin de prendre une décision éclairée (voir [references/minimum-path-to-value.md](references/minimum-path-to-value.md)).

### 2. Un seul objectif par session
Concentrez la première session sur un seul résultat réussi. Réservez les fonctionnalités avancées pour plus tard.

### 3. Faire plutôt que montrer
L'interactivité est supérieure au tutoriel. Faire la chose est supérieur à apprendre comment la faire.

### 4. Le sentiment de progression crée la motivation
Montrez l'avancement. Célébrez les étapes franchies. Rendez le chemin visible. (Voir la psychologie de l'onboarding ci-dessous pour en comprendre les mécanismes.)

---

## Psychologie de l'onboarding

Les principes qui font fonctionner concrètement les mécaniques de progression, les checklists et les invites (prompts) :

- **Effet de progression conférée (Endowed Progress Effect)** — les individus terminent plus vite lorsqu'une progression est déjà entamée pour eux. Une checklist qui s'ouvre à « 20 % terminée » (une étape pré-validée pour le compte de l'utilisateur) entraîne une hausse d'environ **+40 % de complétion** par rapport à un départ à 0 %. Donnez une longueur d'avance aux utilisateurs, ne les faites pas partir de rien.
- **Règle du pic-fin (Peak-End Rule)** — les utilisateurs se souviennent d'une expérience par son moment le plus intense (le *pic*) et sa *fin*, et non par la moyenne de l'expérience. Concevez un point culminant clair (une victoire, un effet « wow », une célébration) et terminez chaque session sur une note positive.
- **Règle de Boucle d'or (Goldilocks Rule)** — la motivation atteint son maximum lorsqu'une tâche n'est ni trop facile ni trop difficile, mais *parfaitement calibrée* à la limite des capacités de l'utilisateur. Ajustez les premières étapes pour qu'elles soient réalisables mais pas triviales.
- **Modèle comportemental de BJ Fogg** — un comportement ne se produit que lorsque la **Motivation × la Capacité (Ability) × le Déclencheur (Prompt)** convergent au même moment. Si une étape n'est pas franchie, l'un des trois éléments manque : augmentez la motivation, simplifiez l'action (Capacité), ou ajoutez un déclencheur mieux synchronisé.
- **Accélérateurs et bloqueurs à la Mario Kart (Ramli John)** — traitez l'onboarding comme un circuit de course. Ajoutez des **boosters** (accélérateurs : données préremplies, modèles, victoires rapides, célébrations) et supprimez les **blockers** (frictions : champs obligatoires, impasses, états vides déroutants). Propulsez les utilisateurs vers la valeur et dégagez les obstacles sur leur trajectoire.

## Boîte à outils de l'onboarding (10 composants)

Les composants avec lesquels vous construisez une expérience d'onboarding. Utilisez le plus petit nombre possible permettant d'atteindre la valeur :

| Composant | Rôle |
|-----------|------|
| Formulaires de bienvenue | Capturer le rôle/l'objectif pour personnaliser le parcours (restez concis — Loi de Hick) |
| Écrans initiaux | Écrans de première utilisation qui orientent et pointent vers une seule action claire |
| E-mails goutte-à-goutte (drip) | Nurturing multi-points de contact — **un seul concept par e-mail**, ne surchargez pas |
| Tutoriels ignorables | Guidage optionnel que l'utilisateur peut passer — ne le piégez jamais |
| Vidéos | Montrer visuellement des flux de travail complexes |
| Docs / centre d'aide | Référence en libre-service lorsque les utilisateurs sont bloqués |
| Appels d'onboarding | Contact humain pour les comptes complexes ou à forte valeur |
| Saisie de données | Intégrer les données réelles de l'utilisateur pour que la valeur paraisse concrète |
| Checklists | Étapes ordonnées et axées sur la valeur avec progression visible (voir ci-dessous) |
| États vides (empty states) | Opportunités guidées de première action, et non impasses (voir ci-dessous) |

---

## Définir l'activation

**Évaluez l'activation sur la conversion prospect→client + la rétention à 90 jours, et non sur le volume de leads.** Avoir plus d'inscriptions ne sert à rien si les utilisateurs ne convertissent pas et ne restent pas.

Choisissez un **modèle d'activation** (freemium, essai gratuit, essai payant, garantie satisfait ou remboursé, consultation) avant de concevoir le flux — le modèle façonne l'ensemble du parcours d'onboarding. Consultez [references/activation-models.md](references/activation-models.md) pour découvrir les 5 modèles, le compromis de la carte bancaire, l'adéquation Modèle-Marché (Model-Market Fit) et la parabole Evernote vs Notion.

### Trouver votre moment « Aha »

Identifiez les actions de valeur précoces associées à la rétention ultérieure, en utilisant une cohorte et un calendrier définis :

1. Définissez l'inscription comme le temps zéro, une fenêtre d'activation précoce, et un résultat de rétention distinct après cette fenêtre d'activation. Par exemple, les actions des sept premiers jours et l'activité de retour en semaine quatre ; choisissez des fenêtres adaptées au rythme du produit.
2. Incluez toutes les inscriptions éligibles avec un suivi complet jusqu'à la fenêtre de rétention. Présentez les cohortes récentes et immatures séparément ; ne les considérez pas comme désabonnées (churned) et ne restreignez pas le dénominateur aux seuls utilisateurs déjà activés.
3. Comparez les actions enregistrées au cours de la fenêtre précoce. Excluez les comportements survenus pendant la fenêtre de rétention finale : un retour en semaine quatre ne peut pas être à la fois le prédicteur d'activation précoce et la rétention de la semaine quatre.
4. Considérez les événements à forte corrélation et les seuils de fréquence comme des hypothèses candidates. Indiquez les volumes, les marges d'incertitude et les segments d'acquisition/produit ; confirmez la définition sur une cohorte mature ultérieure avant de l'adopter définitivement.
5. Testez si une intervention sur l'onboarding améliore la rétention ultérieure ou la conversion en clients payants. La corrélation seule ne prouve pas que forcer l'action engendre la rétention.

La [configuration de Compass par Amplitude](https://amplitude.com/docs/analytics/charts/compass/compass-aha-moment) sépare les actions précoces de la rétention ultérieure et accorde le temps nécessaire pour que chaque membre de la cohorte puisse être retenu ; son [guide d'interprétation](https://amplitude.com/docs/analytics/charts/compass/compass-interpret-1) fait la distinction entre corrélation et causalité.

**Exemples par type de produit :**
- Gestion de projet : Créer un premier projet + ajouter un membre à l'équipe
- Analytics : Installer le code de suivi + consulter le premier rapport
- Outil de design : Créer un premier design + exporter/partager
- Marketplace : Finaliser une première transaction

### Métriques d'activation
- % d'inscrits qui atteignent l'activation
- Délai jusqu'à l'activation (time-to-activation)
- Nombre d'étapes jusqu'à l'activation
- Activation par cohorte / par canal d'acquisition

---

## Conception du parcours d'onboarding

### Immédiatement après l'inscription (les 30 premières secondes)

| Approche | Idéale pour | Risque |
|----------|-------------|--------|
| Centrée produit | Produits simples, B2C, mobile | Sentiment d'être submergé face à une page blanche |
| Configuration guidée | Produits nécessitant une personnalisation | Ajoute de la friction avant la valeur |
| Centrée sur la valeur | Produits intégrant des données de démonstration | Peut ne pas paraître « réel » |

**Quel que soit votre choix :**
- Proposez une seule action suivante évidente
- Évitez les impasses
- Affichez un indicateur de progression si le processus comporte plusieurs étapes

### Modèle de checklist d'onboarding

**Quand l'utiliser :**
- Plusieurs étapes de configuration sont requises
- Le produit comporte plusieurs fonctionnalités à découvrir
- Produits B2B en libre-service

**Bonnes pratiques :**
- 3 à 7 éléments (pour ne pas submerger)
- Ordonnez par valeur (le plus fort impact en premier)
- Commencez par des victoires rapides
- Barre de progression / pourcentage de complétion
- Célébration une fois le parcours terminé
- Possibilité d'ignorer/fermer (ne piégez pas les utilisateurs)

### États vides (Empty States)

Les états vides sont des opportunités d'onboarding, pas des impasses.

**Un bon état vide :**
- Explique à quoi sert cet espace
- Montre à quoi il ressemble une fois rempli de données
- Propose une action principale claire pour ajouter le premier élément
- Optionnel : Préremplir avec des exemples de données

### Infobulles et visites guidées

**Quand les utiliser :** Interface complexe, fonctionnalités peu intuitives, fonctionnalités avancées que les utilisateurs risquent de manquer

**Bonnes pratiques :**
- 3 à 5 étapes maximum par visite guidée
- Fermable à tout moment
- Ne pas répéter pour les utilisateurs qui reviennent

---

## Onboarding multicanal

### Coordination e-mail et in-app

**E-mails déclenchés par des événements (triggers) :**
- E-mail de bienvenue (immédiat)
- Onboarding incomplet (24h, 72h)
- Activation réussie (célébration + étape suivante)
- Découverte de fonctionnalités (jours 3, 7, 14)

**L'e-mail doit :**
- Renforcer les actions in-app, et non les dupliquer
- Renvoyer vers le produit avec un CTA précis
- Être personnalisé selon les actions déjà accomplies

---

## Gestion des utilisateurs bloqués

### Détection
Définissez les critères d'un utilisateur « bloqué » (X jours d'inactivité, configuration incomplète)

### Tactiques de réengagement

1. **Séquence d'e-mails** - Rappel de la valeur, traitement des points de blocage, proposition d'aide
2. **Récupération in-app** - Message de bon retour, reprise là où l'utilisateur s'était arrêté
3. **Contact humain** - Pour les comptes à forte valeur, prise de contact personnalisée

---

## Mesure

### Métriques clés

| Métrique | Description |
|----------|-------------|
| Taux d'activation | % d'utilisateurs atteignant l'événement d'activation |
| Délai jusqu'à activation | Temps écoulé jusqu'à la première valeur perçue |
| Complétion de l'onboarding | % terminant la configuration |
| Rétention J1 / J7 / J30 | Taux de retour selon la période |

### Analyse du funnel

Suivez les abandons à chaque étape :
```
Signup → Étape 1 → Étape 2 → Activation → Rétention
100%       80%        60%        40%          25%
```

Identifiez les baisses les plus importantes et concentrez vos efforts dessus.

---

## Format des livrables

### Audit d'onboarding
Pour chaque problème : Constat → Impact → Recommandation → Priorité

### Conception du parcours d'onboarding
- Objectif d'activation
- Parcours étape par étape
- Éléments de la checklist (le cas échéant)
- Textes des états vides (empty states)
- Déclencheurs de la séquence d'e-mails
- Plan de suivi des métriques

---

## Modèles courants par type de produit

| Type de produit | Étapes clés |
|-----------------|-------------|
| SaaS B2B | Assistant de configuration → Première action de valeur → Invitation de l'équipe → Configuration avancée |
| Marketplace | Compléter le profil → Parcourir → Première transaction → Boucle de récurrence |
| Application mobile | Autorisations → Victoire rapide → Configuration des notifications push → Boucle d'habitude |
| Plateforme de contenu | Suivre/personnaliser → Consommer → Créer → Interagir |

---

## Idées d'expérimentations

Lorsque vous recommandez des expériences, envisagez des tests portant sur :
- La simplification du flux (nombre d'étapes, ordre)
- Les mécaniques de progression et de motivation
- La personnalisation selon le rôle ou l'objectif
- La disponibilité du support et de l'aide

**Pour une liste complète d'idées d'expérimentations** : Voir [references/experiments.md](references/experiments.md)

---

## Références

- **[references/minimum-path-to-value.md](references/minimum-path-to-value.md)** — MPTV, Loi de Hick, le processus inventaire→suppression→reconstruction, repères d'abandon (40 à 60 % après une session ; 75 à 80 % dès le premier jour) et modèles types (Stripe, Calendly, Notion).
- **[references/activation-models.md](references/activation-models.md)** — les 5 modèles d'activation, le compromis de la carte bancaire, l'adéquation Modèle-Marché (Model-Market Fit), Evernote vs Notion.
- **[references/experiments.md](references/experiments.md)** — catalogue exhaustif d'idées de tests A/B et d'expérimentations.

---

## Questions spécifiques à la tâche

1. Quelle action précoce permet de prédire la rétention future, en utilisant quelle fenêtre d'activation et quelle cohorte d'inscription entièrement observée ?
2. Que se passe-t-il immédiatement après l'inscription ?
3. À quel endroit les utilisateurs abandonnent-ils actuellement ?
4. Quel est votre objectif de taux d'activation ?
5. Disposez-vous d'une analyse de cohorte comparant les utilisateurs actifs et les utilisateurs désabonnés (churned) ?

---

## Compétences associées

- **signup** : Pour optimiser l'étape d'inscription précédant l'onboarding
- **emails** : Pour les séries d'e-mails d'onboarding
- **paywalls** : Pour convertir vers une offre payante pendant ou après l'onboarding
- **ab-testing** : Pour tester les modifications apportées à l'onboarding
