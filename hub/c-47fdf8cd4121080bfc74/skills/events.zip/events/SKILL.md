---
name: events
description: >-
  Quand l'utilisateur souhaite planifier, animer, sponsoriser, intervenir ou générer du
  pipeline à partir d'événements — webinaires, conférences, salons professionnels, meetups,
  dîners, ateliers, sommets virtuels ou conférences utilisateurs. À utiliser également
  lorsque l'utilisateur mentionne 'marketing événementiel', 'field marketing', 'organiser un
  webinaire', 'entonnoir de webinaire', 'taux de présence', 'devrions-nous sponsoriser',
  'sponsoriser une conférence', 'stand de salon professionnel', 'stratégie de stand', 'ROI
  événementiel', 'scans de badges', 'suivi événementiel', 'créneau de prise de parole',
  'CFP', 'conférence', 'organiser un dîner', 'conférence utilisateurs' ou 'sommet virtuel'.
  Couvre les quatre rôles : organisateur, sponsor/exposant, intervenant et participant. Pour
  les moments de lancement de produit, voir launch. Pour le volet partenariats des
  webinaires conjoints, voir co-marketing. Pour les apparitions dans des podcasts, voir
  public-relations.
metadata:
  version: 1.0.0
---

# Marketing événementiel

Vous êtes un expert du marketing événementiel — utilisant les webinaires, conférences, dîners et prises de parole pour créer du pipeline, de l'autorité et du contenu à valeur cumulative. Votre mission est de faire en sorte que les événements produisent des résultats commerciaux mesurables, et pas seulement de l'affluence.

## Avant de commencer

**Vérifiez d'abord le contexte de product marketing :**
Si `.agents/product-marketing.md` existe (ou `.claude/product-marketing.md`, ou l'ancien nom de fichier `product-marketing-context.md` dans les configurations plus anciennes), lisez-le avant de poser des questions. Utilisez ce contexte et demandez uniquement les informations non traitées ou spécifiques à cette tâche.

Ensuite, clarifiez en un seul message :

1. **Quel rôle ?** Organiser votre propre événement, sponsoriser/exposer chez un tiers, intervenir ou participer ?
2. **Quel résultat visé ?** Pipeline/rendez-vous, autorité/marque, communauté ou production de contenu ? (Choisissez un objectif principal — les événements qui cherchent à tout faire ne mesurent rien.)
3. **Qui doit être présent dans la salle ?** Le segment ICP cible, et combien de personnes correspondantes participent approximativement à cet événement.
4. **Budget et équipe** — le budget financier et les personnes réellement disponibles pour gérer l'événement.

## Choisissez votre rôle

| Vous êtes… | Approche clé | Référence détaillée |
|---|---|---|
| **Organisateur** | Maîtriser l'audience de bout en bout — webinaire, atelier, dîner, meetup, sommet, conférence utilisateurs | Ce fichier + [webinar-funnel.md](references/webinar-funnel.md) pour le format phare |
| **Sponsor / exposant** | Acheter l'accès à l'audience d'un tiers — évaluer, négocier, animer l'espace, assurer le suivi | [sponsorship-roi.md](references/sponsorship-roi.md) |
| **Intervenant** | Échanger de l'expertise contre du temps de scène — être programmé, concevoir l'intervention, capitaliser sur l'enregistrement | [speaking.md](references/speaking.md) |
| **Participant** | Pas de stand, pas de scène — décrocher des rendez-vous malgré tout | Section ci-dessous |

Les rôles mixtes sont courants (sponsoriser + intervenir, participer + organiser un dîner). Planifiez l'approche de chaque rôle séparément ; ils partagent le même système de suivi.

## Dans quels événements investir (priorité au portefeuille)

Avant les rôles et les tactiques : les événements représentent le canal le plus coûteux, le plus risqué et le plus difficile à mesurer — le levier réside dans la **sélection**, pas dans l'exécution. Ne condamnez jamais les "événements" après une mauvaise conférence ; chaque événement forme son propre écosystème (juger l'ensemble des événements sur une seule conférence revient à juger tout le paid media sur un seul test Google Ads). Le framework complet, les trois types d'événements et les benchmarks de coûts se trouvent dans [event-portfolio-strategy.md](references/event-portfolio-strategy.md).

- **Le présentiel est-il vraiment nécessaire ?** Son coût se justifie principalement pour les cycles de vente à fort niveau de confiance et ACV élevé : contrats grands comptes/multi-décideurs, acheteurs régulés (santé/finance/secteur public), personnalisation poussée, secteurs conservateurs et cycles de plus de 6 mois. Si votre ICP n'y est pas, investissez d'abord sur le digital.
- **Le 80/20 de la sélection.** Une poignée d'événements génère la grande majorité du pipeline événementiel. Identifiez-les, concentrez vos efforts dessus (créneaux de prise de parole, événements parallèles, équipes renforcées, meilleur emplacement) et éliminez le reste.
- **Plus grand ne veut pas dire meilleur.** Les méga-conférences entraînent plus de bruit, des coûts plus élevés et une dilution de l'audience (étudiants, presse, prestataires, curieux). Les événements de niche ou régionaux (50 à 200 participants) apportent souvent plus de leads qualifiés par euro investi.
- **Trois types, trois profils de risque :** **Propriétaire** (contrôle maximal / risque maximal — roadshows, sommets, conférences utilisateurs), **Salons professionnels** (l'arène d'un tiers — 120 jours de préparation surpassent les 4 jours sur place), **Communautaire** (intérêts composés — petits rassemblements réguliers qui en suscitent d'autres, évalués par le "test du samedi").

## L'arc universel : 20 % d'événement, 80 % d'avant et d'après

L'événement en lui-même est la plus petite composante du marketing événementiel. Chaque format obéit au même arc, et la plupart des échecs sont des ruptures d'arc, pas des échecs d'événement :

**Avant (là où le pipeline se crée réellement)**
- Construisez la liste cible : qui participe et correspond à votre ICP ? (Listes de participants, listes d'intervenants, publications "qui y va", participants des éditions passées.)
- **Réservez des rendez-vous avant votre arrivée.** Un rendez-vous confirmé deux semaines à l'avance vaut dix rencontres improvisées et incertaines dans un couloir. Angle de prise de contact : précis, sans friction, limité dans le temps ("15 min au bar à café mardi").
- Annoncez votre présence là où votre audience se trouve déjà (liste e-mail, réseaux sociaux, communautés) avec une bonne raison de venir vous voir — pas juste "retrouvez-nous au stand 402", mais ce qu'ils y gagnent.

**Pendant**
- Optimisez pour les *conversations qualifiées*, pas pour le volume de contacts bruts. Un véritable échange avec un acheteur ICP surpasse cinquante scans de badges.
- Capturez le contexte, pas seulement les coordonnées : après chaque échange, notez ce que la personne a dit, ses priorités actuelles et la prochaine étape convenue. Le message de suivi s'écrit de lui-même grâce à ces éléments ; sans eux, le suivi reste générique et sans effet.
- Produisez du contenu sur place (voir l'Arc de contenu ci-dessous) — l'événement est un studio d'enregistrement dont vous avez déjà réglé la facture.

**Après (là où le pipeline se gagne ou se perd)**
- **La fenêtre des 24–48 heures.** Faites le suivi tant que l'échange est encore frais dans les esprits, en faisant référence à ce qui a été réellement dit. Chaque jour de retard divise approximativement par deux les taux de réponse (tendance générale, pas une règle absolue — mais la déperdition est rapide et bien réelle).
- Segmentez le suivi : les conversations chaudes reçoivent un message personnalisé + une prochaine étape concrète ; les contacts tièdes reçoivent une ressource pertinente liée à leur problème évoqué ; les scans sans conversation réelle reçoivent un point de contact très léger ou rien du tout — ne dégradez pas la réputation de votre domaine pour des personnes qui ne se souviennent pas de vous.
- Transmettez aux outils : CRM avec tag de source événementielle (→ **revops**), séquences de nurturing pour les projets différés (→ **emails**).

## Organiser : choisir le format adapté à l'objectif

| Format | Idéal pour | Effort | Remarques |
|---|---|---|---|
| **Webinaire** | Génération de leads + éducation à grande échelle | Faible à moyen | Le format phare et réutilisable — entonnoir complet dans [webinar-funnel.md](references/webinar-funnel.md) |
| **Atelier** | Leads qualifiés par le produit (PQL), activation | Moyen | La pratique surpasse la présentation magistrale pour la conversion ; format plus restreint et approfondi qu'un webinaire |
| **Dîner / rassemblement restreint** | Relations de niveau exécutif, comptes ABM | Moyen | 8 à 14 places, pas de pitch commercial, sélection soignée des invités — le format au meilleur ratio rendez-vous/coût en B2B |
| **Série de meetups** | Communauté locale, présence récurrente | Moyen | La régularité prime sur la qualité de production ; déléguez progressivement l'animation à des membres de la communauté (→ **community-marketing**) |
| **Sommet virtuel** | Développement de base d'inscrits via les audiences de partenaires | Élevé | Intervenants multiples = diffusion intégrée ; chaque intervenant assure la promotion (→ **co-marketing** pour la mécanique partenariale) |
| **Conférence utilisateurs** | Rétention, expansion, autorité de catégorie | Très élevé | À ne pas tenter avant d'avoir une communauté prête à venir sans qu'on doive la supplier |

Deux règles d'organisation priment sur le choix du format :

- **Le sujet détermine le ciblage.** "État des lieux de [votre catégorie] en 2026" attire votre ICP ; "Tout savoir sur [votre produit]" n'attire que les clients existants. Choisissez des thèmes auxquels votre acheteur assisterait même s'il n'achetait jamais chez vous.
- **La récurrence bat le coup unique.** Un webinaire mensuel ou un dîner trimestriel crée un effet cumulatif — l'audience grandit, le savoir-faire promotionnel s'affine et la bibliothèque de contenus s'enrichit. Un événement ponctuel et isolé retombe aussitôt.

## Participer (sans stand, sans scène)

L'approche à budget zéro, qui offre souvent le meilleur ROI de l'événement :

1. **Liste cible d'abord** — 15 à 30 personnes précises à rencontrer, identifiées à partir de la liste des participants/intervenants et des échanges sur les réseaux sociaux.
2. **Réservation en amont** — prise de contact 1 à 3 semaines avant ; la demande porte sur 15 minutes, calées sur un créneau et un lieu précis.
3. **L'événement satellite** — organisez un dîner ou un petit-déjeuner en marge de la conférence pour 8 à 12 comptes cibles. Vous obtenez le statut d'hôte sans payer le tarif sponsor ; cela génère souvent plus de résultats qu'un stand, pour un dixième du prix (voir [sponsorship-roi.md](references/sponsorship-roi.md)).
4. **Ciblage stratégique des sessions** — assistez aux présentations de vos cibles, posez une question pertinente en séance et rebondissez dessus lors du suivi.
5. Même rigueur de suivi sous 24–48 h que pour n'importe quel autre rôle.

## L'arc de contenu : chaque événement est un moteur de contenu

Les événements produisent vos contenus à plus forte preuve sociale — capturez-les de manière délibérée :

- **Enregistrez tout ce que vous avez l'autorisation d'enregistrer.** Présentations, webinaires, tables rondes. L'enregistrement constitue l'actif durable ; l'audience en direct n'est que son premier spectateur.
- **Les transcriptions se valorisent dans les réponses d'IA.** Les enregistrements publiés et les notes de synthèse sont indexés et cités par les assistants IA — même logique que les apparitions en podcast (→ préparation aux podcasts dans **public-relations**) et la couche textuelle YouTube (→ **ai-seo**). Prononcez clairement les phrases à forte valeur de citation : le nom de votre entreprise accolé à votre catégorie, les chiffres dits à voix haute.
- Découpez l'enregistrement : extraits courts (→ **video**), un article de synthèse par session (→ **content-strategy**), citations marquantes pour les réseaux sociaux (→ **social**), éléments de preuve pour l'équipe commerciale (→ **sales-enablement**).
- Prenez des photos et recueillez des preuves sociales : les témoignages captés sur un événement sont les plus spontanés que vous puissiez obtenir.

## Mesure : du pipeline, pas des applaudissements

| Niveau de métrique | Exemples | Verdict |
|---|---|---|
| **Vanité** | Inscriptions, scans de badges, passage au stand, impressions | À suivre, mais ne jamais optimiser pour, ni présenter comme un succès |
| **Réel** | Conversations qualifiées, rendez-vous confirmés, opportunités créées, pipeline influencé | Le véritable tableau des scores |
| **Décisif** | Coût par rendez-vous qualifié, coût par opportunité, CA conclu influencé | Ce qui détermine si l'on renouvelle l'opération |

- Comparez le coût par rendez-vous qualifié à celui de vos autres canaux (publicité payante, prospection sortante) — c'est le calcul d'arbitrage (go/no-go), détaillé dans [sponsorship-roi.md](references/sponsorship-roi.md).
- Les événements sont par nature multi-points de contact : utilisez le taggage de source + l'attribution autodéclarée ("vous nous avez connus via X") ainsi que des fenêtres d'influence, sans jamais attribuer le crédit au dernier clic à un contrat que l'événement a simplement effleuré (→ **attribution**).
- Évaluez un programme événementiel récurrent sur une tendance de 2 à 3 éditions, jamais sur une seule — la première occurrence d'un format sous-performe systématiquement par rapport à son rythme de croisière.

## Erreurs fréquentes

- **Sponsoriser pour la "notoriété de marque" sans objectif de rendez-vous.** Si personne n'a d'objectif chiffré de rendez-vous, le stand n'est qu'un élément de décor.
- **Le gouffre du suivi.** Des leads sont collectés, puis le premier contact n'intervient que deux semaines plus tard via une séquence impersonnelle. L'événement était réussi ; le suivi l'a anéanti.
- **Optimiser le taux de présence après avoir choisi un sujet dont personne ne veut.** Aucune séquence de relance ne compensera une demande initiale inexistante — retravaillez d'abord le sujet et la promesse.
- **Raisonner au coup par coup.** Prévoyez le budget pour la troisième édition avant même de lancer la première.
- **Réaliser l'événement en oubliant d'enregistrer.** Tout l'effort de production est consenti, mais aucun actif durable n'est créé.
- **Considérer les scans de badges comme des leads.** Un scan correspond simplement à une personne qui marchait lentement. Qualifiez le contact avant de l'intégrer au pipeline.
- **Condamner les "événements" après une mauvaise conférence.** Chaque événement forme son propre écosystème — évaluez-les individuellement plutôt que comme un canal uniforme.
- **Viser systématiquement les plus grandes conférences.** La taille est corrélée au niveau sonore et à la dilution du public, pas au ROI — les événements de niche et régionaux l'emportent souvent sur le coût par rendez-vous qualifié.

## Compétences associées

- **launch** — l'événement sert de tremplin de lancement (annonce, Product Hunt, mise en ligne)
- **co-marketing** — webinaires conjoints et sommets avec partenaires : la mécanique partenariale y est traitée, l'exécution événementielle l'est ici
- **community-marketing** — programmes communautaires continus ; les événements peuvent les amorcer ou les alimenter
- **public-relations** — interventions en podcast et relations presse sur les événements
- **lead-magnets** — replays accessibles sur inscription et contenus événementiels transformés en lead magnets
- **emails** / **sms** — les séquences concrètes de rappel et de suivi
- **cold-email** — prospection en amont pour caler des rendez-vous
- **revops** — routage, scoring et taggage de source des leads issus d'événements
- **attribution** — mesure rigoureuse et honnête de l'influence multi-touch des événements
